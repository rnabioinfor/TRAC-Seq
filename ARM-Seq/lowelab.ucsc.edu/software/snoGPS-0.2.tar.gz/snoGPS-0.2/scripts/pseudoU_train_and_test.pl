#!/usr/local/bin/perl

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits;
use common;
use newtrain qw(&trainSnos);

use vars qw(
	%option
	   );


#########
# usage #
#########
my $usage =<<END_OF_USAGE;

usage: pseudoU_train_and_test.pl [options] outputfilename
Note outputfilename is required, as is scoretable-location-filename
for option r.
options:                                                   [default]
  -h  print this help message
  -o  organism choices: Afulg Pfuri Pabyssi Phori Mjann Scerev Susolf Sutokod Hsp Pae [required]
  -r  train & test & specify location for output scoretable  [train on all snos only] 
  -j  jack-knife testing mode                         [train on all snos only] 
  -k  jack-knife test single sno ( "\$subdir/\$sno" - eg 'yeast/S_cerevisiae/fa/snR003')
  -t  test only mode
  -i  specify custom site-file during training [for Scerev: 'train_and_test.yeast.v4.sites']
  -I  specify custom site-file (**only for use with 'test-only mode'** ) [organism dependent, for Scerev: 'train_and_test.yeast.v4.sites'] (opt_i or opt_I REQUIRED)
  -s  specify custom starting scoretable    [REQUIRED, for Scerev: 'haca2stemv7.tables'] 
  -d  specify custom descriptor file        [REQUIRED, for Scerev:'haca2stemv4a.desc'] 
  -G  specify custom target directory        [default 'targets'] 
  -T  specify option-string to pass to newtrain.pl    [''] NOT CURRENTLY IMPLEMENTED
  -a specify training data file [REQUIRED, for Scerev: 'newtrain.yeast.v2.data'] 
 
END_OF_USAGE

###########################
# command line processing #
###########################
getopts('thjk:r:s:d:T:i:I:D:o:G:a:', \%option);
if ($option{h}) {print $usage; exit;};
if ($option{I} && !$option{t}) {print $usage; exit;};
die("***training data file required***\n\n$usage\n") unless $option{a} ;
unless (@ARGV) { die("$usage\n");}
my $outputfilename = $ARGV[0];
my $outputscoretable;
my $test_sno;
my $data_initialization;
my ($sites, $all_sites, $unique_sites);
my $organism = $option{o} || die("***organism type required***\n\n$usage\n");
my $descDir = $ENV{DESC} ? $ENV{DESC} : "./desc";  # changed 08/13/2004
my $descriptor_file = $option{d} || die("***descriptor file required***\n\n$usage\n");
$descriptor_file = "$descDir/$descriptor_file";
my $initial_scoretable = $option{'s'} || die("***initial scoretable required***\n\n$usage\n");
my $scoreTableDir = $ENV{SCORETABLES} ? $ENV{SCORETABLES} : "./scoretables/"; # changed 08/13/2004
$initial_scoretable = "$scoreTableDir/$initial_scoretable";
die("***site file required***\n\n$usage\n") unless (  $option{i} || ($option{I} && $option{t}));
my $targetdir = $option{G} || "targets";
my $datadir = $ENV{DATA} ? $ENV{DATA} : "./data" ; # changed 08/13/2004
my $DEBUG =1;

if ($option{r})  { $outputscoretable = $option{r};}
if ($option{k})  { $test_sno = $option{k};}
if ($option{T}) {print "Sorry option_T not yet implemented\n"; exit;};
my $site_file = $option{i} || $option{I};
$site_file = "$datadir/trainingData/$site_file";
open(DATAFILE,"$site_file") or die("No can open site file $site_file!\n");
{ local $/ ;  #slurp in file
  $data_initialization = <DATAFILE>;
}
eval $data_initialization;
if ($@) {die("Data initialization of data file $site_file failed with error:\n $@");}
close(DATAFILE);
# $/ = "\n"; # back to line-at-a-time mode
$sites = $unique_sites; # hard code for the moment
#$sites = $all_sites; # hard code for the moment
if ($option{j}) {
    print STDERR  "Beginning jack-knife testing \n";
    &jack_knife($outputfilename, $initial_scoretable, %option);
    print STDERR  "Finishing jack-knife testing \n";
    exit;
} elsif ($option{k}) {
    print STDERR  "Beginning single jack-knife testing of $test_sno \n";
    &jack_knife_single($outputfilename, $initial_scoretable,$test_sno, %option );
    print STDERR  "Finishing single jack-knife testing of $test_sno \n";
    exit;
} elsif ($option{r}) {
    print STDERR  "Beginning training & testing \n";
    &train_on_all_seqs_and_test($outputfilename, $initial_scoretable, $outputscoretable, %option);
    print STDERR  "Finishing training & testing. \n";
    exit;
} elsif ($option{t}) {
    print STDERR  "Beginning testing-only run\n";
    my @site_list = keys %$sites;
    &test_site_list($initial_scoretable, $outputfilename, @site_list);
    my $command = "grep Cmpl $outputfilename";
    system($command);
    print STDERR  "Finishing testing-only run. \n";
    exit;
} else  {
    print STDERR  "Beginning training-only run \n";
    &train_on_all_seqs($outputfilename, $initial_scoretable, %option);
    print STDERR  "Finishing training-only run.  \n";
    exit;
}  

###### End of Main #####################

sub train_on_all_seqs_and_test {
    my ($outputfile, $initial_scoretable, $outputscoretable, %option) = @_;
    &train_without_sno($outputscoretable, $initial_scoretable, "", %option);
    print STDERR  "|n*****Beginning testing phase of train-on-all-seqs-and-test run***\n\n";
    my @site_list = keys %$sites;
    &test_site_list($outputscoretable, $outputfile, @site_list);
    my $command = "grep Cmpl $outputfile";
    &execute($command);
}

###############
sub train_on_all_seqs {
    my ($outputscoretable,  $initial_scoretable, %option) = @_;
    &train_without_sno($outputscoretable, $initial_scoretable, "", %option); 
}

###############
sub jack_knife_single {
	my ($single_sno_resultfile, $initial_scoretable, $test_sno, %option ) = @_; 
	my $scoretablefile = 'scoretables/scoretable.temp';
	my $last_test_sno = "";    
	&train_without_sno($scoretablefile, $initial_scoretable, $test_sno, %option);
	print STDERR  "Finished training prior to jack-knife testing $test_sno\n";
    # Now test all the sites associated with the left out sno      
	my @site_list = ();
	foreach my $site (sort keys %$sites) {  #make list of sites assoc. with sno to be tested
		my $sno = $sites->{$site};
		unless ($sno eq $test_sno) {next;}
		push @site_list, $site;
	}    
	print STDERR  "Testing site(s) @site_list associated with  $test_sno...\n";
	&test_site_list($scoretablefile,  $single_sno_resultfile , @site_list);
	my $command = "grep Cmpl $single_sno_resultfile";
	&execute($command, $DEBUG);
}    

###############
sub jack_knife {
	my ($cumulative_resultfile, $initial_scoretable, %option) = @_;
	my $command;
	my $scoretablefile = 'scoretables/scoretable.temp';
	my $single_sno_resultfile = 'results/jack_knife_single_hit.temp';
	my $tempfile = 'results/eraseme';
	my $last_test_sno = "";
	if ( -e  $tempfile) {system("rm $tempfile");}
	foreach my $test_sno (sort values %$sites) {
		if ($test_sno eq $last_test_sno) {next;} # if sno has multiple sites only test it once for all sites
		print STDERR  "Training without sno $test_sno...\n";
		&jack_knife_single($single_sno_resultfile, $initial_scoretable, $test_sno, %option );
		$command = "cat $single_sno_resultfile $cumulative_resultfile >$tempfile; mv $tempfile $cumulative_resultfile";
		&execute($command, $DEBUG);
		$last_test_sno = $test_sno;
	}
	$command = "grep Cmpl $cumulative_resultfile";
	&execute($command, $DEBUG);
}    

##########private routines################################################

###############
# train_without_sno($scoretablefile, initial_scoretable, $left_out_sno, %option):
#  This subroutine creates a file with a set of "score tables" to be used by
#  pseudoU_test.  
#  Returns : nothing
#  Args    :  $scoretablefile: relative location where computed scoretable 
#             is to be written
#          : $left_out_sno: sno to be left out in building tables (for Jack-knife)
#             If $left_out_sno = "", train on all snos.

sub train_without_sno {
	my ($scoretablefile, $initial_scoretable, $left_out_sno, %option) = @_;
	my $tempfile1 = "eraseme.snohits";
	my $tempfile2 = "eraseme.snohits.tophits";
	my $last_sno = '';
	if ( -e  $tempfile1) {system("rm $tempfile1");}
	foreach my $site (sort keys %$sites) {
		my $sno = $sites->{$site};
		if ($sno eq $left_out_sno) {next;}
		my $command = "pseudoU_test -D 0 -W -q -S 2 -L $initial_scoretable -T $targetdir/$site.targ -F /dev/null $datadir/$sno.fa $descriptor_file >> $tempfile1"; # changed 08/04/2004
		execute($command, !$DEBUG);
	}
# Got the statistics for all snos except $test_sno.  Next make a scoretable file with this data (in $tempscoretable)
	my %sortOptions = ('topHitsOnly' => 1, 'minScore' => 2 );
	sortHits($tempfile1, $tempfile2, %sortOptions);
	my %trainOptions = ('organism'  => $option{o}, 'datafile'  => $option{a});
	$trainOptions{'leftOutSno'} = $left_out_sno if $left_out_sno;
	trainSnos($tempfile2, $scoretablefile, %trainOptions);
# $command = "perl -w scripts/newtrain.pl  $jack_knife_opt $newtrain_options $tempfile2 >$scoretablefile"; # system($command);
}

###############
# test_site_list($scoretablefile, $resultfile, @site_list):
#  This subroutine tests a set of sites using a specified "score table" file and 
#  places the result file with single best hit for each site in specified result file. 
#  Returns : nothing
#  Args    : $scoretablefile: location of file with scoretables to be used during testing
#          : $resultfile: relative location where test results with best hits / site 
#             is to be written
#          : @sites:  list of sites to be tested

sub test_site_list {
	my ($scoretablefile, $resultfile, @site_list) = @_;
  my $site;
	my $tempfile1 = "eraseme.debug.snohits";
	if ( -e  $tempfile1) {system("rm $tempfile1");}
	foreach $site (@site_list) {
		my $sno = $sites->{$site};
		if ( $site =~ /notarget/) { $site='notarget';}
		my $command = "pseudoU_test -D 0 -W -q -L $scoretablefile -T $targetdir/$site.targ -F /dev/null $datadir/$sno.fa $descriptor_file 2>stderr.out >>$tempfile1";
		&execute($command, !$DEBUG);
		my %longOptions = ('topHitsOnly' => 1, 'minScore' => 5 );
		sortHits($tempfile1, $resultfile, %longOptions);
	}
}

__END__

