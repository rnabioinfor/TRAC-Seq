#!/usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
#use lib $ENV{CPANLOCALDIR};
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES);
use parseAlns qw(&parseAllAlns &dbToSpecies &speciesToDb &getAllDbs
	&getAnnotatedSeqs &getStemLimits &stemLength);
use common;

use vars qw(
	%option
	   );


######################
sub mutCovSinglePair {
	my ($aln, $matchedSeq, $posA, $posB, $noChicken) = @_;
	my %foundPairs;
	my %foundMisMatches;
	my %foundGaps;
	foreach my $db (getAllDbs($aln)) {	
			my $species = dbToSpecies($db);
			next if ($noChicken && ($species eq 'gg')) ;
			my $charA = substr ($aln->{$species}->[SEQ_IN_ALN], $posA, 1);
			$charA = substr($matchedSeq, $posA, 1) if ( $charA eq '.'); 
			my $charB = substr ($aln->{$species}->[SEQ_IN_ALN], $posB, 1);
			$charB = substr($matchedSeq, $posB, 1) if ( $charB eq '.');
#			next if compSingle($charA, $charB) < 0; # bases not matched
			my $charAB = $charA . $charB;
			my $compScore = compSingle($charA, $charB);
  		$foundPairs{$charAB} = 1 if ($compScore > 0)  ; 
   		$foundMisMatches{$charAB} = 1 if ($compScore < 0)  ; 
   		$foundGaps{$charAB} = 1 if ($compScore == 0)  ;  		
	}
	my $misMatchCount = scalar(keys %foundMisMatches);
	my $gapCount = scalar(keys %foundGaps);
	my $pairCount = scalar(keys %foundPairs) -1 ;
	if (exists($foundPairs{'GT'}) ) {
		$pairCount -= .5 if (exists($foundPairs{'GC'}) || exists($foundPairs{'AT'}) ) ;
	}
	if (exists($foundPairs{'TG'}) ) {
		$pairCount -= .5 if (exists($foundPairs{'CG'}) || exists($foundPairs{'TA'})) ;
	}
#	throw ("Negative score ($score) found for positions $posA, $posB of aln:\n " . $aln->{'id'} . "\n")
#		if $pairCount < 0 ;
	return ($pairCount, $misMatchCount, $gapCount);  # pairCount < 0 => error
}
	

######################
sub mutCovSingleSeq {
	my ($aln, $limits, $annString, $matchedSeq, $stType, $noChicken) = @_;
	my $pairTotal = 0;
	my $misMatchTotal = 0;
	my $gapTotal = 0;
	my @annString = split //, $annString;
	my ($startA, $endA, $startB, $endB) = @$limits;
	my  $posA = $startA;	
	my  $posB = $endB;	
	while ( ($posA <= $endA) && ($posB >= $startB) ) {
		if ($annString[$posA] eq '-') {
			$posA++;
			next;
		} elsif ($annString[$posB] eq '-') {
			$posB--;
			next;
		} elsif ($annString[$posB] ne $annString[$posA]) {
			my $msg = "Nonmatching annotations $annString[$posA] and $annString[$posB] ";
			$msg .= "at positions $posA and $posB in annotation string:\n$annString\n";
			throw($msg);
		} else {
			 if ($annString[$posA] ne ' ') {
				my ($pairCount, $misMatchCount, $gapCount) = mutCovSinglePair($aln, $matchedSeq, $posA, $posB, $noChicken);
				return (-1, -1, -1) if ($pairCount < 0 ); # error flag
				$pairTotal += $pairCount;
				$misMatchTotal += $misMatchCount;
				$gapTotal += $gapCount;
			}
			$posA++;
			$posB--;	
		}
	}
	return ($pairTotal,$misMatchTotal, $gapTotal);	 
}	

######################
sub mutualCov {
	my ($aln, $mainSpecies, $noChicken ) = @_;
	my $annString = $aln->{$mainSpecies}->[ANN_SEQ];
	if (!$annString) {
		stackWarn("Could not find annotation string for main species $mainSpecies in record:\n" . $aln->{'record'} . "\n");
		return (0, 0);
	}
	my $matchedSpecies = $aln->{'matchedSpecies'};
	my $matchedSeq = $aln->{$matchedSpecies}->[SEQ_IN_ALN];
	my $counts = {'mcPairs' => 0, 'mismatch' => 0, 'gaps' => 0, 'mcScore' => 0};
	my $stemLengths = 0;
	foreach my $stType ('X5', 'I5', 'X3', 'I3') {
		my $limits = getStemLimits($annString, $stType);
		$stemLengths += stemLength($annString, $limits);
		my ($pairSeqTotal,$misMatchSeqTotal, $gapSeqTotal) = 
			mutCovSingleSeq($aln, $limits, $annString, $matchedSeq, $stType, $noChicken);
		if ($pairSeqTotal < 0 ) {
#		my $oneSeqCount = mutCovSingleSeq($aln, $limits, $annString, $matchedSeq, $stType, $noChicken);
#		if ($oneSeqCount < 0 ) {
			my $msg = "Annotation Error in structure $stType with annotation:\n$annString\n";
			$msg .= "and matched seq:\n$matchedSeq\n. Probably wrong start column calculated for highly";
			$msg .= " repetitive sequence.  Skipping record";
			stackWarn("$msg" . $aln->{'record'} . "\n");
			return 0;
		} else {
			$counts->{'mcPairs'} += $pairSeqTotal;
			$counts->{'mismatch'} += $misMatchSeqTotal;
			$counts->{'gaps'} += $gapSeqTotal;
		}
	}
	# note: typical total stem length for known snos = 30 nt.
	$counts->{'mcScore'} = $stemLengths ? 30 * $counts->{'mcPairs'}/$stemLengths : throw("Zero stem length found for annotation:\n$annString");
	return $counts;	 
}	   

######################
sub getCol  {
	my ($aln, $pos, $noChicken) = @_;
	my @col;
	foreach my $db (getAllDbs($aln)) {	
			my $species = dbToSpecies($db);
			next if ($noChicken && ($species eq 'gg')) ;
			my $nt = substr ($aln->{$species}->[SEQ_IN_ALN], $pos, 1);
			push @col, $nt;
	}
	return  \@col;		
}	   

######################
BEGIN {
# keep track of whether one is outside the alignment of the candidate seq, or inside the structured or
# unstructured part of the candidate as one steps through the annotation string.
	my ($region,$hIndex, $acaIndex );
	sub resetRegion {
		$hIndex = 0;
		$acaIndex = 0;
		return $region = 'notAln';
	}
	sub getRegion  {
		my ($pos, $annString) = @_;
		my @structSym = qw(X I L R 1 2 3 4 5 6 7 8 9 l r);
		my @hAcaSym = qw(H A C );
		my $currSym = substr($annString, $pos, 1);
		if (grep {$_ eq $currSym} @structSym) {
			$region = 'struct';
		} elsif (grep {$_ eq $currSym} @hAcaSym) {
			if ($hIndex < 6 ) {
				$hIndex++;
				$region = ( ($hIndex == 1) || ($hIndex == 3) ) ?  'struct' : 'notStruct';
			} elsif ($acaIndex < 4 ) {
				$acaIndex++;
				$region = ( ($acaIndex == 1) || ($acaIndex == 3) ) ?  'struct' : 'notStruct';
			} else {
				$region = 'notAln';
			}
		} elsif ($currSym eq ' ') {
			$region = 'notStruct';
		}	elsif ($currSym ne '-') {
			throw("Unidentified symbol $currSym found at position $pos in annotation:\n$annString");
		}
		return $region ;		
	}	   
}

######################
sub countNtTypes  {
	my ($col ) = @_;
	my $count = 0;
	foreach my $base ('A', 'C', 'G', 'T', '-') {
		my $foundBase = grep {$_ eq $base} @$col;
		$count++ if $foundBase;
	}		
	return $count;		
}	   

######################
sub countSpecies {
	my ($aln, $noChicken)= @_;
	my @dbs = getAllDbs($aln);
	my $speciesCt = scalar(@dbs);	
	$speciesCt-- if ($noChicken && (grep {$_ =~ /gg/} @dbs) );
	return $speciesCt;	
}
	
######################
sub relativeConservation {
	my ($aln, $mainSpecies ) = @_;
# count the number of base changes per alignment column per sequence outside the candidate sequence,
# within the putative structure of the sequence and within the unstructured part of the sequence
	my $counts = {'notAln' => 0, 'struct' => 0, 'notStruct' => 0};
	my $lengths = {'notAln' => 0, 'struct' => 0, 'notStruct' => 0};
	my $annString = $aln->{$mainSpecies}->[ANN_SEQ];
	if (!$annString) {
		stackWarn("Could not find annotation string for main species $mainSpecies in record:\n" . $aln->{'record'} . "\n");
		return $counts;
	}
	resetRegion();
	my $speciesCt = countSpecies($aln, 'noChicken');
	for ( my $pos = 0; $pos < length($annString); $pos++) {
		my $col = getCol($aln, $pos, 'noChicken');
		my $region = getRegion($pos, $annString);
		$counts->{$region} += countNtTypes($col);
		$lengths->{$region} += 1;
	}
	# normalize counts to lengths and number of seq in alignment
	while ( my ($region, $count) = each %$counts) {
		$count /= $lengths->{$region} if ($lengths->{$region}); # length normalization
		$counts->{$region} = $count / $speciesCt; # normalize to same number of species in alignment
	}
	# compute ratios to structured-region conservation value
	my $structCounts = $counts->{'struct'};
	foreach my $region (keys %$counts) {
		$counts->{$region} /= $structCounts;
	}
	return $counts;		
}	   

######################
sub insertScores {
	my ($record, $mutCovHash, $relConCounts) = @_;
	if ($relConCounts != -1 ) {
		my $intScore = sprintf "%.2f", $relConCounts->{'notStruct'};
		my $extScore = sprintf "%.2f", $relConCounts->{'notAln'};
		my $addRec = "IntRelConScore = $intScore, ExtRelConScore = $extScore"; 
		$record =~ s/(##Total aln score = ([\d\.])+)/$1, $addRec/;
#		$record =~ s/(##Total aln score = ([\d\.])+)/$1, RelativeConservation score = $relConScore/;
	}
	if ($mutCovHash && ($mutCovHash != -1 ) ) { 
		my $mutCovCounts = sprintf "%.1f", $mutCovHash->{'mcPairs'};
		my $misMatch = sprintf "%d", $mutCovHash->{'mismatch'};
		my $gaps = sprintf "%d", $mutCovHash->{'gaps'};
		my $mutCovScore = sprintf "%.2f", $mutCovHash->{'mcScore'};
		my $mcOutput = 'Mutual Cov Pairs:Score:Mismatch:gaps = ';
		$mcOutput .= join ":", $mutCovCounts, $mutCovScore, $misMatch, $gaps;
		$record =~ s/(##Total aln score = ([\d\.])+)/$1, $mcOutput/;
	}
	return $record;
}	 	

######################
sub scoreAlns {
	my ($inFile, $outFile, %option) = @_;
	my $outFh = getOutFh($outFile);
  my $inFh = getInFh($inFile);
  my $mainSpecies = $option{mainSpecies};
	my $alnList  = parseAllAlns($inFile, $mainSpecies, %option);
	foreach my $aln (@$alnList) {
  	my $mainDb = speciesToDb($aln, $mainSpecies);
  	my $annAlign = getAnnotatedSeqs($aln);
  	my $mutCovCounts = $option{mutualCov} ? mutualCov($annAlign, $mainSpecies, 'noChicken'): -1 ;
  	my $relConCounts= $option{relCon} ? relativeConservation($annAlign, $mainSpecies): -1 ;
		my $annRecord = insertScores($annAlign->{'record'}, $mutCovCounts, $relConCounts);
		print $outFh "$annRecord\n";
	}
}

######################
my @okSpecies = ('hg', 'mm', 'rn', 'gg', 'ec') ;
my $USAGE =<<END_OF_USAGE;

 Usage: Usage: scoreAlns [options] <snoRNA aln file > <outfile>
   Script to score annotated alignments of snoRNA hits for
   mutual covariance and relative conservation of strucctured and
   non-structured and surrounding sequence 
   options:
	where	
	-m : species of the initial hit: one of @okSpecies  REQUIRED;
	-v : score mutual covariance;
	-r : score relative sequence conservation; opt_r or opt_v or both must be specified

END_OF_USAGE

######################

getopts('m:vr', \%option) || die("$USAGE");
my ($infile, $outfile) = @ARGV;
$outfile || die("$USAGE");
$option{m} || die("Species of original hit must be specified");
$option{r} || $option{v} || die("At least one test must be specified");
my %longNames = ('m' => 'mainSpecies', 'v' => 'mutualCov', 'r' => 'relCon');
my $longOptions = getLongOptionNames(\%longNames, \%option);
my $optionOk = grep { $longOptions->{mainSpecies} eq $_ } @okSpecies ;
$optionOk ||	die ( "Opt m must be one of: " . (join ", ", @okSpecies) . "\n\n$USAGE");
scoreAlns($infile, $outfile, %$longOptions);

__END__

sub mutCovSinglePair {
	my ($aln, $matchedSeq, $posA, $posB) = @_;
	my $score = -1; 
	my %foundPairs;
	foreach my $db (getAllDbs($aln)) {	
			my $species = dbToSpecies($db);
			my $charA = substr ($aln->{$species}->[SEQ_IN_ALN], $posA, 1);
			$charA = substr($matchedSeq, $posA, 1) if ( $charA eq '.'); 
			my $charB = substr ($aln->{$species}->[SEQ_IN_ALN], $posB, 1);
			$charB = substr($matchedSeq, $posA, 1) if ( $charB eq '.');
			next if compSingle($charA, $charB) < 0; # bases not matched
			my $charAB = $charA . $charB;
  		$foundPairs{$charAB} = 1 ;  
	}
	my @pairs = keys %foundPairs;
	$score +=  grep { ($_ eq 'AT') || ($_ eq 'CG') || ($_ eq 'GC') || ($_ eq 'TA') } @pairs;
	if (exists($foundPairs{'GT'}) ) {
		if (exists($foundPairs{'GC'}) || exists($foundPairs{'AT'}) ) {
			$score += .5;
		} else {
			$score++;
		}
	}
	if (exists($foundPairs{'TG'}) ) {
		if (exists($foundPairs{'CG'}) || exists($foundPairs{'TA'}) ) {
			$score += .5;
		} else {
			$score++;
		}
	}
	return $score;
}
	
