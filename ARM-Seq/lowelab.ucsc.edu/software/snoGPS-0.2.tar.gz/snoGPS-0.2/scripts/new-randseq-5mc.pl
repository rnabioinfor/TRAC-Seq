#! /usr/bin/perl -w

# randseq-5mc.pl <Freq file> <Seq output file> <Numseqs> <Starting seq#> \
#                 <Numseqs> <Length of seqs> <Seq comment (in quotes)>

if ($#ARGV < 5) {
    die "Usage:\n  randseq-5mc <Freq file> <Seq output file> ",
    "<Starting seq#> <Numseqs> <Length of seqs> <Seq comment (in quotes)>\n\n";
}

$use_freqs_to_start = 1;   # if set to non-zero, will look in frequency file
#  to start first four bases in each sequence
# if 0, will generate 4 random bases, equal prob
#  for each base

$tot_globfreq = 0.0;
$tot_ktuples = 0;

@alph = ('A','C','G','T','N');
#srand 1;
srand;

($freq_file,$seq_file,$start_seqnum,$tot_seqs,$seq_len,$user_desc) = @ARGV;

open (FREQFILE,$freq_file) || die;

print "\nReading in $freq_file frequency table...";

while ($freqline = <FREQFILE>) {
    if ($freqline =~ /^([ACGTN]{6,6})\t(\d+)\t(\S+)/) {
	$seqkey = $1;
	$Ct{$seqkey} = $2;
	$tot_ktuples += $2;
	$Freq{$seqkey}= $3;  # frequency of 5th base given 4-mer
    }
}
close FREQFILE;

if ($use_freqs_to_start) {
    foreach $seqkey (sort keys(%Ct)) { 
	# frequency of 5-mer out of entire db
	$GlobalFreq{$seqkey} = $Ct{$seqkey}/$tot_ktuples;
	$tot_globfreq += $GlobalFreq{$seqkey};
    }  
}

print "done\nGenerating $tot_seqs \"random sequences\" ($seq_len bp each)...\n";

open (SEQOUT,">$seq_file") || die;
foreach $seqct ($start_seqnum..$start_seqnum+$tot_seqs-1) {
    print "Generating seq# $seqct\n";
    $name = "Randseq".$seqct;	
    $description = "randomly gen seq ".$user_desc;
    $SeqLength = $seq_len;
    $Seq = 'X' x $seq_len;
    
    if ($use_freqs_to_start) {
	substr($Seq,0,6) = &Get_6mer();
	if (substr($Seq,0,5) eq 'XXXXX') {
	    die "Whups! Found XXXXX in seq!";
	}
    }
    else {
	foreach $i (0..4) {
	    substr($Seq,$i,1) = $alph[int(rand(4))];
	}
    }

    foreach $i (5..$seq_len-1) {
	$rnum = rand;
#    $sav_rnum = $rnum;    # variable used only in debugging so it generates warning ps
	$seqindex = substr($Seq,$i-5,5);
	foreach $base (@alph) {
	    unless (defined $rnum) { print " rnum not defined!! \n"; }
	    unless (defined $seqindex) { print " seqindex not defined!! \n";}
	    unless (defined $base) { print " base not defined!! \n";}
	    unless (defined $Freq{"$seqindex$base"}) { 
		print " Freq hash value not defined at base = $base and seqindex = $seqindex index = $i !!\n";
	    }
	    if ($Freq{"$seqindex$base"} >= $rnum) {
		substr($Seq,$i,1) = $base;
		last;
	    }
	    else {
		if ($base eq 'N') { 
#DEBUG		    print "I don't think this should happen!\t";
		    substr($Seq,$i,1) = $alph[int(rand(4))];
#DEBUG		    print "rnum = $rnum \n";
		}
		$rnum -= $Freq{"$seqindex$base"};
#		if ($rnum < 0.0001) { 
	#	    $rnum = 0.0001; # workaround for underflow problem
	#	}
	    }
	}
    }
    &write_fasta($name,$description,$SeqLength,$Seq,SEQOUT);
}

close SEQOUT;

# end Main

sub Get_6mer {
    $rnum = rand;
    $cum_freq = 0.0;
    foreach $key (sort keys(%GlobalFreq)) {
	$cum_freq += $GlobalFreq{$key};
	if ($cum_freq >= $rnum) {
	    return $key;
	}
    }
}

sub write_fasta {
    local($name, $description, $length, $sequence,*FAHANDLE) = @_;
    local($pos, $line);

    print FAHANDLE "> $name $description\n";
    for ($pos = 0; $pos < $length; $pos += 60)
    {
	$line = substr($sequence,$pos,60);
	print FAHANDLE $line, "\n";
    }
    1;
}



