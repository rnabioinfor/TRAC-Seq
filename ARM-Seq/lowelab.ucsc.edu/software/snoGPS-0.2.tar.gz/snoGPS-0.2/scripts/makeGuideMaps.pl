#!/usr/local/bin/perl -w

use strict;
use Getopt::Std;
use English;
use lib $ENV{MYPERLMODULEDIR}; 
#use lib $ENV{CPANLOCALDIR};
use makeGuideMaps qw(&makeGuideMaps);
use common;

use vars qw(
	%option
	   );

######################

my $USAGE =<<END_OF_USAGE;

 Usage: Usage: makeGuideMaps [options] <snoRNA aln file > <outfile>
   Script to convert annotated alignments of snoRNA hits to primer sequences
   options:
	where	
	-m : infile is an alignment file with species to use 
		being one of (hg, mm, rn, gg) (default => infile is a hit file);
	-t : target file to use REQUIRED;
	-l : length of I stem to display (default = 4)
	-s : display entire annotated sequence along with guide
END_OF_USAGE

######################

getopts('m:t:l:s', \%option) || die("$USAGE");
my ($infile, $outfile) = @ARGV;
$outfile || die("$USAGE");
($option{t} )|| die("Species of original hit and target file must be specified");
my %longNames = ('m' => 'mainSpecies', 't' => 'targFile', 'l' => 'istemLen', 's' => 'showSeq');
my $longOptions = getLongOptionNames(\%longNames, \%option);
if ($longOptions->{mainSpecies}) {
	my $optionOk = grep { $longOptions->{mainSpecies} eq $_ } ('hg', 'mm', 'rn', 'gg') ;
	$optionOk ||	die ( "Opt m must be hg, mm, rn or gg\n\n$USAGE");
}
makeGuideMaps($infile, $outfile, %$longOptions);

__END__

