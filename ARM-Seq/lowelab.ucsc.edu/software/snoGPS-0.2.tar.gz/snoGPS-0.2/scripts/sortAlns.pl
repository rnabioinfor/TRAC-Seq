#!/usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES &trimList &parseAllHits &hdrToDb );
#use sortHits qw(:HIT_INDEXES &trimList &calcMatMisMat &subNewMatch
#		&parseAllHits &hdrToDb );
use parseAlns qw(&parseAllAlns &trimName &dbToSpecies );
use sortAlns qw(&sortAlnByScore &sortAlnBySite &sortAlnBySpeciesScore &sortAlnByPairScore
			&sortAlnById &sortAlnByLocation);
use common;

use vars qw(
	%option
	   );
	   
sub cleanUpList {
	my ($inList, $species) = @_;
# Some alignment records may not have all the required data for sorting. Leave them out
	my @filteredList = 
		grep { $_->{'totalScore'} && $_->{'site'} && $_->{'targetRna'} } @$inList;
	return \@filteredList;
}

######################

sub removeParalogs {
# removes records with identical sites, scores and pairs
	my ($alnList) = @_;
	my @filteredList;
	return 0 unless $alnList;
	my $prevSite = 0;
	my $prevScore = 0;
	my $sortedAlnList = sortAlnBySite($alnList); 
	foreach my $aln (@$sortedAlnList) {
		my $site = $aln->{'site'};
		my $score = $aln->{'totalScore'};
		next if ( ($site == $prevSite) && 
							($score == $prevScore) );
		$prevSite = $site;
		$prevScore = $score;
		push @filteredList, $aln;		
	}
	return \@filteredList;
}		

######################
sub outBed {
	my ($sortedAlnList, $species, $outFh, %option) = @_;
	foreach my $aln (@$sortedAlnList) {
		my $hit = $aln->{$species};
		next unless $hit;
		next unless ($hit->[CHROM] && $hit->[GENOME_START] && $hit->[GENOME_END] && $hit->[DB]  );
		my $name = $hit->[NAME] || $aln->{'id'} 
			|| throw("Could not find an ID for species:$species, chrom:" . $hit->[CHROM] . ':' . $hit->[GENOME_START] . '-' . $hit->[GENOME_END] . "\n");
		my $strand = $name =~ /C$/ ? '-' : '+';
		$name = trimName($name) if $option{trimName};
		my $score = $hit->[SCORE] || '0';
		$score = int(10 * $score);
		my $bedLine = join (" ", $hit->[CHROM], $hit->[GENOME_START], $hit->[GENOME_END], 
									$name, $score, $strand, $hit->[DB]) ;
		print $outFh "$bedLine\n";
	}
}

######################

sub uniqueOnly {
# removes records with identical sites, scores and pairs
	my ($alnList) = @_;
	my @filteredList;
	return 0 unless $alnList;
	my $prevIds;
	my $sortedAlnList = sortAlnByScore($alnList); 
	foreach my $aln (@$sortedAlnList) {
		my $id = $aln->{'id'};
		if ($id =~ /^([a-zA-Z0-9]+)(_|:)/) {
			$id = $1;
		}
		next if exists($prevIds->{$id});
		$prevIds->{$id} = $id;
		push @filteredList, $aln;		
	}
	return \@filteredList;
}		

######################
sub getHitHash {
	my ($inFile) = @_ ;
	my $homolHitFile = $inFile;
	$homolHitFile =~ s/aln/homolHits/;
	unless (-f $homolHitFile) {
		$homolHitFile =~ s/homolHits/tmp.homolHits/;
	}
	unless (-f $homolHitFile) {
		throw("Could not find homologous hit file corresponding to $inFile\n");
	}
	my %option = ();
	my ($hitList, $overallHeaderRecord) = parseAllHits($homolHitFile, %option);
	my $hitHash;
	foreach my $hit (@$hitList) {
		my $id = $hit->[NAME] . '-' . $hit->[SCORE] . '-' . $hit->[SITE];
		$hitHash->{$id} = $hit->[RECORD];
	}
	return $hitHash;
}		


######################
sub sortAlns {
	my ($inFile, $outFile, %option) = @_;
	my $outFh = getOutFh($outFile);
        my $speciesList = ['hg', 'mm', 'rn'];
  my $inFh = getInFh($inFile);
#create hash of all homologous hits needed to fix pair Scores
	$option{'fixPairs'} = getHitHash($inFile) if $option{fixPairs}; 
	my $alnList  = parseAllAlns($inFile, $option{mainSpecies}, %option);
	my $sortedAlnList;
	$alnList = cleanUpList($alnList, $option{mainSpecies}); 
	$alnList = removeParalogs($alnList) if $option{paralogs};
	$alnList = uniqueOnly($alnList) if $option{unique};
  $sortedAlnList = sortAlnByLocation($alnList, $option{mainSpecies}) if $option{sortByLocation};
  $sortedAlnList = sortAlnBySite($alnList) if $option{sortBySite};
  $sortedAlnList = sortAlnById($alnList) if $option{sortById};
	$sortedAlnList = sortAlnByPairScore($alnList, $speciesList) if $option{sortByPairScore};
  $sortedAlnList = sortAlnBySpeciesScore($alnList, $option{sortBySpeciesScore}) 
  	if $option{sortBySpeciesScore};
  $sortedAlnList = sortAlnByScore($alnList, $option{topAlnsOnly}) 
  	unless ($option{sortById} || $option{sortBySite} || $option{sortByPairScore} || 
  	$option{sortBySpeciesScore} || $option{sortByLocation});
  throw("Could not sort alignments\n") unless $sortedAlnList;
  $sortedAlnList = trimList($sortedAlnList, $option{topAlnsOnly}, 'aln')
    			if ($option{topAlnsOnly}) ;
  if ($option{bedOut}) {
  	outBed($sortedAlnList, $option{bedOut}, $outFh, %option);
  } else { 			# output alignments
  	map {print $outFh $_->{'record'} , "\n"} @$sortedAlnList;
  }
}

######################

my @okSpecies = ('hg', 'mm', 'rn', 'gg', 'ec') ;
my $USAGE =<<END_OF_USAGE;

 Usage: Usage: sortAlns [options] <snoRNA aln file > <outfile>
   Script to sort annotated alignments of snoRNA hits by overall score 
   Optionally can output bedFile of hits of specified sequence
   options:
	where	
	-m : species of the initial hit: one of @okSpecies  REQUIRED;
	-P      	:  sort alns by Position of complementarity on rRNA
	-I        :  sort alns by align ID  
	-L        :  sort alns by query position
	-c        :  sort alns by overall "pair score" of target guide region
	-h				: remove duplicates (same site & same total score)
	-G <species>:  sort alns by score of hit in genome <species> 
		(hg, mm, rn, gg)  
	-T <number>:  keep only top 'T' alignments /site  
	-S <score>:  sort alns, require minimum score  
	-s <score>:  skip alns with scores above max score [DEFAULT = no max] 
  -f        :  fix pair (mismatch/ match) score
	-p <pairScore>:  minimum pair score for 'initial species' hit 
	-e <expr> :  Extract only snos with <expr> in aln record
	-E <expr> :  Extract only snos without <expr> in aln record
	-b <species> :  Output bedFile for species (hg, mm, rn, or gg) [DEFAULT = output alignments] 
	-u : keep only highest scoring aln for any seq with given sequence ID (eg U65 or H395 or S3)
		(only useful for alns which have IDs other than chr:start-end) 
	-t : trim names (currently only implemented for 'bed' output
END_OF_USAGE

######################

getopts('PIS:s:e:E:T:G:m:b:Lhtufp:c', \%option) || die("$USAGE");
my ($infile, $outfile) = @ARGV;
$outfile || die("$USAGE");
$option{m} || die("Species of original hit must be specified");
my %longNames = ('P' => 'sortBySite', 'I' => 'sortById', 'b' => 'bedOut', 
			't' => 'trimName', 'f' => 'fixPairs', 'p' => 'pairs','c' => 'sortByPairScore',
			'S' => 'minScore', 'L' => 'sortByLocation',  'h' => 'paralogs', 'u' => 'unique',
			'T' => 'topAlnsOnly', 'G' => 'sortBySpeciesScore', 'm' => 'mainSpecies',
			's' => 'maxScore', 'e' => 'acceptRegexp', 'E' => 'rejectRegexp');
my $longOptions = getLongOptionNames(\%longNames, \%option);
my $optionOk = grep { $longOptions->{mainSpecies} eq $_ }  @okSpecies ;
$optionOk ||	die ( "Opt m must be one of: " . (join ", ", @okSpecies) . "\n\n$USAGE");
if ($longOptions->{bedOut} ) { 
	$optionOk = grep { $longOptions->{bedOut} eq $_ }  @okSpecies ;
	$optionOk ||	die ( "Opt m must be one of: " . (join ", ", @okSpecies) . "\n\n$USAGE");
}
sortAlns($infile, $outfile, %$longOptions);

__END__

