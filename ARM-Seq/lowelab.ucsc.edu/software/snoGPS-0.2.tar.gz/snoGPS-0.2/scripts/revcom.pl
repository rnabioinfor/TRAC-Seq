#! /usr/local/bin/perl

use strict;
#use lib '/projects/lowelab/users/schattner/bioperl-1.2';
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use Bio::SeqIO;
my ($in, $out, $temp, $rev);

my ($seqfile) = @ARGV;
$seqfile =~ s/\.fa//;
$in  = Bio::SeqIO->new(-file => "$seqfile.fa" , '-format' => 'Fasta');
$out = Bio::SeqIO->new(-file => ">$seqfile.rc.fa" , '-format' => 'Fasta');

while ( my $seq = $in->next_seq() ) {
    my $id = $seq->id;
    $temp = $seq->trunc(1,$seq->length);  
    $rev = $seq->revcom();
    $rev->id($id . '-rc');
    $out->write_seq($rev);
}
