#! /usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib '/projects/lowelab/users/schattner/bioperl-1.2';
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use Bio::SeqIO;
use Bio::Seq;
use Bio::SearchIO;
use Bio::Annotation::Collection;
use Bio::Annotation::SimpleValue; 
use lib './scripts';  
use score_subs;
#use score_subs  qw(&throw);

my $max_guide_separation = 50 ; # max allowed distance between end of ANANNA hinge and start of ACA xStem 
my $min_guide_separation = 5 ; #  min allowed distance between end of ANANNA hinge and start of ACA xStem

use vars qw(
        $opt_O
        $opt_p
	    );

$opt_O = ''; 
$opt_p = '';

###############################################
#
#  "Main" program follows
#####################################################

my ($hit_fh, $out_fh) = &script_setup;        

my ($previous_hit, $previous_record) ;
$/ = '####';  #read in entire 'hit record' at a time
while (my $record = <$hit_fh>) {
  my $current_hit = &hit2seqobj($record);
  unless ($current_hit) {
      print STDERR "Warning: Could not parse record $record\n";
      next;
  }
  unless ($previous_hit) {
      $previous_hit = $current_hit;
      next;
  }
  my ($current_query_seq, $current_start, $current_end, $current_strand) = 
          &get_annotations($current_hit);
  my ($previous_query_seq, $previous_start, $previous_end, $previous_strand) = &get_annotations($previous_hit);
  my $stem_separation = $current_start - $previous_end;
  if ( ($current_query_seq eq $previous_query_seq) &&
       ( $stem_separation  < $max_guide_separation) &&
       ( $stem_separation  > $min_guide_separation) &&
       ($current_strand  == $previous_strand) 
       ) {
      print $out_fh "$previous_record\n";
      print $out_fh "$record\n\n";
#      &output_double_guide($out_fh, $current_hit, $previous_hit);  
  }
  $previous_hit = $current_hit;
  $previous_record = $record;
}				# end hit-record loop
 
if ($opt_O) {
    close ($out_fh);
    system("cat $opt_O");
}  

######################### End of Main ####################

sub script_setup {

    my $usage = <<END_OF_USAGE;
  Usage: double_guide_search.pl [options] <hitfilename>  
    where    
           -p        :  use STDIN or pipe instead of hit file 
           -O <output file-name> [default = STDOUT]
  Note: hitfile **MUST** be presorted by query location (option -H of new-sort)

END_OF_USAGE
 
    getopts('pO:');

    if ($#ARGV < 0 && !$opt_p) {
	die "$usage";
    }				

    my ($infile) = @ARGV; 
    my $out_fh;

    if ($opt_p) {
	open(INFILE, "-" ) ;
    } elsif ($infile) {
	open(INFILE,"$infile") || die("Can't open $infile\n");
    } else {
	die ("$usage"); 
    }
    my $hit_fh = *INFILE;

    if ($opt_O) {
	open (OUTFILE, ">$opt_O") or die ("Cannot open $opt_O \n");
	$out_fh = *OUTFILE;
    } else {  
	$out_fh = *STDOUT;
    }

    return($hit_fh, $out_fh);
}


 #############

sub   output_double_guide {
  my ($out_fh, $current_hit_seqobj, $previous_hit_seqobj) = @_;
  
  print $out_fh ">", $previous_hit_seqobj->id, " ", $previous_hit_seqobj->desc,  "\n";
  print $out_fh $previous_hit_seqobj->seq,  "\n";
  print $out_fh ">", $current_hit_seqobj->id, " ", $current_hit_seqobj->desc, "\n";
  print $out_fh $current_hit_seqobj->seq,  "\n";
  print $out_fh "####\n";
  return;
  } 

 #############

sub get_annotations {
    my ($hit_obj) = @_;
    my ($start, $end, $strand, $query);
    my $collection = $hit_obj->annotation;
    
    my @query_array = $collection->get_Annotations('query_seq');
    $query = $query_array[0]->value;
    my @start_array = $collection->get_Annotations('start');
    $start = $start_array[0]->value;
    my @end_array = $collection->get_Annotations('end');
    $end = $end_array[0]->value;
    my @strand_array = $collection->get_Annotations('strand');
    $strand = $strand_array[0]->value;

    return ($query, $start,$end,$strand);
}
__END__
