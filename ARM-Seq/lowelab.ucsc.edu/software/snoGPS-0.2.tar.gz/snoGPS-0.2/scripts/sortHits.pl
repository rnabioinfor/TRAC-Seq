#! /usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits;
use common;

use vars qw(
	%option
	   );
	   
######################
my $USAGE =<<END_OF_USAGE;

Usage: sortHits [options] <snoRNA hits file > <outfile> 
	 'stdin' and 'stdout' OK 
       Sort snoRNA hits by overall score
        where -P        :  sort snos by Position of complementarity on rRNA
              -H        :  sort snos by position of hit in query sequence
              -L        :  sort snos by genome position of hit
             -c        :  sort snos by "pairScore"
              -q        :  Do not pass output header 
              -O        :  Remove lower-scoring hit if hits overlap in genomic coordinates
              -l        :  Remove lower-scoring hit if hits overlap in local coordinates
              -h        :  Remove 'paralogs' (hits with identical sites, scores & pairs) 
              -T <int>  :  sort snos, output only top <int> hits per site 
              -S <score>:  sort snos, require minimum score [DEFAULT = 10] 
              -s <score>:  skip snos with scores above max score [DEFAULT = no max] 
              -p <pairScore>:  minimum pair compl pair score (matches - mimatches) 
              -e <expr> :  Extract only snos with <expr> in hit record
              -E <expr> :  Extract only snos without <expr> in hit record
              -F        :  Don't sort -- just filter & output in same order
              -f        :  fix pair (mismatch/ match) score
END_OF_USAGE


getopts('qhPHLOlS:s:e:E:T:Fp:fc', \%option) || die("$USAGE");
my ($infile, $outfile) = @ARGV;
$outfile || die("$USAGE");
die "Can choose remove overlaps in both local and genomic coordinates (opt-O and opt-l)" 
	if ($option{O} && $option{l} );
my %longNames = ('P' => 'sortBySite', 
			'H' => 'sortByHit', 'L' => 'sortByLocation', 'c' => 'sortByPairScore',
			'S' => 'minScore',  'h' => 'paralogs',  'f' => 'fixPairs', 'l' => 'localOverlap',
			's' => 'maxScore', 'e' => 'acceptRegexp', 'E' => 'rejectRegexp', 'p' => 'pairs',
			'q' => 'quiet', 'T' => 'topHitsOnly', 'F' => 'filterOnly', 'O' => 'overlap');
my $longOptions = getLongOptionNames(\%longNames, \%option);
sortHits($infile, $outfile, %$longOptions);

__END__
