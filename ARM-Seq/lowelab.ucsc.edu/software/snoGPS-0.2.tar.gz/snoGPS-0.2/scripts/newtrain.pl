#! /usr/local/bin/perl

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use newtrain qw(&trainSnos);

use vars qw(
	%option
	   );


###############################################
#
#  "Main" program follows
#####################################################
my $usage =<<END_OF_USAGE;

 Usage: perl newtrain.pl [options] <snoRNA hits> <outFile>
      where 
      -j=snRXXX indicates jack-knife testing (leaving out sno snRXXX)
	    -d datafile [required eg newtrain.yeast.v2.data] 
	    -o organism [required] 
 	          choices: Scerev Sbaya Pfuri Pabyssi Phori Mjann Mtherm Afulg Susolf Sutokad Hsp Pae
       Other [options] are of the form -G=[f(\\d)+|i(\\d)+|g(\\d)+|b(\\d)+|z(\\d+)|y[0|1]|+s]
       and options triangular (f)ilter, (i)nterpolate, (g)aussian filter 
       custom (b)insize, (z)ero-bin handling, s(y)mmetrize array and/or (s)kip
       Tests that can be modified are:
       (G)ap, (I)stemlength, (X)stemlength, (S)temfrequencies, (P)ost_ACAfrequencies, (H)ACAbasefrequencies
       (R)compl-HACA-inteval, and H-Xstem(T)wo-Interval
          Note: not all Test/option combinations allowed - if in doubt check the code! 
  <snoRNA hits>  and <outFile>  may be stdin or stdout, respectively

END_OF_USAGE


getopts('G:C:I:X:S:P:H:R:T:j:o:d:', \%option) || die("$usage");
my ( $hitfile, $outFile) = @ARGV;
unless ($outFile && $option{d} && $option{o}) { 
    die("$usage");
#    print "Defaults are: \n";
#    for my $feature (@adjustable_features) {print "# $feature->{'name'} : $feature->{'flags'} \n";}
#   exit(1); 
}				
my %longNames = ('G' => 'Gap-Length', 
			'C' => 'Compl-region-length', 'I' => 'IntStem-length', 'X' => 'ExtStem-length',
			'S' => 'ExtStem',  'P' => 'POST-ACA-U-freqs',  'H' => 'HPosition', 'R' => 'HACA-RCompStart-length',
			'T' => 'XStem-H-length', 'j' => 'leftOutSno', 'o' => 'organism', 'd' => 'datafile',
	);
my $longOptions = getLongOptionNames(\%longNames, \%option);
trainSnos($hitfile,$outFile, %$longOptions);


__END__


