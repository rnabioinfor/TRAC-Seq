#!/usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
#use sortHits qw(&sortHits);
#use sortHits qw(&totalAlnScore &sortByTotalScore &sortHits);
#use runPuSetup qw(&runPuAndSortHits &runPuSeqObj);
#use convertHits qw(&hitsToBed);
#use annotatedAlign qw(&annotateOneAln);          
use common;
use runHomologs qw(&getTargFile &annoMafsForOneHit &setUpOutFiles &outputAnnAlign);
use Bio::SeqIO;
use Bio::Seq;
#use hhObjects::HACA_CandidateIO;
#use constant BADSCORE => -100;
use vars qw(
	%option  
	   );

######################
sub runMafHomologs {
	my ($infile, $targetSite, $outFileBase, %option) = @_;
	$option{'noMafExtension'} = 1;
	my ($outFh, $alignIoOut, $homolFh, $outFileRoot) = 
		setUpOutFiles($infile, $outFileBase, '');
	my $targFile = targFile($targetSite, $option{'targetDir'}); 
	my @annAlign = annoMafsForOneHit($infile, $targFile, 0, %option);
	$annAlign[3] || die "Sorry no alignment found";
	outputAnnAlign($outFh, $alignIoOut, $homolFh, \@annAlign);	

}

######################

my $USAGE =<<END_OF_USAGE;

Usage: runMafHomologs [options] inMafFile.maf targetSite outFileBase

Script to 
	1. write hit results to inMafFile.homolHits
		(or optionally specified name outFileBase.homolHits)
	2. write annotated alignment to inMafFile.aln or outFileBase.aln
 targetSite is of form LSU.U4380 
	options:
	-c skip any chicken sequences in alignments in determining scores
	-t target directory (default is environmental variable \$HS_TARGS
	-d descriptor (default is \$DESC/MamGUs2.v3.desc)
	-l scoretable (default is \$SCORETABLES/human.v3.scoretables)
	
eg
	runMafHomologs \$HS_RESULTS/knownSnos/U64.test.maf LSU.U4965
 
END_OF_USAGE

getopts('ct:d:l:', \%option) || die("$USAGE");
my ($infile, $targetSite, $outFileBase) = @ARGV;
$targetSite || die("$USAGE");
my %longNames = ( 
 			'c' => 'skipChicken', 't' => 'targetDir',
 			'd' => 'descriptor', 'l' => 'scoretable'
);
my $longOptions = getLongOptionNames(\%longNames, \%option);
runMafHomologs($infile, $targetSite, $outFileBase, %$longOptions);

__END__

