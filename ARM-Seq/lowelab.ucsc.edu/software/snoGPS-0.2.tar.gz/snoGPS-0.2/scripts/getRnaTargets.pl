#! /usr/local/bin/perl -w

use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use getRnaTargets qw(&getRnaTargets);

use vars qw(
	%option
	   );

######################
my $USAGE =<<END_OF_USAGE;

  Usage: getRnaTargets.pl [options] <rRNA fasta query-file>  <outFile>
    where    
	-n do *not* create split target files in addition to combined file
	-r create target file(s) for reversed RNA targets (useful as randomized targets)
		only available when targetting every uridine
	-f <fileName> file specifies which uridines are pseudoU's for which target sequence
	-s '656:989:2010' make targets only for specified uridines
                  [default = make *every* uridine into a target]]    

END_OF_USAGE

getopts('s:f:rn', \%option) || die("$USAGE");
my ($inFile, $outFile) = @ARGV;
$outFile || die("$USAGE");
#($option{b} && $option{r} ) && 
#	die("option{b} && option{r} can not both be chosen");
( $option{r}  && ($option{f} || $option{s} ) ) && 
die("Target reversal currently only available when using all uridines in file as targets");
my %longNames = ('s' => 'targetList', 'f' => 'pseudouFile', 
	'n' => 'noSplit', 'r' => 'reversedTargs');
my $longOptions = getLongOptionNames(\%longNames, \%option);
my $targetCount = getRnaTargets($inFile, $outFile, %$longOptions);
print STDERR "\n*** Total number of targets created = $targetCount ****\n\n";

#############
__END__
