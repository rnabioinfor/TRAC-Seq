#! /usr/bin/perl

if ($#ARGV != 1) {
    die "\nGenerate 5th order markov chain frequencies\n",
  "Usage: gen-5mc <input fasta file> <output freq file> \n\n";
}				

$seq_file = shift;
$out_file = shift;

&open_fasta($seq_file,SEQFILE);

$CurSeqLine = '';
$numseqs = 0;
$tot_seqlen = 0;

@alph = ('A','C','G','N','T');

foreach $i1 (@alph) {
    foreach $i2 (@alph) {
	foreach $i3 (@alph) {
	    foreach $i4 (@alph) {
		foreach $i5 (@alph) {
		    foreach $i6 (@alph) {
			$Ct{"$i1$i2$i3$i4$i5$i6"} = 0;
		    }
		}
	    }
	}
    }
}
			
while (&read_fasta("",*SeqName,*SeqDescription,*SeqLength,*Seq,
		   *CurSeqLine,SEQFILE)) {
    print "At seq# $numseqs\n";
    $numseqs++;
    $tot_seqlen += $SeqLength;
    for ($i=0; $i<$SeqLength-5; $i++) {
	$index = substr($Seq,$i,6);
	$Ct{$index}++;
    }
}
&close_fasta(SEQFILE);

foreach $i1 (@alph) {
    foreach $i2 (@alph) {
	foreach $i3 (@alph) {
	    foreach $i4 (@alph) {
		foreach $i5 (@alph) {
		    $index = "$i1$i2$i3$i4$i5";
		    $Total{$index} = 0;
		    foreach $i6 (@alph) {
			$Total{$index} += $Ct{"$index$i6"};
		    }
		    if ($Total{$index} == 0) {
			foreach $i6 (@alph) { 
			    $Freq{"$index$i6"} = 0.25;
			}
			$Freq{"$index"."N"} = 0.0;
		    }	
		    else {
			foreach $i6 (@alph) {
			    $Freq{"$index$i6"} = $Ct{"$index$i6"} / $Total{$index};
			}
		    }
		}
	    }
	}
    }
}




open (OUTFILE,">$out_file");

foreach $key (sort keys(%Ct)) {
    printf OUTFILE "%s\t%d\t%1.5f\n",$key, $Ct{$key},$Freq{$key};
}
close OUTFILE;


# End Main


sub open_fasta {
    local($fname, *FAHANDLE) = @_;
    open(FAHANDLE,$fname) || die("Failed to open FASTA file $fname\n");
    $SavedLine = "";
    1;	
}
sub close_fasta {
    local (*FAHANDLE) = @_;
    close(FAHANDLE);
    1;
}

# converts sequence to uppercase, DNA alphabet (in addition to reading it in) 

sub read_fasta {
    local ($key,*SeqName,*SeqDescription,*SeqLength,*Sequence,
	   *SavedLine, *FAHANDLE) = @_;
    local ($Seqlen, $filepos);
    
    while ((!eof(FAHANDLE)) 
	   && (($SavedLine =~ /^>/) || ($SavedLine = <FAHANDLE>))) 
    {				
	if ($SavedLine =~ /^>\s*(\S*$key)\s+(.*)$/)
	{
	    $SeqName        = $1;
	    $SeqDescription = $2;
	    $Sequence       = "";

	    $filepos = tell(FAHANDLE);
	    $Seqlen = 0;
	    while ($SavedLine = <FAHANDLE>)
	    {
		if ($SavedLine =~ /^>/) { last; }
		$SavedLine =~ s/[ \n\t]//g;     # strip whitespace
		$Seqlen += length($SavedLine);
	    }			

	    seek(FAHANDLE,$filepos,0);
	    $Sequence = 'X' x $Seqlen;  # pre-extending string for efficiency
	    $Seqlen = 0;
	    while ($SavedLine = <FAHANDLE>)
	    {
		if ($SavedLine =~ /^>/) { last; }
		$SavedLine =~ s/[ \n\t]//g;     # strip whitespace
		substr($Sequence,$Seqlen,length($SavedLine)) = $SavedLine;
		$Seqlen += length($SavedLine);
	    }			

	    $SeqLength = length($Sequence);
	    $Sequence = uc($Sequence);
	    $Sequence =~ s/U/T/g;
	    return 1;
	}
	else {
	    $SavedLine = <FAHANDLE>;
	}
    }				
    0;				
}

sub Max {
    local ($a,$b) = @_;
    if ($a > $b) {
	return ($a); }
    else {
	return ($b); }
}

















