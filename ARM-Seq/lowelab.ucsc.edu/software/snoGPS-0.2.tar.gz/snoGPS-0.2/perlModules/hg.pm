#! /usr/local/bin/perl -w

package hg;
use strict;
use Getopt::Std;
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
# routines used to access the hg database and other UCSC files

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	%option
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw();
        @EXPORT_OK = qw(&getNames  &getNamesAndDescs &printAllNames &getDb 
        				&getSeqFromNib &getFaFileFromNib &sortBeds &appendFaFileFromNib
        				&getAllNamesAndDescs &blatGetCoords &blatGetBedLines &blatGetBedLines
        				&faToMaf &bedLineToNibFrag &getDbFromCoords &bedLineToMaf);
}	   

#############	   
sub scoreBed {
 	my ($bed) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bed);
	return $score;
} 	

#############	   
sub sortBeds {
 	my ($bedLines, $how) = @_;
 	throw("Only byScore sorting of bed lines supported so far") unless ($how eq 'byScore');
	return 0 unless $bedLines; 
	my @sortedBeds =
		 map { $_->[0] } 
		 sort { $b->[1] <=> $a->[1] }  
		 map { [$_, scoreBed($_)] } @$bedLines;
	return \@sortedBeds;  
} 	

#############	   
sub parsePsl {
 	my ($line) = @_;
	my @line = split " ", $line;
	my $match = $line[0];
	my $mismatch = $line[1];
	my $repmatch = $line[2];
	my $qNumInsert = $line[4];
	my $tNumInsert = $line[6];
#	my $match_pos = 0;
#	my $mismatch_pos = 1;
#	my $repmatch_pos = 2;
#	my $qNumInsert_pos = 4;
#	my $tNumInsert_pos = 6;
	my $qname = $line[9];
	my $chrom = $line[13];
	my $strand = $line[8];
	my $start = $line[15] ;
	my $end   = $line[16];
	return 0 unless $end;
	return 0 unless ($end =~ /^\d+$/);   #sanity checks
	return 0 unless ($start =~ /^\d+$/);
	return ($qname, $chrom, $strand, $start, $end, $match, $mismatch, $repmatch, $qNumInsert, $tNumInsert);
 }

######################
sub runBlat {
	my ($infile, %option) = @_; 
  my $build = $option{'db'};
	my $min_score = $option{'minPercent'} || 98;
# my $build = $option{D};
#	my $min_score = $option{S} || 98;
# my $port = 17779;
  my $port = $option{'tDnax'} ? 17778 : 17779;
  my %server = ( 'mm3' =>  'blat9.cse.ucsc.edu',
                 'hg13' => 'blat3.cse.ucsc.edu',
                 'hg15' => 'blat2.cse.ucsc.edu',
                 'hg16' => 'blat6.cse.ucsc.edu',
                 'rn2' =>  'blat10.cse.ucsc.edu',
                 'rn3' =>  'blat11.cse.ucsc.edu',
             );
   my %nib_fa = ('mm3' => '/cluster/data/mm3',
                 'hg13' => '/cluster/data/hg13',
                 'hg15' => '/cluster/data/hg15',
                 'hg16' => '/cluster/data/hg16',
                 'rn2' =>  '/cluster/data/rn2',
                 'rn3' =>  '/cluster/data/rn3',
                 );
  throw("\nCould not find blat server for build $build\n\n")
  	unless ( exists $server{$build} );    
  my $pslFile = "/tmp/psltempfile.tmp";   
  my $clusterData = '/cluster/data';         
  my $command = "/cluster/bin/i386/gfClient $server{$build} $port $clusterData/$build/nib $infile $pslFile";
	$command .=  " -t=dnax" if $option{'tDnax'};
	$command .=  " -q=dnax" if $option{'qDnax'};
 	$command .=  " -minIdentity=$min_score -nohead -dots=1";
	$command .=  "  2>1 1>/tmp/blatMessages.tmp";
	execute($command, !$option{'debug'});
# print STDERR "$command\n";
# system($command);
  return $pslFile;
 }

 
######################
sub scorePsl {
	my ($match, $misMatch, $repMatch, $qNumInsert, $tNumInsert, $isProtein) = @_;
#taken from psl.c
#return sizeMul * (psl->match + ( psl->repMatch>>1)) - 
#	sizeMul * psl->misMatch - psl->qNumInsert - psl->tNumInsert;
 	my $sizeMul = $isProtein ? 3 : 1;
	my $score = $sizeMul * ( $match + int($repMatch/2) );
	$score -= $sizeMul * $misMatch;
	$score -= $qNumInsert;
	$score -= $tNumInsert;
	return $score;
}
 
######################
sub blatGetBedLines {
# takes file of fasta seqs and creates a bedfile of their coordinates
# a reference to an array of the bedlines is returned
 	my ($infile, %option) = @_;
	my @bedLines; 
	my $min_length = $option{'minLen'} || 60;
	my $upstreamExtend = $option{'upstreamExtend'} || $option{'extend'} || 0 ; 
	my $downstreamExtend = $option{'downstreamExtend'} || $option{'extend'} || 0 ; 
#	my $min_length = $option{L} || 60;
#	my $upstreamExtend = $option{u} || $option{X} || 0 ; 
#	my $downstreamExtend = $option{d} || $option{X} || 0 ; 
  my $pslFile = runBlat($infile, %option);  
  open (PSLFILE, "<$pslFile") or throw("Cannot open $pslFile \n");
  while (my $line = <PSLFILE>) {
  	my ($qname, $chrom, $strand, $start, $end, $match, $mismatch, $repmatch, $qNumInsert, $tNumInsert)
  		= parsePsl($line);
  	unless ($qname) {
			stackWarn( "Could not parse bedline:\n $line");
  		next;
    }
    my $score = scorePsl($match, $mismatch, $repmatch, $qNumInsert, $tNumInsert, $option{'isProtein'});
  	$start -= $upstreamExtend ;
  	$end  += $downstreamExtend ;
  	next if ( ($end - $start) < $min_length);
  	my $bedLine = bedBuild($qname,	$chrom,	$strand, $start, $end, $score);	
	 	push @bedLines, $bedLine;
  }
  return \@bedLines;
}

#############	   
 sub bedLineToNibFrag {
 # convert single bedLine to fasta
 	my ($bedLine, $nibDir, $outfile,  %option) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine, %option);
	$start -= $option{'extend'} if $option{'extend'};
	$end += $option{'extend'} if $option{'extend'};
	my $nibFile = "$nibDir/$chrom.nib";
  my $command = "nibFrag ";
  my $faName = "$chrom:$start-$end" ;
  if ($option{'strandInName'}) {
  	$faName .= ($strand eq '+') ? 'W' : 'C';
  }
  $command .= " -name=$faName " ;
#  $command .= " -name=$chrom:$start-$end " ;
  $command .= "$option{'miscNibOpts'} " if $option{'miscNibOpts'} ;
  $command .= "$nibFile $start $end $strand ";
  if ($outfile eq 'stdout') {
  	$command .= "stdout";
  } else {
		$command .= "stdout >>$outfile";
	}
  print STDERR "$command\n" if $option{'debug'};
  my $status = system($command);
  return $status;
}

#############	   
 sub blatGetCoords {
 	my ($inFile, $outFile, %option) = @_;
 	my $build = $option{'db'};
# 	my $build = $option{D};
 	my $bedLines = blatGetBedLines($inFile, %option);
  my $outFh = getOutFh($outFile);
	foreach my $bedLine (@$bedLines) {
		my ($chrom, $start, $end, $name, $score, $strand)	= bedParse($bedLine);
		my $strandWc = ($strand eq '+') ? 'W' : 'C';
    print $outFh "$name $build $chrom $start $end $strandWc\n";
	}
	 close($outFh) unless ($outFile eq 'stdout');
}	

######################
sub getDbFromCoords {
	my ($db, $chrom, $start, $end, $sqlOpts, @vars)= @_;
	my $varString = join "," ,  @vars;
	return 0 unless $vars[0];
	my $sqlCommand = "SELECT $varString FROM kgXref, knownGene WHERE chrom = \"$chrom\" ";
	$sqlCommand .= "AND txStart < $end AND txEnd > $start ";
	$sqlCommand .= "AND kgID=name ";
	$sqlCommand .= $sqlOpts;
	my $hgsqlCommand = "hgsql $db -e \'$sqlCommand\' ";
	print STDERR "$hgsqlCommand\n";
	my @retData = `$hgsqlCommand`;
	return \@retData;
}
######################
sub getDb {
# get gene data corresponding to a single bed line using knownGenes and kgXref tables
# return 0 if unable to parse bedLine
	my ($bedLine, $db, @vars) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine);
	return 0 unless $end; 
	my $retData = getDbFromCoords($db, $chrom, $start, $end, '', @vars);
	return $retData;
}

######################
sub getNamesAndDescs {
# return reference to list of gene names corresponding to a single bed line
# return 0 if unable to parse
	my ($bedLine, $db) = @_;
	my $geneNames = getDb($bedLine, $db, 'description');
#	my $geneNames = getDb($bedLine, $db, 'geneSymbol', 'description', 'chrom', 'txStart', 'txEnd');
	return $geneNames;
}

######################
sub getAllNamesAndDescs {
	my ($overlapBed, $db) = @_;
# get gene names corresponding to all lines in a bed file
	my @allGeneNames = ();
	foreach my $bedLine (@$overlapBed) {
		my $geneNames = getNamesAndDescs($bedLine, $db);
		next unless $geneNames; # couldn't parse bedLine
		push @allGeneNames, $geneNames;
	}
	return \@allGeneNames;
}
	
######################

sub printAllNames{
# print and/or return all overlapping gene names and descriptions as a string
	my ($allGeneNames, $msg, $outFh, $headerId) = @_;
	my $lastId;
	my $allGeneDescs = '';
	 unless ($allGeneNames) {
	 	print $outFh "	No $msg\n" if $outFh;
	 	return $allGeneDescs;
	 }
	 print $outFh "	$msg\n" if $outFh;
 	 foreach my $geneDescsOneBed (@$allGeneNames) {
 	 	foreach my $geneDesc (@$geneDescsOneBed) {
 	 		chomp $geneDesc;
 	 		my ($id, $remainder) = split " ", $geneDesc;
 	 		next unless $id;
 	 		next if ($lastId && ($id eq $lastId) ); # skip repeat records
 	 		next if ($geneDesc =~ /$headerId/); # skip header
	 		print $outFh " $geneDesc\n" if $outFh;
	 		$allGeneDescs .= "|$geneDesc";
	 		$lastId = $id;
	 	}
	 }
	 return $allGeneDescs;
}	

#############	   
 sub createMafCommand {
 	my ($db, $chrom, $start, $end, $table, $outfileSingle, %option) = @_;
  my $command = "mafWriteRegion ";
  $command .= $option{'f'} ? " -fasta ": "";
  $command .= $option{'h'} ? " -hitAny ": "";
  $command .= $option{'o'} ? " -outDb=$option{'o'} ": "";
  $command .= $option{'s'} ? " -minScore=$option{'s'} ": "";
#  $command .= $option{l} ? " -minLen=$option{l} ": " -minLen=80 ";
	my $minLength = 80;
  $minLength = $option{'l'} if $option{'l'};
  $minLength = $option{'minLen'} if $option{'minLen'};
  $command .= " -minLen=$minLength ";
  $command .= " $db $table $chrom $start $end $outfileSingle ";
	return $command;
}

#############	   
sub cleanUpMafFaFile {
	my ($infile, $outfile, $qname, $strand, $db, %option) = @_;
	my $inFh = getInFh($infile);
	my $outFh = getInFh($outfile);
	while (my $line = <$inFh> ) {
		$line =~ s/>/>$qname./;
		$line = revComp($line) if ( ($line =~ /^[ACGTU-]+$/i) && ($strand eq '-') );
		print $outFh $line;
	}
	close $inFh;
	close $outFh;
}
	
#############	   
sub cleanUpMafFile {
	my ($infile, $outfile, $qname, $bedStrand, $db, %option) = @_;
	my $inFh = getInFh($infile);
	my $outFh = getOutFh($outfile);
	while (my $line = <$inFh> ) {
		if ($line !~ /^s/ ) {
			print $outFh $line;
			next;
		}
	  my ($lineType, $seqname, $mafStart, $len, $mafStrand, $chromLen, $seq) 
	  		= split " ", $line;
		if ($bedStrand eq '-' ) {
		# set flag to indicate the original sequence was on Crick strand			
			$seqname =	($seqname =~ /^$db/ ) ?
					"C1_$qname.$seqname" :
					"C0_$qname.$seqname" ;
		} else {
			$seqname ="$qname.$seqname";
		}
#		$seqname =	"$qname.$seqname";
		print $outFh join " ", $lineType, $seqname, $mafStart, $len, $mafStrand, $chromLen, $seq, "\n";
	}
	close $inFh;
	close $outFh;
}

#############	   
sub bedLineToMaf {
	my ($bedLine, $db, $outfile, %option) = @_;
	my $tempfile = '/tmp/mafTempFile.maf';
	my %tables = ('mm3' =>  'multizHg15Rn3', 
                'hg13' => 'multizMm3Rn2', 
                #'hg15' => 'multizMm3Rn2',
                'hg15' => 'multizRn3Mm3',
                 'hg16' => 'multizMm3Rn3Gg0',
 #              'hg16' => 'multizMm3Rn3GalGal2',
                'rn3' =>  'multizHg15Mm3',
             );
  my $table = $tables{$db} ||
  	throw("No maf table known for db $db"); 
   ;
  my ($chrom, $start, $end, $qname, $score, $strand) = bedParse($bedLine);
  my $command = createMafCommand($db, $chrom, $start, $end, $table, $tempfile, %option);
  print STDERR "$command\n";
  system($command);
  if ($option{f}) {
  	cleanUpMafFaFile($tempfile, $outfile, $qname, $strand, $db, %option);
  } else {
   	cleanUpMafFile($tempfile, $outfile, $qname, $strand, $db, %option);
	} 	
} 

#############	   
 sub faToMaf {
 # retrieves maf file corresponding to input fa file
 	my ($inFile, $outfile, %option) = @_;
	my $build = $option{'db'};
#	my $build = $option{D};
	my %tables = ('mm3' =>  'multizHg15Rn3', 
                'hg13' => 'multizMm3Rn2', 
                #'hg15' => 'multizMm3Rn2',
                'hg15' => 'multizRn3Mm3',
                'hg16' => 'multizMm3Rn3Gg0',
#               'hg16' => 'multizMm3Rn3GalGal2',
                'rn3' =>  'multizHg15Mm3',
             );
    die("No maf table table known for db $build") unless ( exists $tables{$build} );
    my $table = $tables{$build}; 
 	unlink $outfile; # delete old version
    my $coordinateFile = "/tmp/eraseme.coords";   
   my $outfileSingle  = "/tmp/eraseme.outMaf";   
  blatGetCoords($inFile, $coordinateFile, %option);
  
  open (COORDFILE, "<$coordinateFile") or die ("Cannot open $coordinateFile \n");
  while (my $line = <COORDFILE>) {
    my ($qname, $db, $chrom, $start, $end, $strandWc) = split " ", $line;
    next if ($option{e} && ($qname !~ /$option{e}/) );
    my $command = createMafCommand($line, $table, $outfileSingle, %option);
    print STDERR "$command\n";
    system($command);
    my $filterCommand = $option{f} ?
                        "s/>/>$qname./"  :     
                        "s/^s /s $qname./";
    $command = "perl -i -p -e \'$filterCommand\' $outfileSingle";
    system($command);
    $command = "cat $outfileSingle >> $outfile";
    system($command);
  }
  system("cat $outfile");
}
######################
sub getFaFileFromNib {
# returns fa file of nib sequence
	my($bedLine, $db, $isContig, $contigSubDir, %nibOption ) = @_;
	my $faFile = $nibOption{'outFile'} || makeTempName('nibFaFile.fa');
#	my $faFile = '/tmp/nibFaFile.fa';
	unlink $faFile;
	$nibOption{'debug'} = 1;  
	my $nibDir = "/cluster/data/$db/nib";
	$nibDir .= "/$contigSubDir" if $isContig;
  return 0 unless ( -d $nibDir); # changed 8/9/04 to deal with removed nib directories (eg for gg0)
#  throw ("Cannot find $nibDir \n") unless ( -d $nibDir);
	my $status = bedLineToNibFrag($bedLine, $nibDir, $faFile, %nibOption);
	unless (-f $faFile) {
		stackWarn("Could not retrieve nibFile for db $db & bedline:\n $bedLine\n") ;
		return 0;
	}
	return $faFile;
}

######################
sub	appendFaFileFromNib {
	my($resultFile, $bedLine, $db, $isContig, $contigSubDir , %nibOption ) = @_;
	my $faFile = getFaFileFromNib($bedLine, $db, '', 0 , %nibOption );
 	my $command = "cat $faFile >> $resultFile";
 	execute($command, 'noPrint');
 	$command = "rm $faFile";  # added cleanup lines 1/22/04
 	execute($command, 'noPrint');
}

######################
sub getSeqFromNib {
# returns Bio::Seq object of nib sequence
	my($bedLine, $db, $isContig, $contigSubDir, %nibOption ) = @_;
	my $faFile = getFaFileFromNib($bedLine, $db, $isContig, $contigSubDir, %nibOption );
  return 0 unless $faFile; # changed 8/9/04 to deal with removed nib directories (eg for gg0)
	my $inSeqio =  Bio::SeqIO->new('-format' => 'fasta', '-file'=> $faFile); 
	my $seq = $inSeqio->next_seq;
	$inSeqio->close;	# added cleanup lines 1/22/04
 	my $command = "rm $faFile";  
 	execute($command, 'noPrint');	
	unless ($seq) {
		print STDERR "Could not retrieve sequence for db $db with bed params:\n $bedLine\n\n";	 
		return 0;
	}
	return $seq;
}

1;

__END__


#############	   
 sub bedLineToNibFrag {
 # convert single bedLine to fasta
 	my ($bedLine, $nibDir, $outfile,  %option) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine, %option);
	$start -= $option{'extend'} if $option{'extend'};
	$end += $option{'extend'} if $option{'extend'};
#	$start -= $option{X} if $option{X};
#	$end += $option{X} if $option{X};
	my $nibFile = "$nibDir/$chrom.nib";
  my $command = "nibFrag ";
  $command .= " -name=$chrom:$start-$end " ;
  $command .= "$option{'miscNibOpts'} " if $option{'miscNibOpts'} ;
#  $command .= "$option{N} " if $option{N} ;
  $command .= "$nibFile $start $end $strand ";
  if ($outfile eq 'stdout') {
  	$command .= "stdout";
  } else {
		$command .= "stdout >>$outfile";
	}
  print STDERR "$command\n" if $option{'debug'};
  my $status = system($command);
  return $status;
}
