#! /usr/local/bin/perl -w

package convertHits;
use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES &parseHeader &storeHit &parseHeaderAndSeq );
#use sortHits qw(&parseHeader &storeHit 
#        			&NAME &SCORE &STRAND &HITSTART &HITEND &RECORD &SITE &PAIRS &TARGETRNA
#        			&SEQ &INTRONS &NEIGHBORS &EXONS &UPSTREAM &GENOME_START &GENOME_END &CHROM
#		);
use getNeighbors qw(&getOverlappingFeature &getNearbyGenes );
use common;
use blatToBed;
use hg qw(&printAllNames);
use vars qw( 
	%option
	@ISA @EXPORT @EXPORT_OK
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw();
        @EXPORT_OK = qw(&hitWriteBed &hitWriteFa &hitsToBed);
#        @EXPORT_OK = qw(&hitWriteBed &hitWriteFa &parseHeaderAndSeq &hitsToBed);
}	   
	   	
######################	
sub hitWriteBed {
	my ($hit, $outFh, %option) = @_;
	my $score = int (10 * $hit->[SCORE]); # score in format acceptable to "Bed files"
	my $siteName = $hit->[TARGETRNA] . $hit->[SITE];
	my $outString = join "\t", $hit->[NAME], $hit->[HITSTART], $hit->[HITEND], $siteName, $score, $hit->[STRAND];
	print $outFh "$outString\n";
}	

######################	
sub hitWriteFa {
	my ($hit, $outFh, %option) = @_;
	my $outString = ">" . $hit->[NAME] . ":" . $hit->[HITSTART] .  "\t";
	$outString .= $hit->[TARGETRNA] . ".U" . $hit->[SITE] .  "\t";
	$outString .= $hit->[SCORE] . "\t" . $hit->[PAIRS] .  "\n";
	$outString .= $hit->[SEQ] . "\n";
	print $outFh $outString;
}	

	
######################	
sub getNeighborsSingleHit {
	my ($hit, $db, %option) = @_;
	my $retFeatures;
	my $bedLine = blatSequenceToBed ($hit->[NAME], $hit->[SEQ], %option);
 	$retFeatures = getOverlappingFeature($bedLine, $db, 'exon'); 
#	$hit->[EXONS] = printAllNames($retFeatures, '', '', 'description') ; 
 	$retFeatures = getOverlappingFeature($bedLine, $db, 'intron'); 
#	$hit->[INTRONS] = printAllNames($retFeatures, '', '', 'description') ; 
 	$retFeatures = getOverlappingFeature($bedLine, $db, 'upstream'); 
#	$hit->[UPSTREAM] = printAllNames($retFeatures, '', '', 'description') ; 
	$retFeatures = getNearbyGenes($bedLine, $db); 
#	$hit->[NEIGHBORS] = printAllNames($retFeatures, '', '', 'description') ; 
	return $hit;
}

######################	
sub getDbName {
	my ($hitName, %option) = @_;
	return $option{db} if ($option{db} eq 'mm3' );
	return $option{db} if ($option{db} eq 'hg13' );
	return $option{db} if ($option{db} eq 'hg15' );
	return $option{db} if ($option{db} eq 'rn2' );
	return $option{db} if ($option{db} eq 'mm3' );
	return $option{db} if ($option{db} eq 'rn3' );
	die "Unknown db choice: $option{db} " unless ( $option{db} eq 'all' );
	return 'mm3' if ($hitName =~ /mm/);
	return 'rn3' if ($hitName =~ /rn/);
	return 'hg15' if ($hitName =~ /h[gs]/);
	die "Could not parse hitName $hitName for species choice of mm, rn or h[gs]";
}

######################	
sub writeSummary {
	my ($hit, $outFh, %option) = @_;
	my $siteName = $hit->[TARGETRNA] . $hit->[SITE];
	my $outString = join "\t", $siteName, $hit->[NAME], $hit->[HITSTART], $hit->[HITEND], $hit->[STRAND], $hit->[SCORE], $hit->[PAIRS];
	if ( $option{db} ) {
		my %neighborOption = %option;
		my $db = getDbName($hit->[NAME], %option);
		$neighborOption{db} = $db;
		$hit = getNeighborsSingleHit($hit, $db, %neighborOption);
#		$outString =  join "\t", $outString, $hit->[EXONS], $hit->[INTRONS], $hit->[UPSTREAM], $hit->[NEIGHBORS];
	}
	print $outFh "$outString\n"; 
}	

######################	
sub writeHeader {
	my ($outFh, %option) = @_;
	my $outString;
	return if $option{fasta} ; 
	if ( $option{summary} ) {	
		 $outString =  "Site\tName\tStart\tEnd\tStrand\tScore\tPairs";
		 $outString .= "\tExonOverlaps\tIntronOverlaps\tUpstreamOverlaps\tNeighbors" if $option{db} ;
	} else {
		 $outString =  "Name\tStart\tEnd\tSite\tScore\tStrand";
	}
	print $outFh "$outString\n";
}	

#####################
sub sortKeys {
	my ($hitHash) =@_;
	my @keys = keys %$hitHash;
 	my @sortedKeys =
 		map { 	$_->[0] }
 		sort {		$a->[1] cmp $b->[1] 	||
 					$a->[2] <=> $b->[2] 	||
 					$a->[3] cmp $b->[3] }
 		map { [ $_, (split /:/, ) [0,1,2] ]} @keys;
 	return \@sortedKeys;
 }
 				
 				
######################	
sub hitsToBed {
	my ($infile, $outfile, %option) = @_;
	my $inFh = getInFh($infile);
	my $outFh = getOutFh($outfile);
	my ($hitHash) ;
	while (my $line = <$inFh>) {
		my $foundHit = parseHeaderAndSeq($line, $inFh, %option);
		next unless $foundHit;
		$hitHash = storeHit($hitHash, $foundHit);
	}
	writeHeader($outFh, %option) unless $option{noHeader};
	my $sortedKeys = sortKeys($hitHash);
	foreach my $key (@$sortedKeys) {
		if ( $option{summary} ) {
			throw("Sorry option summary not currently implemented\n");
#			writeSummary($hitHash->{$key}, $outFh, %option);
		} elsif ( $option{fasta} )  {
			hitWriteFa($hitHash->{$key}, $outFh, %option);
		} else {
			hitWriteBed($hitHash->{$key}, $outFh, %option);
		}
	}
	close $inFh;
	close $outFh;
}

1;


__END__