#! /usr/local/bin/perl

package parseAlns;
use strict;
use Getopt::Std;
#use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES &parseHeader &filterScoreAndRegexp &hdrToDb
	&calcMatMisMat &subNewMatch &completeSite);
use common;
use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT_OK = qw( &parseAllAlns &getAllDbs &dbToSpecies &trimName &getStemLimits &stemLength
							&alnGetCoords &speciesToDb &getAnnotatedSeqs &findSpeciesAndCol &getHitSeqs);
	%EXPORT_TAGS = (
        			);
}	   

######################
sub trimName {
# track names must be short
	my ($name) = @_;
	my $newName = $name;
	if ($name =~ /^([UESHK])([a-zA-Z0-9]+)/) {
		$newName = "$1$2";
	} elsif ($name =~ /^AF357(\d\d\d)/) {
		$newName = "H$1";
	} elsif ($name =~ /^AJ609(\d\d\d)/) {
		$newName = "K$1";
	}
	return $newName;
}


######################
sub getAllDbs {
	my ($aln) = @_;
	my $foundDbs = $aln->{'foundDbs'};
	my $otherDbs = $aln->{'otherDbs'};
	my @allDbs = ();
	push @allDbs, @$foundDbs if $foundDbs;
	push @allDbs, @$otherDbs if $otherDbs;
	return @allDbs;
}

######################
sub dbToSpecies {
	my ($db) = @_;
	my $species = $db;
	$species =~ s/\d+//;
	return $species;
}

######################
sub speciesToDb {
	my ($aln, $species) = @_;
	my @allDbs = getAllDbs($aln);
	foreach my $db (@allDbs) {
		return $db if ($db =~ /$species/) ;
	}
	return 0; # species was not in alignment (ie not in maf)
}

######################
sub alnGetCoords {
	my ($aln, $db) = @_; 
	my $species = dbToSpecies($db);
	my $chrom = $aln->{$species}->[CHROM];
	my $start = $aln->{$species}->[GENOME_START];
	my $end = $aln->{$species}->[GENOME_END];
	my $strand = $aln->{$species}->[GENOME_STRAND];
	return ($chrom, $start, $end, $strand); 
}

######################
sub addHitOrOther {
	my ($foundAln, $hitOrOther) = @_ ;
	my $species = dbToSpecies ($hitOrOther->[DB]);
#	$species =~ s/\d+//;
	if ( exists($foundAln->{$species}) ) { # sanity check
		stackWarn ("Found two hits for same species for record:\n" . $foundAln->{'record'} . "\n") ;
		return $foundAln;
	}
	$foundAln->{$species} = $hitOrOther;
	return $foundAln;
}

######################
sub addHit {
	my ($foundAln, $foundHit) = @_ ;
	push @{$foundAln->{'foundDbs'} } , $foundHit->[DB];
	return addHitOrOther($foundAln, $foundHit);
}

######################
sub addNotHit {
	my ($foundAln, $alnNotHit) = @_ ;
	push @{$foundAln->{'otherDbs'} } , $alnNotHit->[DB];
	return addHitOrOther($foundAln, $alnNotHit);
}

######################
sub parseOtherAlnLine {
	my ($foundAln, $line) = @_ ;
	return 0 if $line =~ /^Ann/ ; # skip annotation lines
	my ($label, $seq) = split " ", $line;
	return 0 unless $label ;  
	my ($db, $species);
	if ( $label =~ /(:|_)\d+\.([a-z][a-z]\d+)/ ){ 
		$db = $2; 
		$species = dbToSpecies($db); 
	}
#	throw ("Could not parse for db/species in aln line:\n $line") unless $species;
	return 0 unless $species;	
	return 0 if exists($foundAln->{$species});
	my $alnOther;
	if ( $label =~ /$db.(chr|Contig)(\w+)(:|_)(\d+)-(\d+)([WC]?)/i ){  
		$alnOther->[CHROM] = $1.$2;
		$alnOther->[GENOME_START] = $4;
		$alnOther->[GENOME_END]  = $5;
		$alnOther->[GENOME_STRAND] = $6;
		$alnOther->[DB] = $db;
	}	else {
	throw ("Could not parse for chrom/start/end in aln line:\n $line");		
	}
	return $alnOther;
}

######################
sub parseOneAlnLine {
	my ($foundAln, $line) = @_ ;
	my $foundHit = parseHeader($line);
	return addHit($foundAln, $foundHit) if $foundHit;	
	my $alnNotHit = parseOtherAlnLine($foundAln, $line);
	return addNotHit($foundAln, $alnNotHit) if $alnNotHit;	
	return $foundAln;
}


######################
sub findSpeciesAndCol {
# determine which sequence in alignment is being matched (ie does not have '.'s) 
# and what the start column for the sequence data is
	my ($rec) = @_;
	my ($species, $startCol);
	my @lines = split "\n", $rec;
	foreach my $line (@lines) {
		next 	if $line =~ /^\s*>/;
		my $db = hdrToDb($line);
		next 	if $db eq 'NA' ;
		next 	if $line =~ /Ann:/ ;
		if ($line =~ /^(\S+\s+)[-ACGTN]+$/) {
			$startCol = length $1;
			my $species	= dbToSpecies($db);
			return ($startCol, $species);
		} 
		throw("Could not parse startCol and species to match in line:\n$line of record:$rec\n");
	}
}	   
	
######################
sub getAnnotatedSeqs {
	my ($aln) = @_;
	my $rec = $aln->{'record'};
	my ($startCol, $matSpecies) = findSpeciesAndCol($rec);	
	$aln->{'matchedSpecies'} = $matSpecies;
	my @lines = split "\n", $rec;
	foreach my $line (@lines) {
		next 	if $line =~ /^\s*>/;
		my $db = hdrToDb($line);
		next if ($db eq 'NA');
		my $species = dbToSpecies($db);
		if ($line =~ /Ann:/ ) {
			$aln->{$species}->[ANN_SEQ] .= substr($line, $startCol);  
		} else {
			$aln->{$species}->[SEQ_IN_ALN] .= substr($line, $startCol);  
		}
	}
	return $aln;
}

######################
sub getHitSeqs {
	my ($aln) = @_;
	my $rec = $aln->{'record'};
	my @lines = split "\n", $rec;
	for (my $i = 0; $i < scalar(@lines) ; $i++) {
		next unless ($lines[$i] =~ /^\s*>/);
		my $db = hdrToDb($lines[$i]);
		throw("Could not parse db in header:\n$lines[$i]") if ($db eq 'NA');
		my $species = dbToSpecies($db);
		$i++;
		if ($lines[$i] =~ /^[ACGTUN]+$/i) { 
			$aln->{$species}->[SEQ] = $lines[$i];
		} else {
			throw("Could not parse sequence line:\n$lines[$i] in record:\n$rec\n");
		}	
	}
	return $aln;
}

######################
sub substAlnMatch {
# substitute the corrected pair values into the hdr line in the alignment record
	my($aln, $db, $mat, $misMat) = @_;
	my $rec = $aln->{'record'} ;
	my @newRec;
	my @rec = split /\n/, $rec;
	foreach my $line (@rec) {
		if ($line =~ /^\s*>/ ) {
			my $currDb = hdrToDb($line);
			if ($currDb && ($db eq $currDb) ) {
				$line = subNewMatch($line, $mat, $misMat);	
			}
		}
		push @newRec, $line;
	}
	return join "\n", @newRec;
}

######################
sub fixAlnPairs {
	my ($aln, $hitHash) = @_;
	my $foundDbs = $aln->{'foundDbs'};
	foreach my $db (@$foundDbs) {
		my $species = dbToSpecies($db);
		my $hit = $aln->{$species};
		my $hitHdr = $hit->[RECORD];
		my $id = $hit->[NAME] . '-' . $hit->[SCORE] . '-' . $hit->[SITE];
		my $homolRec = $hitHash->{$id} ||
			throw("Could not find homologous hit record for id $id");
		my ($mat, $misMat) = calcMatMisMat($homolRec);
 		$aln->{$species}->[RECORD] = subNewMatch($hitHdr, $mat, $misMat);
		$aln->{$species}->[PAIRS] = "$mat/$misMat";
		$aln->{'record'} = substAlnMatch($aln, $db, $mat, $misMat);
	}
	return $aln;
}
	
######################
sub parseTotalScores {
	my ($foundAln, $record) = @_;
	if ($record =~ /Total\s*aln\s*score\s*=\s*([\d\.]+)/ ) {
			$foundAln->{'totalScore'} = $1;
	} else {
			$foundAln->{'totalScore'} = 0;
	}
	if ($record =~ /Pairs:Score:Mismatch:gaps\s*=\s*([\d\.:]+)/ ) {
			$foundAln->{'mutCovScore'} = $1;
	} else {
			$foundAln->{'mutCovScore'} = 0;
	}
	if ($record =~ /IntRelConScore\s*=\s*([\d\.]+),\s*ExtRelConScore\s*=\s*([\d\.]+)/ ) {
			$foundAln->{'relConsScore'} = $1 . '/' . $2;
	} else {
			$foundAln->{'relConsScore'} = 0;
	}	
	return $foundAln;
}

######################
sub parseOneAln {
	my ($record, $mainSpecies, %option)	 = @_;
	my ($foundAln);
	$foundAln->{'record'} = $record;	
	$foundAln = parseTotalScores($foundAln, $record);
	return 0 if ( filterScoreAndRegexp($record, $foundAln->{'totalScore'}, %option) == 0);
	my @lines = split "\n", $record;
	foreach my $line (@lines) {
		$foundAln = parseOneAlnLine($foundAln, $line);
	}
	my $mainSpeciesHit = $foundAln->{$mainSpecies};
# some alignment files may not have hits in the 'main' species so also check if
# any hits were found in another species
	if (!exists($mainSpeciesHit->[SITE]) ) {
		my $foundDbs = $foundAln->{'foundDbs'};
		foreach my $db (@$foundDbs) {
			my $species = dbToSpecies($db);
			my $hit = $foundAln->{$species};
			next unless ( exists($hit->[SITE]) ) ;
			$mainSpeciesHit = $hit;
			last;
		}
	}
# remaining alignment attributes require that at least one hit was found
	return $foundAln unless (exists($mainSpeciesHit->[SITE]) ) ;
# added option to filter by main species pair score, 3/8/04
	$foundAln = fixAlnPairs($foundAln, $option{'fixPairs'}) 
		if $option{'fixPairs'};
	if ($option{pairs}) {
		my ($match, $misMatch, $remainder) = split "/", $mainSpeciesHit->[PAIRS];
		return 0 if  ($match - $misMatch) < $option{pairs} ;
	}
	$foundAln->{'site'} = $mainSpeciesHit->[SITE];
	$foundAln->{'targetRna'} = $mainSpeciesHit->[TARGETRNA];
	$foundAln->{'completeSite'} = completeSite($mainSpeciesHit); 
	$foundAln->{'id'} = $mainSpeciesHit->[NAME] . '|' . $foundAln->{'site'} ;
	$foundAln->{'stem'} = $mainSpeciesHit->[STEM];	
	$foundAln = getAnnotatedSeqs($foundAln)	if $option{'parseSeqs'};
	$foundAln = getHitSeqs($foundAln)	if $option{'parseSeqs'};
	return $foundAln ;
}	

######################
sub parseAllAlns {
	my ($inFile, $mainSpecies, %option)	 = @_;
	my ($alnList);
	my $inFh = getInFh($inFile);
  $/ = '##End_of_Alignment##';  		#slurp in record
  while (my $record = <$inFh>) {
    my $foundAln = parseOneAln($record, $mainSpecies, %option);
    push @$alnList, $foundAln
    	if ( ($foundAln && $foundAln->{'totalScore'}) || $option{'keepZeroScoreAlns'}) ;    	
#    push @$alnList, $foundAln if $foundAln;
  }
  $/ = "\n";			#back to normal mode
  close($inFh);
	return $alnList ;
}	

######################

sub getStemLimits {
	my ($annString, $stType) = @_;
	my ($type, $stem) = split //, $stType;
	my @limits = ();
	my @retLimits = ();
	while ($annString =~ /$type/g) {
		my $position = (pos $annString) - 1;
		push @limits, $position;
	}
#	throw("Could not find 2 stems of type $type in annotation string:\n$annString") 
#		unless ((scalar(@limits) == 8) || (scalar(@limits) == 6) ||
#		(scalar(@limits) == 4)); # 1 stem hit
	if (scalar(@limits) == 8) {
		@retLimits = ($stem eq '5') ? @limits[0..3] : @limits[4..7];
	} elsif (scalar(@limits) == 4) {  # 1 stem hit
		@retLimits = @limits;	
	} elsif (scalar(@limits) == 6) { # 6 'X's found => either X3 stem or X5 stem has only 1 'X'		
		if ($annString =~ /^[-]*X[- \d]+X/ ) { 
			@retLimits = ($stem eq '5') ? @limits[0..3] : ($limits[4], $limits[4], $limits[5],$limits[5]);	#single X in 3' stem
		} else {
			@retLimits = ($stem eq '5') ? ($limits[0], $limits[0], $limits[1],$limits[1]) : @limits[2..5];	#single X in 5' stem
		}
	} else {
		throw ("Could not parse $stType stem limits for annotation:\n$annString\n");
	}
	return \@retLimits;	
}

######################
sub stemLength {
	my ($annString, $limits) = @_;
	my ($stStart, $stEnd) = @$limits[0,1];
	my @annString = split //, $annString;
	my $length = grep {$_ ne '-'} @annString[$stStart..$stEnd];
	return $length;
}


1;

__END__

######################

######################
sub parseOneAln {
	my ($record, $mainSpecies, %option)	 = @_;
	my ($foundAln);
	$foundAln->{'record'} = $record;	
	$foundAln = parseTotalScores($foundAln, $record);
#	if ($record =~ /Total\s+aln\s+score\s+=\s+([\d\.]+)/ ) {
#			$foundAln->{'totalScore'} = $1;
#	} else {
#			$foundAln->{'totalScore'} = 0;
#	}
	return 0 if ( filterScoreAndRegexp($record, $foundAln->{'totalScore'}, %option) == 0);
	my @lines = split "\n", $record;
	foreach my $line (@lines) {
		$foundAln = parseOneAlnLine($foundAln, $line);
	}
# some alignment files may not have hits in the 'main' species so also check if
# any hits were found in another species
	my $mainSpeciesHit = $foundAln->{$mainSpecies};
	unless (exists($mainSpeciesHit->[SITE]) ) {
		if ( exists($foundAln->{'hg'}->[SITE]) ) {
			$mainSpeciesHit = $foundAln->{'hg'}
		} elsif ( exists($foundAln->{'mm'}->[SITE]) ) {
			$mainSpeciesHit = $foundAln->{'mm'}
		} elsif ( exists($foundAln->{'rn'}->[SITE]) ) {
			$mainSpeciesHit = $foundAln->{'rn'}
		} else { # give up
			return 0;
		}
	}
# added option to filter by main species pair score, 3/8/04
	$foundAln = fixAlnPairs($foundAln, $option{'fixPairs'}) 
		if $option{'fixPairs'};
	if ($option{pairs}) {
		my ($match, $misMatch, $remainder) = split "/", $mainSpeciesHit->[PAIRS];
		return 0 if  ($match - $misMatch) < $option{pairs} ;
	}
	$foundAln->{'site'} = $mainSpeciesHit->[SITE];
	$foundAln->{'targetRna'} = $mainSpeciesHit->[TARGETRNA];
	$foundAln->{'completeSite'} = completeSite($mainSpeciesHit); 
#	$foundAln->{'completeSite'} = $mainSpeciesHit->[TARGETRNA] . 
#																".U" . $mainSpeciesHit->[SITE];
	$foundAln->{'id'} = $mainSpeciesHit->[NAME] . '|' . $foundAln->{'site'} ;
	$foundAln->{'stem'} = $mainSpeciesHit->[STEM];	
	$foundAln = getAnnotatedSeqs($foundAln)	if $option{'parseSeqs'};
	$foundAln = getHitSeqs($foundAln)	if $option{'parseSeqs'};
	return $foundAln ;
}	
