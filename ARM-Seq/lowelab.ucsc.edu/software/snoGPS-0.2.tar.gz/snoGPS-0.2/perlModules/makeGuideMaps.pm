#!/usr/local/bin/perl -w

package makeGuideMaps;
use strict;
use English;
use lib $ENV{MYPERLMODULEDIR}; 
#use lib $ENV{CPANLOCALDIR};
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES &completeSite &parseAllHits &getSeq &makeAnnString);
use parseAlns qw(&parseAllAlns &getAnnotatedSeqs &getStemLimits &stemLength &getHitSeqs);
use parseTargets qw(&parseAllTargs &parseOneTarg);
use common;

use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT = qw();
	@EXPORT_OK = qw(&makeGuideMaps);
	%EXPORT_TAGS = ( );
}	   

######################
sub getMotifLimits {
	my ($annString, $t) = @_;
# $t is single letter (ie 'L' or 'R' or 'A' or 'H' or 'C')
	my @allowedTypes = ('L','R','A','H','C');
	throw ("Unknown guide type $t\n") 
		unless (grep {$t eq $_} @allowedTypes) ; 	
	if ($annString =~ /($t)[$t ]*$t/i) {  # lower case 'r' or 'l' indicates guide mismatch
		my $motifStart = length $PREMATCH;
		my $motifEnd = $motifStart + (length $MATCH) -1;
		return ($motifStart,$motifEnd);
	} elsif ($t eq 'H' || $t eq 'C' ){
		return getMotifLimits($annString, 'A');  # 'H' or 'C' may be replaced with 'A'
	} else {
		throw ("Could not find symbol $t in annotation string:\n$annString\n"); 
	}
}

######################
sub getGuide {
	my ($annString, $type, $seq) = @_;
	my ($guideStart, $guideEnd) = getMotifLimits($annString, $type);
	my $guideLen = $guideEnd - $guideStart + 1;
	return substr($seq, $guideStart, $guideLen);
}

######################
sub getHaca {
	my ($annString, $hairpin, $seq, $length) = @_;
	my @types = $hairpin == 5 ? ('H', 'A') : ('C', 'A');
	foreach my $type (@types) {
		my ($hacaStart, $hacaEnd) = getMotifLimits($annString, $type);
		next unless $hacaEnd;
		return substr($seq, $hacaStart, $length);
	}
	throw ("Could not find hairpin $hairpin HACA motif in annotation string:\n$annString\n");
}

######################
sub padLine {
	my ($line, $maxLen, $noPad) = @_;
# pad $line with spaces to length $maxLen add a \n and return
	chomp $line; # remove \n if necessary
	return "$line\n" if $noPad; # do nothing if $noPad set
	my $lineLen = length $line;
	my $spaces = ($maxLen - $lineLen) > 0 ? ' ' x ($maxLen - $lineLen) : '';
	$line .= "$spaces\n";
	return $line;
}

######################
sub makeLoop{
	my ($spacesNum, $maxLen, $noPad) = @_;
	my $spaces = ' ' x $spacesNum;
	my $spacesMinus1 = ' ' x ($spacesNum - 1);
	my $outString = padLine( "$spaces---", $maxLen, $noPad);
	$outString .= padLine( $spacesMinus1 . q(/   \\), $maxLen, $noPad);
	$outString .= padLine( $spacesMinus1 . q(\   /) , $maxLen, $noPad);
	return $outString;
}

######################
sub mapIstem{
	my ($istemA, $istemB, $lGuideLen, $spacesNum, $maxLen, $noPad ) = @_;
	my $spaces = ' ' x ($lGuideLen + 1);
	my $outString = makeLoop($spacesNum + $lGuideLen + 1, $maxLen, $noPad );
	my $symbol;
	my @istemA = reverse split //, $istemA;
	my @istemB = split //, $istemB;
	my $inSpace = ' ' x $spacesNum;
	for (my $i = 0; $i < length $istemA; $i++) {
		my $compVal = ($istemA[$i] eq ' ') || ($istemB[$i] eq ' ') ?
			-1 : compSingle($istemA[$i], $istemB[$i]);
		if ($compVal == 1 ) {
			$symbol = '-';
		} elsif ($compVal == .5 ) {
			$symbol = '.';
		} else {
			$symbol = ' ';
		}
		$outString .= padLine($inSpace. $spaces . $istemA[$i] . $symbol . $istemB[$i], $maxLen, $noPad);
	}
	return $outString;
}


######################
sub mapGuideTargMatches{
	my ($leftGuide, $rightGuide, $leftTarg, $rightTarg) = @_;
	my ($lMatch, $rMatch);
	for my $guide ($leftGuide, $rightGuide) {
		my $targ = $guide eq $leftGuide ? $leftTarg: $rightTarg;
		my $match = '';
		my @guide = split //, $guide;
		my @targ = split //, $targ;
		for (my $i = 0; $i < length $guide ; $i++) {
			my $compVal = compSingle($guide[$i], $targ[$i]);
			if ($compVal == 1 ) {
				$match .= '|';
			} elsif ($compVal == .5 ) {
				$match .= '.';
			} else {
				$match .= ' ';
			}
		}
		if ($guide eq $leftGuide) {
			$lMatch = $match;
		} else {
			$rMatch = $match;
		}		
	}
	return "$lMatch    $rMatch";
}

######################
sub parseTargSeq{
	my ($targSeq, $lGuideLen, $rGuideLen) = @_;
	$targSeq = reverse($targSeq);
	my ($leftTarg, $rightTarg) = split /Y/, $targSeq;
	$rightTarg = substr($rightTarg, 0, $rGuideLen);
	my $lastLeft = chop $leftTarg;  # split off final character
	my $targ = "$lastLeft" . 'Y';
	$leftTarg = substr($leftTarg, -1 * $lGuideLen, $lGuideLen);
	return ($leftTarg, $targ, $rightTarg)
}

######################
sub formatSpaces {
	my ($startPos) = @_;
	my $spacesNum = 9;
	if ( $startPos < 10 ) {
		$spacesNum = 7;
	 } elsif ( $startPos < 100 ) {
		$spacesNum = 8;
	 } 
	 return $spacesNum;
}

######################
sub motifInterval {
	my ($annString, $typeA, $typeB) = @_;
	my ($aStart, $aEnd) = getMotifLimits($annString, $typeA);
	my ($bStart, $bEnd) = getMotifLimits($annString, $typeB);
	return ($bStart >= $aStart) ? 
		$bStart - $aEnd:
		$aStart - $bEnd;
}		 

######################

sub calcIndel {
# Need to insert space(s) in graphic if there are unequal length indels at two 
# sides of stem base
	my ($annString, $lGuideEnd, $rGuideStart, $hairpin) = @_;
	my $limits = getStemLimits($annString, "I$hairpin");
	my $aStart = $limits->[0];
	my $bEnd = $limits->[3];
	my $leftIndelLen = $aStart - $lGuideEnd - 1;
	my $rightIndelLen = $rGuideStart - $bEnd - 1;
	return $rightIndelLen - $leftIndelLen;
}

######################
sub getAdjacentStem {
	my ($annString, $seq, $length, $hairpin) = @_;
	my ($lGuideStart, $lGuideEnd) = getMotifLimits($annString, 'L');
	my ($rGuideStart, $rGuideEnd) = getMotifLimits($annString, 'R');
	my $istemA = substr $seq, $lGuideEnd + 1,  $length;
	my $istemB = substr $seq, $rGuideStart - $length,  $length;
	my $indelDif = calcIndel($annString, $lGuideEnd, $rGuideStart, $hairpin);
	if ($indelDif > 0 ) {
		$istemA = substr($istemA, 0, $length - $indelDif);
		$istemA = ' ' x $indelDif . $istemA;
	} elsif ($indelDif < 0 ) {
		$istemB = substr($istemB, -$indelDif, $length + $indelDif );
		$istemB .= ' ' x -$indelDif;
	} 			
	return ($istemA, $istemB);
}

######################
sub makeGuideMap {
# builds and returns the guide map (padded with spaces wo all lines are the same length
	my ($hdrLine, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
			$istemB, $guideHacaDist,$lGuideStartPos, $noPad) = @_;
	my $guideLine = "5'-(N$lGuideStartPos)$lGuide    $rGuide(N$guideHacaDist)$haca";
	my $maxLen = length $hdrLine > length $guideLine ? length $hdrLine : length $guideLine ;
	my $outString = padLine($hdrLine, $maxLen, $noPad) ;
	my $lGuideLen = length $lGuide;
	my $rGuideLen = length $rGuide;
	my $spacesNum = formatSpaces($lGuideStartPos);  # calculate spaces for formatting
	my $inSpace = ' ' x $spacesNum;
	my ($leftTarg, $targ, $rightTarg) = parseTargSeq($targSeq, $lGuideLen, $rGuideLen);
# Istem line padding done internally
	$outString .=  mapIstem($istemA, $istemB, $lGuideLen, $spacesNum, $maxLen, $noPad );
	$outString .= padLine($guideLine, $maxLen, $noPad);
	$outString .= 
          padLine($inSpace . mapGuideTargMatches($lGuide, $rGuide, $leftTarg, $rightTarg), $maxLen, $noPad);	
	$outString .= padLine("$inSpace$leftTarg $targ $rightTarg", $maxLen, $noPad) ;
	return $outString;
}


######################
sub hitMakeGuideMap {
# builds and returns the guide map (padded with spaces wo all lines are the same length
	my ($hit, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
			$istemB, $guideHacaDist,$lGuideStartPos, %option ) = @_;
	my $name = $hit->[NAME];
  my $noPad = 0;
	$name =~ s/:.*/:/;
	my $hairpin = $hit->[STEM];
	my $hdrLine = "$name $hairpin\' stem   " . completeSite($hit) . " " . $hit->[SCORE];
	if ($option{showSeq}) {
		my $seq = getSeq($hit->[RECORD]);
		my $seqLen = length $seq;
		my $annSeq = makeAnnString($hit->[RECORD], $seqLen); 
		$hdrLine .= "\n$seq\n$annSeq\n";
		$noPad = 1;
	}
	return makeGuideMap($hdrLine, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
			    $istemB, $guideHacaDist,$lGuideStartPos, $noPad);
}	
######################
sub alnMakeGuideMap {
# builds and returns the guide map (padded with spaces wo all lines are the same length
	my ($aln, $mainSpecies, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
			$istemB, $guideHacaDist,$lGuideStartPos, %option) = @_;
        my $hit = $aln->{$mainSpecies};
        return hitMakeGuideMap($hit, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
				$istemB, $guideHacaDist,$lGuideStartPos, %option );
}	

######################
sub getGuideMotifs {
	my ($annString, $seq, $hairpin, %option ) = @_;
	my $length = $option{'istemLen'} || 4; # stem length  
	$seq =~ s/T/U/g;
	$annString =~ s/-//g;
	my $lGuide = getGuide($annString, "L", $seq);
	my $rGuide = getGuide($annString, "R", $seq);
	my ($lGuideStartPos, $lGuideEnd) = getMotifLimits($annString, "L");
	$lGuideStartPos--;	
	my ($istemA, $istemB) = getAdjacentStem($annString, $seq, $length, $hairpin);
	my $haca = getHaca($annString, $hairpin, $seq, 3);
 	my $guideHacaDist = $hairpin == 5 ? motifInterval($annString, "R", "H"): motifInterval($annString, "R", "C");
	return ($lGuide, $rGuide, $haca, $istemA, $istemB, $guideHacaDist,$lGuideStartPos);	
}

######################
sub oneAlnToGuideMap {
	my ($aln, $mainSpecies, $targHash, %option ) = @_;
#  	$foundIds{$name} = 1;
	my $hairpin = $aln->{$mainSpecies}->[STEM];
	my $seq = $aln->{$mainSpecies}->[SEQ];
	my $annString = $aln->{$mainSpecies}->[ANN_SEQ];
	my $targSeq = $targHash->{$aln->{'completeSite'}} || 
		throw("Could not retrieve target sequence for site: " . $aln->{'completeSite'} . "\n");
	my ($lGuide, $rGuide, $haca, $istemA, $istemB, $guideHacaDist,$lGuideStartPos) =
		getGuideMotifs($annString, $seq, $hairpin, %option );
	my $outString = 
		alnMakeGuideMap($aln, $mainSpecies, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
				$istemB, $guideHacaDist,$lGuideStartPos, %option);
	return $outString;
} 

######################
sub oneHitToGuideMap {
	my ($hit, $targHash, %option ) = @_;
	my $record = $hit->[RECORD];
	my $hairpin = $hit->[STEM];
	my $seq = getSeq($record);
	my $seqLen = length $seq;
	my $annString = makeAnnString($record, $seqLen);
	throw("Could not extract annotation string for record:\n$record\n") unless $annString;
	my $completeSite = completeSite($hit);
	my $targSeq = $targHash->{$completeSite} || 
#		$targHash->{'hg.' . $completeSite} || 		#default species
		throw("Could not retrieve target sequence for site: $completeSite\n");
	my ($lGuide, $rGuide, $haca, $istemA, $istemB, $guideHacaDist,$lGuideStartPos) =
		getGuideMotifs($annString, $seq, $hairpin, %option );
	my $outString = 
		hitMakeGuideMap($hit, $targSeq, $lGuide, $rGuide, $haca, $istemA, 
				$istemB, $guideHacaDist,$lGuideStartPos, %option );
	return $outString;
} 


######################
sub parseTargsToHash {
	my (%option) = @_;
	my %targHash;
	my $inFh = getInFh($option{targFile});
	while (1) {
  	my $targ = parseOneTarg($inFh, %option);
  	last unless $targ;
		my $id = $targ->{'type'} .	".U" . $targ->{'site'};
		my $seq = $targ->{'seq'};
		$targHash{$id} = $seq ;
	}
	return \%targHash;
}	

######################
sub alnsToGuideMaps {
	my ($inFile, $outFh, $targHash, %option) = @_;
  my $inFh = getInFh($inFile);
  my $mainSpecies = $option{mainSpecies};
# my %foundIds = ();
	my $alnList  = parseAllAlns($inFile, $mainSpecies, %option);
	$alnList || throw("Could not parse hit alignments in file $inFile\n");
	foreach my $aln (@$alnList) {
  	$aln = getAnnotatedSeqs($aln);
  	$aln = getHitSeqs($aln);
 		my $guideMap = oneAlnToGuideMap($aln, $mainSpecies, $targHash, %option );
 		print $outFh "$guideMap\n";
	}
}


######################
sub hitsToGuideMaps {
	my ($inFile, $outFh, $targHash, %option) = @_;
  my $inFh = getInFh($inFile);
	my ($hitList, $fileHdr)  = parseAllHits($inFile,%option);  
	$hitList || throw("Could not parse hits in file $inFile\n");
	foreach my $hit (@$hitList) {
  	my $guideMap = oneHitToGuideMap($hit, $targHash, %option );
 		print $outFh "$guideMap\n";
	}
}

######################
sub makeGuideMaps {
	my ($inFile, $outFile, %option) = @_;
	my $outFh = getOutFh($outFile);
  my $targHash = parseTargsToHash(%option);
	if 	($option{mainSpecies} ) {  # we're using alignments
		alnsToGuideMaps($inFile, $outFh, $targHash, %option);
	} else {
		hitsToGuideMaps($inFile, $outFh, $targHash, %option);
	}
}

1;

__END__

