#! /usr/local/bin/perl

package parseTargets;
use strict;
use Getopt::Std;
#use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT_OK = qw(&parseAllTargs &parseOneTarg);
	%EXPORT_TAGS = (
        			);
}	   

######################
sub targId {
	my($species, $type, $site) = @_;
	return  "$species.$type.U$site";
}

######################
sub parseOneTarg {
	my ($inFh, %option) = @_;
	my ($targ, $species);
	my %species = ('H_sapiens' => 'hg', 'M_musculus' => 'mm', 'R_norvegicus' => 'rn',
	'T_brucei' => 'tb');
	while (my $line = <$inFh> ) {
  	next if $line =~ /^\s*#/ ; # skip comments
		my ($targId, $targDesc, $prelength) = split " ", $line ;
		my ($speciesAndType, $site) = split /\.U/, $targId ;
		$site =~ /^\d+$/ 
			||	throw( "Could not parse site number $site in target file line:\n $line");
		$targ->{'site'} = $site;
		if ($speciesAndType =~ /(\w+)_([a-zA-Z0-9]+)$/ ) {	
			if ( exists $species{$1} ){	
				$targ->{'type'} = $2;
				$species =  $species{$1};
			} 
		}
		if (!$species) {
			$targ->{'type'} = $speciesAndType;
			$species =  'hg';  
		}
		$targ->{'id'} =  targId($species, $targ->{'type'},$site);
#		my $typeOk = grep { $targ->{'type'} eq $_ } ("LSU", "SSU", "5SU", "U1", "U2", "U5", "U6"); 
#		throw( "Could not parse target type in target file line:\n $line") unless $typeOk;
		last;
	}
	while (my $line = <$inFh> ) {
  	next if $line =~ /^\s*#/ ; # skip comments
	  my ($pattern) = $line =~ /^([ACGTUYN]+)$/;
		$pattern || throw("could not parse target pattern $line");
 		$targ->{'seq'} = $pattern;
 		last;
	}
	return $targ;
} 


######################
sub parseAllTargs {
	my ($inFile, %option) = @_;
	my $targList;
	my $inFh = getInFh($inFile);
	while (1) {
  	my $targ = parseOneTarg($inFh, %option);
  	last unless $targ;
    push @$targList, $targ;
  }
  close($inFh);
	return $targList;
} 



1;

__END__

