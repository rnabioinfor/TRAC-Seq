#!/usr/local/bin/perl -w

package runHomologs;
use strict;
use Getopt::Std;
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(&sortHits);
use runPuSetup qw(&runPuSeqObj);
#use runPuSetup qw(&runPuAndSortHits &runPuSeqObj);
use convertHits qw(&hitsToBed);
use annotatedAlign qw(&annotateOneAln &alignWithTcoffee &alignWithTcoffeeToFile);          
use common;
use hg qw(&bedLineToNibFrag &getSeqFromNib);
use Bio::SeqIO;
use Bio::Seq;
use Bio::AlignIO::maf;
use hhObjects::HACA_CandidateIO;
use constant BADSCORE => -100;

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	%option
	   );

BEGIN {
  use Exporter();
  @ISA = qw(Exporter);
  @EXPORT = qw();
  @EXPORT_OK = qw( &getTargFile &alignHomolObjs
  	&annoMafsForOneHit &runSeqSet  
  	&setUpOutFiles &setUpOutWithMafFiles
    &outputAnnAlign &getSeqFromHitRec 
    &removeGaps &updateTotScore &getbestHit &splitMafFile &parseMaf
    );
}	   

######################
sub removeGaps {
# Need to massage Seq data so that:
# 1. dashes are removed from the sequence
	my ($seqObj) = @_;
	my $id = $seqObj->id();
	my $seqString = $seqObj->seq;
	$seqString =~ s/-//g;
	return 0 unless $seqString;
	return Bio::Seq->new(-id=>$id, -seq=>$seqString);
}

######################
sub getTopHitFromFile {
	my ($allHitsFile) = @_;
	my $topHitFile = '/tmp/topHit.out';
	my %sortOption = ('topHitsOnly' => 1, 'fixPairs' => 1) ; # get top hit only & fix pair values
	sortHits($allHitsFile, $topHitFile, %sortOption);
	my $hitIo = HACA_CandidateIO->new($topHitFile);
	my $hit = $hitIo->next_hit;
  return $hit;  
} 

######################
sub getTopHitMultiTargetFromFile {
# return array of single highest scoring hit for each target
	my ($allHitsFile) = @_;
	my $topHitFile = '/tmp/topHit.out';
	my @allTopHits = ();
	my %sortOption = ('topHitsOnly' => 1, 'fixPairs' => 1) ; # get top hit only & fix pair values
	sortHits($allHitsFile, $topHitFile, %sortOption);
	my $hitIo = HACA_CandidateIO->new($topHitFile);
	while (my $hit = $hitIo->next_hit) {
		push @allTopHits, $hit;
	}
  return \@allTopHits;  
} 

######################
sub getSeqFromHitRec {
	my ($record) = @_;
	my $seqString;
	if ($record =~ /^([ACGTN]+)$/m ) {
		$seqString = $1;
	}
	return $seqString;
}
######################
sub updateTotScore {
	my ($bestHit, $totScore, $genomeCount, $id, %option) = @_ ;
	unless( $option{'skipChicken'} && ($id =~ /gg/i)  ) {
		$genomeCount++;
		$totScore += $bestHit->score if $bestHit;
	}  			
	return ($totScore, $genomeCount);
}

######################
#sub getBestHitMultiTargs {
#	my ($targFile, $seqObj, $targCount) = @_;
#	my %runOption = ($targCount && $targCount > 1) ? 
#		('targCount' => $targCount) : () ;
#	my $allHitsFile = runPuSeqObj($targFile, $seqObj, %runOption) ;
#	my $bestHit = getTopHitFromFile($allHitsFile);
#	return $bestHit;
#}

######################
sub getbestHit {
	my ($targFile, $seqObj, %option) = @_;
	my %runOption =  ('descriptor' => $option{descriptor}, 'scoretable' => $option{scoretable} ,
		'scoreMin' => $option{scoreMin}) ;
	my $allHitsFile = runPuSeqObj($targFile, $seqObj, %runOption) ;
	my $bestHit = getTopHitFromFile($allHitsFile);
	return $bestHit;
}

######################
sub runSeqSet {
	my ($seqObjs, $targFile, %option) = @_;
	my ($hits);
	my $totScore = 0;
	my $genomeCount = 0; # number of genomes represented in the alignment 
	foreach my $seqObj ( @$seqObjs) {
		my $id = $seqObj->id;	#save orig id
		my $bestHit = getbestHit($targFile, $seqObj, %option);
		($totScore, $genomeCount) = updateTotScore($bestHit, $totScore, $genomeCount, $id, %option);
		next unless $bestHit; 
		$hits->{$id} = $bestHit;
	}
	$totScore = $totScore/$genomeCount if $genomeCount; #return average of bestHit scores for all genomes
	return ($totScore, $hits);
}

######################
sub runSeqsForOneAln {
# return the a hash keyed by (a regexp of) the ids of the sequences of each sequence
# in the alignment whose value is the top scoring HACA_Candidate hit object for that sequence
# also returns the sum of the scores for all the hits
	my ($alnObj, $targFile, %option) = @_;
	my @noGapSeqs = ();
	foreach my $seqObj ( $alnObj->each_seq) {
		my $id = $seqObj->id;	#save orig id
		my $noGapObj = removeGaps($seqObj); 
		next unless $noGapObj; # sequence was only gap symbols
		push @noGapSeqs, $noGapObj;
	}
	return 0 unless $noGapSeqs[0];
	my ($score, $hits) = runSeqSet(\@noGapSeqs, $targFile, %option);
	return ($score, $hits); 
}  	   

######################
sub parseMafSeqname {
	my ($seqname) = @_;
	my ($db, $chromOrContig, $contigSubDir);		
	my $isContig = 0;
	if ( $seqname =~ /(hg|rn|mm|gg)(\d+)\.(chr|Contig)(\w*)(\w)$/i) {
		$db = $1.$2;
		$isContig = 1 if ( ($3 eq 'Contig') || ($3 eq 'contig') );
		$chromOrContig = $3.$4.$5;
		$contigSubDir = $5 if $isContig;
	}
	throw ("Could not parse mafline sequence name $seqname for db and chrom") unless $db;	
	return ($db, $chromOrContig, $isContig, $contigSubDir);	
}

######################
sub parseMaf {
	my ($mafRec) = @_;
	my %mafStruct = ( 'record' => $mafRec);
	my @mafLines = split /\n/, $mafRec;
	foreach my $mafLine (@mafLines) {
		my @line = split " ", $mafLine;
		if ($line[0] eq "a") {
			my @score = split "=", $line[1];
			$mafStruct{'score'} = $score[1];
		} elsif ($line[0] eq "s") {
			my ($lineType, $seqname, $mafStart, $len, $strand, $chromLen, $seqchar) 
	  		= split " ", $mafLine;
			my ($db, $chromOrContig, $isContig, $contigSubDir) = parseMafSeqname($seqname);
			push @{ $mafStruct{'dbs'} } , $db; # list of dbs represented in this maf
			$mafStruct{$db} =  "$db.$chromOrContig.$mafStart";
		}
	}
	return \%mafStruct;
}

######################
sub checkList {
	my ($mafStruct, $foundMafs) = @_ ;
	my $prevFound = 0;
	my @dbs = @{ $mafStruct->{'dbs'} };
	foreach my $db (@dbs) {
		my $seqId = $mafStruct->{$db};
		if (exists $foundMafs->{$seqId} ) {
			$prevFound = $seqId;
			last;
		}
	}
	return $prevFound;
}
	

######################
sub filterList {
	my ($mafStructs, $outFh ) = @_;
	my @filteredStructs;
	my $foundMafs;
	foreach my $mafStruct (@$mafStructs) {
		unless ($mafStruct->{'dbs'}) {
			print $outFh "Skipped Maf:\n", $mafStruct->{'record'}, "No dbs found \n\n";
			next;
		}
		my @dbs = @{ $mafStruct->{'dbs'} };
		my $prevFound = checkList($mafStruct, $foundMafs);
		if ($prevFound) {
			print $outFh "Skipped Maf:\n", $mafStruct->{'record'}, "\nDuplicate seq:\n", $prevFound, "\n\n";
			next;
		} else {
			foreach my $db (@dbs) {
				my $seqId = $mafStruct->{$db};
				$foundMafs->{$seqId} = 1;   
			}
			push @filteredStructs, $mafStruct;
		}
	}
	return \@filteredStructs;
}
	
######################
sub removeDups {
	my ($mafRecs, $outMafFile) = @_;
# maf records which contain identical chrom&starts need to be filtered out
# maf records of pruned sequences are logged to $outFileBase.maflog 
	my $outLogFile = $outMafFile . 'DupLog';
	my $outFh = getAppendFh($outLogFile);
	my @mafStructs = map { parseMaf($_) } @$mafRecs;
	@mafStructs = sort { $b->{'score'} <=> $a->{'score'} } @mafStructs;
	my $filteredStructs = filterList(\@mafStructs, $outFh );
	my @filteredMafs = map { $_->{'record'} } @$filteredStructs;
	close($outFh);
	return \@filteredMafs;
}

######################
sub splitMafFile {
# returns mafs and also writes them to outMafile after removing duplicates
	my ($mafSingle, $outMafFile) = @_;
	my $mafRecs;
	my $inFh = getInFh($mafSingle);
  $/ = "\n\n";  		#maf records are separated by empty lines
  while (my $record = <$inFh>) {
		push @$mafRecs, "$record\n";
  }
  $/ = "\n";			#back to normal mode
  close($inFh);
  $mafRecs = removeDups($mafRecs, $outMafFile) if $outMafFile ;
#  $mafRecs = removeDups($mafRecs, $outMafFile);
	return $mafRecs;
}

######################
sub extendOneMafSeq {
	my ($mafLine) = @_;
	my %oppStrand = ( '+' => '-', '-' => '+');
	my ($lineType, $seqname, $mafStart, $len, $strand, $chromLen, $seqchar) 
	  = split " ", $mafLine;
	my ($db, $chromOrContig, $isContig, $contigSubDir) = parseMafSeqname($seqname);
	my ($segStart, $segEnd, $strandSym, $revComp) = 
		Bio::AlignIO::maf::calcCoords($seqname, $mafStart, $len, $strand, $chromLen);
	chomp $seqchar;
	my %nibOption;  
	$nibOption{'extend'} = 20;   
#	$nibOption{'X'} = 20;   
	if ($revComp) {
		$seqchar = revComp($seqchar);
		$seqname =~ s/^C[01]_//; # remove the maf tag for revComped input seq
		$strand = $oppStrand{$strand};
	}
	$seqname .= ":$segStart-$segEnd$strandSym";  # convert id to id:segStart-segEnd[WC]
	my $bedLine = bedBuild($seqname,  $chromOrContig, $strand, $segStart, $segEnd);
	my $seq = getSeqFromNib($bedLine, $db, $isContig, $contigSubDir, %nibOption );
	return 0 unless $seq;
	my $seqString = uc $seq->seq;
#	print STDERR "Retrieved seq:\n$seqString\n"; # debug	
	$seq = new Bio::Seq('-seq'=>$seqString,
				'-id'=>$seqname,
				'-start'=>1,
				'-end'=>$len,
				'-strand'=>$strand,
				);
	return $seq;
}


######################
sub alignHomolObjsToFile {
	my ($seqObjs) = @_;
	my $count = 0;
	my $faSeqs = '/tmp/seqsToAln.fa';
	my $outSeqio =  Bio::SeqIO->new('-format' => 'fasta', '-file'=> ">$faSeqs"); 
	foreach my $seqObj (@$seqObjs) { 
		$outSeqio->write_seq($seqObj); 
		$count++;
	}
	$outSeqio->close;
	return 0 unless ($count > 1); # can't align one seq
	my $alignedSeqFile = alignWithTcoffeeToFile($faSeqs);
	return $alignedSeqFile;
}


######################
sub alignHomolObjs {
	my ($bestSeqObjs) = @_;
	my $alignedSeqFile = alignHomolObjsToFile($bestSeqObjs);
	return 0 unless $alignedSeqFile;  
	my $alnIo = Bio::AlignIO->new( '-format' => 'clustalw', '-file' => $alignedSeqFile);
	my $bestAln = $alnIo->next_aln;
	if (!$bestAln) {
		my $string = " Could not create tcoffee alignment for seqs:\n";
		foreach my $seqObj (@$bestSeqObjs) {
			$string .= $seqObj->id ."\n";
		}
		stackWarn("$string\n");
		return 0;
	}
	return $bestAln;
}

######################
sub mafLineToSeqObj {
	my ($mafLine, $noGaps) = @_;
	my ($lineType, $seqname, $mafStart, $len, $strand, $chromLen, $seqString) 
	  = split " ", $mafLine;
	$seqString =~ s/-//g if $noGaps;
	my $seq = new Bio::LocatableSeq('-seq'=>$seqString,
				'-id'=>$seqname,
				'-start'=>1,
				'-end'=>$len,
#				'-strand'=>$strand,
				);
	return $seq;
}


######################
sub makeSeqObjs {
	my ($mafRec, %option) = @_;
	my ($seqObjs, $seqObj);
	my @mafLines = split /\n/, $mafRec;
	foreach my $mafLine (@mafLines) {
		next unless ($mafLine =~ /^s/);
		$seqObj = $option{'noMafExtension'} ? mafLineToSeqObj($mafLine, $option{'noGaps'}) : extendOneMafSeq($mafLine);
		push @$seqObjs, $seqObj if $seqObj;
	}
	return $seqObjs;
}

######################
sub mafRecToAlignObj {
	my ($bestMafRec) = @_;
	my %option = ('noGaps' => 0, 'noMafExtension' => 1) ;
	my $seqObjs = makeSeqObjs($bestMafRec, %option);
	my $aln = new Bio::AnnotatableAlign();
	foreach my $seq (@$seqObjs) {
		$aln->add_seq($seq);
	}
	return $aln;
}

######################
sub makeAlignObj {
	my ($bestSeqObjs, $bestMafRec, %option) = @_;
	my $alignObj = $option{'noMafExtension'} ? mafRecToAlignObj($bestMafRec) : alignHomolObjs($bestSeqObjs) ;
	return $alignObj;
}

######################
sub annoMafsForOneHit {
# $mafSingle may contain multiple maf alignments of the single candidate hit sequence
# this routine tries all of them in HH and returns the one with the highest overall score
	my ($mafSingle, $targFile, $outMafFile, %option) = @_;
	my $bestScore = BADSCORE ;  # initialize for a 'bad score'
	my ($bestHits, $bestSeqObjs, $bestMafRec);
	my $header = ''; my $resultString = '';
	my $mafRecs = splitMafFile($mafSingle, $outMafFile);
	return 0 unless $mafRecs;
	$option{'noGaps'} = 1;
	foreach my $mafRec (@$mafRecs) {
		my $seqObjs = makeSeqObjs($mafRec, %option);
#		my $seqObjs = extendSeqsFromMafRec($mafRec, %option);
		my ($score, $hits) = runSeqSet($seqObjs, $targFile, %option);
		next if ( $score <= $bestScore ) ;
		$bestHits = $hits;
		$bestScore = $score;
		$bestSeqObjs = $seqObjs;
		$bestMafRec = $mafRec;
	}
	return 0 if ($bestScore == BADSCORE );  # no hits found
	my $bestAln = makeAlignObj($bestSeqObjs, $bestMafRec, %option) || return 0; # alignment failed			
#	my $bestAln = alignHomolObjs($bestSeqObjs) || return 0; # alignment failed			
 	foreach my $genomeId (sort keys %$bestHits) {
 		my $hit = $bestHits->{$genomeId};
 		next unless $hit;
  	my $hitSeq = getSeqFromHitRec($hit->record) ||
  		throw("Could not parse sequence for record:\n" . $hit->record . "\n") ;
 		print STDERR $hit->header , "\n$hitSeq\n" ; # for debug
 		$header .= $hit->header ."\n$hitSeq\n" ;
  	$resultString .= $hit->record ."\n";
  	my $alignAnn = $hit->align_hit_annotation($bestAln, $genomeId);
 		$bestAln->add_initial_seq($alignAnn) if $alignAnn;
 	}
  $bestAln->match;
	return ($header, $bestAln, $bestScore, $resultString);
}	

######################
sub setUpOutFiles {
	my ($infile, $outFileRoot, $outHomolHitFile) = @_;
	my ($inDir, $inBase) = getDirAndBase($infile);
	$outFileRoot ||= $inBase; 
	$outFileRoot = "$inDir/$outFileRoot";
	my $outAlnFile = "$outFileRoot.aln";
	unlink $outAlnFile;
	my $outFh = getAppendFh( $outAlnFile);
	$outHomolHitFile ||= 	"$outFileRoot.homolHits"; # set default			
	my $homolFh = getOutFh( $outHomolHitFile);				
	my $alignIoOut  = Bio::AlignIO->new( '-format' => 'clustalw', '-fh' => $outFh) ;
	return ($outFh, $alignIoOut, $homolFh, $outFileRoot);
}

######################
sub setUpOutWithMafFiles {
	my ($infile, $outFileBase, $outHomolHitFile) = @_;
	my ($outFh, $alignIoOut, $homolFh, $outFileRoot) = 
		setUpOutFiles($infile, $outFileBase, $outHomolHitFile);
	my $outMafFile = "$outFileRoot.maf";
	return ($outFh, $alignIoOut, $homolFh, $outMafFile);
}

######################
sub outputAnnAlign  {
	my ($outFh, $alignIoOut,$homolFh, $annAlign ) = @_;
	my ($header, $alnHomol, $bestScore, $resultString ) = @$annAlign;
	print $homolFh "$resultString\n";
	print $outFh "$header\n";
	$bestScore = sprintf "%.2f", $bestScore;
	print $outFh "##Total aln score = $bestScore ##\n";  		
  eval { $alignIoOut->write_aln($alnHomol); } ;
  stackWarn("$@\n for $header\n$resultString") if $@;
	print $outFh "##End_of_Alignment##\n";  		
}

1;

__END__

######################
sub alignHomolObjs {
	my ($bestSeqObjs) = @_;
	my $count = 0;
	my $faSeqs = '/tmp/seqsToAln.fa';
	my $outSeqio =  Bio::SeqIO->new('-format' => 'fasta', '-file'=> ">$faSeqs"); 
	foreach my $seqObj (@$bestSeqObjs) { 
		$outSeqio->write_seq($seqObj); 
		$count++;
	}
	$outSeqio->close;
	return 0 unless ($count > 1); # can't align one seq
	my $alnIo = alignWithTcoffee($faSeqs);
	my $bestAln = $alnIo->next_aln;
	if (!$bestAln) {
		my $string = " Could not create tcoffee alignment for seqs:\n";
		foreach my $seqObj (@$bestSeqObjs) {
			$string .= $seqObj->id ."\n";
		}
		stackWarn("$string\n");
		return 0;
	}
	return $bestAln;
}
######
######################
sub extendSeqsFromMafRec {
	my ($mafRec, %option) = @_;
	my ($seqObjs);
	my @mafLines = split /\n/, $mafRec;
	foreach my $mafLine (@mafLines) {
		next unless ($mafLine =~ /^s/);
		my $seqObj = extendOneMafSeq($mafLine);
		push @$seqObjs, $seqObj if $seqObj;
	}
	return $seqObjs;
}
