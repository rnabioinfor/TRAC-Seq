#! /usr/local/bin/perl

package newtrain;
use strict;
#use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;

use vars qw(
	@ISA @EXPORT_OK 
	   );

my %freq;
my %A_base_freqs; 
my %C_base_freqs; 
my @BASES;
my $Nat_to_bit_conv;
my ($id,  $IStemMisp, $CompSeq);
#my ($line, $id,  $IStemMisp, $CompSeq);
my ($L_IStemSeq, $L_XStemSeq,	$rRNASeq, $R_IStemSeq, $R_XStemSeq, $HACASeq);
my ($HSeq, $ACASeq); 
my (%GapL, $XStem_Hlengths);
my ($unique_sites); 
#my ($unique_sites,$include_redundant_sites, $site_number); 
my ($gap, $compl, $istem, $istem_start, $xstem, $xstem_start); 
my ($HACA_RC, $POST_ACA, $xstem_H , $HACA1_istemR , $HACA2_istemR);
my ($compl_match , $istem_match, $xstem_match, $H_pattern, $ACA_pattern, $HACA_RC_B);
my @adjustable_features;
my $data_initialization;

#######################################
#
#  Initializations
#########################################
BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT_OK = qw(&trainSnos);

# Global Yeast genome frequencies 
  %A_base_freqs = (
    'Afulg' => 0.26 ,    
    'Scerev' => 0.31 ,
    'Susolf' =>  0.32 ,
    'Sutokod' =>  0.33 ,
    'Mjann' =>  0.34 ,
    'Mmazei' =>  0.29 ,
    'Maceti' =>  0.28 ,
    'Pabyssi' =>  0.28 ,
    'Pfuri' =>  0.30 ,
    'Phori' =>  0.29 ,
    'Hsp' =>  0.16 ,
    'Pae' =>  0.245 ,
); 
# Explicit base frequency for species where %C != 0.5 - %A
  %C_base_freqs = (
    'Sutokod' =>  0.16 ,
); 
  @BASES = ('A', 'C', 'G', 'U');
  $Nat_to_bit_conv = 1.443;
  $gap = { 'min' => 30, 'max' => 200, 'binsize' => 10, 'name' => 'Gap-Length', 'data' => {}, 'flags' => 'g10' };
  $compl = { 'min' => 7, 'max' => 20, 'binsize' => 1, 'name' => 'Compl-region-length', 'data' => {}, 'flags' => 'g1' };
  $istem = { 'min' => 4, 'max' => 10, 'binsize' => 1, 'name' => 'IntStem-length', 'data' => {}, 'flags' => 'g1' };
  $istem_start = { 'min' => -3, 'max' => 3, 'binsize' => 1, 'name' => 'IntStem-Start-Position', 'data' => {}, 'flags' => '' };
  $xstem = { 'min' => 1, 'max' => 10, 'binsize' => 1, 'name' => 'ExtStem-length', 'data' => {}, 'flags' => 'g1' };
  $xstem_start = { 'min' => -3, 'max' => 3, 'binsize' => 1, 'name' => 'ExtStem-Start-Position', 'data' => {}, 'flags' => '' };
  $HACA_RC = { 'min' => 13, 'max' => 20, 'binsize' => 1, 'name' => 'HACA-RCompStart-length', 'data' => {}, 'flags' => 'f8' };
  $POST_ACA = { 'min' => 0, 'max' => 12, 'binsize' => 1, 'name' => 'POST-ACA-U-freqs', 'data' => {}, 'flags' => 'z2g1' };
  $xstem_H = { 'min' => 10, 'max' => 140, 'binsize' => 10, 'name' => 'XStem-H-length', 'data' => {}, 'flags' => 'g10' };
  $HACA1_istemR = { 'min' => 13, 'max' => 20, 'binsize' => 1, 'name' => 'HACA1-IStemR-length', 'data' => {}, 'flags' => '' };
  $HACA2_istemR = { 'min' => 13, 'max' => 20, 'binsize' => 1, 'name' => 'HACA2-IStemR-length', 'data' => {}, 'flags' => '' };
  $compl_match = { 'name' => 'Compl_region', 'data1' => {}, 'data2' => {}, 'flags' => '' };
  $istem_match = { 'name' => 'IntStem', 'data1' => {}, 'data2' => {}, 'flags' => 'y1' };
  $xstem_match = { 'name' => 'ExtStem', 'data1' => {}, 'data2' => {}, 'flags' => 'y1' };
  $H_pattern = { 'name' => 'HPosition', 'data' => {}, 'flags' => 'z4' };
  $ACA_pattern = { 'name' => 'ACAPosition', 'data' => {}, 'flags' => 'z4' };
# $HACA_RC_B is temporary auxiliary variable for storing interval data for double-guide snos
  $HACA_RC_B = {'data' => {}, };
  @adjustable_features = ($gap, $compl, $istem, $xstem, $istem_match, $xstem_match, $POST_ACA, $H_pattern,
                           $HACA_RC, $xstem_H, $ACA_pattern);
}

####################################
#
#  Subroutines
##############################

sub Numerically { $a <=> $b}

# The "laplace regularizer" simply adds a 
# "pseudocount" of 1 to each bin 
# Returns reference to modified hash
sub laplace_regularizer {
    my ( $hash_ct) = @_;
    my ( $key);
    foreach $key ( keys %$hash_ct ) {
	$hash_ct->{$key} += 1;
    }  
    return $hash_ct;
}


sub Symmetrize {
# symmetrizes a square array represented as a 2 level hash
    my ( $hash, $feature) = @_;
    my ( $row_key, $column_key, $symmetric_hash);
    foreach $row_key  (keys %$hash) {
	foreach $column_key (keys  %{$hash->{$row_key}}) {
	    unless (defined $hash->{$row_key}->{$column_key} &&
                    defined $hash->{ $column_key}->{$row_key} ) {
		die "Hash-matrix ", $feature->name, " is not square.  Dying... \n";
	    }
	    $symmetric_hash->{$row_key}->{$column_key} = ($hash->{$row_key}->{$column_key} + $hash->{$column_key}->{$row_key} ) / 2. ;
	}
    }
    return $symmetric_hash;
}



# The "multiplicative regularizer" replaces each zero value by a value equal
# to the smaller of '1' and the miminum non-zero value in the input hash (which might
# be less than one if the data has gone through smoothing 
# and each non-zero value by the original value times the specified multiplier 
# Returns reference to modified hash
sub Multiplicative_regularizer {
    my ( $hash_ct, $multipier, $min_value) = @_;
    my ( $key, $value);
    while ( ($key, $value) = each(%$hash_ct) ) {
	if ( $value == 0) {
	    $hash_ct->{$key} = &Min(1, $min_value) ;
	} else {
	    $hash_ct->{$key} *= $multipier;
	}	    
    }  
    return $hash_ct;
}

sub fact {
    my $n = shift;
    my $index;
    my $total = 1;
    for ($index = 1; $index <= $n; $index++) {
	$total *= $index;
    }
    return $total;
}

sub floor {($_[0] > 0) ? int($_[0]) : -int(-$_[0]) }
sub ceil  {($_[0] > 0) ? -int( -$_[0]) : int($_[0]) }
use constant inv_sqrt_2pi => 1 / sqrt(8 * atan2(1,1));

sub gaussian { # From Orwant 
	my ($x, $mean, $variance) = @_;
	return inv_sqrt_2pi *
		exp( -( ($x - $mean) ** 2) / (2 * $variance) ) /
		sqrt $variance;
}

#############
sub check_bins_for_zeros {
# Check that every bin in hash has non-zero value.  If not, 
# 'regularize' the count according to the selected method
	my ( $hash_ct, $check_zeros_value, $is_numeric ) = @_;
	my $outString = ''; 
	my ( @values, $min_val, $index);
	@values = sort Numerically (values %$hash_ct); 
	if ( $values[0] < 0 ) {
		die "Bin with negative count.  Dying...\n";
	} elsif  ( $values[0] > 0 ) {  # all bins positive, nothing to do
		return ($hash_ct, '');
	}
# if we got here there is a zero bin a we need to deal with it
	if ( $check_zeros_value == 0 ) {
		$hash_ct = laplace_regularizer($hash_ct); 
	} else {
# Need to find the minimum non-zero value in hash for Multiplicative_regularizer
		for ($index = 0; $values[$index] == 0; $index++) { }
		$min_val = $values[$index];
		$hash_ct = Multiplicative_regularizer($hash_ct, $check_zeros_value, $min_val ); 
	}
	$outString .= "# Values after regularizing for zero-values with parameter: $check_zeros_value\n";
	$outString .= Print_data($hash_ct, $is_numeric) ;
	return ($hash_ct, $outString);
}    

#############
sub sum_hash_values {
    my ($numeric_hash) = shift;
    my $sum = 0;
    foreach my $value (values %$numeric_hash) {
        $sum += $value;
    }
    return $sum   
    }
########
sub binomial {
    my ($maxval, $i, $prob)  = @_;
    my ($numerator, $denominator);
    $numerator = fact($maxval) * $prob**$i * (1 - $prob)**($maxval - $i);
    $denominator = fact($i) * fact($maxval - $i);
    return ($numerator / $denominator);
}
########
sub Skip_test {
    my ( $data_hash) = @_;
    foreach my $key (keys %$data_hash) {
	$data_hash->{ $key } = 0;
    } 
    return ($data_hash);
}
########
sub Print_data {
	my ($data_hash, $is_numeric) = @_;
	my $outString = ''; 
	my ( $bin, @bins, @values, $binIndex, $valueIndex, $index, $inc);
	my $bins_per_line = 15; # hard code for now
	if ($is_numeric) {
		@bins      = sort {$a <=> $b} keys %$data_hash;   # sort numerically
	} else {
		@bins      = sort  keys %$data_hash;   # sort alphabetically
	}
	for ($index = 0; $index <= $#bins; $index++) {
		$bin = $bins[$index];
		$values[$index] = $data_hash->{$bin}; # convert hash to array
	}
	$outString .= "#";
	$binIndex = 0;
	$valueIndex = 0;
	while ($binIndex <= $#bins ) {
		$bin = $bins[$binIndex];
		if ($is_numeric) {
	    $outString .= sprintf "%7d ",$bin; 
#	    printf ("%7d ",$bin); 
		} else {
	    $outString .= sprintf "%7s ",$bin; 	    
#	    printf ("%7s ",$bin); 	    
		}     
		if ( ($binIndex % $bins_per_line == $bins_per_line - 1) || # end of "bin line"
	     ($binIndex == $#bins )  )  {                          # OR last bin
	  	$outString .= "\n#"; 
			for ($inc = 0; $inc < $bins_per_line && $valueIndex <= $#bins; $inc++) { # output values
				$outString .= sprintf "%7.3f ", $values[$valueIndex];
#				printf ("%7.3f ", $values[$valueIndex]);
				$valueIndex++;
			}
			$outString .= "\n#";
		}
		$binIndex++;
	}                
	$outString .= "\n";
	return $outString;
}
########
sub ConvolveGaussian {
    my (  $feature, $index, $bins, $values, $variance) = @_;
    my   ($convolve_index) ;
    my   $numerator = 0;
    my   $denominator= 0;
    # for now hard-code relation between Gaussian variance and number of bins to sum over
    my  $bin_range = &Max(0 , floor ($variance/ $feature->{'binsize'}) ) ; 
    my ($start_convolve_index, $stop_convolve_index);
    my $number_of_bins = scalar(@$bins);
    $start_convolve_index = &Max( 0  , $index - $bin_range);
    $stop_convolve_index =  &Min( $number_of_bins - 1 , $index + $bin_range);
    for ($convolve_index = $start_convolve_index; $convolve_index <= $stop_convolve_index; $convolve_index++) {
	$numerator += gaussian($bins->[$index], $bins->[$convolve_index], $variance) * $values->[$convolve_index];
	$denominator += gaussian($bins->[$index], $bins->[$convolve_index], $variance);
    } 
    if ($denominator == 0 ) {
	die "Divide by zero in convolution...dying...\n";
    }
    return ($numerator / $denominator);
}
########
sub GaussianFilter {
	my ( $feature, $data_hash, $filter_value) = @_;
	my $outString = ''; 
	my    ($bin, $index, $filtered_data);
	my    @bins      = sort {$a <=> $b} keys %$data_hash;   # sort numerically
	my    @values;
	my $is_numeric = 1;
	for ($index = 0; $index <= $#bins; $index++) {
		$bin = $bins[$index];
		$values[$index] = $data_hash->{$bin}; # convert hash to array
	}
	$outString .= sprintf "# Gaussian Filtering using variance: $filter_value\n";
	for ($index = 0; $index <= $#bins; $index++) {
		$bin = $bins[$index];
		$filtered_data->{$bin} = ConvolveGaussian($feature, $index, \@bins, \@values, $filter_value);
	} 
	$outString .= Print_data($filtered_data, $is_numeric) ;
	return ($filtered_data, $outString);
}
########
sub ChangeFlags {
	my ( $feature, $flags) = @_;
	while ($flags =~ m/(\w)(\d*)/g) {
		my $option = $1;
		my $value = $2;
		$feature->{'flags'} =~ s/$option\d*//; #erase old value
		$feature->{'flags'} .= $option . $value; # add new value
	}
}
########
sub Filter {
	my ( $data_hash, $filter_value) = @_;
	my $outString = ''; 
	my    ($bin, $next_bin, $prev_bin, $index, $filtered_data);
  my $is_numeric = 1;
	my    @bins      = sort {$a <=> $b} keys %$data_hash;   # sort numerically
	$prev_bin = $bins[0];
	$bin = $bins[0];
	$outString .= sprintf "# Filtering using filter value: $filter_value\n";
	for ($index = 0; $index <= $#bins; $index++) {
		if ($index == $#bins) {
	    $next_bin = $bins[$index] ; 
		} else {
	    $next_bin = $bins[$index + 1] ; 
		}  
		$filtered_data->{$bin} = $filter_value * $data_hash->{$bin} + $data_hash->{$next_bin} + $data_hash->{$prev_bin} ;
		$filtered_data->{$bin} /= ($filter_value + 2);
		$prev_bin = $bin;
		$bin = $next_bin;
	} 
	$outString .= Print_data($filtered_data, $is_numeric) ;
	return ($filtered_data, $outString);
}
########
sub Interpolate {
    my ( $data_hash, $interpolation_value) = @_;
	my $outString = ''; 
    my ($bin, $i, $newbin, $interpolated_data, $nextbin, $index);
    my $is_numeric = 1;
    my  @bins  = sort {$a <=> $b} keys %$data_hash;   # sort numerically
    my  $binsize = $bins[1] - $bins[0];
    unless ( $binsize % $interpolation_value == 0) {
	die ( " Sorry, Buddy, but binsize, $binsize, is not exact multiple of interpolation_value, $interpolation_value.\n");
    }
    $outString .= sprintf "# Interpolating using interpolate value: $interpolation_value\n";
    my $newbinsize = $binsize / $interpolation_value;
    
    for ($index = 0; $index < $#bins; $index++) {
	$bin = $bins[$index];
	$nextbin = $bins[$index + 1];
	foreach $i (0..$interpolation_value-1) {
	    $newbin = $bin + $i * $newbinsize;
	    $interpolated_data->{$newbin} = ($interpolation_value - $i) * $data_hash->{$bin} +
		$i * $data_hash->{$nextbin} ;
	    $interpolated_data->{$newbin} /= $interpolation_value ;
	}
    }
# need to copy of value of very last data bin
    $interpolated_data->{$bins[$#bins]} = $data_hash->{ $bins[$#bins]};
    $outString .= Print_data($interpolated_data, $is_numeric) ;    
    return ($interpolated_data, $outString);    
}
########
sub SmoothData {
	my ($feature, $length_ct) = @_;
	my $outString; 
	my $retString;
	my  $check_zeros_value ; 
	my $is_numeric = 1;
	if ( $feature->{'flags'} =~ /g(\d+)/ && ($1 != 0) ) {  # triangular (f)ilter flag if set and non-zero
		my $filter_value = $1;
		($length_ct, $outString) = GaussianFilter( $feature, $length_ct, $filter_value);
	}  
	if ( $feature->{'flags'} =~ /f(\d+)/ && ($1 != 0) ) {  # (g)aussian kernal smoothing flag
		my $filter_value = $1;
		($length_ct, $outString) = Filter($length_ct, $filter_value);
	}  
	if ( $feature->{'flags'} =~ /i(\d+)/ && ($1 != 0) ) {  # (i)nterpolate flag
		my $interpolation_value = $1;
		($length_ct, $outString) = Interpolate($length_ct, $interpolation_value);
	}  
	if ( $feature->{'flags'} =~ /z(\d+)/ ) {  # handle-(z)eros flag
		$check_zeros_value = $1;
	} else {
		$check_zeros_value = 0;
	}      
	($length_ct, $retString)  = check_bins_for_zeros($length_ct, $check_zeros_value, $is_numeric);
	$outString .= $retString if $retString;
	return ($length_ct, $outString) ;
}    
########
sub Train_PairFreq  {
	my $feature = shift;
	my $outString = ''; 
	my $Totals = {'A'=> 0,'C'=> 0,'G'=> 0,'U'=> 0, 'AU'=> 0, 'AU'=> 0,
                  'CG'=> 0,'GU'=> 0,'anymatch'=> 0,'mismatch'=> 0 };
	my $pair_totals = {};
	my $tot_ct = 0;
	foreach my $id (keys %{$feature->{'data1'}}) {
		$pair_totals =  PairFreqs($feature->{'data1'}->{$id}, $feature->{'data2'}->{$id});
		foreach my $key (keys %$Totals) {
	    $Totals->{$key} += $pair_totals->{$key};
		}   
		$tot_ct++;
	}    
	$outString .=  "## " . $feature->{'name'} . " pair-freq matrix 4x4 (A-A A-C A-G A-U) ($tot_ct snos)\n";
	$outString .= Write_Compl_Matrix($Totals, $feature);
  return $outString;
}
########
sub Train_Lengths  {
	my $feature = shift;
	my $outString = ''; 
	my ($length, $id, $array_length);
	my ($length_ct, %length_score, $smoothData);
	my $tot_ct = 0;
	my $is_numeric = 1;
	if ( $feature->{'flags'} =~ /b(\d+)/ ) {  # over-ride default (b)insize
		$feature->{'binsize'} = $1;
	}  
	for ($length = $feature->{'min'}; $length <= $feature->{'max'}; $length += $feature->{'binsize'}) {
		$length_ct->{$length} = 0; 
	}  
	foreach $id (keys %{$feature->{'data'}} ) {
		for ($length = $feature->{'min'}; $length <= $feature->{'max'}; $length += $feature->{'binsize'}) {
	    if ($feature->{'data'}->{$id} <= $length ) { 
				$length_ct->{$length} += 1;  
				$tot_ct++;
				last;
	    }
		}
	}
	$outString .= "## " . $feature->{'name'} . " matrix ($tot_ct snos)\n";
	$outString .= Print_data($length_ct, $is_numeric) ;    
#	$length_ct = SmoothData($feature, $length_ct);
	($length_ct, $smoothData)  = SmoothData($feature, $length_ct);
	$outString .= $smoothData;
	$tot_ct = sum_hash_values($length_ct); # "total count" normalization may be non-integer after filtering/interpolating
	foreach $length (sort Numerically keys %$length_ct) {
		$length_score{$length} = log($length_ct->{$length} / $tot_ct) * $Nat_to_bit_conv;
		if ( $feature->{'flags'} =~ /s/ ) {  # (s)kip_test flag
	    $length_score{$length} = 0 ; # set all scores = 0
		}
	#printf ("%7.3f ", $length_score{$length});
	}
	$outString .= Print_data(\%length_score, $is_numeric);
	$outString .= "\n\n";
# Output in format that can be read by pseudoU_test
	$array_length = keys %$length_ct;
	$outString .= sprintf "%s %d\n", $feature->{'name'} , $array_length;
#	printf ("%s %d\n", $feature->{'name'} , $array_length );
	foreach $length (sort Numerically keys %$length_ct) {
		$outString .= sprintf "%6d %.3f\n", $length, $length_score{$length};
#		printf ("%6d %.3f\n", $length, $length_score{$length});
	}
	$outString .= "\n\n";
  return $outString;
}
########
sub Train_SingleBaseFreq {
	my ( $feature, $position) = @_;
	my $outString = ''; 
	my $retString;
	my $count = {"A" => 0, "C" => 0, "G" => 0, "U" => 0};
	my $tot_ct = 0;
	my $scores = {"A" => 0, "C" => 0, "G" => 0, "U" => 0};
	my ($base, $seq, $name, $check_zeros_value );
	my $is_not_numeric = 0;
	foreach $seq (values %{$feature->{'data'}} ) {
		$base = substr($seq, $position, 1);
		($count->{$base})++;
		$tot_ct++;
	}
	$name = $feature->{'name'} . ($position +1) . 'Scores';
	$outString .=  "## $name Single-Base matrix 1x4 (A C G U) $tot_ct snos\n";
	$outString .=  "##\tA\tC\tG\tU\n";
	$outString .= sprintf "##\t%d\t%d\t%d\t%d\n", $count->{"A"}, $count->{"C"}, $count->{"G"}, $count->{"U"};
#	printf ("##\t%d\t%d\t%d\t%d\n", $count->{"A"}, $count->{"C"}, $count->{"G"}, $count->{"U"});
	if ( $feature->{'flags'} =~ /z(\d+)/ ) {  # handle-(z)eros flag
		$check_zeros_value = $1;
	} else {
		$check_zeros_value = 0;
	}      
	($count,$retString) = check_bins_for_zeros($count, $check_zeros_value, $is_not_numeric);
	$outString .= $retString if $retString ;
	$tot_ct = sum_hash_values($count); # "total count" normalization may be non-integer after filtering/interpolating
	foreach $base (sort keys %$count) {
		$scores->{$base} = ($count->{$base})/$tot_ct;
		$scores->{$base} /= $freq{$base};
		$scores->{$base}  = log($scores->{$base});
		$scores->{$base} *= $Nat_to_bit_conv;     
		$outString .= sprintf "\t%7.3f ", $scores->{$base};
#		printf ("\t%7.3f ", $scores->{$base});
	}
	$outString .= "\n";
  return $outString;
}
########
sub Train_Pattern_Frequencies {
	my ($feature, $char, $prob) = @_;    
	my $outString = ''; 
	my $count = 0;
	my $tot_ct = 0;
	my ($scores, $pattern, $number, $num_of_chars, $array_length, $random_scores, $smoothData) ;
	my $is_numeric =1;
# initialization of $scores
	for ($number = $feature->{'min'}; $number <= $feature->{'max'}; $number++) {
		$scores->{$number} = 0;
	}
	foreach $pattern (values %{$feature->{'data'}}) {
		$num_of_chars = ($pattern =~ s/$char/$char/gi);
		$scores->{$num_of_chars} += 1;
		$tot_ct++;
   }
  $outString .= "##" . $feature->{'name'} . " matrix ($tot_ct snos)\n#";
	$outString .= Print_data($scores, $is_numeric) ;    
	($scores, $smoothData) = SmoothData($feature, $scores);
	$outString .= $smoothData;
#	$scores = SmoothData($feature, $scores);
	$tot_ct = sum_hash_values($scores); # "total count" normalization may be non-integer after filtering/interpolating
	$outString .= "#";
	foreach $number (sort Numerically keys %$scores) {
		$random_scores->{$number} = binomial($feature->{'max'}, $number, $prob) ;
		$scores->{$number} = $scores->{$number} / $tot_ct ;	
		$scores->{$number} = $scores->{$number} / $random_scores->{$number}  ;
		$scores->{$number} = log($scores->{$number} ) * $Nat_to_bit_conv;
		$outString .= sprintf "%7.3f ",$scores->{$number} ;
#		printf ("%7.3f ",$scores->{$number} );
	}
	$outString .= "\n\n";
# Output in format that can be read by pseudoU_test
	$array_length = keys %$scores;
	$outString .= sprintf "%s %d\n", $feature->{'name'}, $array_length;
#	printf ("%s %d\n", $feature->{'name'}, $array_length );
	foreach $number (sort Numerically keys %$scores) {
		$outString .= sprintf "%6d %.3f\n", $number, $scores->{$number};
#		printf ("%6d %.3f\n", $number, $scores->{$number});
	 }
	$outString .= "\n\n";
	return $outString;
}
########
sub PairFreqs {
	my ($str1, $str2) = @_;   
	my $comp_len = length($str1);
	my $i;
	my $counts =  {'A'=> 0,'C'=> 0,'G'=> 0,'U'=> 0, 'AU'=> 0, 'AU'=> 0,
		   'CG'=> 0,'GU'=> 0,'anymatch'=> 0,'mismatch'=> 0 };
	for ($i=0; $i < $comp_len; $i++) {
    BASE_TEST:
		foreach my $base1 (@BASES) {
	    foreach my $base2 (@BASES) {
				my $base1_base2 = $base1.$base2;
				if ( (substr($str1,$i,1) eq $base1) && (substr($str2,$i,1) eq $base2) ) {
		    	$counts->{$base1}++;
		    	$counts->{$base2}++;
		    	if ($base1_base2 eq 'AU' || $base1_base2 eq 'UA' ) {
						$counts->{'AU'}++;
						$counts->{'anymatch'}++;
		    	} elsif ($base1_base2 eq 'GC' || $base1_base2 eq 'CG' ){
						$counts->{'CG'}++;
						$counts->{'anymatch'}++;
		    	} elsif ($base1_base2 eq 'GU' || $base1_base2 eq 'UG' ){
						$counts->{'GU'}++;
						$counts->{'anymatch'}++;
		    	} else {
						$counts->{'mismatch'}++;
		    	}
          last BASE_TEST;
				}		
	    }
		} # end of BASE_TEST	
  }
  return ( $counts);
}    
########
sub Write_Compl_Matrix {
	my ($Totals, $feature) = @_;
	my $outString = ''; 
    # Total counts for all compl observations
	my $total;
	my $odds_ratio = {};
	$outString .= "## Tot: $Totals->{'anymatch'}, GU: $Totals->{'GU'}, AU: $Totals->{'AU'}, ";
	$outString .= "GC: $Totals->{'CG'}, Mis: $Totals->{'mismatch'}\n";
 # First base is rRNA, second is query seq (e.g. in A-C comment below 
	foreach my $base1 (@BASES) {
		foreach my $base2 (@BASES) {
	    my $base1_base2 = $base1.$base2;
	    if ($base1_base2 eq 'AU' || $base1_base2 eq 'UA' ) {
				$total = $Totals->{'AU'};
	    } elsif ($base1_base2 eq 'GC' || $base1_base2 eq 'CG' ){
				$total = $Totals->{'CG'};
	    } elsif ($base1_base2 eq 'GU' || $base1_base2 eq 'UG' ){
				$total = $Totals->{'GU'};
	    } else {
				$total = $Totals->{'mismatch'};
	    }
# if no GUs, CGs, AUs or mismatches in feature, "regularize" number so it equals 1 
# so logarithm doesn't crash.
	    if ( $total == 0 ) {
				$total = 1;
				print STDERR ("# Total number of $base1_base2 pairs in feature ", $feature->{'name'}, 
				" = 0. Setting total = 1 so logarithm doesn't crash \n");
	    } 
	    $odds_ratio->{$base1}->{$base2} = $total/$Totals->{$base1}/$freq{$base2};
		}
	}
  if ( $feature->{'flags'} =~ /y[1-9]/ ) {  # s(y)mmetrize-array flag y0 means *don't* symmetrize
		$outString .= ("# Symmetrizing stem matrices...\n");
		$odds_ratio = Symmetrize($odds_ratio, $feature);
  }  
  foreach my $base1 (@BASES) {
		foreach my $base2 (@BASES) {
	    my $current_log_ratio = $odds_ratio->{$base1}->{$base2};
	    if ( $current_log_ratio) {
				$outString .= sprintf "%7.3f ", $Nat_to_bit_conv* log($current_log_ratio);
#				printf ("%7.3f ", $Nat_to_bit_conv* log($current_log_ratio));
	    } else {
				my $feature_name = $feature->{'name'};
				&throw("Odds ratio for base1 = $base1 and base2 = $base2 for feature $feature_name equals 0! Can\'t take log.\n\n");
	    }
		}
		$outString .= ("\n");
  }
  $outString .= ("\n");
  return $outString;
}

######################
sub Min {
    my ($a,$b) = @_;
    if ($a < $b) {
	return ($a); }
    else {
	return ($b); }
}

######################
sub Max {
    my ($a,$b) = @_;
    if ($a > $b) {
	return ($a); }
    else {
	return ($b); }
}
######################
sub parseHitFile {
	my ($inFh, $unique_sites) = @_;
	my ($id);
	my $site_number = 99999999; # initial to impossible number to avoid perl warning
  my $include_redundant_sites = 0; # hardcoded for now
#my  $include_redundant_sites = 1; # hardcoded for now
	while (my $line = <$inFh>) {
#    if ($line =~ m{^>(\S+)\s.+([LS]SU-)(\d+).+Pairs:\s+(\d+)/(\d+)/(\d+)/(\d+)}) {
    if ($line =~ m{^>(\S+)\s.+Cmpl:\s+(\S+\D)(\d+)\s.+Pairs:\s+(\d+)/(\d+)/(\d+)/(\d+)}) {
			$id             = $1.'//'. $2. $3;
			$site_number = $3;
			$compl->{'data'}->{$id}     = $4 + $5;   #target matching data
 # If "unique_sites_only" keep only target matching data for unique sites
			if ($include_redundant_sites || exists $unique_sites->{$site_number} ) {
	    	$istem->{'data'}->{$id}    = $6;
	    	$xstem->{'data'}->{$id}    = $7;
			}
    }
    if ($include_redundant_sites || exists $unique_sites->{$site_number} ) {
			if ($line =~ /Gap Len:\s+(\d+)/) {
	    	$gap->{'data'}->{$id}      = $1;
			}
			if ($line =~ /IntStem Dither:\s+(-?\d+).*ExtStem Dither:\s+(-?\d+)/) {
	    	$istem_start->{'data'}->{$id}      = $1;
	    	$xstem_start->{'data'}->{$id}      = $2;
			}
			if ($line =~ /HACA:\s+([ACGU]+)/) {
#	    $HACASeq->{$id} = $1;  # not currently used
			}
			if ($line =~ /POST_ACA:\s+([ACGU]+)/) {    
# 	$Post_ACA_motifs->{$id} = $1;   # use known patterns for training
			}
			if ($line =~ /XSTEM2-H Int:\s+(\d+)/) {    
	    	$xstem_H->{'data'}->{$id} = $1;
			}
			if ($line =~ /HACA2-ISTEM2Rend Int: (\d+)/) {    
	    	$HACA2_istemR->{'data'}->{$id} = $1; 
			}
			if ($line =~ /HACA-ISTEMRend Int: (\d+)/) {    
	    	$HACA1_istemR->{'data'}->{$id} = $1; 
			}
    }    
    if ($line =~ /^#\s+LCompl:\s([ACGU]+).+RCompl:\s([ACGU]+).+IntStem: 5'([ACGU]+).+ExtStem: 5'([ACGU]+)/) {
			$compl_match->{'data1'}->{$id} = $1. $2;  # concatenate the comp sequences (#target matching data)
			if ($include_redundant_sites || exists $unique_sites->{$site_number} ) {
	    	$istem_match->{'data1'}->{$id} = $3;  
	    	$xstem_match->{'data1'}->{$id} = $4;
			}
    }
    if ($line =~ /^#\s+rRNA:\s([ACGU]+).+:\s([ACGU]+).+\s([ACGU]+).+ExtStem: 3'([ACGU]+)/) {    
			$compl_match->{'data2'}->{$id} = $1 . $2; # concatenate the target sequences (#target matching data)
			if ($include_redundant_sites || exists $unique_sites->{$site_number} ) {
	    	$istem_match->{'data2'}->{$id} = $3;
	    	$xstem_match->{'data2'}->{$id} = $4;
			}
    }
	}
}



######################
sub trainSnos {
	my ($hitfile, $outfile, %option) = @_;
	my $outFh = getOutFh($outfile);
	my $inFh = getInFh($hitfile);
# Genomic base frequencies can all be determined from frequency of 'A' by "Chargaff's Laws"
	my $organism = $option{organism} || die("\n***Organism must be specified!***\n");
	my $left_out_sno = $option{leftOutSno};	
	my @organisms = sort keys %A_base_freqs;
	exists($A_base_freqs{$organism}) 
    || die("***Unknown organism $organism. Available choices are @organisms.*** \n");
	$freq{'A'} =  $freq{'T'}  =  $freq{'U'} =  $A_base_freqs{$organism};
	$freq{'C'} =  $C_base_freqs{$organism} ||  (0.50 - $freq{'A'} ); 
	$freq{'G'} =  $freq{'C'} ;  
	for my $feature ($gap, $compl, $istem, $xstem, $xstem_match, $POST_ACA, $H_pattern, $HACA_RC, $xstem_H) {
		my $optionId = $feature->{'name'};
		if ($option{$optionId}) {
			ChangeFlags($feature, $option{$optionId});
		}
	}
	$ACA_pattern->{'flags'} = $H_pattern->{'flags'}; # H and ACA patterns handled identically for now
	$istem_match->{'flags'}= $xstem_match->{'flags'}; # istem_match and xstem_match handled identically for now
#open(HITFILE,"$hitfile") || die("Can't open hit file $hitfile\n");
	my $dataDir = "$ENV{DATA}" ? "$ENV{DATA}" : "./data";
	my $datafile = $dataDir . "/trainingData/" . $option{datafile};
	open(DATAFILE,"$datafile") or die "No can open datafile $datafile!\n";
	{ local $/ ;  #slurp in file
  	$data_initialization = <DATAFILE>;
	}
	eval $data_initialization;
	if ($@) {  &throw("Data initialization failed with error:\n $@\n");} # check for initializion error
	close(DATAFILE);
# $/ = "\n"; # back to line-at-a-time mode
	if($left_out_sno) { #jack_knife mode, so leave out corresponding training data
    for my $feature ($H_pattern, $ACA_pattern, $POST_ACA, $HACA_RC, $HACA_RC_B) {
			if (exists $feature->{'data'}{$left_out_sno}) {
	    	delete $feature->{'data'}{$left_out_sno};
			}  
    }
	}
# combine HACA-RC interval data for double-guide snos
	while ( my ($sno, $interval_2) = each ( %$HACA_RC_B) ) {
    my $key = $sno . '-B';
    $HACA_RC->{'data'}{$key} = $interval_2;
	}
	print $outFh "# Training data file using following options and defaults...\n";
	for my $feature (@adjustable_features) {
    print $outFh "# $feature->{'name'} : $feature->{'flags'} \n";
	}
	print $outFh "#Data_and_defaults_file:  $datafile \n"; 
	print $outFh "#SnoRNA_hitfile used:  $hitfile \n\n"; 
	parseHitFile($inFh, $unique_sites);
	print $outFh Train_Lengths($gap);
	print $outFh Train_Lengths($compl);
	print $outFh Train_Lengths($istem);
	print $outFh Train_Lengths($istem_start);
	print $outFh Train_PairFreq($compl_match);
	print $outFh Train_PairFreq($istem_match);
##### Following tables not used in Todd's original scoring scheme ******
	print $outFh Train_Lengths($xstem);
	print $outFh Train_Lengths($xstem_start);
	print $outFh Train_PairFreq($xstem_match);
	print $outFh Train_SingleBaseFreq($H_pattern, 1); 
	print $outFh Train_SingleBaseFreq($H_pattern, 3); 
	print $outFh Train_SingleBaseFreq($H_pattern, 4); 
	print $outFh Train_SingleBaseFreq($H_pattern, 5); 
	print $outFh Train_SingleBaseFreq($ACA_pattern, 1); 
	print $outFh Train_SingleBaseFreq($ACA_pattern, 3); 
	print $outFh Train_SingleBaseFreq($ACA_pattern, 4); 
	print $outFh Train_SingleBaseFreq($ACA_pattern, 5); 
	print $outFh Train_Lengths($HACA_RC);
### Added 8/26/02
#Train_Lengths($min_ACA_H_len, $max_ACA_H_len, $ACA_H_binsize, $ACA_Hlengths, "ACA-H-length");
	print $outFh Train_Lengths($HACA1_istemR);
	print $outFh Train_Lengths($xstem_H);
	print $outFh Train_Pattern_Frequencies($POST_ACA, 'U', $freq{'U'});
#Train_Pattern_Frequencies($POST_ACA, 'U', $Sc_freq{'U'});
}

1;

__END__