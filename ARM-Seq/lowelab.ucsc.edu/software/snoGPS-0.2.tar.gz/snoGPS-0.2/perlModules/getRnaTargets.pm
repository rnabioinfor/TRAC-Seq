#! /usr/local/bin/perl -w

package getRnaTargets;
use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use Bio::SeqIO;
use Bio::Seq;
use Bio::SearchIO;

use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT = qw();
	@EXPORT_OK = qw(&getRnaTargets &splitTargetFile);
	%EXPORT_TAGS = (
        			);
}	   

######################
sub splitTargetFile {
	my ($infile, %option) = @_;
	my ($inDir, $inBase) = getDirAndBase($infile);
	my $outDir = $option{'outDir'} || $inDir;
	my $inFh = getInFh($infile);
	while (my $line = <$inFh>) {
		next if ( $line =~ /^\s*#/) ; #skip comments
		my ($targ, $remainder) = split " " , $line;
		my $pattern = <$inFh>;
		$pattern =~ /^[ACGUTNY]+$/ ||
			throw("Could not parse target $line\n$pattern\n");
		my $outFh = getOutFh("$outDir/$targ.targ");
		print $outFh $line;
		print $outFh $pattern;
		close $outFh;
	}
}

#############

sub outputTarget {
	my ($outFh, $rrna_seqobj, $targetPosition, $reverseTarg) = @_;
	my $prelength = $targetPosition > 10 ? 10 : ($targetPosition - 1) ; # number of bases prior to (possible) pseudoU target to extract
	my $rnaLength = $rrna_seqobj->length;
	my $postlength = ($rnaLength - $targetPosition) > 9 ? 9 : $rnaLength - $targetPosition ; # number of bases after (possible) pseudoU target to extract
	my $rrna_seq = $rrna_seqobj->seq;
	my $rrna_id = $rrna_seqobj->id;
	unless ($rrna_seqobj->subseq($targetPosition, $targetPosition) =~/^[UT]$/i) {
		return $rrna_seqobj->subseq($targetPosition - 3, $targetPosition +3) ;  # target location is not a uridine!
	}
	my $startposition = $targetPosition - $prelength;
	my $stopposition =  $targetPosition + $postlength;
#	my $startposition = &Max(1, $targetPosition - $prelength);
#	my $stopposition = &Min($rnaLength - 1, $targetPosition + $postlength  + 1);
	my $targ_seq = uc $rrna_seqobj->subseq($startposition, $stopposition);
	$targ_seq =~ s/T/U/g;
	my $pseudoUposition = $targetPosition - $startposition;
	my $sub_char =  substr( $targ_seq, $pseudoUposition, 1);
	if ($sub_char ne 'U') {
		die(" Found a $sub_char at location  $targetPosition instead of a U ! \n");
	}
	substr( $targ_seq, $pseudoUposition, 1, 'Y'); #replace target 'pseudoU' with ''Y'
	my $targ_id = $rrna_id . '.U' . $targetPosition;
	$targ_id = 'rev' . $targ_id if $reverseTarg;
	my $targ_desc = " Nd " . $prelength;
	print $outFh "$targ_id $targ_desc\n";
	print $outFh "$targ_seq\n";
	return 0;
}

###############################################
sub getTargets {
	my ($rnaSeqobj, $targetHash) = @_ ;
	my $rnaId = $rnaSeqobj->id;
	foreach my $id (keys %$targetHash) {
		next unless ( $id eq $rnaId);
		return $targetHash->{$id};
	}
	throw ("Could not find targets for id: $rnaId\n");
}

###############################################
sub makeTargetHash {
	my ($pseudouFile) = @_ ;
	my $targetHash;
	my $inFh = getInFh($pseudouFile);
	while (my $line = <$inFh>) {
		next if ($line =~ /^\s*#/);
		my ($rnaId, $speciesTypes, $targets) = split " ", $line;
		$targetHash->{$rnaId} = $targets;
	}
	return $targetHash;
}

###############################################
sub outsideRange {
# checks that position of uridine to be tested is not so close to end of target equence that
# it would produce an error in the scanning program
	my ($position, $rrnaLen) = @_ ;
	my $minPos = 5 ;	#hard coded for now
	my $minDistToEnd = 5 ; #hard coded for now
	my $maxPos = $rrnaLen - $minDistToEnd;
	return 1 if ($position < $minPos);
	return 1 if ($position > $maxPos );
	return 0;
}

###############################################
sub getRnaTargets {
# converts target sequence into a '.targ' file.  Returns number of targets in .targ file
	my ($inFile, $outFile, %option) = @_ ;
	my $rrna_seqIO =  Bio::SeqIO->new('-format' => 'fasta', -file=> $inFile); 
	my $outFh = getOutFh($outFile);
	my ($targets);
	my $targetCount = 0;
	my $targetHash = makeTargetHash($option{'pseudouFile'})
		if $option{'pseudouFile'};
	while ( my $rrna_seqobj = $rrna_seqIO->next_seq) {
    my $rrna_seq = $rrna_seqobj->seq;
    if ($option{'reversedTargs'}) {
    	my $revSeq = join '', reverse(split //, $rrna_seq); 
    	$rrna_seqobj->seq($revSeq) ;
    	$rrna_seq = $revSeq;
    }
    my $rrnaLen = $rrna_seqobj->length;
    if (!$option{'targetList'} && !$option{'pseudouFile'}) { # make all uridines targets
			while ( $rrna_seq =~ /[UT]/gi ) {
	    	my $matchposition = pos($rrna_seq);
	    	next if outsideRange($matchposition, $rrnaLen);
	    	my $error = outputTarget($outFh, $rrna_seqobj, $matchposition, $option{'reversedTargs'});
				if ($error) {
					throw("Location $matchposition of ", $rrna_seqobj->id, " is not a uridine it is at midpoint of $error. !\n");
				} else {
					$targetCount++;
				}
			}
		} else {  #make only specified uridines targets
    	if ($option{'targetList'}) { # select specified targets
				$targets = $option{'targetList'};
			} else {
				$targets = getTargets($rrna_seqobj, $targetHash);
			}
			my @targets = split /:/, $targets;			
			foreach my $targetPosition (@targets) {
	    	next if outsideRange($targetPosition, $rrnaLen);
#	    	next if ($targetPosition > $rrna_seqobj->length);
	    	my $error = outputTarget($outFh, $rrna_seqobj, $targetPosition);
				if ($error) {
					print STDERR "Location $targetPosition of ", $rrna_seqobj->primary_id, " is not a uridine it is at midpoint of $error. Skipping!\n"
				} else {
					$targetCount++;
				}
			}
		}
	}
	close $outFh;	
	splitTargetFile($outFile, %option) unless $option{'noSplit'} ;
	return $targetCount;   
}

######################

1;

__END__
