# PROGRAM  :
# PURPOSE  :
# AUTHOR   : Peter Schattner schattner@alum.mit.edu
# CREATED  :
# REVISION :

package common;
use strict;
use lib './scripts'; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use FileHandle;
use Bio::SeqIO;
use Bio::AlignIO;
use Bio::Root::Root;
use Bio::Root::RootI;

use vars qw(@ISA @EXPORT @EXPORT_OK $ID $VERSION $DESC $DEBUG);
BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw(&checkInfile &getOutFh &getInFh &getAppendFh &targFile &compSingle
        							&getLongOptionNames &opt &revComp &makeFaId &execute &dbPrint &getUpdateFh
        							&getDir &getBase &getDirAndBase &makeTempName &rmTmpFiles &unique
        			&bedParse &bedBuild &alnToFasta &mafToFa &mafSplit &appendFile &throw &stackWarn);
        @EXPORT_OK = qw(&cvsMv &makeFaId);
}

# Global variables & constants

$ID      = 'common';
$VERSION = 0.00;
$DESC    = " common perl subroutines";

##################
sub throw {
    my ($mesg) = @_ ;
    Bio::Root::Root->throw("$mesg");
}

##################
sub stackWarn {  
# modified 6/30/04 to adjust for changes in bioperl code
    my ($mesg) = @_ ;
		my $std = Bio::Root::RootI->stack_trace_dump;
		print STDERR "\n**WARNING**:\n$std\n$mesg\n";
#		eval {Bio::Root::Root->throw("$mesg"); };
}

######################
sub dbPrint {
	my $outFh = shift @_;
	my $debugOn = shift @_;  
#	my @results = @_;
#	my $results = join "", @results;  
	print $outFh @_;
	print STDERR @_ if $debugOn;
#	print $outFh $results;
#	print STDERR $results if $debugOn;
}

##################
sub execute {
    my ($command, $noPrint) = @_;
    print STDERR "$command\n" unless $noPrint;
    my $status = system("$command");
    if ($status != 0) {  &throw("Command: $command exited with status code $status and error: $!\n");}
}

##################
sub unique {
	my %count = ();
	my @unique = grep { ++$count{$_} < 2 } @_;
	return @unique;
}

##################
sub getDirAndBase {
	my ($fileName) = @_;
	my $dir = '';
	my $baseAndExt = $fileName;  # default if no directory in filename
	if ($fileName =~ m!
				^(.*)					# complete directory
				/
				([^/]*)				# base and ext
				!x) { 
		$dir = $1;
		$baseAndExt = $2;
	}
	my $base = $baseAndExt;
	if ($baseAndExt =~ m/
				^(.*)		# everything until final '.'
				\.
				[^\.]*								 
				/x) { 
		$base = $1;
	}
	return ($dir, $base);
}

##################
sub getBase {
	my ($fileName) = @_;
	my ($dir, $base) = getDirAndBase($fileName);
	return $base;
}
##################
sub getDir {
	my ($fileName) = @_;
	my ($dir, $base) = getDirAndBase($fileName);
	return $dir;
}

##################
sub compSingle {
# compare base pairing, return 1 if WC, .5 if GU, 0 if either base is a '-' or 'N', -1 otherwise
	my ($base1, $base2) = @_;
	my $b1 = uc $base1; # to be safe
	my $b2 = uc $base2; # to be safe
	$b1 =~ s/T/U/;
	$b2 =~ s/T/U/;
	return 0 
		if ( 
			($b1 eq '-') || ($b2 eq '-')  ||
			($b1 eq 'N') || ($b2 eq 'N')   
			) ;
	return 1 
		if ( 
			($b1 eq 'A') && ($b2 eq 'U')  ||
			($b1 eq 'C') && ($b2 eq 'G')  ||
			($b1 eq 'G') && ($b2 eq 'C')  ||
			($b1 eq 'U') && ($b2 eq 'A') 
			) ;
	return 0.5 
		if ( 
			($b1 eq 'G') && ($b2 eq 'U')  ||
			($b1 eq 'U') && ($b2 eq 'G') 
			) ;
	return -1; 	
 }

##################
sub revComp {
	my ($string) = @_;
	my $rcString = reverse($string);
	$rcString =~ tr/ACGTUNacgtun\-\./TGCAANtgcaan\-\./;
	return $rcString;
}

######################
sub makeTempName {
	my ($suffix) = @_;
	my $rand = rand;
	return "/tmp/pS$rand.$suffix";
}

######################
sub rmTmpFiles {
	my ($suffix) = @_;
	my $command = 'rm /tmp/pS0*';
	$command .= $suffix if $suffix;
	execute($command, 'noPrint');
}

##################

sub cvsMv {
	my ($oldDir, $newDir, @files) = @_;
	$oldDir =~ s{/$}{}; #remove trailing slash if nec.
	$newDir =~ s{/$}{}; #remove trailing slash if nec.
	unless (-d $newDir) { # make dir if nec.
		mkdir $newDir;
		`cvs add $newDir`;
	}
	foreach my $file (@files) {
		`mv $oldDir/$file $newDir/$file`;
		`cvs remove $oldDir/$file`;
		`cvs add $newDir/$file`;
	}
}
#####################
sub checkInfile {
	my ($infile) = @_;
	unless (-s $infile) {
		warn "Input file nonexistent or zero size\n";
		return 0;
	} 
    my $readStatus = open (INFILE, "<$infile");
	unless ($readStatus) {
		warn "Cannot open $infile \n";
		return 0;
	} 
	# close file and return success
	close INFILE;
	return 1;
}

##################
sub checkInfileOrDie {
	my ($infile) = @_;
	checkInfile($infile) or
		throw ("Opening of $infile for input failed. Dying...\n");
}

##################
sub bedParse {
# parse a single bed line into array of ($name,	$chrom,	$strand, $start, $end)
# return 0 if unable to parse
	my ($bedLine, %option) = @_;
	return 0 unless $bedLine;
	my ($chrom, $start, $end, $name, $score, $strand);
	if ($option{'tab'}) {
		($chrom, $start, $end, $name, $score, $strand) = split /\t/, $bedLine;
	} else {
		($chrom, $start, $end, $name, $score, $strand) = split " ", $bedLine;
	}
	return 0 unless ($start && $end ); 
	unless ($start =~ /^\d+$/ && $end =~ /^\d+$/ ) {
	 return 0;
	 }
	return ($chrom, $start, $end, $name, $score, $strand);
}

######################
sub bedBuild {
# create a single bed line
	my ($name,	$chrom,	$strand, $start, $end, $score) = @_;
	$score = '0' unless $score;
	my $bedLine = join (" ", $chrom, $start, $end, $name, $score, $strand) ;
	return $bedLine;
}
###################### 
sub getOutFh {
	my ($outfile) = @_;
	my $outFh; 
  	if ($outfile eq "stdout") {
    	$outFh = *STDOUT;
  	} else {  
    	$outFh = new FileHandle ">$outfile" 
    		or throw ("Cannot open $outfile \n");;
    }
	return $outFh;
}

###################### 
sub getAppendFh {
	my ($outfile) = @_;
	my $outFh; 
  	if ($outfile eq "stdout") {
    	$outFh = *STDOUT;
  	} else {  
    	$outFh = new FileHandle ">>$outfile" 
    		or throw ("Cannot open $outfile \n");;
    }
	return $outFh;
}

######################
sub getInFh {
  my ($infile) = @_;
  my $inFh; 
  if ($infile eq "stdin") {
    $inFh = *STDIN;
  } else {  
    $inFh = new FileHandle "<$infile" 
    	or throw ("Cannot open $infile \n");
#    open (INFILE, "<$infile") or throw ("Cannot open $infile \n");
#    $inFh = *INFILE;
  }
	return $inFh;
}
######################
sub getUpdateFh {
  my ($file) = @_;
  my $fh; 
  $fh = new FileHandle "+<$file" 
    	or throw ("Cannot open $file \n");
	return $fh;
}
###############################################
sub makeFaId {  #  massage seq id to include start & end info
# should be obsolete, will be deleted
	my ($seq) = @_;
	my $id = $seq->id;
	my ($strand);
	if ($id =~ /[-+WC]$/ ) {
		$strand = $1;
		$id =~ s/[-+WC]$//;
	}
	if ($id =~ /:\d+$/ ) { # if only 'start' data present, add 'end' data
		$id .= '-' . $seq->end;
		$id .= $strand if $strand;
	}
	return $id;
}
###############################################
sub alnToFasta {  # can't use the "canned" alignIO fasta output because it doesn't strip dashes
# Take sequence(s) from an alignment (object), strip dashes and write fasta
  my ($aligned_homolog_obj, $fastaOut, %option) = @_;
  unless ($fastaOut && $fastaOut->can('write_seq') ) {
  	die ("alnToFasta not passsed proper SeqIO obj");
   } # check inputs
  unless ($aligned_homolog_obj && $aligned_homolog_obj->can('each_seq') ) {
  	die ("alnToFasta not passsed proper SimpleAlign obj");
   } # check inputs
   my $speciesRegexp = $option{'e'};
   my $minLength = $option{'l'} || 1;
 foreach my $seq ( $aligned_homolog_obj->each_seq() ) {
  	my $seqString = $seq->seq;
  	$seqString =~ s/-//g;
  	next if ( (length $seqString) < $minLength);
  	my $id = makeFaId($seq);
#    my $id = $seq->id . ":" . $seq->start . "-" . $seq->end . $seq->strand;
#    my $id = $seq->id;
    next if ($speciesRegexp && $id !~ /:\d+\.$speciesRegexp/);  # only output seqs of selected species
#    next if ($speciesRegexp && $id !~ /$speciesRegexp/);  # only output seqs of selected species
#  	$id =~ s{/\S+}{}g;  # remove /start-end from alignment seq ids	
#	$id =~ s{(/\S+)-\S+}{$1};  # remove -end from alignment seq ids	
    my $editedSeq = Bio::Seq->new( '-id' => $id, '-seq' => $seqString);
  	$fastaOut->write_seq($editedSeq);
  }
 }

####################
sub mafToFa {
	my ($infile, $outfile, %option) = @_;
	checkInfileOrDie($infile);
	my $i = 0;
    my $format = $option{a} || 'maf';
  	my $fastaOut = ($outfile eq 'stdout') ?
  		Bio::SeqIO->new( '-format' => 'fasta'):
  		Bio::SeqIO->new( '-format' => 'fasta', '-file' => ">$outfile");
   	my $alnIn = Bio::AlignIO->new( '-format' => $format, '-file' => $infile) ;
	while (my $aligned_homolog_obj =  $alnIn->next_aln ) {
		unless ( $option{m} ) { # write all records to single file
  			alnToFasta($aligned_homolog_obj, $fastaOut, %option) ;
  			next;
  		}
		$i++;  # write fa records for each maf alignment to separate file
		my $singleOut = "$outfile.$i" . '.fa';
		$fastaOut = Bio::SeqIO->new( '-format' => 'fasta', '-file' => ">$singleOut");
		alnToFasta($aligned_homolog_obj, $fastaOut, %option) ;
		$fastaOut->close;
  	}
#  	print STDERR "DEBUGGING mafToFa!!:\n";
# 	`cat $outfile`;  #DEBUG
  	return $i;
}

####################
sub mafSplit {
# split a maf file into individual maf files each with one alignment
# returns number of files created
	my ($mafFile, $mafRootName, %option) = @_;
	my $i = 0;
	my $header = "##maf version=1 scoring=multiz\n";
	my $infh = getInFh($mafFile);
	my $outFh;
	my $fileOpen = 0;	#flag to indicate if file is already open
	while (my $line = <$infh> ) {
		if ( $line =~ /score=\d+/) {
			$i++;
			my $outName = "$mafRootName.$i";
			$outFh = getOutFh($outName);
			$fileOpen = 1;
			print $outFh $header;
			print $outFh $line;
		} elsif ( $fileOpen && ( $line =~ /^\s*$/) ) { # maf records are separated by blank lines
			print $outFh $line;
			close $outFh;
			$fileOpen = 0;
		} elsif ( $line =~ /^\s*s\s+/) {		
			print $outFh $line;
		}
	}
	return $i;
}

####################
sub targFile {
	my ($targ, $targDir) = @_;
        $targDir ||= $ENV{HS_TARGS};
	return "$targDir/$targ.targ";
#	return "$ENV{HS_TARGS}/$targ.targ"; 
}

####################
sub opt {
# for option name checking, not currently used
	my ($options, $opt) = @_;
	throw ("Unknown option: $opt\n") unless exists($options->{$opt});
	return $options->{$opt};
}

####################
sub getLongOptionNames {
# enable the use of long option names
	my ($longNames, $options) = @_;
	my %longOptions;
	# initialize optionsHash
	while (my ($singleLet, $longName) = each(%$longNames) ) {
		$longOptions{$singleLet} = '';
		$longOptions{$longName} = '';
	}	
	while (my ($singleLet, $value) = each(%$options) ) {
		my $longName = $longNames->{$singleLet};
		$longOptions{$singleLet} = $value;	#keep short name&value for backward compatibility
		$longOptions{$longName} = $value;
	}
	return 	\%longOptions;
}
1;

__END__
