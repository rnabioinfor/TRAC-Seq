#! /usr/local/bin/perl -w
# $Id: annotatedAlign.pm,v 1.5 2003/12/24 18:24:58 schattner Exp $

package annotatedAlign;
use strict;
use Getopt::Std;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use Bio::SeqIO;
use Bio::AlignIO;
use hhObjects::HACA_CandidateIO;
use common;
use runPuSetup qw(&runPuAndSortHits);;
use sortHits;
use hg qw(&faToMaf);

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	%option
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw();
        @EXPORT_OK = qw(&annotatedAlign &annotateOneAln &alignWithTcoffee &alignWithTcoffeeToFile);
}	   


###############################################
sub alignWithTcoffeeToFile {
 my ($seqs_in, $outFile) = @_;
 my $tempfile3 = $outFile || '/tmp/eraseme.aln';
 # align with tcoffee
 my $command = "t_coffee -in=S$seqs_in,Mlalign_id_pair,Mclustalw_pair,Xblosum ";
 $command .= " -outfile=$tempfile3 -type=dna -quiet";
 print STDERR "$command\n";
 system($command);
 
 # Build a tcoffee alignment factory
 # exit gracefully if T_coffee has problem
 if ($@) {
      print STDERR "$@\n\n ****T_coffee problem with Seq file $seqs_in Continuing ***\n\n";
      exit (1);
 }  
 return $tempfile3;
}

###############################################
sub alignWithTcoffee {
 my ($seqs_in) = @_;
 my $tempfile3 = alignWithTcoffeeToFile($seqs_in);
 my $alnIn = Bio::AlignIO->new( '-format' => 'clustalw', '-file' => $tempfile3);
 return $alnIn;
}

###############################################
sub revCompAln {  # rev comp alignment (in place) if 'master seq' is on negative strand
   my ($aln, $option) = @_;
   return unless $option;
   my $found_id = '';
   my $id_hash = $aln->retrieve_order;  # get id hash
   #find "master seq"
   foreach my $nse (sort values %$id_hash) {
      next unless ( $nse =~ /$option/ ) ;  # 'master sequence'?
      if ($nse =~ m{\-/\d}) { # id ends in '-/start-end' => negative strand sequence
         $aln->revcomp;
         last;
      }
    }
}
###############################################
sub alnSingleToFasta {  # can't use the "canned" alignIO fasta output because it doesn't strip dashes
  my ($aligned_homolog_obj) = @_;
  my $fastaFile = "eraseme.aln.fa";
  my %alignOpt = ();  
  my $fastaOut = Bio::SeqIO->new( '-format' => 'fasta', '-file' => ">$fastaFile");
  alnToFasta($aligned_homolog_obj, $fastaOut, %alignOpt) ;
  $fastaOut->close;
  return $fastaFile;
 }



#####################################################

sub filter {
	my ($unfilteredSeqs, %option) = @_;  
	my $filteredSeqs = "/tmp/$option{e}";
	$filteredSeqs .= ".$option{T}" if $option{T} ;
	$filteredSeqs .= ".fa";
	my $inSeqio =  Bio::SeqIO->new('-format' => 'fasta', -file=> $unfilteredSeqs); 
	my $outSeqio =  Bio::SeqIO->new('-format' => 'fasta', -file=> ">$filteredSeqs"); 
	my $seqCount = 0;

	while ( my $seq = $inSeqio->next_seq ) {
  		my $seqName = $seq->id;
  		next unless ($seqName =~ /$option{e}/i );
  		$outSeqio->write_seq($seq);
  		$seqCount++;
 	}
 	$outSeqio->close;
 	if ($seqCount < 2) {
   		print STDERR "*** Only $seqCount sequences for filter $option{e} ... skipping ***\n";
   		exit (0)
  	} 
# 	exit(0) if $option{f};
 	return $filteredSeqs;
}

#####################################################

sub getTopHits {
	my ($aligned_homolog_obj, $targFile, %option) = @_;
	my ($hits);
	my %runOption = ();
	my %outSortOption = ('topHitsOnly' => 1); 
  my $puInputFasta = alnSingleToFasta($aligned_homolog_obj);							
 	#Run seqs with pseudoU_test and sort hits by score
  my $resultFile = $option{r} ?
  		$option{r} :
  		runPuAndSortHits($targFile, $puInputFasta, \%runOption , \%outSortOption);
	#Get top hit for each sequence
  my $HACA_IO = HACA_CandidateIO->new ($resultFile);
  while (my $hit = $HACA_IO->next_hit ) {
    my $current_id = $hit->id;
    $current_id =~ s/\.[\.\d]+$//; # trim all except original sequence-id
    $current_id =~ s/:/_/g unless $option{a}; # remove : from id to keep t-coffee happy
    my $current_score = $hit->score;
    next if (exists $hits->{$current_id}) ;
    $hits->{$current_id} = $hit;
  }
	return $hits;
}

#####################################################

sub getHeaders {
	my ($hits) =@_;
	my $header = '';
  foreach my $hit (values %$hits) {
  	$header .= $hit->header . "\n";
  }
  return $header;
}
	
#####################################################

sub getAnnotation {
	my ($aligned_homolog_obj, $hits) =@_;
	my $genomeRegexp = 'hg|mm|rn';
	my $genomeId;
  while ( my ($id, $hit) = each(%$hits) ) {
  	if ($id =~ /(:\d+\.$genomeRegexp)/) {
  	 	$genomeId = $1;
  	} else {
  		stackWarn("Could not find :d+.$genomeRegexp in id $id");
  	}
    my $aligned_annotation = $hit->align_hit_annotation($aligned_homolog_obj, $genomeId);
    $aligned_homolog_obj->add_initial_seq($aligned_annotation) if $aligned_annotation;
  }
  $aligned_homolog_obj->match;
	return $aligned_homolog_obj;
}

#####################################################

sub annotateOneAln {
	my ($aligned_homolog_obj, $targFile, %option) = @_;
	my $hits = getTopHits($aligned_homolog_obj, $targFile, %option);
	my $headers = getHeaders($hits); 
	# annotate alignment with each top hit
	my $annoAlnHomObj = getAnnotation($aligned_homolog_obj, $hits);
	return ($headers, $annoAlnHomObj);
}
  
#####################################################

sub annotatedAlign {
	my ($seqs_in, $targFile, $outFile, %option) = @_;
#	my $tempFile0 = '/tmp/eraseme0.temp';
	die ("Could not open $targFile\n") unless (-e $targFile);
	my $outFh = getAppendFh( $outFile);				
	my $alignIoOut  = ($outFile eq 'stdout') ? 
					Bio::AlignIO->new( '-format' => 'clustalw') :
					Bio::AlignIO->new( '-format' => 'clustalw' , '-fh' => ">>$outFh");
	$seqs_in = filter($seqs_in, %option) if ($option{e});    
	my ($alnIn, $header);
	# align seqs if not already aligned  
  $alnIn = $option{a} ? Bio::AlignIO->new( '-format' => $option{a}, '-file' => $seqs_in) :
                    alignWithTcoffee($seqs_in);
  while (my $aligned_homolog_obj =  $alnIn->next_aln ) {
  	($header, $aligned_homolog_obj) = annotateOneAln($aligned_homolog_obj, $targFile, %option); 
		print $outFh "$header\n";
  	$alignIoOut->write_aln($aligned_homolog_obj );
	}
}

#######################

1;

__END__

###############################################
sub alignWithTcoffee {
 my ($seqs_in) = @_;
 my $tempfile3 = '/tmp/eraseme.aln';
 # align with tcoffee
 my $command = "t_coffee -in=S$seqs_in,Mlalign_id_pair,Mclustalw_pair,Xblosum ";
 $command .= " -outfile=$tempfile3 -type=dna -quiet";
 print STDERR "$command\n";
 system($command);
 
 # Build a tcoffee alignment factory
 # exit gracefully if T_coffee has problem
 if ($@) {
      print STDERR "$@\n\n ****T_coffee problem with Seq file $seqs_in Continuing ***\n\n";
      exit (1);
 }  
 my $alnIn = Bio::AlignIO->new( '-format' => 'clustalw', '-file' => $tempfile3);
 return $alnIn;
}

