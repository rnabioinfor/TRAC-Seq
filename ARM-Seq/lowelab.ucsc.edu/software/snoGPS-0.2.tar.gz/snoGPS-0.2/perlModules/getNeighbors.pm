#! /usr/local/bin/perl -w

package getNeighbors;
use strict;
use Getopt::Std;
use lib './scripts'; 
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use hg qw(&getAllNamesAndDescs &printAllNames);
#use blatToBed;

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	%option
	%extensions
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw();
        @EXPORT_OK = qw(&getNeighborsSingle &getOverlappingFeature 
        	&runFeatureBits &getNearbyGenes);
}	   

####Globals currently hard-coded#####
#	$table = 'knownGene';  
	%extensions = (
		'exon' => 10 ,
		'intron' => 1 ,
		'upstream' => 1000 ,
		'neighbors' => 10000 ,
	);

######################
sub runFeatureBits {
# called in list context returns bedlines (or fasta lines) directly to program
# otherwise writes them to fileName embedded in $featureBitsOpts
	my ($bedLine, $chrom, $db, $cdsTables, $featureBitsOpts) = @_;
	my $tempBedFile = '/tmp/eraseme1.bed';
  open (OUTFILE, ">$tempBedFile") or die ("Cannot open $tempBedFile \n");
	print OUTFILE "$bedLine\n";
	close (OUTFILE);
	my $command = "nice featureBits $db $tempBedFile $cdsTables";
	$command .= " $featureBitsOpts" if $featureBitsOpts;
	$command .= " -chrom=$chrom" if $chrom;
	return `$command` if wantarray;
	execute($command);
}

######################
sub featureBits {
# run featureBits for a single bedLine
	my ($bedLine, $db, $qualifier, $extend) = @_;
	my $qualTable = 'knownGene';
#	my $qualTable = $table;
	$qualTable .= ":$qualifier:$extend" if $qualifier;	
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine); # get chromNum
	my $featureBitsOpts = " -bed=stdout";
	my @overlapBed = runFeatureBits($bedLine, $chrom, $db, $qualTable, $featureBitsOpts);
	return \@overlapBed;
}

######################
sub getOverlappingFeature {
	my ($bedLine, $db, $feature) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine);
	my $extend = $extensions{$feature};
	my $overlapBed = featureBits($bedLine, $db, $feature, $extend);
	return getAllNamesAndDescs($overlapBed, $db);
}

######################
sub getNearbyGenes {
	my ($bedLine, $db) = @_;
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine);
	return 0 unless $end; # could not parse	
	$start -= $extensions{'neighbors'};
	$end += $extensions{'neighbors'};
	$bedLine = bedBuild($name,	$chrom,	$strand, $start, $end);	
	my $overlapBed = featureBits($bedLine, $db,'', 0);
	return getAllNamesAndDescs($overlapBed, $db);
}

######################
sub writeOverlappingFeature {
	my ($bedLine, $db, $outFh, $feature) = @_;
	my $allGeneNames = getOverlappingFeature($bedLine, $db, $feature);
	my $extend = $extensions{$feature};
    my $msg = "Overlapping $feature(s) (extendValue = $extend nt):";
    printAllNames ($allGeneNames, $msg, $outFh, 'description') ;
}

######################
sub writeNearbyGenes {
	my ($bedLine, $db, $outFh) = @_;
	my $allGeneNames = getNearbyGenes($bedLine, $db);
	my $extend = $extensions{'neighbors'};
    my $msg = "genes within $extend nt";
    printAllNames ($allGeneNames, $msg, $outFh, 'description') ;
}

######################
sub getNeighborsSingle {
	my($bedLine, $outFh, %option) = @_;
	my $db = $option{'D'};
# Get all 'neighbors' for a single Bedline
	writeOverlappingFeature($bedLine, $db, $outFh, 'exon');
	writeOverlappingFeature($bedLine, $db, $outFh, 'intron');
	writeOverlappingFeature($bedLine, $db, $outFh, 'upstream');
	writeNearbyGenes($bedLine, $db, $outFh);
}

1;

__END__

######################
sub featureBits {
# run featureBits for a single bedLine
	my ($bedLine, $db, $qualifier, $extend) = @_;
	my $qualTable = $table;
	$qualTable .= ":$qualifier:$extend" if $qualifier;	
	my ($chrom, $start, $end, $name, $score, $strand) = bedParse($bedLine); # get chromNum
	my $tempBedFile = '/tmp/eraseme1.bed';
    open (OUTFILE, ">$tempBedFile") or die ("Cannot open $tempBedFile \n");
	print OUTFILE "$bedLine\n";
	close (OUTFILE);
	print STDERR "DEBUG:: bedLine = $bedLine\n";
	my $command = "nice featureBits $db $tempBedFile $qualTable -bed=stdout ";
	$command .= " -chrom=$chrom ";
	print STDERR "$command\n";
	my @overlapBed = `$command`;
	return \@overlapBed;
}
