#! /usr/local/bin/perl -w
package runPuSetup;
use strict;
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits;

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw();
        @EXPORT_OK = qw(&makeSnoHash &runPu &runPuAndSortHits &runPuSeqObj);
}	   
	   
###############################################
sub makeSnoHash {
 my $snos = { };
 my $siteFile = "$ENV{HS_DATA}/sitesAndSnos.dat"; # hard code for now
# my $siteFile = 'data/H_sapiens/sitesAndSnos.dat'; # hard code for now
	open (SITEFILE, "<$siteFile") or die ("Cannot open $siteFile \n");
	while (my $line = <SITEFILE>) {
    	my ($site, $sno, $comment) = split " ", $line;
    	next unless $sno; # skip blank lines
		if (exists $snos->{$sno} ) {
			push (@{ $snos->{$sno} } , $site);
		} else {
			$snos->{$sno} = [$site];
		}	
	 }
  return $snos;
}

###############################################
sub runPu {
 my ($targFile, $seqs_in, %option) = @_;
 my $execDir = $option{execDir};
 my $errDir = $option{errDir} || '/tmp';
 my $executable = 'pseudoU_test';
 $executable = "$execDir/$executable" if $execDir;
 my $outfile = $option{outfile} || '/tmp/eraseme.hits';
 my $scoreMin = $option{scoreMin} || 20; # fixed bug 3/11/04
#  additional defaults added 8/13/04
 my ($descDir, $scoreDir);
 my $desc = $option{descriptor};
 if (!$desc) {
 	$descDir = $ENV{DESC} ? $ENV{DESC} : "./desc";
 	$desc = "$descDir/MamGUs2.v3.desc";
 }
 my $scoreTable = $option{scoretable};
 if (!$scoreTable) {
 	$scoreDir = $ENV{SCORETABLES} ? $ENV{SCORETABLES} : "./scoretables";
 	$scoreTable = "$scoreDir/human.v3.scoretables";
 }
# my $desc = $option{descriptor} || "$ENV{DESC}/MamGUs2.v3.desc";
# my $scoreTable = $option{scoretable} || "$ENV{SCORETABLES}/human.v3.scoretables";
 my $otherOpts = $option{puOptions} || ' -D 0 -W '; 
 $otherOpts .= " -t $option{targCount} " 
 	if ($option{targCount} && ($option{targCount} > 1)  ) 	;
 #Run seqs with pseudoU_test 
 my $command = "$executable $otherOpts -S $scoreMin -L $scoreTable ";
 $command .=  " -F /dev/null "; 
 $command .=  " -T $targFile "; 
 $command .= " $seqs_in ";
 $command .= " $desc  >$outfile 2>$errDir/eraseme.pU.stderr";
# $command .= " $desc  >$outfile 2>/tmp/eraseme.pU.stderr";
 print STDERR "\n$command\n";
 system($command);
 return $outfile;
 }
 
###############################################
sub runPuSeqObj {
# runs HH using a Bio::Seq object as a query
	my ($targFile, $seqObj, %option) = @_;
	my $tempFile = '/tmp/hh.fa';
	my $fastaOut = Bio::SeqIO->new( '-format' => 'fasta', '-file' => ">$tempFile");
	$fastaOut->write_seq($seqObj);
	$fastaOut->close;
 	my $resultFile = runPu($targFile, $tempFile, %option); 
	return $resultFile;
}

###############################################
sub runPuAndSortHits {
 my ($targFile, $seqs_in, $runOption, $sortOption, $outFile) = @_;
 $outFile ||= '/tmp/eraseme.sorted.hits';
 my $tempfile1 = runPu($targFile, $seqs_in, %$runOption); 
 #sort by score
 sortHits($tempfile1,  $outFile, %$sortOption);
 return  $outFile;
 }

###############################################
1;
