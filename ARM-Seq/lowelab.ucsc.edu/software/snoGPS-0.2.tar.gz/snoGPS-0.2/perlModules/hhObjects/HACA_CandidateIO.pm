# POD documentation - main docs before the code

=head1 NAME

HACA_CandidateIO -  a "hit" from the pseudoU_test program  

=head1 SYNOPSIS

   $hit_IO = new HACA_CandidateIO (  '-file_handle'  => $fh);
   $hit = $hit_IO->next_hit;
 
=head1 DESCRIPTION

The only difference between this object and Generic_CandidateIO is that it
creates a specific HACA_Candidate object. In particular, its next_hit
method parses the entire hit record, not just the header line

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package HACA_CandidateIO;
use vars qw(@ISA);
use strict;

use lib $ENV{MYPERLMODULEDIR}; 
#use hhObjects::Species;
use hhObjects::HACA_Candidate;
use hhObjects::Generic_CandidateIO;

#use Bio::Root::Root ;
@ISA = qw(Generic_CandidateIO);

=head2 next_hit

 Title   : next_hit
 Usage   :  
 Function: $hit_candidate = $hit_io->next_hit; 
 Returns : HACA_Candidate object
 Args    :  

=cut

  sub next_hit {
    my ($self) = @_;
    my $fh = $self->fh ;
    $/ = '####';  		#read in entire 'hit record' at a time
    my $record = <$fh>; 
    $/ = "\n";			# back to line-at-a-time mode to be safe
    my $hit = new HACA_Candidate ( '-record' => $record);
#    my $hit = new Generic_Candidate ( '-record' => $record);
	 return $hit if $hit->id;
	 my $file_header = $self->parse_file_header($record);
	 return 0 unless $file_header;
# If we got here, we just read the file header so we need to read in the first hit
     $hit = $self->next_hit;
     return $hit if ($hit && $hit->id);
     return 0; # EOF or give up
  }

=head2 write_hit

 Title   : write_hit
 Usage   :  
 Function: NOT IMPLEMENTED
 Returns :  
 Args    :  


=cut

sub write_hit {
    my ($self,$hit) = @_;
     $self->throw("Sorry. Writing of Hit_Candidates in \'pseudoU\' format is not implemented yet\n");
}
 

1;	
	
__END__ 

use Class::MethodMaker  
  get_set => [qw / fh  /];

=head2 new

 Title   : new
 Usage   : $str = HACA_CandidateIO->new( '-file' => $file)
 Function: generate HACA_Candidate stream object 
 Returns : new HACA_Candidate stream object
 Args    : HACA_Candidate file

=cut

  sub new {
    my ( $caller, , $file) = @_;   # note extra 'comma' so interface is the standard one
    my ($self) = $caller->SUPER::new(); # initialize parent attributes
    open (HITFILE, "<$file") || $self->throw("Cannot open $file \n");
    my $in_fh = *HITFILE;
    $self->fh($in_fh);
    return $self;
  }

