# POD documentation - main docs before the code

=head1 NAME

Species -  data structure and methods for manipulating species-specific
parmaeters and datafiles  

=head1 SYNOPSIS

 
=head1 DESCRIPTION

This class stores and retrieves species-specific paramters and data files.  If the 
data file does not yet exist, the program attempts to create it. Object
also stores all the 'environmental' parameters which is a little wasteful and
redundant, but will do for now.

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package Species;
use vars qw(@ISA $GROUP $DATABASE_ID $DATABASE_LIST 
         $DESCRIPTOR $KNOWN_PATTERNS $CHROMOSOMES
         $TRAINING_DATA $SITE_FILE  $SCORETABLE $PARAMETERS
	     $SEQ_FILE_SUFFIX $TARGET_RNAS);

use strict;


use File::Temp qw/ tempfile tempdir / ;
use lib './scripts';  

use Bio::Root::Root ;
@ISA = qw(Bio::Root::Root);

use Class::MethodMaker  
  get_set => [qw / 
	      environment descriptor training_data site_file scoretable target_types
	      group environment_id known_patterns chromosomes  chromosome_number           
              /],
  key_attrib => [ qw / id genome_seqid / ],
  hash => [ qw /fasta_obj /] ;
#	       multiple_file_flag genome_regex 


BEGIN {
  $GROUP = {
	    'Human' =>'vertebrate',
	    'Mouse' =>'vertebrate',
	    'Scerev' =>'yeast',
	    'Sbaya' => 'yeast',
	    'Scast' => 'yeast',
	    'Skluya' => 'yeast',
	    'Skudr' => 'yeast',
	    'Smika' => 'yeast',
	    'Pfuri' => 'pyro',
	    'Pabyssi' => 'pyro',
	    'Phori' => 'pyro',
	    'Suacid' => 'sulfolobus',
	    'Susolf' => 'sulfolobus',
	    'Sutokod' => 'sulfolobus',
	    'Afulg' => 'afulgidis',
	    'Mjann' => 'meth',
	    'Mmazei' => 'meth',
	    'Mmari' => 'meth',
	   };
# Hash to convert between short and long keys
  $DATABASE_ID = {
	      'Human' =>'H_sapiens',
	      'Mouse' =>'M_musculus',
		  'Scerev' => 'S_cerevisiae',
		  'Sbaya' => 'S_bayanus',
		  'Scast' => 'S_castelli',
		  'Skluya' => 'S_kluyveri',
		  'Skudr' => 'S_kudriavzevii',
		  'Smika' => 'S_mikatae',
		  'Pfuri' => 'P_furiosus',
		  'Pabyssi' => 'P_abyssi',
		  'Phori' => 'P_horikoshii',
          'Suacid' => 'S_acidocaldarius',
          'Susolf' => 'S_solfataricus',
		  'Sutokod' => 'S_tokodaii',
		  'Afulg' => 'A_fulgidis',
		  'Mjann' => 'M_jannaschii',
		  'Mmazei' => 'M_mazei',
		  'Mmari' => 'M_maripaludis',
		 };
   $KNOWN_PATTERNS= {
    'Scerev' =>  { # taken from Todd's list
	 'SSU.U106' =>  "GCUCAUUAAAYCAGUUAUCGUU",
	 'SSU.U120' =>  "UAUCGUUUAYUUGAUAGUUCCU",
	 'SSU.U211' =>  "GAUGUAUUUAYUAGAUAAAAAA",
	 'SSU.U302' =>  "UUCAUUCAAAYUUCUGCCCUAU",
	 'SSU.U466' =>  "AGGGAGGUAGYGACAAUAAAUA",
	 'SSU.U632' =>  "AAGCUCGUAGYUGAACUUUGGG",
	 'SSU.U759' =>  "UUGAAAAAAUYAGAGUGUUCAA",
	 'SSU.U766' =>  "AAUUAGAGUGYUCAAAGCAGGC",
	 'SSU.U1000' => "UCGAAGAUGAYCAGAUACCGUC",
         'SSU.U1179' => 'AGCCUGCGGCYUAAUUUGACU', #  - rrnaSSU
	 'SSU.U1185' => "CGGCUUAAUUYGACUCAACACG",
	 'SSU.U1189' => "UUAAUUUGACYCAACACGGGGA",
         'SSU.U1289' => 'CGUUCUUAGUYGGUGGAGUGAU', # rrnaSSU
	 'SSU.U1414' => "GAUGGAAGUUYGAGGCAAUAAC",
	 
	 'LSU.U775' =>  "UUCGGAUGGAYUUGAGUAAGAG",
	 'LSU.U959' =>  "GAAGUUUCCCYCAGGAUAGCAG",
	 'LSU.U965' =>  "UCCCUCAGGAYAGCAGAAGCUC",
	 'LSU.U985' =>  "UCGUAUCAGUYUUAUGAGGUAA",
	 'LSU.U989' =>  "AUCAGUUUUAYGAGGUAAAGCG",
	 'LSU.U1003' => "GUAAAGCGAAYGAUUAGAGGUU",
	 'LSU.U1041' => "CUUGACCUAUYCUCAAACUUUA",
	 'LSU.U1051' => "UCUCAAACUUYAAAUAUGUAAG",
	 'LSU.U1055' => "AAACUUUAAAYAUGUAAGAAGU",
	 'LSU.U1109' => "UGAAGAGCUUYUAGUGGGCCAU",
	 'LSU.U1123' => "UGGGCCAUUUYUGGUAAGCAGA",
	 'LSU.U2128' => "AAGGGGAAUCYGACUGUCUAAU",
	 'LSU.U2132' => "GGAAUCUGACYGUCUAAUUAAA",
	 'LSU.U2190' => "CAAUGUGAUUYCUGCCCAGUGC",
	 'LSU.U2257' => "CGGGAGUAACYAUGACUCUCUU",
	 'LSU.U2259' => "GGAGUAACUAYGACUCUCUUAA",
	 'LSU.U2263' => "UAACUAUGACYCUCUUAAGGUA",
	 'LSU.U2265' => "ACUAUGACUCYCUUAAGGUAGC",
	 'LSU.U2313' => "CGCGCAUGAAYGGAUUAACGAG",
	 'LSU.U2339' => "CCACUGUCCCYAUCUACUAUCU",
	 'LSU.U2348' => "CUAUCUACUAYCUAGCGAAACC",
	 'LSU.U2350' => "AUCUACUAUCYAGCGAAACCAC",
	 'LSU.U2415' => "CCUGUUGAGCYUGACUCUAGUU",
	 'LSU.U2730' => "UCAGUGUGAAYACAAACCAUGA",
	 'LSU.U2822' => "GAUAACUGGCYUGUGGCAGUCA",
	 'LSU.U2861' => "UGCUUUUUGAYUCUUCGAUGUC",
	 'LSU.U2876' => "CGAUGUCGGCYCUUCCUAUCAU",
         'LSU.U2919' => 'CGUUGGAUUGYUCACCCACUAA', # rrnaSSU
         'LSU.U2940' => 'AUAGGGAACGYGAGCUGGGUUU', # rrnaSSU
	 'LSU.U2971' => "UGAGACAGGUYAGUUUUACCCU",            
      },
	 'DEFAULT' => {}  ,
    };
 
  $CHROMOSOMES = {
			'Scerev' =>  ['I', 'II','III','IV','V','VI','VII','VIII',
			              'IX', 'X','XI','XII','XIII','XIV','XV','XVI'],
	        'DEFAULT' => ['I']  ,
	       };
  $TARGET_RNAS = {
			'Human' =>  ['LSU','SSU', '5SU'],
	        'DEFAULT' => ['LSU','SSU']  ,
	       };
   $DESCRIPTOR = {
		 'pyro' => 'desc/Archaea.v5.desc',
		 'sulfolobus' => 'desc/Archaea.v5.desc',
		 'afulgidis' => 'desc/Archaea.v5.desc',
		 'meth' => 'desc/Archaea.v5.desc',
		 'yeast' => 'desc/haca2stemv4a.desc' ,
		 'vertebrate' => 'desc/MamGUs1.v2.desc' ,
		};
  $SCORETABLE = {
		 'yeast' =>  'scoretables/haca2stemv7.tables' ,
		 'vertebrate' =>  'scoretables/human.v2.scoretables' ,
		 'sulfolobus' =>  'scoretables/Archaea.1-stemv1.tables' ,
		 'pyro' =>  'scoretables/Pfuri.1-stemv1.tables' ,
		 'meth' =>  'scoretables/Mjann.1-stemv1.tables' ,
		 'afulgidis' =>  'scoretables/Archaea.1-stemv1.tables' ,
		};
  $TRAINING_DATA = {
		    'pyro' => 'train.archaea_with_yeast.data',
		    'sulfolobus' => 'train.archaea_with_yeast.data',
		    'afulgidis' => 'train.archaea_with_yeast.data',
		    'meth' => 'train.archaea_with_yeast.data',
		    'vertebrate' => 'newtrain.human.v2.data' ,
		    'yeast' => 'newtrain.yeast.v2.data' ,
		   };
  $SITE_FILE = {
		'pyro' => 'scripts/train_test.archaea_yeast.sites',
		'sulfolobus' => 'scripts/train_test.archaea_yeast.sites',
		'afulgidis' => 'scripts/train_test.archaea_yeast.sites',
		'meth' => 'scripts/train_test.archaea_yeast.sites',
		'yeast' => 'scripts/train_and_test.yeast.v2.sites' ,
    	'vertebrate' => 'scripts/train_and_test.human.v2.sites' ,
	       };
    $DATABASE_LIST = {
		    'yeast' => ['S_bayanus', 'S_castelli', 'S_kluyveri',
				'S_kudriavzevii', 'S_mikatae', 'S_cerevisiae'] ,
		    'vertebrate' =>  ['H_sapiens','M_musculus'] ,
		    'sulfolobus' =>  ['S_solfataricus','S_tokodaii'] ,
		    'afulgidis' =>  ['A_fulgidis'] ,
		    'pyro' =>  ['P_abyssi', 'P_horikoshii', 'P_furiosus'] ,
		    'meth' =>  ['M_jannaschii', 'M_mazei', 'M_acetivorans', 'M_barkeri',
				'M_thermoautotroph', 'M_kandleri', 'M_maripaludis'] ,
		   };
  $PARAMETERS = {
		 'group' => $GROUP,
		 'genome_seqid' => $DATABASE_ID,
		 'database_list' => $DATABASE_LIST,
		 'chromosomes' => $CHROMOSOMES,
		 'target_types' => $TARGET_RNAS,
		 'descriptor' => $DESCRIPTOR,
		 'known_patterns' => $KNOWN_PATTERNS,
		 'training_data' => $TRAINING_DATA,
		 'site_file' => $SITE_FILE,
		 'scoretable' => $SCORETABLE,
		};              
}

=head2 new

 Title   : new
 Usage   : $str = Species->new( '-id' => $id, '-environment_id' => $environment_id)
 Function: generate Species object 
 Returns : new Species object
 Args    : currently MUST include id => $id  

=cut

  sub new {
    my ( $caller, @args) = @_;   # note extra 'comma' so interface is the standard one
    my ($self) = $caller->SUPER::new(@args); # standard calling sequence
   $self->set_Species_attributes(@args);  
   $self->set_environment();
  my $group = $self->store_from_tables('group');
  if (!$group) {
    print STDERR " Allowed species_ids are: ", join ' ', sort keys %$GROUP, "\n";
    $self->throw("Couldn\'t find a group associated with species ", $self->id, "\n");
  }    
 # Need to check that "Species" hasn't already been created
  my $seq_id = $self->get_from_tables('genome_seqid');
  if ( $self->find_genome_seqid($seq_id)) {
#     $self->throw("Trying to set Species id $seq_id which is already used. Something's very wrong\n");
     $self->warn("Trying to set Species id $seq_id which is already used. Probably not what you want\n");
   }
  $self->genome_seqid($seq_id);
  
  $self->store_from_tables('descriptor');
  my $chromosomes = $self->store_from_tables('chromosomes');
  $self->store_from_tables('training_data');
  $self->store_from_tables('site_file');
  $self->store_from_tables('target_types');
  $self->store_from_tables('scoretable');
#  $self->store_from_tables('multiple_file_flag');
  $self->store_from_tables('known_patterns');
  $self->chromosome_number(scalar(@$chromosomes));
  return $self;
  }

=head2 set_Species_attributes

  Title   : set_Species_attributes
  Usage   :
  Function: Set array of parameters specific to Generic_Candidate at once.
    Returns : none
    Args    : Named parameters, in the form as they would otherwise be passed
    to new(). Currently recognized are:
    -id           
    -environment_id              

=cut

    sub set_Species_attributes {
      my ($self,@args) = @_;
      my ($id, $environment_id) =
	 $self->_rearrange([qw(ID
			      ENVIRONMENT_ID
			     )], @args);
  
  # as convenience, 'id' might be either a 'long' id (eg 'P_furiosus')
  # or a short id like 'Pfuri'.  In the former case we need to convert
  # id
  if ($id) {
    if ( $self->find_id($id) || $self->find_genome_seqid($id)) {
     $self->warn("Trying to set Species id $id which is already used. Probably not what you want\n");
#     $self->throw("Trying to set Species id $id which is already used. Something's very wrong\n");
   }
    my $genome_id = $DATABASE_ID->{$id};
    # if we can't find a genome_id then (hopefully) we were passed a 'long' id and need to convert
    $id = Species->seqid2id($id) unless $genome_id;
  }
      $id    && $self->id($id);
      $environment_id  =  $environment_id ||
                          'Laptop'; # default;
      $self->environment_id($environment_id);
   }

#############
=head2 retrieve_known_pattern

 Title   :  retrieve_known_pattern
 Usage   :  $pattern = $self->retrieve_known_pattern($location);
 Function:  If passed location is available as a known pseudoU, returns the pattern 
            present at that location in the associated target RNA 
 Returns :  target pattern as string if known, 0 otherwise
 Args    :  Nominal location of pseudoU (eg 'LSU_2350')

=cut

sub retrieve_known_pattern {
 my ($self, $location) = @_;
   $location =~ s/^([A-Z]_[a-z]+_)//; # strip off genome_id if necessary
   my $pattern_hash = $self->known_patterns;
   return 0 unless exists($pattern_hash->{$location});
   return $pattern_hash->{$location};
}

#############
=head2 fasta_seq_id

 Title   :  fasta_seq_id
 Usage   :  $fasta_id = $self->fasta_seq_id($contig);
 Function:  Retrieve fasta id of chromosome/contig for (future) use where multiple 
            chromosome/contigs are stored in single file
 Returns :  fasta_seq_id
 Args    :  chromosome or contig id

=cut

sub fasta_seq_id {
 my ($self, $contig_id) = @_;
   unless ($contig_id eq $self->genome_seqid) {
   $self->throw("Sorry multiple contig-chromosomes per file not yet supported\n");
 }
return $self->genome_seqid;
}

#############
=head2 make_group_species

 Title   :  make_group_species
 Usage   :  $species_hash = Species->make_group_species()
 Function:  create a species object for each species in group               
 Returns :  Hash of ids => Species objects (keys are genome_seqids)
 Args    :  group {default is group of "instance" of object)

=cut

sub make_group_species {
  my ($self, $group) = @_;
  my %species_hash;
  my $species_obj;
  $group ||= $self->group; 
  my $grouplist = $DATABASE_LIST->{$group} ||
   $self->throw("Could not find species list corresponding to group $group\n");
  foreach my $genome_seqid (@$grouplist) {
     my $id = $self->seqid2id($genome_seqid) ||
  $self->throw("Could not find id corresponding to seqid $genome_seqid\n");
     $species_obj = Species->create($id);
     $species_hash{$genome_seqid} = $species_obj;
  }
  return %species_hash;
}
#############
=head2 make_gapless_target_seqs

 Title   :  make_gapless_target_seqs
 Usage   :  Species->make_gapless_target_seqs()
 Function:  create a species object for each species in group               
 Returns :  Nothing, new seq stored in 
 Args    :  None (aligned seq looked up), throws if aligned seq not found
            $force forced overwrite of gapless target file

 Note: the gapless_target_seqs have 'T's rather than 'U's

=cut

sub make_gapless_target_seqs {
  my ($self, $force) = @_;
   my $seqIO_in;
  my @RNA_ids = ('LSU', 'SSU') ; # only rRNA for now
  for my $RNA_id (@RNA_ids) {
    # retrieve aligned target RNA seq
    my $aligned_seq_file = $self->aligned_rRNA_file($RNA_id);
    eval { $seqIO_in= Bio::SeqIO->new( '-file' => $aligned_seq_file, '-format' => 'fasta');};
    if ($@ ) {
      $self->warn("Could not find aligned-file: $aligned_seq_file.. Skipping sequence");
      next;
    }    
    my $gapped_seq_obj = $seqIO_in->next_seq;
    my $seq = uc $gapped_seq_obj->seq;
    $seq =~ s/\W+//g;
# Change 'o' in rrna-db alignment files to generic unknown 'N' symbol
    $seq =~ s/O/N/g; 
    $seq =~ s/U/T/g; 
    my $ungapped_seq_obj = Bio::Seq->new('-id' => $gapped_seq_obj->id,
          '-seq' => $seq); 
    # I **think** that seqio strips the gaps automatically...
    my $gapless_seq_file = $self->rRNA_file($RNA_id); 
    # check if gapless target RNA seq already exists
    if ( (-e $gapless_seq_file) && !$force) {
      $self->warn("RNA-targetfile $gapless_seq_file already exists. \nYou must remove or rename it before creating new one");
      next;
    }
    my $seqIO_out = Bio::SeqIO->new( '-file' => ">$gapless_seq_file", '-format' => 'fasta');
    $seqIO_out->write_seq($ungapped_seq_obj);
  }
}
#############
=head2 trusted_sequence

 Title   :  
 Usage   :  $aln_file = Species->trusted_sequence('LSU');
 Function:  retrieve 'trusted' sequence with correct gaps for structural alignment           
 Returns :  name of file containing trusted_sequence
 Args    :  RNA_type (must match either 'LSU' or 'SSU')

=cut

sub trusted_sequence {
  my ($self, $RNA_id) = @_;
  my $group = $self->group;
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $prefix = $genome_data_dir . "/$group/"  . 'gapped_reference.' ;

   my $allowed_target_types = join '|', @{$self->target_types};
   $RNA_id =~ /$allowed_target_types/ ||
#   $RNA_id =~ /[LS]SU/ ||
   $self->throw("RNA_id $RNA_id does not include $allowed_target_types");
   my $suffix = $&;
   return $prefix .  $suffix;
}
#############
=head2 create_from_blast

 Title   :  create_from_blast
 Usage   :  $gapless_seq_file = $self->create_target_file_with_blast($other_species);
 Function:  create rRNA target file for species by blasting genome with rRNA seqs f related species              
 Returns :  name of created target-sequence file  
 Args    :  other species object to use a source of rna seqs to use in blast

=cut

sub create_from_blast {
  my ($self, $other_species) = @_;
  $self->throw("Sorry, subroutine create_from_blast not yet implemented");
}


############
sub create {
  my ($self, $id) = @_;
  my $new_object; 
  my $load = "$id.pm";
    eval {
        require $load;
    };
    if ( !$@ ) {  
      $new_object = $id->new('-id' =>  $id);  
    } else { # Species-specific object doesn't exist yet 
#      print STDERR "\nWarning module $load does not exist\n";   
      $new_object = Species->new('-id' =>  $id);     
    }
    return $new_object;
}

############
#  Class utiity to convert between key types
########
sub seqid2id {
  my ($self, $given_seqid) = @_ ;
  my ($id, $seqid);
  my @ids = sort keys %$DATABASE_ID;
  foreach $id (@ids) {
    $seqid = $DATABASE_ID->{$id} ||
      $self->throw("$seqid not found in seq_id hash\n");
    if ( $seqid ne $given_seqid) {
      next;
    }
    return $id;
  }
  return 0;			# failure
}
 
#############
sub group_list {
  my ($self) = @_;
  my $database_list = $self->get_from_tables('database_list');
  return $database_list;
}

#############
sub gff_db {
  my ($self,$chromosome, $value ) = @_;
  $self->{'gff_db'}->{$chromosome} = $value if $value;
  return $self->{'gff_db'}->{$chromosome};
}

#############
sub database_list {
  my ($self) = @_;
  my $database_list = $self->get_from_tables('database_list');
  my $group = $self->group;
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my @full_database_list = 
    map { $genome_data_dir . "/$group/" . $_ . '.fasta'} @$database_list;
  my $value = \@full_database_list;
  return $value;
}

#############
sub pseudoU_bins {
  my ($self) = @_;
  my $pseudoU_bin_size = $self->get_from_tables('pseudoU_bin_size');
  my $pseudoU_min = $self->get_from_tables('pseudoU_min');
  my $pseudoU_max = $self->get_from_tables('pseudoU_max');
  my $pseudoU_bin_min =  int ($pseudoU_min / $pseudoU_bin_size);
  my $pseudoU_bin_max =  int ($pseudoU_max / $pseudoU_bin_size);
  my @pseudoU_bins = map {  $pseudoU_bin_size * $_ } ($pseudoU_bin_min .. $pseudoU_bin_max);
  my $value = \@pseudoU_bins;
  return $value;
}

#############
sub fold_bins {
  my ($self) = @_;
  my $value = $self->get_from_tables('fold_bins');
  return $value;
}

=head2 get_chromosome_or_contig

 Title   : get_chromosome_or_contig
 Usage   : $entire_seq = $self->get_chromosome_or_contig($number, $flag);
 Function: Return primary seq object for entire sequence, saves for future_use  
 Returns : A primary seq object
 Args    : number of chromosome or contig to get
           flag indicating whether file names are for "chromosome" or "contig"

=cut

sub get_chromosome_or_contig {
#  my ($self, $chromosome) = @_;
  my ($self, $number, $flag) = @_;
  use Bio::Index::Fasta;
  my ($message,$seq_id) ;
  $number = $number || 0 ; # default for single chromosome genomes
  return $self->fasta_obj($number) if $self->fasta_obj($number);
#  $self->throw("Sorry, multiple-file storage of fasta seqs of single genome not yet supported\n")
#    if ($self->multiple_file_flag);
#  my $fasta_file = $self->genome_fasta_file($number);  
  $seq_id = $self->genome_seqid;
  if ($number) {
    $seq_id = $self->genome_seqid . '_chr' . $number if ($flag =~ /chromosome/i);
    $seq_id = $self->genome_seqid . '_Contig' . $number if ($flag =~ /contig/i);
  }
  my $Index_File_Name = $self->index_file;  
  my $inx = Bio::Index::Fasta->new('-filename' => $Index_File_Name);
  my $seq = $inx->get_Seq_by_id($seq_id) ||
    $self->throw("Unable to find query sequence $seq_id\n");
  $self->fasta_obj($number,$seq);  # store for possible later use
  return $self->fasta_obj($number);
}

#############
sub db_file {
  my ($self) = @_;
  my $group = $self->group;
  my $blast_data_dir = $self->environment->{'blast_data_dir'};
  my $value = $blast_data_dir . "/All-$group.nt" ;
  return $value;
}

#############
# make blast-index of fasta files of species in the group
# iff $force is set, overwrite file if it already exists
# return 1 if file already present or successfully built
# return 0 otherwise
#
sub make_db_file {
  my ($self, $force) = @_;
  my $db_file_name = $self->db_file;
  my $file_present = (-e $db_file_name);
  return 1 if ($file_present && !$force);
  # Next we have to make the blast index files as in:
  # $ cat P_abyssi.fa P_horikoshii.fa Pyrobaculum_a.fa >/home/peter/blast/data/Other-pyro
  # $ ./formatdb -i data/Other-pyro.nt  -p F -o T
  my $database_list = $self->database_list; 
  my $database_list_as_string = join ' ', @$database_list;
  my $command = "cat $database_list_as_string >$db_file_name";
  system($command);
  my $blast_dir = $self->environment->{'blast_dir'};
  $command = "$blast_dir/formatdb -i $db_file_name -p F -o T";
  my $status = $self->_execute($command);
  return !$status;		# Blast returns 0 for success
}

#############
sub gbk_file {
  my ($self, $chromosome) = @_;
  return $self->_build_file_name_multi('gbk', $chromosome);
}

#############
# need to create separate ids for each target RNA of the species
# so far just creating IDs for rRNA LSU and SSU
#######
sub get_RNA_id {
  my ($self, $RNA_id) = @_;
  my $allowed_target_types = join '|', @{$self->target_types};
  $RNA_id =~ /$allowed_target_types/ ||
    $self->throw("Using unknown RNA ID $RNA_id");
  my ($suffix) = $RNA_id =~ /($allowed_target_types)/;
  #  my ($suffix) = $RNA_id =~ /([LS]SU)/;
  $suffix ||
    $self->throw("RNA_id $RNA_id does not contain $allowed_target_types");
  my $genome_seqid;
  $genome_seqid = $self->genome_seqid; 
  my $value = $genome_seqid . '_' . $suffix ;
  return $value;
}
#############
sub aligned_rRNA_file {
  my ($self, $RNA_id) = @_;
  my $allowed_target_types = join '|', @{$self->target_types};
  $RNA_id =~ /$allowed_target_types/ ||
    $self->throw("Using unknown RNA ID $RNA_id");
  my ($suffix) = $RNA_id =~ /($allowed_target_types)/;
  #  my ($suffix) = $RNA_id =~ /([LS]SU)/;
  $suffix ||
    $self->throw("RNA_id $RNA_id does not contain $allowed_target_types ");
  $suffix .= '.aln.fa';
  my $group = $self->group; 
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $genome_seqid;
  $genome_seqid = $self->genome_seqid;
  my $genome_data_prefix = $genome_data_dir . "/$group/$genome_seqid" ; 
  my $value = "$genome_data_prefix.$suffix" ;
  # sanity check 
  ($group && $genome_data_dir && $genome_seqid) ||
    $self->throw("Incomplete file name: $value \n");
  return $value;
}

#############
sub gff_file {
  my ($self, $chromosome) = @_;
  return $self->_build_file_name_multi('gff', $chromosome);
}

#############
sub genome_fasta_file {
  my ($self, $chromosome) = @_;
  return $self->_build_file_name_simple('fasta',$chromosome );
}

#############
=head2 edit_genome_file

 Title   : edit_genome_file
 Usage   : $self->edit_genome_file($genome_input_file, $chromosome_id);
 Function: Massage fasta sequence id(s) in genome file to standard format
 Returns : Nothing (writes edited file to appropriate location) 
 Args    :  genome_input_file_name if not editing in place
            chromosome_id if genome is stored in more than one file

=cut

sub edit_genome_file {
  my ($self, $input_genome_file, $chromosome) = @_;
  my ($message,$seq_id, $fh, $out_file, $in_file) ;
  use File::Temp qw/ tempfile tempdir / ;
#  $self->throw("Sorry, multiple-file storage of fasta seqs not yet supported")
#     if $self->multiple_file_flag;
  my $genome_fasta_file = $self->genome_fasta_file($chromosome);
my $genome_seqid = $self->genome_seqid;
  if (!$input_genome_file) {  # we're editing in place...
    ($fh, $out_file) = tempfile();
     $in_file = $genome_fasta_file;
  } else {
     $in_file = $input_genome_file;
     $out_file = $genome_fasta_file;
  }
  my $in = Bio::SeqIO->new('-file' => $in_file, '-format' => 'fasta');
  my $out = Bio::SeqIO->new('-file' => ">$out_file", '-format' => 'fasta');
  while (my $seq = $in->next_seq) {
   my $seq_id = $seq->id;
   $seq_id =~ s/^[a-zA-Z0-9]+/$genome_seqid/;
      $seq_id =~ s/[-:]/_/g; # some programs (eg tcoffee) don't like unusual characters in id name
   $seq->id($seq_id);
   $out->write_seq($seq);
} 
$in->close;
$out->close;
if (!$input_genome_file) { 
    my $status = rename $out_file, $genome_fasta_file;
    }
}  

#############
sub rRNA_file {
  my ($self, $RNA_id) = @_;
  my ($suffix) = $RNA_id =~ /([LS5]SU)/;
  $suffix ||
   $self->throw("RNA_id $RNA_id does not contain [LS5]SU");
  $suffix .= '.fa';
  my $group = $self->group; 
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $genome_seqid;
  $genome_seqid = $self->genome_seqid;
  my $genome_data_prefix = $genome_data_dir . "/$group/$genome_seqid" ; 
  my $value = "$genome_data_prefix.$suffix" ;
# sanity check 
  ($group && $genome_data_dir && $genome_seqid) ||
      $self->throw("Incomplete file name: $value \n");
  return $value;
}

#############
sub Not_Feature_file {
  my ($self) = @_;
  return $self->_build_file_name_simple('NotFeature.fa');
}
#############
sub group_directory {
  my ($self) = @_;
  my $group = $self->group; 
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $group_directory = $genome_data_dir . "/$group/" ; 
  return $group_directory;
}

#############
=head2 make_all_gff_files

 Title   : make_all_gff_files
 Usage   : $self->make_all_gff_files($force);
 Function: Convert all gbk file(s) to gff file(s)
 Returns : Nothing (writes edited file to appropriate location) 
 Args    :  $force - if set over-write file  

=cut

sub make_all_gff_files {
  use Bio::Seq;
  use Bio::SeqIO;
  use Bio::Tools::GFF;
  
  my ($self, $force) = @_;
  my $chromosomes = $self->chromosomes;
  return $self->make_gff_file('', $force) if (scalar(@$chromosomes) == 1); # only 1 chromosome
  foreach my $chromosome (@$chromosomes) {
   $self->make_gff_file($chromosome, $force);
 }
}

#############
=head2 make_gff_file

 Title   : make_gff_file
 Usage   : $self->make_gff_file($chromosome, $force);
 Function: Convert gbk file(s) to gff file(s)
 Returns : Nothing (writes edited file to appropriate location) 
 Args    : $chromosome - which chromosome gff-file to make 
           ( should be set 'False' (0) for single chromosome genome) 
           $force - if set over-write file  

=cut

sub make_gff_file {
  use Bio::Seq;
  use Bio::SeqIO;
  use Bio::Tools::GFF;
  
  my ($self, $chromosome, $force) = @_;
  
  my $gff_file_name = $self->gff_file($chromosome);
  my $file_present = (-e $gff_file_name);
  return 1 if ($file_present && !$force);

  my $gbk_file_name = $self->gbk_file($chromosome) ;
  $self->throw("Could not find gbk file $gbk_file_name") unless (-e $gbk_file_name);
  my $seqIO_in = Bio::SeqIO->new( '-file' => $gbk_file_name, '-format' => 'genbank');
  my $GFF_out = Bio::Tools::GFF->new( '-file' => ">$gff_file_name", '-gff_version' => 2);
  while (my $seq = $seqIO_in->next_seq ) {
     foreach my $feature ($seq->get_SeqFeatures) { # top level features only
         $GFF_out->write_feature($feature);
      }
  }
}
#############
sub target_file {
  my ($self) = @_;
  my $group = $self->group;
  my $genome_seqid = $self->genome_seqid;
  my $value = "targets/$genome_seqid/$genome_seqid" . "_all_Us.targ";
  return $value;
}
#############
sub target_id_file {
  my ($self) = @_;
  my $target_file = $self->target_file;
  return "$target_file.id";
}


#############
sub other_genome_number {
  my ($self) = @_;
  my $database_list = $self->get_from_tables('database_list');
  my $value = scalar(@$database_list) ;
  return $value;
}

#############
sub other_data {
  my ($self) = @_;
  my $group = $self->group;
  my $other_data = "Other-$group".'s'; # used by align-pipeline.pl
  return $other_data;
}

#############
sub  all_data {
  my ($self) = @_;
  my $group = $self->group;
  my $all_data = "All-$group".'s'; # used by align-pipeline.pl
  return $all_data;
}

#############
sub index_file {
  my ($self) = @_;
  my $group = $self->group;
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $index_file = "$genome_data_dir/$group/All_$group.index";
  return $index_file;
}

#############
# make index_file of fasta files of species in the group
# iff $force is set, overwrite file if it already exists
# return !=0 if file already present or successfully built
# return 0 otherwise
#
sub make_index_file {
  use Bio::Index::Fasta;
  my ($self, $force) = @_;
  my $index_file_name = $self->index_file;
  my $file_present = (-e $index_file_name);
  return 99999 if ($file_present && !$force);
  unlink $index_file_name if $file_present; # Bio::Index squawks if overwriting file
  my $database_list = $self->database_list; 
  my $inx = Bio::Index::Fasta->new(
				   '-filename' => $index_file_name,
				   '-write_flag' => 1);
  my $status = $inx->make_index(@$database_list);
  return $status;
}

#############
sub store_from_tables {
  my ($self, $parameter) = @_;
  my $value = $self->get_from_tables($parameter);
  $self->$parameter($value);
  return $value ;
}
#############
sub get_from_tables {
  my ($self, $parameter) = @_;
  my $species = $self->id;
  my $group = $self->group;
  my $value = $PARAMETERS->{$parameter}->{$species};
  return $value if (defined $value) ;
  $value = $PARAMETERS->{$parameter}->{$group};      
  return $value if (defined $value) ;
  $value = $PARAMETERS->{$parameter}->{'DEFAULT'};      
  return $value if (defined $value) ;
$self->throw("Could not find value for parameter $parameter and species $species\n");
#  return undef;			# Couldn't find value in table
}
############
sub set_environment {
  #    my ($self, $environment_id) = @_;
  my ($self) = @_;
  my $environment_id = $self->environment_id;
  $self->environment ({});
  if (!$environment_id || $environment_id =~ /^L/ ) { # 'L' for Laptop
    $self->environment->{'blast_dir'} = './blast'; #symbolically linked
    $self->environment->{'blast_data_dir'} = './blast/data';
#    $self->environment->{'blast_dir'} = '/home/peter/blast';
#    $self->environment->{'blast_data_dir'} = '/home/peter/blast/data';
    $self->environment->{'genome_dir'} = './genome_data';
#    $self->environment->{'genome_dir'} = '/home/peter/genome_data';
    $self->environment->{'tcoffee_dir'} = '/home/peter/alignprograms/T-COFFEE_distribution_Version_1.26/bin';
    $self->environment->{'mfold_dir'} = '/usr/local/bin'; 
    $self->environment->{'rnafold_dir'} = '.'; #  RNAfold executable is symbolic-linked to current directory
  } elsif ($environment_id =~ /^U/ ) { # 'U' for UCSC
    $self->environment->{'blast_dir'} = '/projects/compbio/bin/i686';
    $self->environment->{'blast_data_dir'} = '/home/peter/blast/data';
    $self->environment->{'genome_dir'} = '/home/peter/genome_data';
    $self->environment->{'tcoffee_dir'} = '';
    $self->environment->{'mfold_dir'} = ''; 
    $self->environment->{'rnafold_dir'} = ''; 
  } else { 
    $self->throw("Unknown environment choice $environment_id. Sorry!\n"); 
  }
}
##################
# Private routines
##################
#############
sub _build_file_name_simple {
  my ($self, $suffix) = @_;
  my $group = $self->group; 
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $seqid;
 $seqid = $self->genome_seqid;
  my $genome_data_prefix = $genome_data_dir . "/$group/$seqid" ; 
  my $value = "$genome_data_prefix.$suffix" ;
# sanity check 
  ($group && $genome_data_dir && $seqid) ||
      $self->throw("Incomplete file name: $value \n");
  return $value;
}
#############
sub _build_file_name_multi {
  my ($self, $suffix, $chromosome) = @_;
  my $group = $self->group; 
  my $genome_data_dir = $self->environment->{'genome_dir'};
  my $seqid;
  $seqid = $self->genome_seqid . '.chr' . $chromosome; 
  my $genome_data_prefix = $genome_data_dir . "/$group/$seqid" ; 
  my $value = "$genome_data_prefix.$suffix" ;
# sanity check 
  ($group && $genome_data_dir && $seqid && $chromosome) ||
      $self->throw("Incomplete file name: $value \n");
  return $value;
}

sub _execute {
  my ($self, $command) = @_;
  print STDERR "$command\n";
  my $status = system("$command");
  $self->throw("Command: $command exited with status code: $status and error: $!\n")
    if $status ;
}

__END__




sub rRNA_file {
  my ($self) = @_;
  return $self->_build_file_name('rRNA.fa');  
}

#############
=head2 make_gapped_target_seqs

 Title   :  make_gapped_target_seqs
 Usage   :  Species->make_gapped_target_seqs()
 Function:  create gapped target sequences that aligns with the 'trusted' sequence               
 Returns :  Nothing, new seqs stored  
 Args    :  None (gapless seqs looked up), throws if gapless seqs not found
            (later will create gapless seqs from blast if not found)
            $force forced overwrite of gapped target file

=cut

sub make_gapped_target_seqs {
  my ($self, $force) = @_;
  use Bio::Tools::Run::Alignment::TCoffee;
  my @RNA_ids = ('LSU', 'SSU') ; # only rRNA for now
  my $gapless_seq_file = $self->rRNA_file;
  my $species_id = $self->genome_seqid;
  my %seqs ;
  my ($fh, $temp_RNA) = tempfile();
  unless ( -e  $gapless_seq_file) {
        $gapless_seq_file = $self->create_target_file_with_blast;
  }
   my $seqIO_in = Bio::SeqIO->new( '-file' => "$gapless_seq_file", '-format' => 'fasta');
   while (my $inseq = $seqIO_in->next_seq) {
     $seqs{'LSU'} = $inseq if ( $inseq->id =~ /LSU/ );
     $seqs{'SSU'} = $inseq if ( $inseq->id =~ /SSU/ );
   }
   $self->throw("Could not parse sequence names for file $gapless_seq_file") unless ($seqs{'LSU'} && $seqs{'SSU'});
#  set up tcoffee
  my @params = ();
  my $factory = new Bio::Tools::Run::Alignment::TCoffee (@params);
# do for both SSU and LSU
  for my $RNA_id (@RNA_ids) {
# check if aligned target RNA seq already exists
    my $aligned_seq_file = $self->aligned_rRNA_file($RNA_id);
    $self->throw("RNA-target-alignment-file $aligned_seq_file already exists. \nYou must remove or rename it before creating new one")
        if ( (-e $aligned_seq_file) && !$force);
# (profile-)align the sequence with the 'trusted' alignment 
    my $trusted_seq = $self->trusted_sequence($RNA_id);   
    my $aln = $factory->align($known_seq, $seqs{$RNA_id});   
# extract the now-gapped sequence from the alignment and write to the appropriate file
    my $gapped_seq;
    foreach $gapped_seq ($aln->each_seq) {
      if ( $gapped_seq =~ /$species_id/) {
        my $outfile = $self->aligned_rRNA_file($RNA_id);
        $self->throw("gapped-RNA-targetfile $outfile already exists. \nYou must remove or rename it before creating new one")
           if ( (-e $outfile) && !$force);
        my $seqIO_out = Bio::SeqIO->new('-file' => $outfile, '-format' => 'fasta'); #will this work??
        $seqIO_out->write_seq($gapped_seq);
        last;
       }
    } # end foreach loop
   } # end of LSU/SSU loop
}


  #############
  sub check_and_get {
    my ($self, $parameter, $is_file) = @_;
    $self->throw("Parameter $parameter unknown \n") unless (exists $OK_FIELD{$parameter});
    my $value = $self->{"_$parameter"};
    $self->throw("No value for parameter $parameter found\n") unless $value;
    if ($is_file == INPUT_FILE) {
      $self->throw("$parameter file $value not readable \n") unless (-r $value);
    } 
    if ($is_file == OUTPUT_FILE) {
      return $value if (-w $value) ;
      # perhaps the directory hasn't been made yet, so let's try to make it...
      if ($value =~ m{^(.*/)[^/]+} ) {
	my $outdir = $1; 
	mkdir $outdir;
	print STDERR "\nOutput directory $outdir not found.  Trying to make it...\n\n"; 
	# try again...       
	$self->throw("$parameter file $value not writeable \n") unless (-w $value);
      }  
    }  
    return $value;
  }
  sub init {
    my ($self, %args) = @_;
    $self->_setup(%args);
    $self->set_environment();
    my $group = $self->store_from_tables('group');
    if (!$group) {
      print STDERR " Allowed species_ids are: ", sort keys %$GROUP, "\n";
      $self->throw("Couldn\'t find a group associated with species ", $self->id, "\n");
    }    
    my $blast_data_dir = $self->environment->{'blast_data_dir'};
    my $genome_data_dir = $self->environment->{'genome_dir'};

    my $database_list = $self->get_from_tables('database_list');
    my $genome_seqid = $self->store_from_tables('genome_seqid');
    my $bin_number = $self->get_from_tables('bin_number');
    my $fold_bins = $self->get_from_tables('fold_bins');
    my $pseudoU_bin_size = $self->get_from_tables('pseudoU_bin_size');
    my $pseudoU_min = $self->get_from_tables('pseudoU_min');
    my $pseudoU_max = $self->get_from_tables('pseudoU_max');
    my $descriptor = $self->store_from_tables('descriptor');
    my $training_data = $self->store_from_tables('training_data');
    my $site_file = $self->store_from_tables('site_file');
    my $genome_regex = $self->store_from_tables('genome_regex');
    my $scoretable = $self->store_from_tables('scoretable');

    $self->other_genome_number( scalar(@$database_list) );

    my @full_database_list = 
      map { $genome_data_dir . "/$group/" . $_ . '.fasta'} @$database_list;
    $self->database_list( \@full_database_list);
     
    my $genome_data_prefix = $genome_data_dir . "/$group/$genome_seqid" ; 
    $self->genome_gbk_file("$genome_data_prefix.gbk");
    $self->genome_fasta_file("$genome_data_prefix.fasta");
    $self->rRNA_file("$genome_data_prefix.rRNA.fa");
    $self->target_file("targets/$genome_seqid" . "_all_Us.targ");
    $self->Not_Feature_file("$genome_data_prefix.NotFeature.fa");
         
    my $other_data = "Other-$group".'s'; # used by align-pipeline.pl
    my $all_data = "All-$group".'s'; # used by align-pipeline.pl
    my $index_file = "$genome_data_dir/$group/All_$group.index";
    $self->other_data($other_data);
    $self->all_data($all_data);
    $self->index_file($index_file);

    my $pseudoU_bin_min =  int ($pseudoU_min / $pseudoU_bin_size);
    my $pseudoU_bin_max =  int ($pseudoU_max / $pseudoU_bin_size);
    my @pseudoU_bins = map {  $pseudoU_bin_size * $_ } ($pseudoU_bin_min .. $pseudoU_bin_max);
    $self->pseudoU_bins(\@pseudoU_bins);
    $self->fold_bins($fold_bins);
    $self->db_file($blast_data_dir . "/All-$group.nt");
  }


__END_
 $BIN_NUMBER = {
		 'DEFAULT' => 5,
		};
  $PSEUDOU_BIN_SIZE = {
		       'DEFAULT' => 4,
		      };
 $PSEUDOU_MIN = {
		  'DEFAULT' => 20,
		 };
  $PSEUDOU_MAX = {
		  'DEFAULT' => 40,
		 };
  my @fold_bins_default =  reverse (-0.10, -0.14, -0.18, -0.22, -0.26, -0.30, 
				    -0.34, -0.38, -0.42, -0.46, -0.50, -0.54);
  my @fold_bins_yeast =  reverse (-0.10, -0.14, -0.18, -0.22, -0.26, -0.30); 
  $FOLD_BINS = {
		'DEFAULT' =>  \@fold_bins_default ,
		'yeast' =>  \@fold_bins_yeast ,
	       };
$GENOME_REGEX = {
		   'yeast' => ['^(.+)(_Contig\d+)', '(ySc_chr\d+)'] ,
		   'sulfolobus' =>  ['(^S\S+)'] ,
		   'pyro' =>  ['(^P\S+)'] ,
		   'meth' =>  ['(^M\S+)'] ,
		   'afulgidis' =>  ['(^A\S+)'] ,
		  };
  # $SEQ_FILE_SUFFIX = {		# used if fasta/gbk sequences are stored in multiple files
 #	  'DEFAULT' => '',
 #	 };
