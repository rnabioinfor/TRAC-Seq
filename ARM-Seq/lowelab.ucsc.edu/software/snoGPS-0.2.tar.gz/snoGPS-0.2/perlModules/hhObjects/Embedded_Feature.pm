# POD documentation - main docs before the code

=head1 NAME

Embedded_Feature

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class also implements Bio::SeqFeatureI by inheriting
off Bio::SeqFeature::Generic.

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package Embedded_Feature;
use vars qw(@ISA);
use strict;
use Bio::SeqFeature::Generic;
use Bio::Seq;
use File::Temp qw/ tempfile tempdir / ;
use lib './scripts';  

@ISA = qw(Bio::SeqFeature::Generic);

use Class::MethodMaker  
  get_set => [qw / chromosome hit_seq species chromosome_or_contig/];


=head2 new

 Title   : new
 Usage   : $new_obj = Embedded_Feature->new( -species => $species_obj, -start => start,
                                              -end => $end, -strand => $strand)
 Function: Initial new object in manner consistent with inherited constructors from Bioperl
 Returns : new Embedded_Feature object
 Args    : Any attributes of Embedded_Feature or Bio::SeqFeature::Generic

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    $self->set_Embedded_attributes(@args); # for compatibility with bioperl, can't use MethodMakers init_hash
    return $self;
  }

=head2 set_Embedded_attributes

  Title   : set__Embedded_attributes
  Usage   :
  Function: Sets a whole array of parameters specific to Embedded Features at once.
    Example :
    Returns : none
    Args    : Named parameters, in the form as they would otherwise be passed
    to new(). Currently recognized are:
  -chromosome          chromosome id
    -species             reference to species object
    -hit_seq             sequence (as string) of feature

=cut

    sub set_Embedded_attributes {
      my ($self,@args) = @_;
      my ($chromosome, $species, $hit_seq) =
	$self->_rearrange([qw(CHROMOSOME
			      SPECIES
			      HIT_SEQ
			     )], @args);
      $chromosome    && $self->chromosome($chromosome);
      $species    && $self->species($species);
      $hit_seq    && $self->($hit_seq);
    }


=head2 get_neighbors

      Title   : get_neighbors
      Usage   : @nearby_features = $feature->get_neighbors(5000,'');
  Function: Retrieve all Seq Features within a given distance of "self"         
      Returns : Array of SeqFeatureObjects
 Args    : Length: Look for features from (feature_start - Length) to (feature_end + Length)
           hit_object to use [default = 'self']

=cut

sub  get_neighbors {  
  my ($self, $extension, $hit) = @_;
  my @near_features;
  use Bio::DB::GFF;
  $hit = $self unless $hit; # enable over-ride of which hit to search
  my $start = $hit->start;
  my $end = $hit->end ;
  
# if it's a single chromosome species set the chromosome = 1 
  unless ($hit->chromosome) {
     $hit->chromosome('I') if ($hit->species->chromosome_number == 1 );
  }
 
  my $chromosome = $hit->chromosome  ||
    $self->throw("Can not get feature neighbors without specifying chromosome!")  ;
  $self->throw("Can not get feature neighbors without specifying feature start and end!") unless ($start && $end);

 # Should do error checking to not extend past end of sequence 
  $start -=  $extension if $extension;
  $end   += $extension if $extension;
  my $db = $hit->species->gff_db($chromosome);
  unless ($db) {
    my $GFF_file = $hit->species->gff_file($chromosome);
    $self->throw("Could not find GFF file $GFF_file") unless (-e $GFF_file); 
    $db = Bio::DB::GFF->new( -adaptor=>'memory');
    $db->initialize(1); # is this necessary??
    $db->load_gff($GFF_file);
    $hit->species->gff_db($chromosome, $db); # save for later use
  }
   my $seg = $db->segment(-start => $start, -end => $end, -absolute => 1 );
   @near_features = $seg->features();
# just extract coding and rna feature
   @near_features = grep {$_->type =~ /cds|rna/i} @near_features;
   return @near_features;
}


=head2 superseq

 Title   : superseq
 Usage   : $superseq = $candidate->superseq($pre_extend, $post_extend)
 Function: Return primary seq object that extends feature          
 Returns : A primary seq object extended by specied # of nts
 Args    : number of nt to extend before start and after end

=cut

sub superseq {
  my ($self,$pre_extend, $post_extend) = @_;
  $pre_extend |= 0; #defaults
  $post_extend = $pre_extend unless $post_extend;

  # For Crick strand the 'pre' extension is actually at the end...
  if ($self->strand < 0 ) {
    my $temp = $post_extend; 
    $post_extend = $pre_extend;
    $pre_extend = $temp;
  }
  # get the associated sequence
   my $entire_seq = $self->get_entire_seq;

  $entire_seq  ||
    $self->throw("Could not get entire sequence of " . $self->display_name );

# my $temp_seq = $entire_seq->trunc($self->start, $self->end);
# print STDERR "Truncated entire_seq =\n", $temp_seq->seq, "\n"; 
# my $temp_revcom = $temp_seq->revcom;
# print STDERR "Truncated revcom entire_seq =\n", $temp_revcom->seq, "\n"; 


  my $save_start = $self->start;
  my $save_end = $self->end;
  ($self->start  && $self->end ) ||
    $self->throw("Start & end must be defined to obtain superseq \n");

  # check that extension doesn't go beyond end of sequence
  my $start = ($save_start > $pre_extend ) ? (
					      $save_start - $pre_extend) : 1;
  my $end =  ( ($save_end + $post_extend) < $entire_seq->length) ?
    $save_end + $post_extend : $entire_seq->length;

  # temporarily change start and stop positions...
  $self->start($start);
  $self->end($end);

  #get the extended sequence
  my $extended_seq = $self->seq ||
  $self->throw("Could not extract extended sequence for: " . $self->display_id . "\n");

#print STDERR "Used start = $start, used end = $end\n";
#print STDERR "\n", $self->id, "\n"; 
#print STDERR "Hitseq = \n", $self->hit_seq, "\n";
#print STDERR "extracted seq = \n", $extended_seq->seq, "\n";
#my ($blast_start, $blast_end, $blast_strand) = $self->get_blast_location();
#print STDERR "expected location ($save_start:$save_end:", $self->strand, ")\n"; 
#print STDERR "found location ($blast_start:$blast_end:",  $blast_strand, ")\n"; 
  # replace start and end values and return the extended sequence
  $self->start($save_start);
  $self->end($save_end); 
  return $extended_seq;
}

=head2 get_entire_seq

 Title   : get_entire_seq
 Usage   : $entire_seq = $self->get_entire_seq
 Function: Return primary seq object for entire sequence, tries to obtain
           object from Species.pm if it is not already attached         
 Returns : A primary seq object
 Args    : 

=cut

sub get_entire_seq {
  my ($self) = @_;
  my $message;
  return $self->entire_seq if $self->entire_seq;
  unless ($self->species) {
    $message = "Failed to find sequence or species attached to feature " . $self->display_name;
    $self->throw($message);
  }    
    my $number = $self->chromosome;
    my $chromosome_or_contig_flag = $self->chromosome_or_contig;
    my $entire_seq = 
      $self->species->get_chromosome_or_contig($number, $chromosome_or_contig_flag);
    $self->attach_seq($entire_seq) if $entire_seq;
    return $entire_seq if $entire_seq;
    $message = "Could not find sequence associated with species " . $self->species->id; 
    $self->throw($message);
}

=head2 get_blast_location

 Title   : get_blast_location
 Usage   : ($start, $end, $strand) = $candidate->get_blast_location()
 Function: Return location of candidate_seq in the attached_seq         
 Returns : (start, end and strand) of top blast hit, undef if no hit found
 Args    : None

=cut

sub get_blast_location {
  my ($self, $blast_db) = @_;
  $self->species || 
    $self->throw("Must know species to search for location! \n");
  my $target_id = $self->species->genome_seqid; 
  $blast_db =  $blast_db || $self->species->db_file ||
    $self->throw("Need species type or location of blast-db file for get_blast_location\n") ;
  my ($id, $start, $end, $strand, $e_score) = $self->get_best_homolog( $target_id, $blast_db, 0);
#  my ($id, $start, $end, $strand, $e_score) = $self->get_best_homolog( $target_id, $blast_db);
  return ($start, $end, $strand);
}

=head2 get_best_homolog

 Title   : 
 Usage   : ($id, $start, $end, $strand, $e_score) = $candidate->get_best_homolog($blast_db, $target_id)
 Function: Return best blast hit with target_id in blast_db         
 Returns : (name, start, end, strand and e-value) of top blast hit of target species, undef if no hit found
 Args    : blast database, id of target species

=cut

sub get_best_homolog {
  my ($self, $target_id, $blast_db) = @_;
  my %target_ids = ($target_id => 1);
  my $result = $self->get_all_best_homologs (
                '-TARGET_IDS' => \%target_ids, '-BLAST_DB' => $blast_db);
#  my $result = $self->get_all_best_homologs(\%target_ids, $blast_db);
  my $top_hit_array = $result->{$target_id};
  return @$top_hit_array;
}
#############
=head2 get_homolog_seqs

 Title   : get_homolog_seqs
 Usage   :   my $homologous_seqs = $hit->get_homolog_seqs('-best_homologs' =>$best_homologs, 
          '-pre_extend' => $extension); #extract homo seqs
 Function: Return actual homologous sequences (extended if required)         
 Returns : Ref to array of PrimarySeqI objects of homologs 
 Args    : Reference to hash with keys being target_ids and values are references to 
            arrays of (hit_name, start, end, strand and e-value) of top blast hit / species;
            also amount to extend retrieved sequence
            cutoff for e-value of hits to retrieve [default = 0.001]
=cut

  sub get_homolog_seqs {
    my ($self,@args) = @_;
    my ($best_homologs, $pre_extend, $post_extend, $e_cutoff) = 	
      $self->_rearrange([qw(BEST_HOMOLOGS
			    PRE_EXTEND
			    POST_EXTEND
			    E_CUTOFF
			   )], @args);
    $pre_extend |= 0;		#defaults
    $post_extend = $pre_extend unless $post_extend;
    $e_cutoff ||= 0.001 ;	# default value
    my ($homolog_seqs);
# try to compute the query_length in 1 of 2 ways. If it can't, program dies.
    my $query_length = $self->length if ($self->start && $self->end);
    $query_length ||= length $self->hit_seq;
    $query_length ||                      
      $self->throw("Can't extract homologs with unknown sequence length"); 
    $self->species || 
      $self->throw("Need to specify species to find homologous seqs");
    my $index_file = $self->species->index_file;
    my $inx = Bio::Index::Fasta->new('-filename' => $index_file) ||
      $self->throw("Can\'t open index file $index_file\n");

    while ( my ($result_id, $result_ref) = each %$best_homologs) {
      my ($hit_name, $start, $end, $strand, $e_value, $strand_symbol, $qstart, $qend);
      ($hit_name, $start, $end, $strand, $e_value, $qstart, $qend) = @$result_ref;
      # sometimes the balst report leaves out the '1' in exponential notation
      $e_value =~ s/^e/1e/;	
      next if ($e_value > $e_cutoff);
      my $seq;
      my $entire_seq = $inx->fetch($hit_name) ||
	$self->throw("Couldn\'t find record for index:$hit_name\n"); # Returns Bio::Seq object
      my $entire_seq_len = $entire_seq->length;

      # For Crick strand the 'pre' extension is actually at the end...
      if ($strand > 0 ) {
	$strand_symbol = 'W';
	#need to adjust for fact that some Blast hits will not be as long as the entire candidate
	$start  -= ($pre_extend + $qstart - 1);
	$end += ($post_extend + $query_length - $qend);
	#      $start  -= $pre_extend;
	#      $end += $post_extend;
	$start = ($start > 1 ) ? $start : 1 ;
	$end = ($end < $entire_seq_len ) ? $end : $entire_seq_len ;    
	$seq = $entire_seq->trunc($start, $end);
   
      } else {
	$strand_symbol = 'C';
	#need to adjust for fact that some Blast hits will not be as long as the entire candidate
	$start -= ($post_extend + $query_length - $qend);
	$end +=  ($pre_extend + $qstart - 1);
	#      $start -= $post_extend;
	#      $end +=  $pre_extend;
	$start = ($start > 1 ) ? $start : 1 ;
	$end = ($end < $entire_seq_len ) ? $end : $entire_seq_len ;    
	my $temp = $entire_seq->trunc($start, $end);
	$seq = $temp->revcom;
      }
      my $id = $hit_name . '(' . $start . '_' . $end . ")_$strand_symbol";             
      # Need to check that "Hit" id hasn't already been used
      if ( $self->find_id($id)) {
	$self->throw("Trying to set Hit id $id which is already used. Something's very wrong\n");
      }
      $seq->id($id);
      push @$homolog_seqs, $seq;
    }
    return $homolog_seqs;
  }
###########
=head2 get_all_best_homologs

 Title   : get_all_best_homologs
# Usage   : $results = $candidate->get_all_best_homologs(%target_ids, $blast_db, $e_cutoff)
 Usage   : $results =  $candidate->get_all_best_homologs (
                '-TARGET_IDS' => $target_ids_ref, '-BLAST_DB' => $blast_db,
               '-E_CUTOFF' => $e_cutoff, '-HIT_SEQ' => $hit_seq)
 Function: Return single best blast hit for each genome with target_ids hash in (group) blast_db         
 Returns : Reference to hash with keys being target_ids and values are references to 
            arrays of (hit_name, start, end, strand and e-value) of top blast hit 
            of each target species, undef if no hit found
 Args    : Ref to hash of ids of target species (default = all species of 'group'), 
           (opt) blast database,
           e_cutoff - return all hits with e_val < e_cutoff, if not set return top hit only

=cut

sub get_all_best_homologs {
#  my ($self, $target_ids_ref, $blast_db, $e_cutoff) = @_;
    my ($self,@args) = @_;
   my ($target_ids_ref, $blast_db, $e_cutoff, $hit_seq) = 	
      $self->_rearrange([qw(TARGET_IDS
			    BLAST_DB
			    E_CUTOFF
			    HIT_SEQ
			   )], @args);
  my %target_ids;
  $self->species || 
    $self->throw("Need to specify species to find homologous seqs");
  # make target_id list if necessary
  if (!$target_ids_ref) {  
    my $database_list = $self->species->get_from_tables('database_list');
    foreach my $database_id (@$database_list) {
      $target_ids{$database_id} = 1;
    } 
  } else {
    %target_ids = %$target_ids_ref;
  }
  # run blast
  use Bio::Tools::Run::StandAloneBlast; 
  $blast_db =  $blast_db || $self->species->db_file;
  # some useful blastall options ('W' => 8, 'L' => 20, ) are hardcoded for now
  my @params = ('program' => 'blastn','outfile' => 'blast.out', 
		'W' => 8, 
  #              'L' => 20,   #this option (which is actually the default causes problems on the version at UCSC)
                'F' => 'F',	# hard code no blast filtering for now
		'database' => $blast_db, );
  my  $factory = Bio::Tools::Run::StandAloneBlast->new(@params);
  $hit_seq ||= $self->hit_seq;
  $hit_seq ||
    $self->throw("Must have candidate_seq to search for its location! \n"); 
  my $input1 = Bio::Seq->new(-id=>"Candidate-seq",
			     -seq=>$hit_seq);
# following explicit tempfile creation added because File::Temp not working on UCSC   
  my $tempfile = 'temp/blast_input.tmp';
  my $seqio = Bio::SeqIO->new(-file => ">$tempfile",
			      -format =>'Fasta');
  $seqio->write_seq($input1);
  $seqio->close;
  my $best_homologs = {};
  my $blast_report;
    eval {$blast_report = $factory->blastall($tempfile); };
    if ($@) {			# trap possible blast crashes
      alarm(0);			#reset alarm just to be safe
      if ($@ =~ /timeout/) {
	die "Trapped Blast timeout"; #trap at higher level
      } else {
	print STDERR "\n**************\n";
	print STDERR "Blast crashed with error $@\n";
	print STDERR " attempting to proceed...\n";
      }
      return $best_homologs;	# ie an empty hash
    }
    # my $blast_report = $factory->blastall($input1);

  #parse report object
  my ($start, $end, $strand, $e_score, $qstart, $qend);
  my $result = $blast_report->next_result;
  while ( my $hit = $result->next_hit ) {
    my $target_regex = join '|', keys %target_ids;
    last unless $target_regex;
    next if $hit->name !~ /$target_regex/i;
    my $found_id = $& ;		# save the target_id that matched
    $e_score = $hit->significance;
    $e_score =~ s/^e/1e/;
    last if ($e_cutoff && ( $e_score > $e_cutoff) );
    my $hsp = $hit->next_hsp ;
    #    if ($hsp) {  
    $start = $hsp->sbjct->start; # hit must have at least one hsp
    $end =  $hsp->sbjct->end;
    $qstart = $hsp->start('query');
    $qend =  $hsp->end('query');
    $strand = $hsp->sbjct->strand;
    $best_homologs->{$found_id} = [$hit->name, $start, $end,  $strand, $e_score, $qstart, $qend]; 
    delete($target_ids{$found_id})
       unless $e_cutoff ; # Only search for top hit / species if cutoff not specified
  }  
  return $best_homologs;
}

__END__
