# POD documentation - main docs before the code

=head1 NAME

Target_pseudoU    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class also implements Bio::SeqFeatureI by inheriting
off Bio::SeqFeature::Generic.

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package Target_pseudoU;
use vars qw(@ISA);
use strict;

use Bio::Seq;
use Bio::AlignIO;
use File::Temp qw/ tempfile tempdir / ;
use lib './scripts';  
use hhObjects::Embedded_Feature;
use Bio::AnnotatableAlign;
#use String::Approx 'adist';

my $DEBUG = 1;
use constant NOT_FILE => 0;
use constant INPUT_FILE => 1;
use constant OUTPUT_FILE => 2;

@ISA = qw(Embedded_Feature);

use Class::MethodMaker  
  get_set => [qw / site_pattern alias site_desc /],
  key_attrib => 'site_label',
  static_hash => 'params' ;

=head2 new

 Title   : new
 Usage   : $new_obj = Target_pseudoU->new( '-site_pattern' => $site_pattern, 
                                               '-site_number' => $site_number, '-RNA_id' => $RNA_id)
 Function: Initial new object in manner consistent with inherited constructors from Bioperl
 Returns : new Target_pseudoU object
 Args    : Attributes of Target_pseudoU objects

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    $self->set_Target_pseudoU_attributes(@args); # for compatibility with bioperl, can't use MethodMakers init_hash
    return $self if $self->alias; # if target has alias, doesn't need a label 
    my $site_label = $self->site_label;
    $self->throw("New target site-label $site_label does not parse correctly") 
            unless ($site_label =~ /^\S+\.U\d+/);
    return $self;
  }

=head2 set_Target_pseudoU_attributes

  Title   : set_Target_pseudoU_attributes
  Usage   :
  Function: Sets a whole array of parameters specific to Target_pseudoU at once.
    Example :
    Returns : none
    Args    : Named parameters, in the form as they would otherwise be passed
    to new(). Currently recognized are:
    -site_pattern           
    -RNA_id              
    -site_label              
    -site_number
    -site_description
    -alias              

=cut

  sub set_Target_pseudoU_attributes {
    my ($self,@args) = @_;
    my ($site_pattern, $RNA_id, $site_label,
	$site_number, $desc, $alias) =
	  $self->_rearrange([qw(SITE_PATTERN
				RNA_ID
				SITE_LABEL
				SITE_NUMBER
				SITE_DESCRIPTION
				ALIAS
			       )], @args);
    $site_pattern    && $self->site_pattern($site_pattern);
    $alias    && $self->alias($alias);
    $site_number    && $self->site_number($site_number);      
    $desc   ||= 'Nd';
    $self->site_desc($desc);      
    $RNA_id  &&  $self->RNA_id($RNA_id);      
    $site_label   ||= $RNA_id . '.U' . $site_number;
    $self->site_label($site_label);
  }

##############
sub RNA_id {     
  my ($self, $value) = @_;
  my $RNA_id;
  $self->{'RNA_id'} = $value if $value ;
  unless ($self->{'RNA_id'}) {
     my $site_label = $self->site_label;
     ($RNA_id) = $site_label =~ /^(\w+)\.U/ ;
     $RNA_id || $self->throw("Could not parse site label $site_label");
     $self->{'RNA_id'} = $RNA_id;
  }
  return $self->{'RNA_id'} ;
}
##############
sub RNA_type {     
  my ($self) = @_;
  my $RNA_id = $self->RNA_id;
   my $allowed_target_types = join '|', @{$self->species->target_types};
   my ($RNA_type) = $RNA_id =~ /($allowed_target_types)/ ||
     $self->throw("Could not parse RNA_id $RNA_id for RNA_type");
#  my ($RNA_type) = $RNA_id =~ /([LS]SU)/;
#  $RNA_type || $self->throw("Could not parse RNA_id $RNA_id for RNA_type"); 
  return $RNA_type;
}

##############
sub site_number {     
  my ($self, $value) = @_;
  my $site_number;
  $self->{'site_number'} = $value if $value ;
  unless ($self->{'site_number'}) {
     my $site_label = $self->site_label;
     ($site_number) = $site_label =~ /\.U(\d+)$/ ;
     $site_number || $self->throw("Could not parse site label $site_label");
     $self->{'site_number'} = $site_number;
  }
  return $self->{'site_number'} ;
}
##############
=head2 target_lengths

 Title   : target_lengths
 Usage   : ($prelength, $postlength) = $target->target_lengths;
 Function: return actual 'instance' value of the number of nt pre and post the 'Y' in the pattern        
 Returns : array with number of nt pre and post the 'Y' in the pattern 
 Args    : none

=cut

sub target_lengths {     
  my ($self) = @_;
  my $site_pattern = $self->site_pattern ||
   $self->throw("Need a target pattern to compute pre and post lengths");
  $site_pattern =~ /^([ACGU]+)Y([ACGU]+)$/ ||
   $self->throw("Could not parse site pattern $site_pattern");
  my $prelength = length $1;
  my $postlength = length $2;
  return ($prelength, $postlength);
}

##############
=head2 prelength postlength

 Title   : prelength postlength
 Usage   : $target->prelength(
 Function: Get-set global (class) parameters        
 Returns : value of parameter
 Args    : value to set

=cut

sub prelength {     
  my ($self, $value) = @_;
  Target_pseudoU->params('prelength' => $value) if $value ;
  return Target_pseudoU->params('prelength');
}

sub postlength {     
  my ($self, $value) = @_;
  Target_pseudoU->params('postlength' => $value) if $value ;
  return Target_pseudoU->params('postlength');
}


##############
=head2 make_pattern

 Title   : make_pattern
 Usage   : $pattern = $target->make_pattern($pre_extend, $post_extend)
 Function: Retrieve target pattern (assumes target RNA is in attached seq)         
 Returns : string around target site, with target 'U' converted to 'Y'
 Args    : number of nt to extend before and after pseudoU [default 10]

Warning: This routine may yield unexpected results.  The problem is not with
the routine per-se but rather with the unreliability of rRNA residue
numbering. 

=cut

sub make_pattern {     
  my ($self, $prelength, $postlength) = @_;
  my $extension_default = 10;
  $prelength ||= $extension_default;
  $postlength ||= $prelength;
  # check that all is well
  my $targ_pattern;
  my $site_number = $self->site_number;
  $site_number ||
    $self->throw("Need site number to extract target \n");
  $self->start( $site_number);	#just to be safe
  $self->end( $site_number);
  $self->strand(1); 
  $self->get_target_seq; # does nothing if we already have it
  $targ_pattern = $self->superseq($prelength, $postlength)->seq;

  $targ_pattern = uc $targ_pattern;
  $targ_pattern =~ s/T/U/g;	# convert to RNA if necessary
  if ( $targ_pattern =~ /^[ACGU]{$prelength}U/ ) { # 
    substr($targ_pattern, $prelength, 1, "Y");
  } else {  
    $self->throw("Could not parse target pattern $targ_pattern for site_number $site_number \n");
  }  
#  return $self->site_pattern($targ_pattern);
   return $targ_pattern;
}
##############
=head2 get_target_seq

 Title   : get_target_seq
 Usage   : $seq = $target->get_target_seq;
 Function: Retrieve entire (rRNA) target-sequence associated with a specific target
           and attaches it to self if ID is that of current target        
 Returns : PrimarySeq object of entire target sequence
 Args    : $other_species_RNA_id (optional), otherwise uses id of current target

=cut

sub  get_target_seq {  
  my ($self, $other_ID) = @_;
  return $self->entire_seq if (!$other_ID && $self->entire_seq); 
  use Bio::Index::Fasta;
  # check that all is well
  my $RNA_id = $other_ID || $self->RNA_id;
  $RNA_id ||
    $self->throw("Need RNA-ID to extract target sequence \n");
  #hard-coded index file location for now
  my $base = '/home/peter/genome_data/';
  my $Index_File_Name =  $base . 'Target_RNA.index';  
  my $inx = Bio::Index::Fasta->new('-filename' => $Index_File_Name);
  my $seq = $inx->get_Seq_by_id($RNA_id) ||
    $self->throw("Unable to find target sequence $RNA_id\n");
  $self->attach_seq($seq) unless $other_ID ; # store for later use if retrieving seq of current target
  return $seq;
}
##############
=head2 retrieve_pattern_location

 Title   : retrieve_pattern_location
 Usage   : @locations = $target->retrieve_pattern_location;
 Function: Find position of target's pU in RNA sequence.  Mainly for debugging since it should
           be the same as that given by the site_number method        
 Returns : Array of positions of pU in pattern in sequence (usually only one), empty array if not found
 Args    : RNA sequence file (optional), otherwise determines file from id of current target

=cut

sub  retrieve_pattern_location {  
  my ($self, $RNA_file) = @_;
  my $target_seq;
  my @locations = ();
  if ($RNA_file) {
    my $seqIO = Bio::SeqIO->new('-file' => $RNA_file, '-format' => 'fasta');
    $target_seq = $seqIO->next_seq; # assumes only one sequence / file
  } else {
    my $target_species = $self->species ||
      $self->throw("Need File id or species to retrieve target pattern location");
    $target_seq = $self->get_target_seq;
  }
  my $seq = $target_seq->seq;
  $seq =~ s/T/U/g; # convert to RNA 
  $seq =~ s/[^ACGU]//g ; # strip gaps, spaces
  my $pattern = $self->site_pattern ||  
       $self->throw("Need site pattern to retrieve pattern location");
  $pattern =~ m/Y/  ||  
       $self->throw("Could not find Y in $pattern ");  # find location of pU in pattern
  my $postlength =  length $'; 
  $pattern =~ s/Y/U/g; # convert convert pseudoU symbol
  while ($seq =~ /$pattern/g ) {  # using /g for (unlikely) case of multiple matches
    push @locations, pos($seq) - $postlength;
  }
  print STDERR "\n****WARNING: Pattern $pattern not found in ", 
                $target_seq->id, " ****\n" unless scalar(@locations);  
  return @locations;
}
##############
=head2 next_target

 Title    :next_target
 Usage   : ($targ_id, $targ_desc, $prelength, $pattern) = Target_pseudoU->next_target($in_fh) 
 Function: Extract next target from a target file          
 Returns : array of target info or 0 at EOF
 Args    : input filehandle

=cut

  sub next_target {
    my ($self, $in_fh ) = @_;
    my ($targ_id, $targ_desc, $prelength, $pattern);
    while (my $line = <$in_fh> ) {
      next if $line =~ /^\s*#/ ; # skip comments
	($targ_id, $targ_desc, $prelength) = $line =~ /^(\S+)\s+(\S+)\s+(\d+)$/ ;
      #      print $targ_id; # debug
      $targ_id || 
	$self->throw("could not parse target id line $line");
      while ($line = <$in_fh> ) {
	next if $line =~ /^\s*	#/ ; #skip comments
	  ($pattern) = $line =~ /^([ACGTUY]+)$/;
	$pattern || 
	  $self->throw("could not parse target pattern $line");
        return ($targ_id, $targ_desc, $prelength, $pattern);
      }
    }
   return 0;
  }
##############
=head2 next_target_obj

 Title    :next_target_obj
 Usage   : $targ_obj = Target_pseudoU->next_target_obj($in_fh) 
 Function: Extract next target object from a target file          
 Returns : Target_pseudoU object or 0 at EOF
 Args    : input filehandle

=cut

  sub next_target_obj {
    my ($self, $in_fh ) = @_;
    my ($targ_id, $targ_desc, $prelength, $pattern) =
        $self->next_target($in_fh)  ;
    return 0 unless $targ_id;
    my $target = Target_pseudoU->new( '-site_pattern' => $pattern, 
                             '-site_label' => $targ_id);
    return $target;
}

##############
=head2 write_target_file

 Title    :write_target_file
 Usage   : $target->write_target_file($out_fh);
 Function: Write formatted target file associated with current target         
 Returns : Nothing
 Args    : output filehandle

=cut

sub write_target_file {
  my ($self, $out_fh ) = @_;
  my ($prelength, $id);
  if (!$self->site_label) {	# create label from site_number and target_ID
    ($self->site_number && $self->RNA_id) ||
      $self->throw("Missing all or part of target ID \n");
    $id = $self->RNA_id . '.U' . $self->site_number;
    $self->site_label($id);
  }
  my $targ_id = $self->site_label;
  my $targ_seq = $self->site_pattern;
  if ( $targ_seq =~ /^([ACGTU]+.)Y/ ) { # base before Y may not be determined
    $prelength = length($1);
  } else {  
    $self->throw("Could not parse target pattern $targ_seq for target $targ_id \n");
  }  
#  my $targ_desc = " Nd " . $prelength;
#  print $out_fh "$targ_id $targ_desc\n";
   print $out_fh "$targ_id ", $self->site_desc, " $prelength\n";
   print $out_fh "$targ_seq\n";
}
##############
=head2 create_from_RNA_file

 Title    : create_from_RNA_file
 Usage   : Target_pseudoU->create_from_RNA_file($other_species, $RNA_type);
 Function: Create a hash of Target_pseudoU objects for each uridine 
           Note: this is a _class_ method      
 Returns : Nothing (hash is stored within Target_pseudoU object)
 Args    :  species obj with pointer to RNA file
           RNA_id which includes LSU or SSU to specify which set of targets to
           create. If not specified creates both sets

=cut

sub create_from_RNA_file {
  my ($self, $second_species, $RNA_type) = @_;
  my ($desired_RNA,$rrna_seq_file) ;
  my $prelength = $self->params('prelength') ||
    $self->throw("Need prelength to create Target Hash from RNA file \n");
  my $postlength = $self->params('postlength') ||
    $self->throw("Need postlength to create Target Hash from RNA file \n");

   my @allowed_target_types = @{$self->species->target_types};
   


  if ($RNA_type) {
     $desired_RNA = $RNA_type; 
#   ($desired_RNA) = $RNA_type =~ /([LS]SU)/; 
  }
  for my $RNA (@allowed_target_types) {
#  for my $RNA ('LSU', 'SSU') {
    next if ($desired_RNA && ($desired_RNA ne $RNA) );
    my $second_species_RNA_id = $second_species->get_RNA_id($RNA);
    my $rrna_seqobj = Target_pseudoU->get_target_seq($second_species_RNA_id);
    #  while ( my $rrna_seqobj = $rrna_seqIO->next_seq) {
    my $rrna_seq = uc ($rrna_seqobj->seq);
    $rrna_seq =~ s/T/U/g;
    $rrna_seqobj->seq($rrna_seq); # uc & T->U for later use
    my $rrna_length = $rrna_seqobj->length;
    my $rrna_id = $rrna_seqobj->id;
    while ( $rrna_seq =~ /[U]/gi ) {
      next if ( (length $` < $prelength) ||  (length $' < ($postlength-1) ) ) ;
      my $matchposition = pos($rrna_seq);
      my $new_target = 
	Target_pseudoU->new('-site_number' => $matchposition,
					       '-RNA_id' => $rrna_id) ;
      $new_target->attach_seq($rrna_seqobj);
      my $pattern = $new_target->make_pattern($prelength, $postlength);
      $new_target->site_pattern($pattern);
    }				# end target-location loop
  my $RNA_key = $second_species->genome_seqid . '_' . $RNA;
  $self->params( $RNA_key => 1) ; # set species 'done' flag 
  }				# end RNA loop
#  $rrna_seqIO->close;
}
##############
=head2 retrieve_aligned_targets

 Title    :retrieve_aligned_targets
 Usage   : $aln = $self->retrieve_aligned_targets($target_aligned, $ortho_RNA_aligned);
 Function: Retrieves alignment (origninally from rRNA database) of target sequences       
 Returns : SimpleAlign object
 Args    : file-names of the two previously aligned targets sequences

=cut

sub retrieve_aligned_targets {
    my ($self, $target_aligned, $ortho_RNA_aligned) = @_;
    my ($fh, $align_file) = tempfile();
    my $command = "cat $target_aligned $ortho_RNA_aligned >$align_file";
 	system("$command");
 	my $alignIO = Bio::AlignIO->new('-file' => $align_file, '-format' => 'fasta');
 	my $aln = $alignIO->next_aln;
    return $aln;
}
##############
=head2 create_aligned_targets

 Title    :create_aligned_targets
 Usage   : $aln = $self->create_aligned_targets($other_species);
 Function: Create alignment of target sequences       
 Returns : SimpleAlign object
 Args    : file-names of the two unaligned target sequences

=cut

sub create_aligned_targets {
  my ($self, $other_species) = @_;
  my $target_species = $self->species;
  my $target_RNA_id = $self->RNA_id;
  my $ortho_RNA_id = $other_species->get_RNA_id($target_RNA_id);
  my $target_seq = $self->get_target_seq;
  my $ortho_seq = $self->get_target_seq($ortho_RNA_id);
  $self->throw("Need target and ortho seqs to create aligned targets") 
      unless (  $target_seq->isa('Bio::PrimarySeqI')  
             &&  $ortho_seq->isa('Bio::PrimarySeqI')  );
# Next perform actual alignment    
  use Bio::Tools::Run::Alignment::TCoffee;
  # Build a tcoffee alignment factory
  my @params = ('quiet' => 'stdout.temp' ); # Note that Tcoffee.pm doesn't want leading '-'
  my $factory = new Bio::Tools::Run::Alignment::TCoffee (@params);
  my $aln = $factory->align([$target_seq, $ortho_seq]);
#  my $aln = $factory->align($align_file);
  return $aln;
}
##############
=head2 ortho_target_object_global

 Title    :ortho_target_object_global
 Usage   : $target->ortho_target_global($other_species, $align_flag, $DEBUG, $prelength);
 Function:  see ortho_target_global       
 Returns : ortho_target_site as Target_pseudoU object
 Args    :  prelength = length to pass to "make pattern"
           for others see ortho_target_global
=cut

sub ortho_target_object_global {
    my ($self, $other_species, $align_flag, $DEBUG, $prelength) = @_;
    my $ortho_site_label = $self->ortho_target_global($other_species, $align_flag, $DEBUG);
    my $ortho_target = Target_pseudoU->new('-site_label' => $ortho_site_label);
    my $pattern = $ortho_target->make_pattern($prelength);
    $ortho_target->site_pattern($pattern);
    return $ortho_target;
}

##############
=head2 ortho_target_global

 Title    :ortho_target_global
 Usage   : $ortho_site_label = $target->ortho_target_global($other_species, $align_flag, $DEBUG);
 Function: Find single global orthologous target to current target 
   If structural alignments available for both species, uses it for
   alignment.  Otherwise performs alignment with tcoffee. If 'forced
   align' set, does tcoffee alignment even if structural files exist.
   If neither species has known global alignment, throws exception.        
 Returns : site_label of ortho_target
 Args    : species in which to look for homologous site
           align-flag if set forces actual global alignment 
              this is a temporary workaround to problems with structural alignments
           flag to turn on debug info

=cut

sub ortho_target_global {
    my ($self, $other_species, $align_flag, $DEBUG) = @_;
    my $target_species = $self->species;
    my $target_RNA_id = $self->RNA_id;
    my $ortho_RNA_id = $other_species->get_RNA_id($target_RNA_id);
    my $ortho_RNA_aligned = $other_species->aligned_rRNA_file($ortho_RNA_id);
    my $target_aligned = $target_species->aligned_rRNA_file($target_RNA_id); 
    my $target_site_number = $self->site_number;
    my ($aln, $status);
    my $status_OK = 1;
# Determine whether alignment can be simply read from aligned seqs or whether
# we need to actually perform the alignment    
    if ( -e $target_aligned && -e $ortho_RNA_aligned && !$align_flag) {
      $aln = $self->retrieve_aligned_targets($target_aligned, $ortho_RNA_aligned);
    } else {
      unless ( -e $target_aligned || -e $ortho_RNA_aligned ) {
	$self->warn("\nWarning! No structural alignment available for $target_RNA_id or $ortho_RNA_id. Attempting alignment anyway\n" );
      }
      $aln = $self->create_aligned_targets($other_species);
    } 
     my $pattern = $self->site_pattern || 
        $self->throw("Need pattern to do homology search") ;
# Get column of desired residue
    my ($pre_seq, $post_seq) = $pattern =~ /^([ACGTU]+)Y([ACGTU]+)$/;
    my $prelength = length $pre_seq;
       $pattern =~ tr /TY/UU/;	 	
    my @seq_list =  $aln->each_seq_with_id($target_RNA_id);
    my $target_seq =  $seq_list[0];
    my $column =  Bio::AnnotatableAlign->column_from_string($pattern, $target_seq ); #$column is start of pre_seq
    $self->throw("Could not find pattern $pattern in target seq") unless $column;
 
# need to increment column from start of 'pre_seq' to actual pseudoU
    while ($prelength > 0 ) {
      my $current_location =  $target_seq->location_from_column($column);
      $column++;
      if ( $current_location->isa('Bio::Location::Simple') &&
	   ( $current_location->location_type eq 'EXACT') ) {
	$prelength-- ;		#skip if gap
      }
    }	
    foreach my $ortho_seq ( $aln->each_seq_with_id($ortho_RNA_id) ) {
      my $ortho_location = $ortho_seq->location_from_column($column);     
      $status_OK = 0 unless (  $ortho_location &&
                              ($ortho_location->isa('Bio::Location::Simple') ) &&
			      ($ortho_location->start == $ortho_location->end ) ); # corresponding psotion is a 'gap'
      # get unaligned residue
      my $ortho_residue_number = $ortho_location->start; 
      my $ortho_residue = $ortho_seq->subseq($column,$column);
      #      my $ortho_residue = $self->_unaligned_subseq($ortho_seq, $ortho_residue_number, $ortho_residue_number);
      $status_OK = 0 unless ($ortho_residue =~ /[UuTt]/ ); # corresponding position is not a 'U'
      if (!$status_OK || $DEBUG) {
        # let's debug
	my $mini_aln = $aln->slice($column - 10, $column + 10);
	my $debug_out = Bio::AlignIO->new('-format' => 'fasta');
	print " column = $column\n";
	$debug_out->write_aln($mini_aln);
	print " residue = $ortho_residue\n";
	return 0 unless $status_OK;
      }
      #
      my $ortho_site_label = $ortho_RNA_id . '.U' . $ortho_residue_number ;
      return $ortho_site_label;
    }
}
##################
=head2 ortho_targets_local

 Title    :ortho_targets_local
 Usage   : $target->ortho_targets_local($species, $method);
 Function: Find orthologous targets to current target by *local* homology         
 Returns : Reference to array of site_labels of ortho_targets
 Args    : string to indicate species to be searched, reference to method hash:
    my $method = {
    'ID' =>'LOCAL_String-Approx' ,
    'pattern_dist_max' => 2 ,
    'ortho_dist_max' => 1000,
    'prefix_length' =>  10,  
    'suffix_length' =>  10,}; 
=cut

  sub ortho_targets_local {
    my ($self, $other_species, $method) = @_;
    my ($pattern_distance, $prefix_length, $suffix_length, $ortho_distance ); 

    my $other_species_id = $other_species->genome_seqid;

    my ($target_prelength, $target_postlength) = $self->target_lengths;
    my    $method_prelength = $method->{'prefix_length'};
    my    $method_postlength = $method->{'suffix_length'};
    my $RNA_type = $self->RNA_type;
    my $RNA_key = $other_species_id . '_' . $self->RNA_type;
    unless (exists $self->params->{$RNA_key}) {
      $self->throw(" Target pre- and post lengths -$target_prelength,$target_postlength - must"
		   . " be greater than method pre- and post lengths - $method_prelength,$method_postlength")
	unless (($target_prelength >= $method_prelength ) && ( $target_postlength >= $method_postlength));    

      $self->prelength($method_prelength); 
    $self->postlength($method_postlength); 
    $self->create_from_RNA_file($other_species, $self->RNA_type);
  }
  my $orthologs = [];
  my ($target2, $targ2_label);
#  my $genome1_pattern = $self->make_pattern($self->prelength, $self->postlength) ;


my $genome1_pattern = $self->site_pattern || 
   $self->throw("Need pattern to do homology search") ;
# Next trim the target pattern 
   $genome1_pattern =~ /[ACGU]{$method_prelength}Y[ACGU]{$method_postlength}/;   
   $genome1_pattern = $&;
   $genome1_pattern =~ s/Y/U/;

  my $source_targ_location = $self->site_number;
  while ( ($targ2_label, $target2) = each %{Target_pseudoU->find_site_label} ) {
    next unless $targ2_label =~ /$other_species_id/;          
    next unless $targ2_label =~ /$RNA_type/;          
    my $uridine2_position = $target2->site_number;
    $ortho_distance = abs($source_targ_location - $uridine2_position);	    
    next if ($ortho_distance > $method->{'ortho_dist_max'}   ) ;
    my $genome2_pattern = $target2->site_pattern  || 
      $self->throw("No target pattern found for position $uridine2_position\n");  
    if ($method->{'ID'} =~ /String-Approx/i) {
       $pattern_distance = String::Approx::adist($genome1_pattern, $genome2_pattern);
#      $pattern_distance = adist($genome1_pattern, $genome2_pattern);
    } else {			# method is smith-waterman
      #	    $pattern_distance = $self->_water($genome1_pattern, $genome2_pattern, $method);	    
	}
	# Check if species2 pattern is close enough to keep...
	next if ($pattern_distance   > $method->{'pattern_dist_max'} ) ;
# Add the found target to the orthologs target-collection
	push @$orthologs, $targ2_label;
    } # end uridine2 loop
    return $orthologs;  
}

##########
# Private 
##############
=head2 _unaligned_subseq

 Title    :_unaligned_subseq
 Usage   : $subseq = $target->_unaligned_subseq($seq, $unaligned_start, $unaligned_end);
 Function: Obtain substring of sequence after gap symbols have been removed         
 Returns : substring of sequence **without** gaps
 Args    : Bio::LocatableSeq and start and end locations
 
 By rights should be part of Bio::LocatableSeq but don't want to bother with 
 putting it there now.

=cut

sub _unaligned_subseq {
    my ($self, $seq, $unaligned_start, $unaligned_end) = @_;
    my $class = ref $seq;
    $self->throw("unaligned_subseq only works on Bio::LocatableSeq not $class") 
         unless $seq->isa('Bio::LocatableSeq');
    my $aligned_length = $seq->length;
    my $entire_seq = $seq->subseq(1,$aligned_length);
    $entire_seq =~ s/\W//g;
    my $unaligned_length = $unaligned_end - $unaligned_start +1;
    my $subseq = substr($entire_seq, $unaligned_start + 1, $unaligned_length);
    return $subseq;
    }  
  
__END__


