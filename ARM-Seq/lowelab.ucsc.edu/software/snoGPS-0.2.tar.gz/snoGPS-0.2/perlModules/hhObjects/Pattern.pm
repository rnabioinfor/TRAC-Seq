# POD documentation - main docs before the code

=head1 NAME

Pattern    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class is a type of Generic Sequence Feature which also implements 
"pattern" structures and methods

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

package Pattern;
use vars qw(@ISA);
use strict;
use Bio::SeqFeature::Generic;
use Bio::Seq;
use lib './scripts';  

@ISA = qw(Bio::SeqFeature::Generic);

use Class::MethodMaker  
  get_set => [qw / found_pattern local_start symbol/];


=head2 new

 Title   : new
 Usage   : $new_obj = Pattern->new( '-start' => $start, '-found_pattern' => $found_pattern)
 Function: Initial new object construction in manner consistent with Bioperl
 Returns : new Pattern object
 Args    : Any attributes of Pattern or Bio::SeqFeature::Generic

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    $self->set_Pattern_attributes(@args); # for compatibility with bioperl, can't use MethodMakers init_hash
    return $self;
  }

=head2 set_Pattern_attributes

  Title   : set_Pattern_attributes
  Function: Sets parameters specific to Pattern Features.
  Returns : none
  Args    : Named parameters, in the form as they would otherwise be passed
              to new(). Currently recognized are:
          -found_pattern   pattern-string found        
          -symbol          symbol to be used in display pattern        

=cut

    sub set_Pattern_attributes {
      my ($self,@args) = @_;
      my ($found_pattern, $symbol) =
	$self->_rearrange([qw(FOUND_PATTERN
	                      SYMBOL
			     )], @args);
      $found_pattern    && $self->found_pattern($found_pattern);
      $symbol    && $self->symbol($symbol);
    }


 ###########

sub seq_paired {
    my ($self, $unaligned_seq, $position, $other_stem_position) = @_;
    my $nuc1 = substr $unaligned_seq, $position, 1;
    my $nuc2 = substr $unaligned_seq, $other_stem_position, 1;
    my $result = $self->paired($nuc1, $nuc2);
    return $result;
}
 ###########

sub display_pattern {
    my ($self, $value) = @_;
    $self->{'display_pattern'} = $value if $value;
    return $self->{'display_pattern'} if  $self->{'display_pattern'};
    $self->create_display_pattern;
    return $self->{'display_pattern'};
}


############

sub paired {
    my ($self, $nuc1, $nuc2) = @_;
    if ((($nuc1 eq "A") && ($nuc2 eq "U")) ||
        (($nuc1 eq "C") && ($nuc2 eq "G")) ||
        (($nuc1 eq "G") && ($nuc2 eq "C")) ||
        (($nuc1 eq "U") && ($nuc2 eq "A"))) {
        return 1;
    }
    elsif ((($nuc1 eq "G") && ($nuc2 eq "U")) ||
           (($nuc1 eq "U") && (($nuc2 eq "G")))) {
        return 2;
    }
    else {
        return 0;
    }
}
############
__END__

