# POD documentation - main docs before the code

=head1 NAME

Generic_CandidateIO -  a "hit" from the pseudoU_test program  

=head1 SYNOPSIS

   $hit_IO = new HACA_CandidateIO ( '-file_handle' => $fh);
   $hit = $hit_IO->next_hit;
 
=head1 DESCRIPTION


=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package Generic_CandidateIO;
use vars qw(@ISA);
use strict;

use lib './scripts';  
use hhObjects::Species;
use hhObjects::HACA_Candidate;

use Bio::Root::Root ;
@ISA = qw(Bio::Root::Root);

use Class::MethodMaker  
  get_set => [qw / fh  /];

=head2 new

 Title   : new
 Usage   : $str = Generic_CandidateIO->new( '-file' => $file)
 Function: generate Generic_Candidate stream object 
 Returns : new Generic_Candidate stream object
 Args    : file  or file_handle (but not both) containing a Generic_Candidate hit list              


=cut

sub new {
  my ( $caller, @args) = @_;   
  my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
  $self->set_Generic_CandidateIO_attributes(@args); # for compatibility with bioperl, can't use MethodMakers init_hash
  return $self;
}

=head2 set_Generic_CandidateIO_attributes

  Title   : set_Generic_Candidate_attributes
  Usage   :  internal
  Function: Sets a whole array of parameters specific to Generic_Candidate at once.
    Returns : none
    Args    : Named parameters, in the form as they would otherwise be passed
    to new(). Currently recognized are:
    -file           
    -file_handle
  Either file or file_handle (but not both) must be set              

=cut

sub set_Generic_CandidateIO_attributes {
  my ($self,@args) = @_;
  my ($file, $file_handle) =
    $self->_rearrange([qw(FILE
			  FILE_HANDLE
			 )], @args);
  $self->throw("File or filehandle (but not both) must be set when creating a hit-stream")
    if ( ($file && $file_handle) || (!$file && !$file_handle) );
  if ($file) {
    open (HITFILE, "<$file") || $self->throw("Cannot open $file \n");
    $file_handle = *HITFILE;
  }
  $self->fh($file_handle);
}

=head2 next_hit

 Title   : next_hit
 Usage   :  
 Function: $hit_candidate = $hit_io->next_hit; 
 Returns : Generic_Candidate object
 Args    :  

=cut

  sub next_hit {
    my ($self) = @_;
    my $fh = $self->fh ;
    $/ = '####';  		#read in entire 'hit record' at a time
    my $record = <$fh>; 
    $/ = "\n";			# back to line-at-a-time mode to be safe
    my $hit = new Generic_Candidate ( '-record' => $record);
	 return $hit if $hit->id;
	 my $file_header = $self->parse_file_header($record);
	 return 0 unless $file_header;
# If we got here, we just read the file header so we need to read in the first hit
     $hit = $self->next_hit;
     return $hit if $hit->id;
     return 0; # EOF or give up
  }

=head2 write_hit

 Title   : write_hit
 Usage   :  
 Function: NOT IMPLEMENTED
 Returns :  
 Args    :  


=cut

sub write_hit {
    my ($self,$hit) = @_;
     $self->throw("Sorry. Writing of Hit_Candidates in \'pseudoU\' format is not implemented yet\n");
}
 

1;	

=head2 parse_file_header

 Title   : parse_file_header
 Usage   : $file_header = $self->parse_file_header($record); 
 Function: Parse & store file-header record, currently just checks whether a file-header is present
 Returns : the record if found, 0 otherwise
 Args    : the input record as a string

=cut

    sub parse_file_header {
	my ($self, $record) = @_;
	return 0 unless ($record && ($record =~ /##\sDescriptor/)  );
	    Generic_Candidate->file_header($record);
	    return $record; 
	}	
    __END__ 
