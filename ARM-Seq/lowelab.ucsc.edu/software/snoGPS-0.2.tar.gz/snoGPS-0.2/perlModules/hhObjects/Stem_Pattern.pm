# POD documentation - main docs before the code

=head1 NAME

Stem_Pattern    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class is a type of Generic Sequence Feature which also implements 
"pattern" structures and methods

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

package Stem_Pattern;
use vars qw(@ISA);
use strict;
use lib './scripts';  
use hhObjects::Pattern;

@ISA = qw(Pattern);

use Class::MethodMaker  
  get_set => [qw / complementary_stem /];


############
sub create_display_pattern {
    my ($self) = @_;
    next if $self->{'display_pattern'}; # may have already computed from other half of stem
	my @display_pattern_left;
	my @display_pattern_right;
    my ($left_feature, $right_feature);
    my $comp_feature = $self->complementary_stem;
    if ( $self->local_start < $comp_feature->local_start) {
      $left_feature = $self;
      $right_feature = $comp_feature;
     } else {
      $left_feature = $comp_feature;
      $right_feature = $self;
     }
# added 2/20/04
	unless ($left_feature->found_pattern && $right_feature->found_pattern) {
		print STDERR "Missing stem patterns\n";
		$left_feature->display_pattern('notFound');
		$right_feature->display_pattern('notFound');
		return;
	}
	my @left_pattern = split '', $left_feature->found_pattern;
	my @right_pattern = split '', $right_feature->found_pattern;
	my $length = scalar(@left_pattern);
	for my $position (0 .. $length -1) {
	    my $right_position = $length - $position - 1;
	    if ($self->paired($left_pattern[$position], $right_pattern[$position]) ) {
		if ($position == 0 || $position == $length -1 ) {
		    $display_pattern_left[$position] =  $display_pattern_right[$right_position] = $self->symbol;
		} else {
		    $display_pattern_left[$position] =  $display_pattern_right[$right_position] = $position % 10;
		}
	    } else {
		$display_pattern_left[$position] = ' ';   
		$display_pattern_right[$right_position] = ' ';   
	    }
	}
	$left_feature->display_pattern(join '', @display_pattern_left);
	$right_feature->display_pattern(join '', @display_pattern_right);
} 

__END__

=head2 new

 Title   : new
 Usage   : $new_obj = Stem_Pattern->new( '-start' => $start, '-found_pattern' => $found_pattern)
 Function: Initial new object construction in manner consistent with Bioperl
 Returns : new Stem_Pattern object
 Args    : Any attributes of Stem_Pattern  

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    return $self;
  }

