# POD documentation - main docs before the code

=head1 NAME

Generic_Candidate    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class also implements Bio::SeqFeatureI by inheriting
off Bio::SeqFeature::Generic.

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package Generic_Candidate;
use vars qw(@ISA);
use strict;
use Bio::SeqIO;
#use Bio::Location::Simple;
use Bio::Coordinate::Pair;

use File::Temp qw/ tempfile tempdir / ;
use lib './scripts';  
use hhObjects::Embedded_Feature;
use hhObjects::Target_pseudoU;

@ISA = qw(Embedded_Feature);

use Class::MethodMaker  
  get_set => [qw / mfold_per_base rnafold_per_base header db
              query_seq feature_description site_label site_number
              record  contig2absolute local2absolute absolute2local/],
  key_attrib => 'id',
  static_hash => 'class_variables' ;


=head2 new

 Title   : new
 Usage   : $new_obj = Generic_Candidate->new( '-query_seq' => $query_seq, 
                                               '-record' => $record, '-site_label' => $site_label)
 Function: Initial new object in manner consistent with inherited constructors from Bioperl
 Returns : new Generic_Candidate object
 Args    : Attributes of Generic_Candidate objects

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    $self->set_Generic_Candidate_attributes(@args); # for compatibility with bioperl, can't use MethodMakers init_hash
    $self->_read_record($self->record) if $self->record;   
    return $self;
  }

=head2 set_Generic_Candidate_attributes

  Title   : set_Generic_Candidate_attributes
  Usage   :
  Function: Sets a whole array of parameters specific to Generic_Candidate at once.
    Example :
    Returns : none
    Args    : Named parameters, in the form as they would otherwise be passed
    to new(). Currently recognized are:
    -query_seq           
    -feature_description              
    -site_label              
    -site_number              
    -record              

=cut

    sub set_Generic_Candidate_attributes {
      my ($self,@args) = @_;
      my ($query_seq, $feature_description, $site_label,
           $site_number, $record) =
	 $self->_rearrange([qw(QUERY_SEQ
			      FEATURE_DESCRIPTION
			      SITE_NUMBER
			      SITE_LABEL
			      RECORD
			     )], @args);
      $query_seq    && $self->query_seq($query_seq);
      $feature_description    && $self->feature_description($feature_description);
      $site_label    && $site_label->site_label($site_label);
      $site_number    && $self->site_number($site_number);
      $record    && $self->record($record);
   }

=head2 file_header

 Title   : file_header
 Usage   : Generic_Candidate->file_header($file_header);
 Function: Get-set global (class) file_heade parameter        
 Returns : value of parameter
 Args    : value to set

=cut

sub file_header {     
  my ($self, $value) = @_;
  Generic_Candidate->class_variables('file_header' => $value) if $value ;
  return Generic_Candidate->class_variables('file_header');
}

###################
=head2 get_candidate_neighbors

      Title   : get_neighbors
      Usage   : $neighbor_string = $feature->get_candidate_neighbors(5000);
      Function: Retrieve all Seq Features within a given distance of "self"         
      Returns : Array of SeqFeatureObjects
 Args    : Length: Look for features from (feature_start - Length) to (feature_end + Length)
           hit_object to use [default = 'self']

=cut

sub  get_candidate_neighbors {  
  my ($self, $extension) = @_;
  my  $neighbor_string = '';
  my $label = $extension ? 'nearby_genes' : 'overlapping_genes' ; 
  my $id = $self->id;
  if ($self->db) { 
    $neighbor_string = $self->db->get_value($id, $label);
    return $neighbor_string if (defined $neighbor_string);
  }  
  my @near_features = $self->get_neighbors($extension);
  if (!scalar(@near_features) ) {
    $neighbor_string .= " None";
    $self->db->store_value($id, $label, $neighbor_string) if $self->db; # store in db
    return $neighbor_string;
  }
  $neighbor_string .= "\n";
  foreach my $feature (@near_features) {
    my @attributes = $feature->attributes;
    $neighbor_string .= join '', $feature->display_name, "\t", $attributes[1], " start:", $feature->start,
      " end:", $feature->end, " strand:", $feature->strand, "\n";
  }
  #   $neighbor_string .= "\n";
  $self->db->store_value($id, $label, $neighbor_string) if $self->db; # store in db
  return $neighbor_string;
}

##########################
=head2 transform_coordinates

 Title   :  transform_coordinates
 Usage   :  @transformed_triple = $hit->transform_coordinates($trasformer,@input_triple )
 Function:  convert coordinate-triple (eg start, end, strand) between
            coordinate systems               
 Returns :  Coordinate triple output
 Args    :  transformer object and triple (start, end, strand) to be converted

=cut

sub transform_coordinates {     
  my ($self, $transformer, $in_start, $in_end, $in_strand) = @_;
  my ($out_start, $out_end, $out_strand);
  my $input = Bio::Location::Simple->new 
      (-start => $in_start , -end =>  $in_end , -strand=> $in_strand );
  my $res = $transformer->map($input);
  $out_start = $res->match->start;
  $out_end = $res->match->end;
  $out_strand = $res->match->strand;
  return ($out_start, $out_end, $out_strand);
}
#############
=head2 sort_by_query_position

 Title   : sort_by_query_position
 Usage   : $sorted_list = $self->sort_by_query_position( $input_list );
 Function:  sort hit-candidates by query_position 
 Returns :  list of candidate objects sorted by query_position
 Args    :  Ref to list of candidate objects

=cut



sub sort_by_query_position {     
  my ($self, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits ($input_list) ;
  my @temp = map { [$_ , $_->query_seq, $_->start, $_->end , $_->strand]  } @input_hits;
  my @sorted_temp = sort { 
                          $a->[0] cmp $b->[0]          # Sort by query seq_id
                                  ||
                          $a->[0] <=> $b->[0]          # next by start position
                                  ||
                          $a->[0] <=> $b->[0]          # next by end position
                                  ||
                          $a->[0] <=> $b->[0]          # finally by strand
                         } @temp;
  my @sorted_hits = map { $_->[0]} @sorted_temp;
  return @sorted_hits;
 }
#############
=head2 filter_by_query_position_and_strand

 Title   : filter_by_query_position_and_strand
 Usage   : $sorted_list = $self->filter_by_query_position_and_strand($input_list );
 Function:  sort hit-candidates by query_position 
 Returns :  list of candidate objects sorted by query_position with hits on same strand segregated
 Args    :  allowed fractional overlap [0.0 to 1.0]- must be included / no default
            reference to list of candidate objects

=cut

sub filter_by_query_position_and_strand {     
  my ($self, $allowed_overlap, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits ($input_list) ;
  $self->throw("Alowed overlap must be number between 0 and 1, not $allowed_overlap") 
    unless (  ($allowed_overlap >= 0 ) && ($allowed_overlap < 1 )  ) ;
  my @filtered_hits;
  
  my @sorted_temp = $self->sort_by_query_position_and_strand(\@input_hits);
  my $last_hit = $sorted_temp[0];
  foreach my $hit (@sorted_temp) {    # if new query_seq or opoosite strand keep hit
    if ( ($hit->query_seq ne $last_hit->query_seq) ||
         ($hit->strand ne $last_hit->strand) ) {
 		 push @filtered_hits, $hit;
         $last_hit = $hit;
         next;
   }
    my ($last_unique, $overlap, $current_unique) = $hit->overlap_extent($last_hit);  # from Bio::Range  
    my $current_overlap = $overlap / ($overlap + $current_unique) ;
    next if ( $current_overlap > $allowed_overlap );# skip hit, too much overlap
 	push @filtered_hits, $hit;
    $last_hit = $hit;
  } # end foreach
  return @filtered_hits;
 }

#############
=head2 sort_by_query_position_and_strand

 Title   : sort_by_query_position_and_strand
 Usage   : $sorted_list = $self->sort_by_query_position_and_strand($input_list );
 Function:  sort hit-candidates by query_position 
 Returns :  list of candidate objects sorted by query_position with hits on same strand segregated
 Args    :  list of candidate objects

Same as sort_by_query_position, except that all hits on same strand are kept together. This version
is needed in filtering since we generally want to keep overlapping conadidates on opposite strands

=cut

sub sort_by_query_position_and_strand {     
  my ($self, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits($input_list);
    my @temp = map { [$_ , $_->query_seq, $_->start, $_->end , $_->strand]  } @input_hits;
  my @sorted_temp = sort { 
                         $a->[0] cmp $b->[0]          # Sort by query seq_id
                                  ||
                         $a->[0] <=> $b->[0]           # next sort by strand
                                  ||
                          $a->[0] <=> $b->[0]          # next by start position
                                  ||
                          $a->[0] <=> $b->[0]          # finally by end position
                         } @temp;
  my @sorted_hits = map { $_->[0]} @sorted_temp;
  return @sorted_hits;
 }

#############
=head2 sort_by_score

 Title   : sort_by_score
 Usage   : $sorted_list = $self->sort_by_score($input_list );
 Function:  sort hit-candidates by score 
 Returns :  list of candidate objects sorted by score
 Args    :  Ref to list of candidate objects

=cut

sub sort_by_score {     
  my ($self, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits($input_list);
  my @temp = map { [$_->score, $_] } @input_hits;
  my @sorted_temp = reverse sort { $a->[0] <=> $b->[0] } @temp;
  my @sorted_hits = map { $_->[1]} @sorted_temp;
  return @sorted_hits;
 }
#############
=head2 filter_by_regex

 Title   : filter_by_regex
 Usage   : $filtered_list = $self->filter_by_regex($regex, $invert_flag, $input_list);
 Function:  filter hit-candidates by some regex in header line 
 Returns :  list of candidate objects filtered by regex 
 Args    :  regex to use
            invert_flag   ['invert'|'simple'] if 'invert', keep hits that do **not** match regex
            ref to list of candidate objects  


=cut

sub filter_by_regex {     
  my ($self, $regex, $invert_flag, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits($input_list);
  my @filtered_hits;
  $self->throw("Invert-flag must be \'simple\' or \'invert\' not $invert_flag\n")
    unless ( ($invert_flag eq 'simple' ) || ($invert_flag eq 'invert' ) );
  if ($invert_flag eq 'invert') {   
  @filtered_hits = grep { $_->header !~ /$regex/} @input_hits;  
  } else {
  @filtered_hits = grep { $_->header =~ /$regex/ } @input_hits;
  }
  return @filtered_hits;
 }

#############
=head2 filter_by_score

 Title   : filter_by_score
 Usage   : $filtered_list = $self->filter_by_score($score_cutoff, $input_list);
 Function:  filter hit-candidates by score 
 Returns :  list of candidate objects filtered by score 
 Args    :  ref list of candidate objects, score-cutoff value 


=cut

sub filter_by_score {     
  my ($self, $score_cutoff, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits ($input_list) ;
  my @filtered_hits = grep { $_->score >= $score_cutoff } @input_hits;
  return @filtered_hits;
 }

#############
=head2 filter_by_target

 Title   : filter_by_target
 Usage   : $filtered_list = $self->filter_by_target($site_label, $input_list);
 Function:  filter hit-candidates by target site_label 
 Returns :  list of candidate objects for specified target site
 Args    :  site_label of desired target, ref to list of candidate objects

=cut

sub filter_by_target {     
  my ($self, $site_label, $input_list ) = @_;   
  my @input_hits = $self->_set_input_hits($input_list);
  my @filtered_hits = grep { $_->site_label eq $site_label } @input_hits;
  return @filtered_hits;
 }

#############
=head2 filter_by_top_hits

 Title   : filter_by_top_hits
 Usage   : @filtered_list = $self->filter_by_top_hits($top_hit_number, $input_list);
 Function:  extract top "n" hits (by score) from list 
 Returns :  list of top n scoring candidate objects (sorted by score)
 Args    :  number of top hits to extract, ref to list of candidate objects

=cut

sub filter_by_top_hits {     
  my ($self, $number_to_extract, $input_list ) = @_;
  my @input_hits = $self->_set_input_hits($input_list);
  my @sorted_hits = $self->sort_by_score(\@input_hits);
  $number_to_extract--; # correction needed because arrays start at index "0"
  my @filtered_hits = @sorted_hits[0..$number_to_extract];
  return @filtered_hits;
 }

#############
=head2 target

 Title   : target
 Usage   : $hit_target = $hit->target();
 Function:  create target_object corresponding to target of current hit
 Returns :  Target_pseudoU object
 Args    :   

=cut

sub target {     
  my ($self) = @_;
  my $extend_length = 10 ;
  my $target_label =  $self->site_label ||
    $self->throw("Need target label to create new target");
  my $target =  Target_pseudoU->new('-site_label' =>  $target_label);
  $target->species($self->species) if   $self->species;  
 my $pattern;
 # First, check if this is a known pU site. If so retrieve the pattern
  $pattern = $target->species->retrieve_known_pattern($target_label);
# if known-pseudoU not found, make the pattern
  $pattern = $target->make_pattern($extend_length, $extend_length)
      unless $pattern;                                
  $target->site_pattern($pattern) ;  
  return $target;
}

#############
=head2 create_transformer

 Title   : create_transformer
 Usage   : $transformer = $self->create__transformer(@in_coords, @out_coords);
 Function:  create transformer to transform hit-feature coordinates
 Returns :  transformer object
 Args    :  input and output quadruples of coordinate systems

=cut

sub create_transformer {     
  my ($self, $in_id, $in_start, $in_end, $in_strand,
             $out_id, $out_start, $out_end, $out_strand ) = @_;
  my $match1 = Bio::Location::Simple->new 
      (-seq_id =>  $in_id , -start => $in_start, -end => $in_end , -strand=> $in_strand);
  my $match2 = Bio::Location::Simple->new
      (-seq_id =>  $out_id , -start => $out_start, -end => $out_end , -strand=> $out_strand);
  my $transformer = Bio::Coordinate::Pair->new(-in => $match1,
  					-out => $match2
                                        );
 return $transformer;
}

#############
sub mfold {
  my ($self, $auxfile) = @_;
  # Note 'mfold_score' is **score_per_base**
  my ($mfold_score_total, $mfold_score, $db);
  my $id = $self->id;
  $mfold_score = $self->mfold_per_base;
  if (defined $mfold_score) {
    return $mfold_score;
  }
  if ($self->db) { 
    my $mfold_score = $self->db->get_value($id, 'mfold');
    if (defined $mfold_score) {
      $self->mfold_per_base($mfold_score);
      return $mfold_score;
    }
  }
  # use specific tempfile since Temp::File is causing me problems  
  my $single_seq_fasta = 'temp/mfold.fasta';  
  #  my ($fh, $single_seq_fasta) = tempfile();
  my $out =  Bio::SeqIO->new('-format' => 'fasta', -file=> ">$single_seq_fasta");
  my $hitseq = $self->hit_seq ||
    $self->throw("Need actual sequence to run mfold\n");
  my $temp_id = $self->primary_tag || 'Candidate-sequence';
  my $seq = Bio::Seq->new( -display_id => $temp_id ,
			   -seq => $hitseq);

  $out->write_seq($seq) ;	# make temporary fasta file with single current hit-seq
  $out->close;  
  ($mfold_score_total, $mfold_score) = $self->_get_mfold_score($single_seq_fasta, $auxfile);
  $self->mfold_per_base($mfold_score);
  $self->db->store_value($id, 'mfold', $mfold_score) if ($self->db) ; # store in db
  return $mfold_score;
}

#############
sub rnafold {
  my ($self) = @_;
# Note 'rnafold_score' is **score_per_base**
  my ($rnafold_score_total, $rnafold_score);
  my $id = $self->id;
  $rnafold_score = $self->rnafold_per_base;
  if (defined $rnafold_score) {
    return $rnafold_score;
  }
  if ($self->db) { 
    my $rnafold_score = $self->db->get_value($id, 'rnafold');
    if (defined $rnafold_score) {
      $self->rnafold_per_base($rnafold_score);
      return $rnafold_score;
    }
  }
  my $seqline = $self->hit_seq;
# use specific tempfile since Temp::File is causing me problems  
  my $single_rnafold_fasta = 'temp/rnafold.fasta';  
# my ($fh, $single_rnafold_fasta) = tempfile();
  open (RNAFOLDFILE, ">$single_rnafold_fasta") or die ("Cannot open $single_rnafold_fasta \n");
  printf RNAFOLDFILE ">Candidate_seq \n";
  printf RNAFOLDFILE "$seqline"; # if a \n is appended to sequence, RNAfold complains
  close (RNAFOLDFILE);
  ($rnafold_score_total, $rnafold_score) = $self->_get_rnafold_score($single_rnafold_fasta);
  $self->rnafold_per_base($rnafold_score );
  $self->db->store_value($id, 'rnafold', $rnafold_score) if ($self->db) ; # store in db
  return $rnafold_score;
}

#########################
# private methods
########################
# set input hit list to default of all hits if not specified
sub _set_input_hits {     
  my ($self, $input_list ) = @_;
  my @input_hits;
  if ($input_list) {
    @input_hits = @$input_list;
  } else {
    @input_hits = values %{$self->find_id};
  }
  return @input_hits;
}

###############

# usually this will be overridden by something more specific
#
sub _read_record {
  my ($self, $record) = @_;
  my $status = $self->_read_header($record);
  return 0 unless $status;
}

###############

sub _read_header {
  my ($self, $record) = @_;
  my ($seq_name, $query_seq, $contig_from, $contig_to, $score, $header);
  my ($site_number, $site_label, $desc, $contig_strand, $H_or_ACA, $seq);

  if ($record =~ />((\S+)\.\d+)\s+ # query.candidate_number
      (
       (\S+)\s+			# score
       \(
       (\d+)\-(\d+)		# (from)-(to) 
       \)\s+              
     Cmpl:\s+(\S+\D)(\d+)\s.*	# Cmpl:site-number
       \/
       ([chCH])			# h|H or c|C (aca) (will need to change for non HACA hits!)
       .*    \(
       ([WC])			#  (W) or (C) strand
       \)                         
      )/x) { 
    $header = $&;                 
    $seq_name = $1;
    $query_seq = $2;
    $desc = $3;
    $score = $4;
    $contig_from = $5;
    $contig_to = $6;
    $site_label = $7 . $8;
    $site_number = $8;
    $H_or_ACA = $9;		# not currently stored
    $contig_strand = $10;
    $contig_strand = $contig_strand eq 'W' ? 1 : -1;  
  } else {
    return 0;
  }
  if ($record =~ /([ACGTUN]{40,})/i) {
    $seq = $1;  
  } else {
    return 0;
  } 
  my ($chromosome) = $seq_name =~ /chr(\w+)/;
  my ($contig) = $seq_name =~ /ontig(\w+)/;
 
  #Next we need to calculate the arrays for the (up to) three relevant coordinate
  #systems: local, segment (or "contig" or "Not_feature_segment") and absolute 
  # (or "chromosomal")
  my @absolute_coords;
  my @hit_in_local_coords = (1, $contig_to - $contig_from + 1, 1);
  if ($contig_strand == 1) { # Fix for 1-off error in pseudoU output
    $contig_from++;  $contig_to++;
  }
  my @hit_in_contig_coords = ($contig_from, $contig_to, $contig_strand);
  my @hit_in_absolute_coords = ();

  my ($base_name, $contig_start, $contig_end) =  
    $query_seq =~  /(\w+):(\d+):(\d+)/;

  if (defined $contig_start) {	# Query segment is part of a larger sequence (eg chromosome)
    $query_seq = $base_name;
    my @contig_in_contig_coords = ('contig', 1, $contig_end - $contig_start + 1, 1);
    my @contig_in_absolute_coords = ('absolute', $contig_start, $contig_end, 1);
    my $contig2absolute = $self->create_transformer(@contig_in_contig_coords,@contig_in_absolute_coords);
      @hit_in_absolute_coords = 
      $self->transform_coordinates($contig2absolute, @hit_in_contig_coords); 
  } else {
      @hit_in_absolute_coords = @hit_in_contig_coords;   
  }
  my $absolute2local = $self->create_transformer('absolute', @hit_in_absolute_coords, 'local', @hit_in_local_coords);
  my $local2absolute = $self->create_transformer('local',@hit_in_local_coords,'absolute', @hit_in_absolute_coords);

  $self->absolute2local($absolute2local);
  $self->local2absolute($local2absolute);

  $self->chromosome($chromosome) if $chromosome;
  $self->chromosome($contig) if $contig;
  $self->chromosome_or_contig('chromosome') if $chromosome;
  $self->chromosome_or_contig('contig') if $contig;
  $self->start($hit_in_absolute_coords[0]);
  $self->end($hit_in_absolute_coords[1]);
  $self->strand($hit_in_absolute_coords[2]);
  $self->query_seq($query_seq );
  $self->feature_description($desc );
  $self->score($score );
  $self->site_label($site_label );
  $self->site_number($site_number );
  $self->hit_seq($seq);

#  $self->id($seq_name); 
  my $id = "$seq_name." . $self->start;
  # Need to check that "Hit" id hasn't already been used
  if ( $self->find_id($id)) {
# removed warning 3/27/04. I can't remember why I cared and it's just confusing me now
#    $self->warn("Trying to set Hit id $id for site $site_number which is already used. This may not be what you want to do.\n");
  }
  $self->id($id);

  $self->header($header);
  $self->record($record);
}
############################

sub _get_mfold_score {
  my ($self, $single_seq_fasta, $auxfile) =@_;
  my ($score, $score_per_base, $length, $record);
  my $score_per_base_total = 0;
  my $mfold_file = $single_seq_fasta . '_1.ct';
  my $auxoption = $auxfile ? " AUX=$auxfile " : '';
  my $command2 ='';
  my $species = $self->species || 
    $self->throw("Need to know species and environment to run mfold\n");
  my $mfold_dir = $species->environment->{'mfold_dir'}; 
  my $command1 = "$mfold_dir/mfold SEQ=$single_seq_fasta $auxoption >stdout.temp";
  #    if ($opt_q) {  # this doesn't work yet !
  #	$command2 = " | egrep -v Fill|1\,2|10\,20 ";
  #	$command1 .= $command2 ;
  #    }
  print STDERR "$command1\n"; 
  my $status = system("$command1");
  if ($status != 0) {
    $self->throw("$command1 exited with status code $status and errno $!\n");
  }
  open(INFILE,"$mfold_file");
  $record = <INFILE>;     
  if ($record =~ /^\s*(\d+)\s+dG\s+=\s+(-\d+\.?\d*)/) {
    $score = $2;
    $length = $1;
  } else {
    die("Could not parse record $record of mfold result file $mfold_file");
  } 
  close(INFILE);    
  $score_per_base = $score / $length;
  return ($score, $score_per_base) ;
}

#############		  

sub _get_rnafold_score {
  my ($self, $single_seq_fasta) =@_;
  my ($score, $score_per_base, $length, $seq, $record);
  my $score_per_base_total = 0;
  my ($fh, $rnafold_file) = tempfile();
  my $species = $self->species || 
    $self->throw("Need to know species and environment to run mfold\n");
  my $RNAfold_dir = $species->environment->{'rnafold_dir'}; 
  my $command1 = "$RNAfold_dir/RNAfold <$single_seq_fasta >$rnafold_file";
  print STDERR "$command1\n"; 
  my $status = system("$command1");
  if ($status != 0) {
    $self->throw("$command1 exited with status code $status and errno $!\n");
  }
  open(INFILE,"$rnafold_file");
  local $/ ;			#slurp in record
  $record = <INFILE>;     
  if ($record =~ /\D(-\d+\.\d+)/) {
    $score = $1;
  }     
  if ($record =~ /([ACGTU ]{30,})/i) {
    $seq = $1;
    $seq =~ s/\s//g;
    $length = length $seq;
  }     
  $score_per_base = $score / $length;
  return ($score, $score_per_base) ;
}

__END__





=head2 local2contig

 Title   : local2contig
 Usage   : $hit->local2contig($local_start, $local_end, $local_strand)
 Function:  convert coordinate (eg start, end, strand) between
            "hit" and "contig" coordinate systems       
 Returns :  Coordinate value in "contig" coordinate system
 Args    :  Coordinate value triple in candidate-hits 
            coordinate system

=cut
# Not inplemented yet
sub local2contig {     
  my ($self, $value) = @_;
  return ;
}

=head2 contig2local

 Title   : contig2local
 Usage   : $hit->contig2local($contig_start, $contig_end, $contig_strand)
 Function:  convert coordinate-triple (eg start, end, strand) between
            "hit" and "contig" coordinate systems               
 Returns :  Coordinate value in candidate-hits 
            coordinate system
 Args    :  Coordinate value triple in "contig" coordinate system

=cut
# Not inplemented yet
sub contig2local {     
  my ($self, $value) = @_;
  return ;
}

sub _create_converters {
  my ($self, @local_coords, @contig_coords, @absolute_coords) = @_;
#  my $local2contig = $self->create_transformer(@local_coords, @contig_coords);
#  my $contig2local = $self->create_transformer(@contig_coords,@local_coords);
#  my $absolute2contig = $self->create_transformer(@absolute_coords, @contig_coords);
  my $contig2absolute = $self->create_transformer(@contig_coords,@absolute_coords);
  my $local2absolute = $self->create_transformer(@local_coords, @absolute_coords);
  my $absolute2local = $self->create_transformer(@absolute_coords,@local_coords);

  $self->contig2absolute($contig2absolute);
#  $self->absolute2contig($absolute2contig);
#  $self->contig2local($contig2local);
#  $self->local2contig($local2contig);
  $self->absolute2local($absolute2local);
  $self->local2absolute($local2absolute);
}
