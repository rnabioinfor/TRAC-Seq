# POD documentation - main docs before the code

=head1 NAME

Primary_Pattern    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class is a type of Generic Sequence Feature which also implements 
"pattern" structures and methods

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

package Primary_Pattern;
use vars qw(@ISA);
use strict;
use lib './scripts';  
use hhObjects::Pattern;
use constant HACA_LENGTH => 6;

@ISA = qw(Pattern);

use Class::MethodMaker  
  get_set => [qw / target_pattern /];


############
sub create_display_pattern {
    my ($self) = @_;
    my $symbol = $self->symbol;
    my $length = $self->found_pattern ?
                 length $self->found_pattern :  HACA_LENGTH; # default for HACA patterns
    $self->display_pattern($symbol x $length);
}

__END__

