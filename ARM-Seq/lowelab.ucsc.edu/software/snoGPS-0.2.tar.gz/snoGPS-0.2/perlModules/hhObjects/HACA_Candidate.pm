# POD documentation - main docs before the code

=head1 NAME

HACA_Candidate -  a "hit" from the pseudoU_test program  

=head1 SYNOPSIS


=head1 DESCRIPTION


=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut


# Let the code begin...

package HACA_Candidate;
use vars qw(@ISA);
use strict;
use Bio::Root::Root;

use lib './scripts';  
use hhObjects::Species;  
use hhObjects::Generic_Candidate;
use hhObjects::Primary_Pattern;
use hhObjects::Compl_Pattern;
use hhObjects::Stem_Pattern;

@ISA = qw(Generic_Candidate);

use Class::MethodMaker  
  get_set => [qw /  H_or_ACA H ACA HACA Stem2_I_L   
                    Stem1_I_L Stem1_I_R Stem1_X_L Stem1_X_R 
                    Stem2_I_R Stem2_X_L Stem2_X_R Comp_L Comp_R 
                  /];

=head2 new

 Title   : new
 Usage   : $new_obj = HACA_Candidate->new()
 Function: Initial new object in manner consistent with inherited constructors from Bioperl
 Returns : new HACA_Candidate object
 Args    : Attributes of parents of Generic_Candidate objects (see those modules for options)

=cut

  sub new {
    my ( $caller, @args) = @_;   
    my ($self) = $caller->SUPER::new(@args); # initialize parent attributes
    return $self;
  }

 ###########

sub annotation_string {
    my ($self, $value) = @_;
    $self->{'annotation_string'} = $value if defined $value; # added 'defined' 2/20/04
    return $self->{'annotation_string'} if defined $self->{'annotation_string'}; # added 'defined' 2/20/04
#    $self->{'annotation_string'} = $value if $value;
#    return $self->{'annotation_string'} if  $self->{'annotation_string'};
    $self->create_annotation_string;
    return $self->{'annotation_string'};
}

###########

=head2 create_annotation_string

 Title   :  create_annotation_string
 Usage   :  $annotation_string = $hit->create_annotation_string()
 Function:  Create an annotation string for display in hit alignment               
 Returns :  annotation_string
 Args    :  optional length argument added 3/27/04 for cases where HACA_Candidate parser
 					can not compute absolute start & end properly.  Should be backward compatible since
 					old callers will not be passing a $length argument

=cut

sub create_annotation_string {     
#  my ($self) = @_;
  my ($self, $length) = @_;
	my $subfeature;
	$length ||= $self->end - $self->start + 1;  # 3/27/04
#my $length = $self->end - $self->start + 1;
	my $annotation_string = ' ' x $length;

foreach $subfeature ( $self->get_SeqFeatures) {
# added 2/20/04 to deal with unparseable records
#  my $display = $subfeature->display_pattern;
#  if ($display && ($display eq 'notFound') ) {
#		return $self->annotation_string('');
#	}  
  next unless $subfeature->local_start; # may not have stem2 features
  my $display = $subfeature->display_pattern;
  my $offset = $subfeature->local_start - 1;
  my $length = length $display;
  substr($annotation_string, $offset, $length, $display);
}
return $self->annotation_string($annotation_string);
}

###########

=head2 align_homologs

 Title   :  align_homologs
 Usage   :  $aligned_homolog_obj = $hit->align_homologs($seq_array_ref)
 Function:  Use TCoffee to align set of homologs to hit               
 Returns :  AnnotatableAlign obj ( mod. SimpleAlign obj) or 0
            if less than 2 seqs in input array
 Args    :  Ref to array of PrimarySeqI objects to be aligned

=cut

sub align_homologs {     
  my ($self, $seq_array_ref) = @_;
  use Bio::Tools::Run::Alignment::TCoffee;
# Need at least two seqs to perform alignment
  return 0 if ( scalar(@$seq_array_ref) < 2 ) ;
  # Build a tcoffee alignment factory
  my @params = ('quiet' => 'stdout.temp' ); # Note that Tcoffee.pm doesn't want leading '-'
  my $factory = new Bio::Tools::Run::Alignment::TCoffee (@params);

  my $aln = $factory->align($seq_array_ref);

return $aln ;
}

###########

=head2 align_hit_annotation

 Title   :  align_hit_annotation
 Usage   :  $aligned_annotation = $hit->align_hit_annotation($aln);
 Function:  Insert gap symbols into Annotation String and then convert to Annotation Bio:LocatableAnnSeq obj               
 Returns :  aligned_annotation as a Bio:LocatableAnnSeq (Annotation) obj
            0 (and warns) if hit sequence not found in alignment or could not parse seq id
 Args    :  AnnotatableAlign obj in which the $hit sequence occurs
            optionally specified tag to identify associated sequence in alignment 

# Edited 9/17/03 to enable use of custom seqids
# Refactored 11/14/03: added private subroutines "_getPosition', "_getSeqId" 
#                            and methods "_stackWarn", "_getStartCol"
# 4/16/04 allow '|' in seq name since that's the way NCBOI genome seqs are 
=cut

##################
sub _stackWarn {  # kludgy way to display bioperl's stack messages without dying
    my ($mesg) = @_ ;
    warn ("$mesg\n");
    eval {
    	Bio::Root::Root->throw("$mesg");
    };
}
##################
sub _parseNse {   
	my ($nse) = @_;
# $nse =~ m{^([-\+\.:\w]+)		# name
  $nse =~ m{^([-\+\.\|:\w]+)		# name
	      /
	      (\d+) - (\d+)	# local start and end
	     }x;
	my ($id, $start, $end) = ($1, $2, $3);
  _stackWarn("Could not parse name-start-end in $nse\n") unless $id;  
	return $id
}

##################
sub _idMatch {
# allow for ':' to have been converted to '_' as workaround to problem in tCoffee
	my ($id, $seqId ) = @_ ;
  return 1 if ($id eq $seqId ) ;
  my $tCoffeeId = $seqId;
  $tCoffeeId =~ s/:/_/g;
  return 1 if ($tCoffeeId eq $id ) ;
  return 0;
}
	
##################
sub _getPosition {
# get the start position and id of the hit with id that matches $seqid     
  my ($aln, $seqId ) = @_;
  my ($foundPos, $foundId);
  my $order_hash = $aln->retrieve_order;
  while ( my ($position, $nse) = each %$order_hash) {    
    next if ($nse =~ /Ann:/);	# skip annotations
    my ($id, $start, $end) = _parseNse($nse);
    return -1 unless $id;
#    print STDERR " seqId = $seqId, id = $id \n";  #for debug only
    next unless _idMatch($id, $seqId ) ;
#    next unless ($id eq $seqId ) ;
#    next if ($nse !~ /$seqId/ ) ;
    $foundPos = $position;
    $foundId = $id;
    last;
  }
  unless ($foundId) {  
    _stackWarn("Could not find seqId $seqId in aln with id: " . $aln->id ."\n") ;
    return -1 ;
  }  
	return ($foundPos, $foundId);
}
################
sub _getSeqId {
# get the start position of the hit with id $seqid in the alignment     
  my ($self, $aln, $seqid ) = @_;
  return $seqid if $seqid;
  ($aln && $aln->isa('Bio::SimpleAlign'))  ||
    $self->throw("Need an alignment not $aln to align annotation\n");
  $self->throw("Need a species_id to align annotation\n")
    unless ($self->species && $self->species->genome_seqid);  
  return $self->species->genome_seqid;
} 

################
sub _getStartCol {
	my ($self, $aln, $id) = @_;
	my $string_begin = substr($self->hit_seq, 0, 20); #if we match the first 20 characters we should be OK
  $string_begin =~ s/-//g; # strip gaps
  my $annStartCol = $aln->column_from_string($string_begin, $id);
  _stackWarn("Could not find hit subseq $string_begin in $id\n") unless $annStartCol;
	return $annStartCol;
}

################
sub align_hit_annotation {     
  my ($self, $aln, $seqId ) = @_;
  $seqId = $self->_getSeqId($aln, $seqId);
  my ($position, $id) = _getPosition($aln, $seqId );
  return 0 if ( $position == -1 ); # _getPosition failed       
# get_seq_by_position starts at '1' while order hash starts at '0' => need to add 1
  my $hit_seq = $aln->get_seq_by_pos($position + 1);
  my $annStartCol = $self->_getStartCol($aln, $id);
  return 0 unless $annStartCol ; # _getStartCol failed
  my $alignAnnObj = $self->align_annotation_string($hit_seq, $annStartCol);
  return $alignAnnObj;  # 2/20/04 returns '0' if no annotation string
}

###########

=head2 align_annotation_string

 Title   :  align_annotation_string
 Usage   :  $aligned_annotation = $hit->align_annotation_string($master_seq, $annotation_start_column)
 Function:  Insert gap symbols into Annotation String and then convert to Annotation Bio:LocatableAnnSeq obj               
 Returns :  aligned_annotation as a Bio:LocatableAnnSeq (Annotation) obj
 Args    :  "Master" Sequence obj to align annotation to, start position of annotation in Master Seq
            Note master Seq comes from an alignment and may have '-' gap symbols
            match symbol [default = '.']
 11/16/03 refactored. created private subroutines: _confirmNoMatchSymbols, _insertAnnotationGaps

=cut

sub _confirmNoMatchSymbols {     
# check that there are no 'match' symbols in the master sequence
my ($self, $master_seq, $match ) = @_;
  $match ||= '.';
  my ($matching_char) = $match;
# escape the match character if necessary
  $matching_char = "\\$match" if $match =~ /[\^.$|()\[\]]/ ;  
  my $seq_string = $master_seq->seq;
  if ($seq_string =~ /$matching_char/ ) {
    $self->throw("Sorry can not align annotation string if alignment is in 'match' mode");
  }
}
#######################
sub _insertAnnotationGaps {
	my ($self, $master_seq, $annotation_start_column) = @_;
# When gap symbol ocurs in master sequence, insert a ' ' symbol in corresponding annotation sequence
	my @annotation = split '', $self->annotation_string; 
	my @aligned_annotation;
	my $master_length = length $master_seq->seq; 
	my $position = 0;		# position in annotation-string without gaps
	my $output_position = 0;	# position in annotation-string with gaps
	my $gap_count = 0;
	my $master_pos = $position + $annotation_start_column; #position in gapped master seq

  while ($position < length $self->annotation_string) {
  	last if ($master_pos > $master_length);
    if ($master_seq->subseq($master_pos,$master_pos) ne '-') {
       $aligned_annotation[$output_position] = $annotation[$position];
       $position++;
    } else {
       $aligned_annotation[$output_position] = '-';
       $gap_count++;
    }
    $output_position++;
    $self->throw("Error in processing alignment annotation\n")
       if ($master_pos > $master_seq->length );
    $master_pos++;
  }
  my $annotation_length = (length $self->annotation_string) + $gap_count;
	my $aligned_annotation = join '',  @aligned_annotation;
  return ($aligned_annotation, $annotation_length);
}


#######################
sub align_annotation_string {     
	my ($self, $master_seq, $annotation_start_column, $match ) = @_;
	unless ($self->annotation_string) {
  	_stackWarn("Could not find (unaligned) annotation string for hit: " . $self->id) ;
  	return 0;
  } 
#  $self->throw("Could not find (unaligned) annotation string for hit: " . $self->id)
#  		unless $self->annotation_string;
  my $id = "Ann: " . $self->id;
	my $master_length = length $master_seq->seq; 

	$self->_confirmNoMatchSymbols($master_seq, $match);
	my ($aligned_annotation, $annotation_length) = $self->_insertAnnotationGaps($master_seq, $annotation_start_column);
	# embed the annotation string into a string of '-' (gap symbols) the length of the master sequence
	my $aligned_annotation_string = '-' x $master_length; # aligned homologs may be longer than the hit sequence
 	substr($aligned_annotation_string, $annotation_start_column - 1, $annotation_length) 
       = $aligned_annotation;
# put the extended annotation string in an object so that it can be incorporated in the alignment
	my $aligned_annotation_obj = Bio::LocatableAnnSeq->new(-seq => $aligned_annotation_string, 
   		-id  => $id, -start => 1,  -end   => $master_length);
 	return $aligned_annotation_obj;
}

=head2 set_master_seq

 Title     : set_master_seq
 Usage     : $hit->set_master_seq($aln, $seq_id)
 Function  : Set the "master sequence" for an annotable alignment
 Returns   : complete id of new master_seq with its local start & end positions
 Args      : AnnotatableAlign obj, 
             ID-pattern to match for new master_seq [default is species genome_seqid]

=cut

sub set_master_seq  {
  my($self, $aln, $seqid) = @_;
  my($position, $nse);
  ($aln && $aln->isa('Bio::SimpleAlign'))  ||
    $self->throw("Need an alignment to set a master seq\n");
  $self->throw("Need a seqid or species_id to set a master seq\n")
     unless ($seqid || $self->species);  
  $seqid ||= $self->species->genome_seqid; 
  my $order_hash = $aln->retrieve_order;
  while ( ($position, $nse) = each %$order_hash) {
    next unless ( $nse =~ /$seqid/ );
    $aln->swap_order(0, $position) ;
#    $aln->swap_order(1, $position) ;
    last;
  }
  my ($id, $start, $end) = 
#   $nse =~ m{^(\w+)\.?\d*		# name
   $nse =~ m{^([\.\w]+)		# name
               /
               (\d+) - (\d+)    # local start and end
            }x;
 $self->throw("Could not parse master_seq nse $nse for seq_id $seqid\n") unless ($id && $start && $end);
 return  ($id, $start, $end);
}             


#######################################
#   Private methods

#############

sub _read_record {
    my ($self, $record) = @_;

    my $status = $self->_read_header($record);
    return 0 unless $status;

    $self->_initialize_pattern_objects;
    
  $self->_parse_found_patterns($record);
  $self->_parse_found_locations($record);
  $self->_compute_absolute_coordinates;
  $self->record($record);
}
######################################
sub _initialize_pattern_objects {
 my ($self) = @_;
 my %primary = ('H' => 'H', 'ACA' => 'C',  'HACA' => 'A');
 my %compl = ('Comp_L' => 'L', 'Comp_R' => 'R');
 my %I_stem_pairs = ('Stem1_I_L' => 'Stem1_I_R', 'Stem2_I_L' => 'Stem2_I_R');
 my %X_stem_pairs = ('Stem1_X_L' => 'Stem1_X_R', 'Stem2_X_L' => 'Stem2_X_R');
 my ($subfeature1, $subfeature2, $method, $left, $right, $symbol) ;
# @defaults are 'place-holder' values to keep SeqFeature->new from complaining
# They are set to the correct values in  _compute_absolute_coordinates 
# after the record is completely parsed
 my @defaults = ('-start' => $self->start, '-end' => $self->end, '-strand' => $self->strand);

 while (($method, $symbol) = each %primary ) {
    $subfeature1 = $self->$method( Primary_Pattern->new( @defaults, '-symbol' => $symbol)  );
    $self->add_SeqFeature( $subfeature1 );      
 }
 while (($method, $symbol) = each %compl ) {
    $subfeature1 = $self->$method( Compl_Pattern->new( @defaults, '-symbol' => $symbol)  );
    $self->add_SeqFeature( $subfeature1 );      
 }

 while (($left, $right) = each (%I_stem_pairs)) {
     $subfeature1 = $self->$left(  Stem_Pattern->new( @defaults, '-symbol' => 'I') );
     $subfeature2 = $self->$right( Stem_Pattern->new( @defaults, '-symbol' => 'I')  );
    $self->$left->complementary_stem($subfeature2);
    $self->$right->complementary_stem($subfeature1);
    $self->add_SeqFeature( $subfeature1 );  
    $self->add_SeqFeature( $subfeature2 );  
 }

 while (($left, $right) = each (%X_stem_pairs)) {
     $subfeature1 = $self->$left(  Stem_Pattern->new( @defaults, '-symbol' => 'X') );
     $subfeature2 = $self->$right( Stem_Pattern->new( @defaults, '-symbol' => 'X')  );
    $self->$left->complementary_stem($subfeature2);
    $self->$right->complementary_stem($subfeature1);
    $self->add_SeqFeature( $subfeature1 );  
    $self->add_SeqFeature( $subfeature2 );  
 }
}
######################################
sub _parse_found_patterns {
  my ($self, $record) = @_;
    
  if ($record =~  /LCompl:\s([ACGU]+)
      .+RCompl:\s([ACGU]+)
      .+IntStem:\s5'([ACGU]+)
                     .+ExtStem:\s5'([ACGU]+)/x ) {
    $self->Comp_L->found_pattern($1);
    $self->Comp_R->found_pattern($2);
    $self->Stem1_I_L->found_pattern($3);
    $self->Stem1_X_L->found_pattern($4);
  } else {
    print STDERR "\n**Could not parse LCompl patterns for ", $self->id, " **\n";
  }

  if ($record =~ /rRNA:\s([ACGU]+)
      .+\s:\s([ACGU]+)
      .+\s([ACGU]+)
      .+ExtStem:\s3'([ACGU]+)/x) {
  $self->Comp_L->target_pattern($1);
  $self->Comp_R->target_pattern($2);
  $self->Stem1_I_R->found_pattern($3);
  $self->Stem1_X_R->found_pattern($4);
  } else {
   print STDERR "\n**Could not parse rRNA patterns for ", $self->id, " **\n";
  }

                if ($record =~ /IntStem2:\s5'([ACGU]+)
      .+ExtStem2:\s5'([ACGU]+)/x ) {
   $self->Stem2_I_L->found_pattern($1);
   $self->Stem2_X_L->found_pattern($2);
  } else {
#   print STDERR "\n**Could not parse IntStem2 patterns for ", $self->id, " **\n";
  }

                if ($record =~ /\s+([ACGU]+)
                      .+ExtStem2:\s3'([ACGU]+)/x) {
    $self->Stem2_I_R->found_pattern($1);
    $self->Stem2_X_R->found_pattern($2);
  } else {
    #   print STDERR "\n**Could not parse ExtStem2 patterns for ", $self->id, " **\n";
  }
}

######################################
 sub _parse_found_locations {
 my ($self, $record) = @_;
  
                 if ($record =~   /IntStem2\sSc:.+\(
                      (\d+),(\d+)
                       .+ExtStem2\sSc:.+\(
                       (\d+),(\d+)/x ) {
  $self->Stem2_I_L->local_start($1);
  $self->Stem2_I_R->local_start($2);
  $self->Stem2_X_L->local_start($3);
  $self->Stem2_X_R->local_start($4);
  } else {
#   print STDERR "\n**Could not parse IntStem2 locations for ", $self->id, " **\n";
  }

	            if ($record =~  /IntStem\sSc:.+\(
		       (\d+),(\d+)
		        .+ExtStem\sSc:.+\(
		        (\d+),(\d+)/x ) {
  $self->Stem1_I_L->local_start($1);
  $self->Stem1_I_R->local_start($2);
  $self->Stem1_X_L->local_start($3);
  $self->Stem1_X_R->local_start($4);
  } else {
   print STDERR "\n**Could not parse IntStem locations for ", $self->id, " **\n";
  }

                if ($record =~  /LC\sSc:.+\(
	                (\d+)
		         .+RC\sSc:.+\(
		         (\d+).+Int/x) {
  $self->Comp_L->local_start($1);
  $self->Comp_R->local_start($2);
  } else {
   print STDERR "\n**Could not parse LC locations for ", $self->id, " **\n";
  }

if ($record =~  /\s+H:.+\((\d+)/x) {
$self->H->local_start($1);
  } else {
   print STDERR "\n**Could not parse H location for ", $self->id, " (probably 1-stem) **\n";
  }
if ($record =~  /\s+HACA:.+\((\d+)/x) {
$self->HACA->local_start($1);
  } else {
   print STDERR "\n**Could not parse HACA location for ", $self->id, " **\n";
  }
if ($record =~  /\s+ACA:.+\((\d+)/x) {
$self->ACA->local_start($1);
  } else {
   print STDERR "\n**Could not parse ACA location for ", $self->id, " (probably 1-stem)**\n";
  }
}

######################################
sub  _compute_absolute_coordinates{
  my ($self) = @_;
  my ($subfeature, $local_end) ;
  my $local_strand = $self->strand;
foreach $subfeature ( $self->get_SeqFeatures) {
  next unless $subfeature->local_start; # may not have stem2 features
  if ($subfeature->found_pattern) {
     $local_end = $subfeature->local_start + length $subfeature->found_pattern;
  } else { # HACA patterns currently have (hard-coded) fixed length 
     $local_end = $subfeature->local_start + 5;
  }
  my ($abs_start, $abs_end, $strand) = 
      $self->transform_coordinates($self->local2absolute, 
             $subfeature->local_start, $local_end, $local_strand);
  $subfeature->start($abs_start);
  $subfeature->end($abs_end);
  $subfeature->strand($strand);
}
}

######################################

__END__

