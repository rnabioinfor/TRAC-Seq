# POD documentation - main docs before the code

=head1 NAME

Primary_Pattern    

=head1 SYNOPSIS

  
=head1 DESCRIPTION


This class is a type of Generic Sequence Feature which also implements 
"pattern" structures and methods

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

package Compl_Pattern;
use vars qw(@ISA);
use strict;
use lib './scripts';  
use hhObjects::Pattern;

@ISA = qw(Pattern);

use Class::MethodMaker  
  get_set => [qw / target_pattern /];

############
sub create_display_pattern {
	my ($self,  $length) = @_;
	my @display_pattern;
	unless ($self->found_pattern && $self->target_pattern) {
		print STDERR "Missing complement patterns\n";
		return $self->display_pattern('notFound');
	}
	my @compl_pattern = split '', $self->found_pattern;
	my @rRNA_pattern = split '',  $self->target_pattern;
	for my $position (0..scalar(@rRNA_pattern) -1) {
		if ($self->paired($compl_pattern[$position], $rRNA_pattern[$position]) ) {
			$display_pattern[$position] =  $self->symbol;
		} else {
# Changed 3/25/04 because we need to be able to determine proximal end of guide region 
# even when proximal base is a mismatch 		
			$display_pattern[$position] = lc $self->symbol;    
#			$display_pattern[$position] = ' ';   
		}
	}
	$self->display_pattern( join '',  @display_pattern);
} 

