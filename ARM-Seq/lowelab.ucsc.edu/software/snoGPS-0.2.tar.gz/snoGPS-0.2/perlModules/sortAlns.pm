#! /usr/local/bin/perl

package sortAlns;
use strict;
use Getopt::Std;
use lib './scripts'; 
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use sortHits qw(:HIT_INDEXES &makeChromNumeric &pairsToPairScore);
use common;

use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT = qw();
	@EXPORT_OK = qw(&sortAlnByScore &sortAlnBySite &sortAlnBySpeciesScore &sortAlnByPairScore
			&sortAlnById &sortAlnByLocation &sortAlnBySiteAndSpeciesScore);
	%EXPORT_TAGS = (
        			);
}	   

######################
sub sortAlnByScore {
	my ($alnList) = @_;
	return 0 unless $alnList; 
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { $b->[1] <=> $a->[1] }  
		 map { [$_, $_->{'totalScore'}] } @$alnList;
	return \@sortedAligns;  
} 	

######################
sub sortAlnBySite {
	my ($alnList) = @_;
	return 0 unless $alnList;
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $a->[3] cmp $b->[3] ||
		 $a->[2] <=> $b->[2] ||
		 $b->[1] <=> $a->[1] 
		 }  
		 map { [$_, $_->{'totalScore'}, $_->{'site'}, $_->{'targetRna'}] } @$alnList;
	return \@sortedAligns;  
} 	

######################
sub getSpeciesVar {
	my ($aln, $species, $var) = @_;
	return -1 unless exists($aln->{$species});
	return -1 unless $aln->{$species}->[$var];
	return -1 if ($aln->{$species}->[$var] eq 'NA') ;
	return $aln->{$species}->[$var];
} 

######################
sub getSpeciesScore {
	my ($aln, $species) = @_;
	return getSpeciesVar($aln, $species, SCORE);
} 

######################
sub getSpeciesChrom {
	my ($aln, $species) = @_;
	return getSpeciesVar($aln, $species, CHROM);
} 

######################
sub getSpeciesStart {
	my ($aln, $species) = @_;
	return getSpeciesVar($aln, $species, GENOME_START);
} 

######################
sub makeChromNumericForSorting {
# returns a 'numeberized' chromosome number for sorting purposes only
# if chrom is numeric returns number, otherwise (eg chrX) returns numeric version
	my ($aln, $mainSpecies) = @_;
	my $chrom = getSpeciesChrom($aln, $mainSpecies);
	return 999 if ($chrom eq '-1') ; # can't sort
	my $numericChrom = makeChromNumeric($chrom);
	return $numericChrom;
}
				
######################
sub sortAlnByLocation{
	my ($alnList, $mainSpecies) = @_;
	return 0 unless $alnList; 
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $a->[2] <=> $b->[2] 
		 || 
		 $a->[3] <=> $b->[3] 
 		 ||	
 		 $b->[1] <=> $a->[1] 
		 }  
		 map { [	$_, $_->{'totalScore'}, makeChromNumericForSorting($_ , $mainSpecies), 
		 				  getSpeciesStart($_ , $mainSpecies)	 	]	} 
		 @$alnList;
	return \@sortedAligns;  
} 	

######################
sub sortAlnById {
	my ($alnList) = @_;
	return 0 unless $alnList; 
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $a->[2] cmp $b->[2] ||
		 $b->[1] <=> $a->[1] 
		 }  
		 map { [$_, $_->{'totalScore'}, $_->{'id'}] } @$alnList;
	return \@sortedAligns;  
} 	

######################
sub sortAlnBySpeciesScore {
	my ($alnList, $species) = @_;
	return 0 unless $alnList; 
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $b->[2] <=> $a->[2] ||
		 $b->[1] <=> $a->[1] 
		 }  
		 map { 
		 			[$_, $_->{'totalScore'}, getSpeciesScore($_ , $species)  ]
#		 			[$_, $_->{'totalScore'}, getSpeciesStart($_ , $species)  ]  # fixed bug 2/22/04
		 			} @$alnList;
	return \@sortedAligns;  
} 	

######################
sub sortAlnBySiteAndSpeciesScore {
	my ($alnList, $species) = @_;
	return 0 unless $alnList;
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $b->[3] cmp $a->[3] ||
		 $a->[2] <=> $b->[2] ||
		 $b->[1] <=> $a->[1] 
		 }  
		 map { [$_, getSpeciesScore($_ , $species) , $_->{'site'}, $_->{'targetRna'}] } @$alnList;
	return \@sortedAligns;  
} 	



######################
sub compositePairScore {
	my ($aln, $speciesList) = @_;
        my $speciesNum = my $pairScore = 0;
        foreach my $species (@$speciesList) {
          my $hit = $aln->{$species};
          next unless $hit->[CHROM];# skip, if no sequence available for this species
          $speciesNum++;
          $pairScore +=  $hit->[PAIRS] ? pairsToPairScore($hit->[PAIRS]): 0;
        }
        $pairScore = $speciesNum ? $pairScore / $speciesNum : 0;
        return $pairScore;
}


######################
sub sortAlnByPairScore {
	my ($alnList, $speciesList) = @_;
	return 0 unless $alnList;
	my @sortedAligns =
		 map { $_->[0] } 
		 sort { 
		 $b->[2] <=> $a->[2] ||
		 $b->[1] <=> $a->[1] 
		 }  
		 map { [$_, $_->{'totalScore'}, compositePairScore($_,$speciesList) ] } @$alnList;
	return \@sortedAligns;  
} 	


1;

__END__
