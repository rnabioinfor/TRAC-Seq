#! /usr/local/bin/perl

package sortHits;
use strict;
use Getopt::Std;
use lib './scripts'; 
use lib $ENV{MYPERLMODULEDIR}; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;
use hhObjects::HACA_Candidate;
use constant NAME => 1; use constant SCORE => 2; use constant STRAND => 3;  
use constant HITSTART => 4; use constant HITEND => 5; use constant RECORD => 0;  
use constant SITE => 7;  use constant PAIRS => 8; use constant TARGETRNA => 9; 
use constant CHROM => 10; use constant GENOME_START => 11; use constant GENOME_END => 12;
use constant SEQ => 13; use constant  DB => 6; use constant STEM => 15; use constant GENOME_STRAND => 16;
use constant SEQ_IN_ALN => 17; use constant ANN_SEQ => 14;
#use constant EXONS => 19; use constant INTRONS => 14; use constant NEIGHBORS => 18; UPSTREAM => 17;

use vars qw(
	@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS
	%option
	   );

BEGIN {
	use Exporter();
	@ISA = qw(Exporter);
	@EXPORT = qw(&sortHits &sortHitDirectory &sortHitsAppend);
	@EXPORT_OK = qw(&parseHeader &storeHit &totalAlnScore &sortByTotalScore &parseAllHits &pairsToPairScore
			&filterScoreAndRegexp &calcMatMisMat &subNewMatch &hdrToDb &knownSnoName
			&parseHeaderAndSeq &trimList &makeChromNumeric &completeSite &getSeq &makeAnnString
        			&NAME &SCORE &STRAND &HITSTART &HITEND &RECORD &SITE &PAIRS &TARGETRNA &STEM &DB
        			&SEQ &SEQ_IN_ALN &ANN_SEQ &GENOME_START &GENOME_END &CHROM &GENOME_STRAND);
	%EXPORT_TAGS = (
     	  			'HIT_INDEXES' => 
        			[qw (&NAME &SCORE &STRAND &HITSTART &HITEND &RECORD &SITE &PAIRS &TARGETRNA &STEM &DB
        			&SEQ  &SEQ_IN_ALN &ANN_SEQ &GENOME_START &GENOME_END &CHROM &GENOME_STRAND) ]
        			);
}	   

######################
sub pairScore {
  my ($match, $mismatch) = @_;
  my $mismatchCost = 1.25; # modified 3/30/04 
# my $mismatchCost = 1;
  return $match - $mismatch * $mismatchCost;
}

######################
sub completeSite {
	my ($hit) = @_;;
	return $hit->[TARGETRNA] .	".U" . $hit->[SITE];
}

######################
sub storeHit {
	my ($hitHash, $hit) = @_;
	my $key = join ':', $hit->[TARGETRNA], $hit->[SITE], $hit->[NAME], $hit->[HITSTART];
	$hitHash->{$key} = $hit;
	return $hitHash;	
}

######################
sub knownSnoName {
# For a 'known sno', its full name will start with something like H399, U66, E2, SE2b, ACA60 etc
	my ($fullName) = @_;
	if ($fullName =~ /^([HASUE][a-zA-Z0-9]+)/ ) {
		return $1;
	}
	return 0;	
}

######################
sub getGenomeCoords {
	my ($hit, $name)	 = @_;
	my ($genomeStart, $genomeEnd, $chrom, $contigStart, $contigEnd, $contigStrand, $genomeStrand);
	my $localStart = $hit->[HITSTART];
	my $localEnd = $hit->[HITEND];
	if ( $name =~ /.*(chr|Contig)(\w+):(\d+)-(\d+)([WC]?)/i ){  # the .* in the regex is to force a "rightmost" match
		$chrom = $1.$2;
		$contigStart = $3;
		$contigEnd = $4;
		$contigStrand = $5;
	}	else {
		return ( 'NA', 'NA', 'NA', 'NA');
	}				
 	if ($hit->[STRAND] eq '+' ) {   
		$genomeStart = $contigStart + $localStart ;
		$genomeEnd = $contigStart + $localEnd + 1;
 	} else {
		$genomeStart = $contigEnd - $localEnd + 1;
		$genomeEnd = $contigEnd - $localStart + 1;
#		$genomeStart = $contigStart + $localStart - 1 ;
#		$genomeEnd = $contigStart + $localEnd;
 	}
 	if (!$contigStrand ) { 
 		$genomeStrand = 'NA';
 	} elsif ($contigStrand eq 'W' ) { 
 		$genomeStrand = $hit->[STRAND];
 	} elsif  ($hit->[STRAND] eq '+' ) {  
 	 	$genomeStrand = '-';
 	} else {
 		$genomeStrand = '+';
 	}
	return ($chrom, $genomeStart, $genomeEnd, $genomeStrand);
}	

######################
{
my $prokaryoteDbs ;
	sub initProkaryoteDbs {
		$prokaryoteDbs = {
		'NC_002607' => 'hb' ,
		'NC_000854' => 'ap' ,  
		'NC_000868' => 'pa' ,  
		'NC_000909' => 'mj' ,  
		'NC_000917' => 'af' ,  
  	'NC_000961' => 'ph' , 
  	'NC_002754' => 'ss' , 
  	'NC_003106' => 'st' , 
  	'NC_003364' => 'pae' , 
  	'NC_003413' => 'pf' , 
 		'NC_005791' => 'mma' ,
  	'NC_000913' => 'ec' ,
 		'NC_003143' => 'yp' , 
 		'NC_003198' => 'se' , 
 		'NC_004337' => 'sf' , 
		'NC_004431' => 'ecc' }; 
		return $prokaryoteDbs;
	}
	sub hdrToDb {
		my ($hdr) = @_;
		$prokaryoteDbs ||=  initProkaryoteDbs() ;  
		my $db = 'NA'; #default value
# Note the regexes are complicated because 'mm3' or 'hgXX' is currently embedded in the
# names of the Ganot & Huttenhofer snos
		if ( $hdr =~ /hg\d+.+(hg|mm|rn|gg)(\d+)/ ){   
			$db = $1 . $2;
		}	elsif  ( $hdr =~ /mm\d+.+(hg|mm|rn|gg)(\d+)/ ){  
			$db = $1 . $2;
		}	elsif  ( $hdr =~ /(hg|mm|rn|gg)(\d+)/ ){  
			$db = $1 . $2;
		}	elsif ( $hdr =~ /(NC_\d+)/ ){
			$db = $prokaryoteDbs->{$1} . '0';
		}
		return $db;
	}
}
	
######################
sub parseName {
	my ($hit, $name)	 = @_;
	(	$hit->[CHROM], $hit->[GENOME_START], $hit->[GENOME_END], $hit->[GENOME_STRAND])
			= getGenomeCoords($hit, $name);	
	$hit->[DB] = hdrToDb($name);
	return $hit;			
}

######################
sub parseHeader {
	my ($record)	 = @_;
	my ($currentHit, $contigStart, $contigEnd);
  if ($record =~ m!>(\S+)\.\d+\s+
    				 (\S+)\s+
    				 \((\d+)\-(\d+)\)\s+
    				 Cmpl:\s*(\w+_)?([\-0-9a-zA-Z:]+)\.U(\d+)\s.* 
#    				 Cmpl:\s*(\w+_)?([\-0-9a-zA-Z]+)\.U(\d+)\s.* 
     				 Pairs:\s(\d+(\.5)?/\d+)/\d+/\d+/([HChc]).*
    				 (\d+)\s+bp.*
    				 ([WC])!x) {
		my $header = $&;
		my $name = $currentHit->[NAME] = $1;
		$currentHit->[SCORE] = $2;
		$currentHit->[HITSTART] = $3;
		$currentHit->[HITEND] = $4;
 		$currentHit->[TARGETRNA] = $6;
		$currentHit->[SITE] = $7;
		$currentHit->[PAIRS] = $8;
		my $stem = $10;
		my $hitLen = $11;
		my $strand = $12;
		$currentHit->[STEM] = (($stem eq 'H') || ($stem eq 'h') )? 5 : 3 ;  
		$currentHit->[STRAND] = '+' if ( $strand eq 'W') ;
		$currentHit->[STRAND] = '-' if ( $strand eq 'C') ;
 		$currentHit	= parseName($currentHit, $name);
		$currentHit->[RECORD] = $record;
		return $currentHit;
	} else {
		return 0;
	}	  
}

######################
sub getSite {
	my ($hit)	 = @_;
	return 0 unless $hit;
	return $hit->[SITE];  
}


######################
sub filterScoreAndRegexp {
	my ($record, $score, %option) = @_;
	return 0 if ( $option{acceptRegexp} && ($record !~ /$option{acceptRegexp}/) );	
	return 0 if ( $option{rejectRegexp} && ($record =~ /$option{rejectRegexp}/) ); 
	return 0 if ($option{minScore} && $score < $option{minScore}); 
	return 0 if ($option{maxScore} && ($score > $option{maxScore})  ); 
	return 1;
}


######################
sub filterRecord {
# returns 1 to include record, 0 to skip record 
	my ($record, $foundHit, %option) = @_;
#	my ($record, $foundHit, $lastHit, %option) = @_;
	return 0 unless $foundHit;
	my $score = $foundHit->[SCORE];
	return 0 if ( filterScoreAndRegexp($record, $score, %option) == 0);
	if ($option{pairs}) {
		my ($match, $misMatch, $remainder) = split "/", $foundHit->[PAIRS];
		return 0 if  pairScore($match, $misMatch) < $option{pairs} ;
#		return 0 if  ($match - $misMatch) < $option{pairs} ;
	}
	return 1;  
}


######################
sub sortBySite {
	my ($hitList, %option)	 = @_;
	return 0 unless $hitList; 
# added TARGETRNA to sort 3/9/04
	my @sortedList =
		sort {		
			$a->[TARGETRNA] cmp $b->[TARGETRNA] ||
			$a->[SITE] <=> $b->[SITE] ||
			$b->[SCORE] <=> $a->[SCORE]
		} @$hitList;
	return \@sortedList;  
}

######################
sub makeChromNumeric{
# returns a 'numeberized' chromosome number for sorting purposes only
# if chrom is numeric returns number, otherwise (eg chrX) returns numeric version
	my ($chrom) = @_;
	$chrom =~ s/(chr|Contig)//;
	return $chrom if ($chrom =~ /^(\d+)$/) ;
	return 24 if ($chrom =~ /^X/i) ; # put x and y chromosomes at end
	return 25 if ($chrom =~ /^Y/i) ;
	return 26 if ($chrom =~ /^U/i) ; # put 'unknown' chromosomes at very end
	if ($chrom =~ /^(\d+)\D/) {
		return $1 + 0.5;  # put 'random' chromosomes in place
	}
	# give up if we get here
	throw ("Could not parse chromosome name $chrom");
}
	
######################
sub sortByLocation {
	my ($hitList, %option)	 = @_;
	return 0 unless $hitList; 
	my @sortedHitList=
		 map { $_->[0] } 
		 sort { 
		 $a->[2] <=> $b->[2] 
		 || 
		 $a->[3] <=> $b->[3] 
 		 ||	
 		 $b->[1] <=> $a->[1] 
 		 ||	
 	 	 $a->[4] <=> $b->[4] 
		 }  
		 map { [	$_, $_->[SCORE], makeChromNumeric($_->[CHROM]), 
		 					$_->[GENOME_START] , $_->[HITSTART] 	]	} 
		 @$hitList;
	return \@sortedHitList;  
}

######################
sub pairsToPairScore {
  my ($pairs) = @_;
  my ($match, $misMatch, $remainder) = split "/", $pairs;
  return pairScore($match, $misMatch);
}

######################
sub sortByPairScore {
	my ($hitList, %option)	 = @_;
	return 0 unless $hitList; 
	my @sortedHitList=
		 map { $_->[0] } 
		 sort { 
		 $b->[2] <=> $a->[2] 
 	       ||	
 		 $b->[1] <=> $a->[1] 	
 		 }  
		 map { [$_, $_->[SCORE], pairsToPairScore($_->[PAIRS])] }
                   @$hitList;
	return \@sortedHitList;  
}

######################
sub sortByHit {
	my ($hitList, %option)	 = @_;
	return 0 unless $hitList; 
	my @sortedList =
		sort {
			$a->[NAME] cmp $b->[NAME] ||
			$b->[STRAND] cmp $a->[STRAND] ||
			$a->[HITSTART] <=> $b->[HITSTART]	||
			$b->[SCORE] <=> $a->[SCORE]
		} @$hitList;
	return \@sortedList;  
}
######################
sub sortByScore {
	my ($hitList, %option)	 = @_;
	return 0 unless $hitList; 
	my @sortedList =
		sort {
			$b->[SCORE] <=> $a->[SCORE]
		 }  @$hitList;
	return \@sortedList;  
}

######################
sub findOverlap {
	my ($hit1, $hit2, $overlapType)	 = @_;
	my ($label, $start, $end);
	if ($overlapType eq 'genomic') {
		$label = CHROM;
		$start = GENOME_START;
		$end = GENOME_END;
	} elsif ($overlapType eq 'local') {
		$label = NAME;
		$start = HITSTART;
		$end = HITEND;
	}	else {
		throw ("Unknown method $overlapType for determining overlaps, expected 'genomic' or 'local' ");
	}	
	return 0 unless ($hit2->[$label]); 
	return 0 if ($hit1->[$label] ne $hit2->[$label]);
	return 0 if ($hit1->[STRAND] ne $hit2->[STRAND]);
#	return 0 if ($hit1->[SITE] ne $hit2->[SITE]);
	my $start1 = $hit1->[$start];
	my $end1 = $hit1->[$end];
	my $start2 = $hit2->[$start];
	my $end2 = $hit2->[$end];
	if ( ($start1 < $end2) && ($start2 < $end1) ) {
		return 1;
	} else {
		return 0;
	}
}

######################

sub removeOverlaps {
# removes overlapping records for identical targets only
	my ($hitList, %option) = @_;
	my @filteredList;
	return 0 unless $hitList;
	my $prevHits = {};
	my $sortedHitList = $option{localOverlap} ? 
											sortByHit($hitList) : sortByLocation($hitList); 
# added TARGETRNA to $prevHits hash key 3/9/04
	foreach my $hit (@$sortedHitList) {
		my $site = $hit->[TARGETRNA];
		$site .= '.U' . $hit->[SITE];
		my $overlapType = $option{localOverlap} ? 'local' : 'genomic';
		my $recordsOverlap = findOverlap($hit, $prevHits->{$site}, $overlapType ) if exists($prevHits->{$site});
#		my $recordsOverlap = findOverlap($hit, $prevHits->{$site} ) if exists($prevHits->{$site});
		unless ($recordsOverlap) {
			push @filteredList, $prevHits->{$site} if exists($prevHits->{$site});
			$prevHits->{$site} = $hit;
			next;
		}
		next if ($hit->[SCORE] < $prevHits->{$site}->[SCORE] ) ;
		$prevHits->{$site} = $hit;
	}
	push @filteredList, values %$prevHits if $prevHits; # push remaining hits
	return \@filteredList;
}

######################

sub removeParalogs {
# removes records with identical sites, scores and pairs
# added TARGETRNA 3/9/04
	my ($hitList) = @_;
	my @filteredList;
	return 0 unless $hitList;
	my $prevRna = '';
	my $prevSite = 0;
	my $prevScore = 0;
	my $prevPairs = 0;
	my $sortedHitList = sortBySite($hitList); 
	foreach my $hit (@$sortedHitList) {
		my $targRna = $hit->[TARGETRNA];
		my $site = $hit->[SITE];
		my $score = $hit->[SCORE];
		my $pairs = $hit->[PAIRS];
		next if ( ($site == $prevSite) && 
							($targRna eq $prevRna) && 
							($score == $prevScore) && 
							($pairs eq $prevPairs) );
		$prevRna = $targRna;
		$prevSite = $site;
		$prevScore = $score;
		$prevPairs = $pairs;
		push @filteredList, $hit;		
	}
	return \@filteredList;
}

######################
sub extractRecords {
	my ($hitList) = @_;
	return 0 unless $hitList; 
	my @recordList;
	@recordList = map { $_->[RECORD] } @$hitList; 
	return \@recordList;  
}

######################
sub outputRecords {
	my ($overallHeaderRecord, $recordList, $outFh, %option) = @_;
	my $outputString = '' ;
	$outputString .= $overallHeaderRecord unless ($option{quiet});
	$outputString .= join '', @$recordList if $recordList;
	print $outFh $outputString;
	return $outputString;  
}
######################
sub hitsPerSite {
  my ($site, $hitsPerSite)	 = @_;
  if (exists $hitsPerSite->{$site}) {
    $hitsPerSite->{$site} += 1;
  } else {
    $hitsPerSite->{$site} = 1;
    #    return $hitsPerSite->{$site}; 
  }
  return $hitsPerSite;
}

######################
sub getHitOrAlnSite {
	my ($hitOrAln, $type) = @_;
	if ($type ne 'aln') {
  	my $completeSite = $hitOrAln->[TARGETRNA] . '.U' . $hitOrAln->[SITE]  ;
  	return $completeSite ;
  }
#  return $hitOrAln->[SITE]  if ($type ne 'aln');
  return $hitOrAln->{'completeSite'};	
}	

######################
sub trimList {
  my ($hitList, $maxCount, $type)	 = @_;
  return 0 unless $hitList; 
  my $trimmedList;
  my $hitsPerSite;
  foreach my $hit (@$hitList) {
    my $site = getHitOrAlnSite($hit, $type);
#    my $site = $hit->[SITE];
    $hitsPerSite = hitsPerSite($site, $hitsPerSite);
    next if ($hitsPerSite->{$site} > $maxCount);
    push @$trimmedList, $hit;
  }
  return $trimmedList;
}	

#####################
sub getSequenceData {
	my ($foundHit, $seqLine ) =@_;
	if ($seqLine =~ /^[ACGTUN]+$/i) {
		$foundHit->[SEQ] = $seqLine;
	} else {
		warn "Could not parse sequence line $seqLine";
	}
 	return $foundHit;
 }

######################	
sub parseHeaderAndSeq {
# create array of hit header and seq data if $line is header line that matches desired regex
# otherwise return 0
	my ($line, $inFh, %option) = @_;
	return 0 unless ($line =~ />/);
	return 0 if ( $option{acceptRegexp} && ($line !~ /$option{acceptRegexp}/) );	
	return 0 if ( $option{rejectRegexp} && ($line =~ /$option{rejectRegexp}/) ); 
    my $foundHit = parseHeader($line);
    die ("Could not parse hit line:\n $line\n") unless $foundHit;
	my $seqLine = <$inFh>;
    $foundHit = getSequenceData($foundHit, $seqLine );
	return $foundHit;
}



######################
sub parseTargs {
# Parse:   rRNA: ACGUUAA-5'	       : GUAAU
	my ($record) = @_;
	if ($record =~ 
					/rRNA:\s+
					([ACGU]+)
					-5'\s+:\s+
					([ACGU]+)
					/x
					) {
		return ($1, $2);
	}
	return (0,0);
}		 	 

######################
sub parseGuides {
#  Parse: LCompl: UGCAAUU-3'	 RCompl: CAUUA	
	my ($record) = @_;
	if ($record =~ 
					/LCompl:\s+
					([ACGU]+)
					-3'\s+RCompl:\s+
					([ACGU]+)
					/x
					) {
		return ($1, $2);
	}
	return (0,0);
}		 	 

######################
sub subNewMatch {
	my ($record, $mat, $misMat) = @_;
# substitute into: 	Pairs: 12/0/9/6/H
	$record =~ s!Pairs: \d+(\.5)?/\d+!Pairs: $mat/$misMat!;
	return $record;
}

######################
sub lCompGuideTarg {
	my ($targ,$guide) = @_;
	my $currMat = 0 ; my $currMisMat = 0 ; my $currScore = 0 ;
	return (-1, -1) unless (length($targ) == length($guide) );
	my @targ = split //, $targ;
	my @guide = split //, $guide;
	for (my $i = 0; $i < length($targ); $i++) {
		my $cmpOne = compSingle($targ[$i], $guide[$i]);
		if ($cmpOne > 0) { # match
			$currMat += $cmpOne;
			$currScore += $cmpOne;
		} elsif ($currScore <= 1) {  # skip initial mismatches for *left* guide only
			$currMat = $currMisMat = $currScore = 0;
		} else {
			$currScore = pairScore($currScore,1) ;  #mismatch
#			$currScore-- ;  #mismatch
			$currMisMat++;
		}
	}
	return ($currMat, $currMisMat);
}

######################
sub rCompGuideTarg {
	my ($targ,$guide, $mismatchCost) = @_;
	my $bestMat = 0 ; my $bestMisMat = 0 ; my $bestScore = 0 ;
	my $currMat = 0 ; my $currMisMat = 0 ; my $currScore = 0 ;
	return (-1, -1) unless (length($targ) == length($guide) );
	my @targ = split //, $targ;
	my @guide = split //, $guide;
	for (my $i = 0; $i < length($targ); $i++) {
		my $cmpOne = compSingle($targ[$i], $guide[$i]);
		if ($cmpOne > 0) { # match
			$currMat += $cmpOne;
			$currScore += $cmpOne;
			if ($currScore > $bestScore) {
				$bestMat = $currMat;
				$bestMisMat = $currMisMat;
				$bestScore = $currScore;
			}
		} else {
			$currScore = pairScore($currScore,1) ;  #mismatch
#			$currScore-- ;  #mismatch
			$currMisMat++;
		}
	}
	return ($bestMat, $bestMisMat);
}

######################
sub calcMatMisMat {
	my ($record) = @_;
        my $mismatchCost = 1;
 	my ($lTarg, $rTarg) = parseTargs($record);
 	my ($lGuide, $rGuide) = parseGuides($record);
 	throw ("Could not parse guides & targets for record:\n $record\n") 
 		unless ($rTarg && $rGuide);
# Created specific left and right guide match routines 3/25/04
# because end mismatches are treated differently in both cases
# my ($lMat, $lMisMat) = compGuideTarg($lTarg,$lGuide);
# my ($rMat, $rMisMat) = compGuideTarg($rTarg,$rGuide);
 	my ($lMat, $lMisMat) = lCompGuideTarg($lTarg,$lGuide,$mismatchCost );
 	my ($rMat, $rMisMat) = rCompGuideTarg($rTarg,$rGuide, $mismatchCost);
  my $mat =  $lMat + $rMat;	
  my $misMat =  $lMisMat + $rMisMat;	
	return ($mat, $misMat);
}	
 	
######################
sub fixPairsRec {
	my ($record) = @_;
	my ($mat, $misMat) = calcMatMisMat($record);
 	$record = subNewMatch($record, $mat, $misMat);
 	return ($record, $mat, $misMat);
}

######################
sub fixPairsHit {
	my ($hit) = @_;
	my $record = $hit->[RECORD];
	my ($fixedRec, $mat, $misMat) = fixPairsRec($record);
	$hit->[RECORD] = $fixedRec;
	$hit->[PAIRS] = "$mat/$misMat";
	return $hit;
}

######################
sub parseAllHits {
	my ($inFile, %option)	 = @_;
	my ($hitList);
	my $inFh = getInFh($inFile);
  my $overallHeaderRecord ='';
  my $filterStatus = 1;
  my $lastHit = []; my $currentHit = [];
  $/ = '####';  		#slurp in record
  while (my $record = <$inFh>) {
    my $foundHit = parseHeader($record);
    if ( !$foundHit) {		# Header record
      $overallHeaderRecord .= $record;
      next;
    }
   	$foundHit = fixPairsHit($foundHit) if $option{fixPairs}; #must fix pairs before filtering
   	$filterStatus = filterRecord($record, $foundHit, %option );
  	push @$hitList, $foundHit if $filterStatus == 1;
  }
  $/ = "\n";			#back to normal mode
  close($inFh);
  print STDERR "\n****Could not parse any hits in file $inFile!!***\n\n"
  	unless $hitList;
	return ($hitList, $overallHeaderRecord) ;
}	


######################
sub sortHitsAppend {
# write sorted hits to already opened fileHandle 
# and return them as a long string as well
  my ($infile, $outFh, %option) = @_;
  $option{minScore} ||= 10.0;
#  my $resultBuffer = '';	#store result internally as well as printing
  my ($sortedHitList) ;
	my ($hitList, $overallHeaderRecord)  = parseAllHits($infile, %option);
  throw("Could not parse any hits in file $infile\n")
    if (!$hitList && $option{interactive} ) ;
	$hitList = removeOverlaps($hitList, %option) if ($option{overlap} || $option{localOverlap} ) ;
	$hitList = removeParalogs($hitList) if $option{paralogs};
  if ($option{filterOnly} ) {		# filter only
    my $recordList = extractRecords($hitList);
    return outputRecords($overallHeaderRecord, $recordList, $outFh, %option);
  }
  if ($option{sortBySite}) {
    $sortedHitList = sortBySite($hitList, %option);
  } elsif ($option{sortByPairScore}) {
    $sortedHitList = sortByPairScore($hitList, %option); 
  } elsif ($option{sortByHit}) {
    $sortedHitList = sortByHit($hitList, %option); 
  } elsif ($option{sortByLocation}) {
    $sortedHitList = sortByLocation($hitList, %option); 
  } else {			# 
    $sortedHitList = sortByScore($hitList, %option); 
  }
  my $hitsPerSite = {};
  if ($option{topHitsOnly}) {
    $sortedHitList = trimList($sortedHitList, $option{topHitsOnly}, 'singleHit');
  }
  my $recordList = extractRecords($sortedHitList);
  return outputRecords($overallHeaderRecord, $recordList, $outFh, %option);
}

######################
sub sortHits {
	my ($infile, $outfile, %option) = @_;
	my $outFh = getOutFh($outfile);
	my $sortedHits = sortHitsAppend($infile, $outFh, %option);
    close $outFh;
    return $sortedHits;
}

######################
sub sortHitDirectory {
	my ($indir, $outfile, %option) = @_;
	$indir =~ s{/$}{};		#remove trailing slash if nec.
	opendir(INDIR, $indir) or die "Couldn't open as directory: $indir: $!\n";
	my $catCommand = 'cat ';
	my $catFile = '/tmp/eraseme.cat';
	unlink $catFile if (-f $catFile); 
	foreach my $name (readdir INDIR) {
#		next if ( -d "$indir/$name");
		next unless ( -f "$indir/$name");  # eliminate dirs  
		next if ( $name =~ /\s+/);  # file names with whitespace
		next if ($option{filenameRegexp} && ( $name !~ /$option{filenameRegexp}/i) );
		$catCommand .= " $indir/$name";
	}
	$catCommand .= " > $catFile";
#	print STDERR "$catCommand\n"; # DEBUG ONLY
	system($catCommand) == 0 	|| 
		die "Could not make temp cat file for dir $indir: $?";
	sortHits($catFile, $outfile, %option);
	unlink $catFile;
}


######################
sub getSeq {
	my ($hitRec) = @_;
# retrieve sequence from hit record
	my @hitRec = split /\n/, $hitRec;
	for (my $i = 0; $i < scalar(@hitRec); $i++) {
		my $line = $hitRec[$i];
		next unless ($line =~ /^>/);
		my $seqLine = $hitRec[$i+1];
		throw ("Could not parse sequence line:\n $seqLine\n in record $hitRec\n")
			unless ($seqLine =~ /^[acgtnu]+$/i);
		return $seqLine;
	}
	throw ("Could not find a header line in record $hitRec\n")
	
}

######################
sub makeAnnString {
	my ($hitRec, $seqLen) = @_;
# create annotation string from hit record
# intended to encapsulate all the parsing complexities of the HACA_Candidate Object
	$hitRec =~ s/^.+>/>/s; # remove any commentary detritus before header line
	my $hitObj = HACA_Candidate->new( '-record' => $hitRec);
	my $annString = $hitObj->create_annotation_string($seqLen);
	return $annString;	 
}



1;

__END__

