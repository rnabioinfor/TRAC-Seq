# POD documentation - main docs before the code
#

=head1 NAME

AnnotatableAlign - Multiple alignments held as a set of sequences with 
"Annotation Sequences"

=head1 SYNOPSIS

=head1 DESCRIPTION


=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object
methods. Internal methods are usually preceded with a _

=cut

# 'Let the code begin...

package Bio::AnnotatableAlign;
use vars qw(@ISA %CONSERVATION_GROUPS);
use strict;

use lib './scripts';
use Bio::SimpleAlign;
use Bio::LocatableSeq;         # uses Seq's as list
use Bio::LocatableAnnSeq;      # Annotation "Sequence"

@ISA = qw(Bio::SimpleAlign);

=head2 new

 Title     : new
 Usage     : my $aln = new Bio::AnnotatableAlign();
 Function  : Creates a new annotated align object
 Returns   : Bio::AnnotatableAlign
 Args      : 

=cut


sub new {
  my($class,@args) = @_;

  my $self = $class->SUPER::new(@args);

  return $self;  
}

=head2 swap_order

 Title     :  swap_order
 Usage     :  $aln->swap_order(1,4);
 Function  :  Exchange the position of two seqs(or annotation strings) in the alignment
 Returns   :  1 if interchanged succeeded, 0 otherwise
 Args      :  Positions of rows in alignment (including any annotation strings) to be
              exchanged, Both positions must be less <= # of seqs 

=cut

sub  swap_order {
  my($self, $pos1, $pos2) = @_;
  my $seq1 = $self->{'_order'}->{$pos1} ||
     return 0;
  my $seq2 = $self->{'_order'}->{$pos2} ||
     return 0;
 $self->{'_order'}->{$pos1} = $seq2;    
 $self->{'_order'}->{$pos2} = $seq1;     
 return 1;  
}

#############################
=head2 retrieve_order

 Title     : retrieve_order
 Usage     : $order_hash = $aln->retrieve_order;
 Function  : Retrieve the alignment's order hash
 Returns   : Ref to hash with keys being integers from 1 to no_seqs
             and values being ids of the seqs at that position in the alignment
 Args      : none

=cut

sub  retrieve_order {
  my($self) = @_;
  my $hash = $self->{'_order'};
  return $hash;  
}
#############################
=head2 revcomp

 Title     : revcomp
 Usage     : $aln->revcomp()
 Function  : Rev comp all data sequences in alignment
 			 reverse all annotation sequences in alignment
 Returns   : -
 Args      : -

=cut

sub  revcomp {
  my($self) = @_;
  foreach my $seq ( $self->each_seq() ) {
    my $seqString = $seq->seq;
    my $revString =  reverse($seqString);  # reverse sequence
    if ( $revString = m/^[-ACGTU]+$/i) { # data sequence?
      $revString =~ tr/acgtuACGTU/tgcaaTGCAA/; # if so, complement as well
    }
    $seq->seq($revString);
  }
 }

#############################
=head2 add_initial_seq

 Title     : add_initial_seq
 Usage     : $aln->add_initial_seq($new_seq)
 Function  : Inserts sequence (or annotation) in position 1, all other sequences move
             to positions increased by 1
 Returns   : 
 Args      : Bio::LocateableSeq

=cut

sub  add_initial_seq {
  my($self, $new_seq) = @_;
  $self->add_seq($new_seq);
  my $number_seqs = $self->no_sequences;
  for my $i (0...$number_seqs-2) {
#  for my $i (1...$number_seqs-1) {
#   $self->swap_order($i, $number_seqs);
   $self->swap_order($i, $number_seqs-1);
  }
}
#############################

=head2 column_from_string

 Title     : column_from_string
 Usage     : $column = $aln->column_from_string($string, $seq, $match);
 Function  : returns column of (first) occurrence of $string in the (first) sequence
             with ID $seq_id. 
 Returns   : column number (starts at 1) returns undef if not found
 Args      : string to search for and 
             either ID of sequence_obj in alignment or the sequence_object itself
             optional match symbol (default = '.') . Warning, if ma

The hard part of the subroutine is that the string may be interrupted with
gap symbols in the alignment. Also, we need to 'unmatch' the sequence before we can
search for the string.  And if we 'unmatch' we must remember to put the alignment
back in 'match' mode when we are done.

=cut

sub column_from_string  {
  my($self, $string, $seq, $match) = @_;
  my ($column, $seq_obj, $unmatched_flag_set);
  my @seq_list;
  $match ||= '.';
  my ($matching_char) = $match;
# escape the match character if necessary
  $matching_char = "\\$match" if $match =~ /[\^.$|()\[\]]/ ;  
  my $gap_symbols = '[-]*';
  my @gapped_string = ();
# build regex
  $string =~ tr/T/U/ ; #convert to RNA to be safe
  my @string = split '', $string;
  my $regex = shift @string; # place first letter of string at start of regex
 while (my $letter = shift @string) {
     $regex = $regex . $gap_symbols . $letter;
  }
  if ($seq->isa('Bio::LocatableSeq')) {
   @seq_list = ($seq);
  } else {
   @seq_list =  $self->each_seq_with_id($seq);
  }
# Need to first check whether alignment has match symbols
  foreach $seq_obj ( @seq_list) {
    my $seq_string = $seq_obj->seq;
    if ($seq_string =~ /$matching_char/ ) {
      $self->unmatch;
      $unmatched_flag_set = 1;
      last;
    }
  }
# Now search each sequence for the (possibly) gapped string
  foreach $seq_obj ( @seq_list) {
    my $seq_string = $seq_obj->seq;
    $seq_string  =~ tr/T/U/ ; #convert to RNA to be safe
    next unless $seq_string =~ /$regex/ ; # skip if no match
#    $seq_string =~ /$regex/;
#    next unless $&; # skip if no match
    $column = (length $`) + 1; # $` = $PREMATCH
    last;
  }
# put the alignment back into 'match' mode if necessary
  $self->match if $unmatched_flag_set ;
  return $column ;  
}

=head2 match

 Title     : match()
 Usage     : $ali->match()
 Function  : Goes through all columns and changes residues that are
             identical to residue in first sequence to match '.'
             character. Sets match_char. Same as function in SimpleAlign
             **except** that annotation sequences are skipped

 Returns   : 1
 Argument  : a match character, optional, defaults to '.'

=cut

sub match {
    my ($self, $match) = @_;

    $match ||= '.';
    my ($matching_char) = $match;
    $matching_char = "\\$match" if $match =~ /[\^.$|()\[\]]/ ;  #'; 
    $self->map_chars($matching_char, '-');

    my @seqs = $self->each_seq();
    return 1 unless scalar @seqs > 1;

#    my $refseq = shift @seqs ;
     my $refseq;
     while ($refseq = shift @seqs) {
       next if $refseq->isa('Bio::LocatableAnnSeq') ; # skip annotations
       last;
     }
     
    my @refseq = split //, $refseq->seq;
    my $gapchar = $self->gap_char;

    foreach my $seq ( @seqs ) {
       next if $seq->isa('Bio::LocatableAnnSeq') ; # skip annotations
	   my @varseq = split //, $seq->seq();
	   for ( my $i=0; $i < scalar @varseq; $i++) {
	    $varseq[$i] = $match if defined $refseq[$i] &&
		( $refseq[$i] =~ /[A-Za-z\*]/ ||
		  $refseq[$i] =~ /$gapchar/ )
		      && $refseq[$i] eq $varseq[$i];
	   }
	   $seq->seq(join '', @varseq);
   }
    $self->match_char($match);
    return 1;
}


=head2 unmatch

 Title     : unmatch()
 Usage     : $ali->unmatch()
 Function  : Undoes the effect of method match. Unsets match_char.
             Same as function in SimpleAlign
             **except** that annotation sequences are skipped
 Returns   : 1
 Argument  : a match character, optional, defaults to '.'

See L<match> and L<match_char>

=cut

sub unmatch {
    my ($self, $match) = @_;

    $match ||= '.';

    my @seqs = $self->each_seq();
    return 1 unless scalar @seqs > 1;


#    my $refseq = shift @seqs ;
     my $refseq;
     while ($refseq = shift @seqs) {
       next if $refseq->isa('Bio::LocatableAnnSeq') ; # skip annotations
       last;
     }
     
    my @refseq = split //, $refseq->seq;
    my $gapchar = $self->gap_char;
    foreach my $seq ( @seqs ) {
    next if $seq->isa('Bio::LocatableAnnSeq') ; # skip annotations
	my @varseq = split //, $seq->seq();
	for ( my $i=0; $i < scalar @varseq; $i++) {
	    $varseq[$i] = $refseq[$i] if defined $refseq[$i] && 
		( $refseq[$i] =~ /[A-Za-z\*]/ ||
		  $refseq[$i] =~ /$gapchar/ ) &&
		      $varseq[$i] eq $match;
	}
	$seq->seq(join '', @varseq);
    }
    $self->match_char('');
    return 1;
}
#############################
=head2 add_hit_annotation

 Title     : add_hit_annotation
 Usage     : $aln->add_hit_annotation($hit, $extension)
 Function  : Add the annotation string from $hit to the alignment
 Returns   : 
 Args      : hit object to use in alignment
             extension - if sequence is extended prior to annotation [default = 0]
##Note this routine unmatches the sequences in the alignment##

=cut

sub  add_hit_annotation {
  my($self, $hit, $extension) = @_;
  $extension ||= 0;
  my ($master_seq_id, $s, $e) = $hit->set_master_seq($self);
  $master_seq_id || $self->throw("Could not get master seq id ");
  my $master_seq = $self->get_seq_by_pos(1);
  $master_seq || $self->throw("Could not set master seq for id: $master_seq_id");
  $self->unmatch;
  my $annotation_start_column = 
     $self->column_from_residue_number( $master_seq_id, $extension +1 );  
  my $aligned_annotation = $hit->align_annotation_string($master_seq, $annotation_start_column);
  $self->add_initial_seq($aligned_annotation);
  return;  
}

=head2 match_line

 Title    : match_line()
 Usage    : $align->match_line()
 Function : Generates a match line - much like consensus string
            except that a line indicating the '*' for a match.
 Args     : (optional) Match line characters ('*' by default)
            (optional) Strong match char (':' by default)
            (optional) Weak match char ('.' by default)

11/14/03 This is identical to match_line in SimpleAlign
**except** that Annotation Sequences are skipped

=cut

sub match_line {
  my ($self,$matchlinechar, $strong, $weak) = @_;
  my %matchchars = ( 'match'  => $matchlinechar || '*',
		'weak'   => $weak          || '.',
		'strong' => $strong        || ':',
		'mismatch'=> ' ', 
		);
	my @seqchars;
	my $seqcount = 0;
	my $alphabet;
	foreach my $seq ( $self->each_seq ) {
    next if $seq->isa('Bio::LocatableAnnSeq') ; ## ***skip annotations*** 11/14/03
		push @seqchars, [ split(//, uc ($seq->seq)) ];
		$alphabet = $seq->alphabet unless defined $alphabet;
	}
	my $refseq = shift @seqchars;
	# let's just march down the columns
	my $matchline;
	POS: foreach my $pos ( 0..$self->length ) {
	my $refchar = $refseq->[$pos];
	next unless $refchar; # skip '' 
	my %col = ($refchar => 1);
	my $dash = ($refchar eq '-' || $refchar eq '.' || $refchar eq ' ');
	foreach my $seq ( @seqchars ) {
	# DEBUG
		unless (defined $seq->[$pos] ) {
			print STDERR "Undefined seq at position $pos of seq.\n $seq\n";
		}
	    $dash = 1 if( $seq->[$pos] eq '-' || $seq->[$pos] eq '.' || 
			  $seq->[$pos] eq ' ' );
	    $col{$seq->[$pos]}++;
	}
	my @colresidues = sort keys %col;
	my $char = $matchchars{'mismatch'};
	# if all the values are the same
	if( $dash ) { $char =  $matchchars{'mismatch'} }
	elsif( @colresidues == 1 ) { $char = $matchchars{'match'} }
	elsif( $alphabet eq 'protein' ) { # only try to do weak/strong
	                                  # matches for protein seqs
	    TYPE: foreach my $type ( qw(strong weak) ) {
                # iterate through categories
		my %groups;
		# iterate through each of the aa in the col
		# look to see which groups it is in
		foreach my $c ( @colresidues ) {
		    foreach my $f ( grep /\Q$c/, @{$CONSERVATION_GROUPS{$type}} ) {
			push @{$groups{$f}},$c;
		    }
		}
		GRP: foreach my $cols ( values %groups ) {
		    @$cols = sort @$cols;
		    # now we are just testing to see if two arrays
		    # are identical w/o changing either one

		    # have to be same len
		    next if( scalar @$cols != scalar @colresidues );
		    # walk down the length and check each slot
		    for($_=0;$_ < (scalar @$cols);$_++ ) {
			next GRP if( $cols->[$_] ne $colresidues[$_] );
		    }
		    $char = $matchchars{$type};
		    last TYPE;
		}
	    }
	  }
	$matchline .= $char;
    }
    return $matchline;
}


__END__

