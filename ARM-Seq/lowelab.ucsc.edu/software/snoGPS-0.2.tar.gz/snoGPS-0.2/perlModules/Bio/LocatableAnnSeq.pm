# POD documentation - main docs before the code

=head1 NAME

Bio::LocatableAnnSeq - Bio::Seq-like object for 
multiple-sequence-alignment annotation

=head1 SYNOPSIS

=head1 DESCRIPTION

This object is identical to a Bio::LocatableSeq but without alphabet
checking so that it can be used to store annotations.

=head1 AUTHOR -  Peter Schattner

Email schattner@alum.mit.edu

=head1 APPENDIX

The rest of the documentation details each of the object
methods. Internal methods are usually preceded with a _

=cut


# Let the code begin...


package Bio::LocatableAnnSeq;
use vars qw(@ISA);
use strict;

use Bio::LocatableSeq;

@ISA = qw(Bio::LocatableSeq);

=head2 new

 Title     : new
 Usage     : my $aln = new Bio::AnnotatedAlign();
 Function  : Creates a new annotated align object
 Returns   : Bio::AnnotatedAlign
 Args      : 

=cut


sub new {
  my($class,@args) = @_;

  my $self = $class->SUPER::new(@args);

  return $self;  
}

=head2 seq

 Title   : seq
 Usage   : $string    = $obj->seq()
 Function: Identical to "seq" in PrimarySeq.pm ***except*** that alphabet
           checking is not enforced so arbitrary annotation strings may be stored
 Returns :  
 Args    :  

=cut

sub seq {
   my ($obj,@args) = @_;

   if( scalar(@args) == 0 ) {
       return $obj->{'seq'};
   }

   my ($value,$alphabet) = @args;


   if(@args) {
# Next 4 lines commented out so I can annotate the alignment as I want
#       if(defined($value) && (! $obj->validate_seq($value))) {
#	   $obj->throw("Attempting to set the sequence to [$value] ".
#		       "which does not look healthy");
#       }
       # if a sequence was already set we make sure that we re-adjust the
       # mol.type, otherwise we skip guessing if mol.type is already set
       # note: if the new seq is empty or undef, we don't consider that a
       # change (we wouldn't have anything to guess on anyway)
       my $is_changed_seq =
	   exists($obj->{'seq'}) && (CORE::length($value || '') > 0);
       $obj->{'seq'} = $value;
       # new alphabet overridden by arguments?
       if($alphabet) {
	   # yes, set it no matter what
	   $obj->alphabet($alphabet);
       } elsif( # if we changed a previous sequence to a new one
		$is_changed_seq ||
		# or if there is no alphabet yet at all
		(! defined($obj->alphabet()))) {
	   # we need to guess the (possibly new) alphabet
	   $obj->_guess_alphabet();
       } # else (seq not changed and alphabet was defined) do nothing
       # if the seq is changed, make sure we unset a possibly set length
       $obj->length(undef) if $is_changed_seq;
   }
   return $obj->{'seq'};
}

=head2 

 Title     : 
 Usage     : 
 Function  : 
 Returns   : 
 Args      : 

=cut
