# $Id: maf.pm,v 1.4 2003/12/13 20:47:34 schattner Exp $
#
# This is a modified BioPerl module for Bio::AlignIO::maf specific
# to decoding maf files

#	based on the Bio::SeqIO::fasta module
#       by Ewan Birney <birney@sanger.ac.uk>
#       and Lincoln Stein  <lstein@cshl.org>
#
#       and the SimpleAlign.pm module of Ewan Birney
#
# Copyright Peter Schattner
#
# You may distribute this module under the same terms as perl itself
# _history
# September 5, 2000
# POD documentation - main docs before the code


package Bio::AlignIO::maf;
use vars qw(@ISA $SOURCEROOT);
use strict;

use Bio::AlignIO;
#use Bio::SimpleAlign;
use Bio::AnnotatableAlign;
use lib $ENV{MYPERLMODULEDIR}; # used by specific enhncements
use common; # used by specific enhncements

@ISA = qw(Bio::AlignIO);
$SOURCEROOT = '';


#######
sub calcCoords {
# Calculate genomic start, stop and end for annotating name
	my ($seqname, $mafStart, $len, $strand, $chromLen) = @_;
	my ($segStart, $segEnd, $strandSym, $revComp, $origSeq);
	my %oppStrand = ( '+' => 'C', '-' => 'W');
	$strandSym = $strand;
	$strandSym =~ tr/+-/WC/;
	if ($seqname =~ /^C([01])_/ ) {
	  $revComp = 1;
		$origSeq = $1;
	} else {
  	$revComp = 0;
	}
	if ($revComp) { # origSeq on Crick strand
		if ($origSeq) {
			if ($strand eq '+') {
		  	$strandSym = $oppStrand{$strand};
	  		$segStart = $mafStart;
	  		$segEnd = $segStart + $len;
			} else {  # $strand eq '-'
		  	$strandSym =~ tr/+-/WC/;
				$segEnd =  $chromLen - $mafStart; 
				$segStart = $segEnd - $len;
			}					
		} else { # not $origSeq
			if ($strand eq '+') {
		  	$strandSym = $oppStrand{$strand};
	  		$segStart = $mafStart;
	  		$segEnd = $segStart + $len;
				} else {  # $strand eq '-'
	  		$strandSym =~ tr/+-/WC/;
				$segEnd =  $chromLen - $mafStart; 
				$segStart = $segEnd - $len;
			}									
		}				
	} else { # origSeq on Watson strand
			$strandSym =~ tr/+-/WC/;
			if ($strand eq '+') {
#		  	$strandSym = 'W';
	  		$segStart = $mafStart;
	  		$segEnd = $segStart + $len;
			} else {  # $strand eq '-'
#	 			$strandSym = 'C';  
				$segEnd =  $chromLen - $mafStart; 
				$segStart = $segEnd - $len;
			}	
	}
	return ($segStart, $segEnd, $strandSym, $revComp);
}


=head2 next_aln

 Title   : next_aln
 Usage   : $aln = $stream->next_aln()
 Function: returns the next alignment in the stream.
 Returns : L<Bio::Align::AlignI> object - returns 0 on end of file
	    or on error
 Args    : NONE

=cut

sub next_aln {
  my $self = shift;
  my ($start,$end, $seqname,$seq,$seqchar);
# **Need to make alignment annotatable ** ps 10/01/03
#   my $aln =  Bio::SimpleAlign->new();
  my $aln =  Bio::AnnotatableAlign->new(-source  => 'maf',
				     -verbose => $self->verbose);    
  my $dataFound = 0;
  while(defined (my $entry = $self->_readline)) {
    last if ($dataFound && ($entry =~ /^\s*$/) ); # blank lines separate alignments
    next if ($entry =~ /^\s*$/) ; # skip initial blank lines
 		my @entry = split " ", $entry;
		if ($entry[0] eq "##maf") {
			my @version = split "=", $entry[1];
			my $version = $version[1];
			my @scoring = split "=", $entry[2];
			my $scoring = $scoring[1];
			$SOURCEROOT = "$scoring.v$version";
			$aln->source($SOURCEROOT);
		}
		if ($entry[0] eq "a") {
			my @score = split "=", $entry[1];
			my $score = $score[1];
			my $source = "$SOURCEROOT.score=$score";
			$aln->source($source);
		}
		if ($entry[0] eq "s") {
	  	unless (&_formatOK(@entry) ) {
	    	$self->warn("format error for \'s\' line $entry\n");
	    	return 0;
	  	}	  	
	  	my ($lineType, $seqname, $mafStart, $len, $strand, $chromLen, $seqchar) 
	  		= split " ", $entry;
	  	my ($segStart, $segEnd, $strandSym, $revComp) = calcCoords($seqname, $mafStart, $len, $strand, $chromLen);
			chomp $seqchar;
			$seqchar = revComp($seqchar) if $revComp;
			$seqname =~ s/^C[01]_// if $revComp; # remove the maf tag for revComped input seq
			$seqname .= ":$segStart-$segEnd$strandSym";  # convert id to id:segStart-segEnd[WC]
			$seq = new Bio::LocatableSeq('-seq'=>$seqchar,
				'-id'=>$seqname,
				'-start'=>1,
				'-end'=>$len,
				'-strand'=>$strand,
				);
	 		$aln->add_seq($seq);
	 		$dataFound = 1;		
	  }
	}
  return $aln if ($dataFound) ;
  return 0;
}
	
=head2 write_aln

 Title   : write_aln
 Usage   : $stream->write_aln(@aln)
 Function: writes the $aln object into the stream in maf format
 Returns : 1 for success and 0 for error
 Args    : L<Bio::Align::AlignI> object

=cut

sub write_aln {
    my ($self,@aln) = @_;
    $self->throw("Sorry: writing maf output is not available! /n");
}

=head2 _formatOK
 Title   : _formatOK
 Usage   : $OK = &_formatOK(@entry)
 Function: check that maf format syntax OK
 Returns : 1 for OK syntax and 0 for error
 Args    : 's' line of a maf alignment

This is a "private" routine

=cut

sub _formatOK {
    my ($s, $seqname, $start, $len, $strand, $totLen, $seqchar) = @_;
	return 0 unless ($s eq "s");
	return 0 unless ($start =~ /^\d+$/);
	return 0 unless ($len =~ /^\d+$/);
	return 0 unless ($totLen =~ /^\d+$/);
	return 0 unless ($strand =~ /[-+]/);
	return 0 unless ($seqchar =~ /^[\w-]+$/i);
	return 1;
}

1;

__END__

		if ($entry[0] eq "s") {
	  	unless (&_formatOK(@entry) ) {
	    	$self->warn("format error for \'s\' line $entry\n");
	    	return 0;
	  	}	  	
	  	my ($lineType, $seqname, $mafStart, $len, $strand, $chromLen, $seqchar) 
	  		= split " ", $entry;
	  	my $strandSym = 'W';
	  	my $segStart = $mafStart;
	  	my $segEnd = $segStart + $len;;
			if ( $strand eq '-') {
 				$strandSym = 'C';  
				$segEnd =  $chromLen - $mafStart; 
				$segStart = $segEnd - $len;
			}
			$seqname .= ":$segStart-$segEnd$strandSym";  # convert id to id:segStart-segEnd[WC]
			$seq = new Bio::LocatableSeq('-seq'=>$seqchar,
				'-id'=>$seqname,
				'-start'=>1,
				'-end'=>$len,
				'-strand'=>$strand,
				);
	 		$aln->add_seq($seq);
	 		$dataFound = 1;		
	  }
