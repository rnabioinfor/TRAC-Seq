#! /usr/local/bin/perl -w

######### Deprecated use module hd instead ##########


package blatToBed;
use strict;
use Getopt::Std;
use lib './scripts'; 
use lib './modules'; 
use lib '/projects/lowelab/users/schattner/local_perl/lib/site_perl/5.6.1/';
use common;

use vars qw(
	@ISA @EXPORT @EXPORT_OK
	%option
	   );

BEGIN {
        use Exporter();
        @ISA = qw(Exporter);
        @EXPORT = qw(&blatToBed blatSequenceToBed);
#       @EXPORT_OK = qw();
}	   
	   
use constant ERROR => 1;

######################
sub blatToBed {
# takes file of fasta seqs and creates a bedfile of their coordinates
# bedfile is written to $outfile and a reference to an array of the bedlines is returned
 	 my ($infile, $outfile, %option) = @_;
	my @bedLines;
     my $outFh = getOutFh($outfile);
     my $build = $option{D};
     my $min_score = $option{S} || 98;
     my $min_length = $option{L} || 60;
     my $upstreamExtend = $option{u} || $option{X} || 0 ; 
     my $downstreamExtend = $option{d} || $option{X} || 0 ; 
     my $qname_pos = 9;
     my $match_pos = 0;
     my $mismatch_pos = 1;
     my $chrom_pos = 13;
     my $strand_pos = 8;
     my $start_pos = 15;
     my $end_pos = 16;
     my $repmatch_pos = 2;
     my $qNumInsert_pos = 4;
     my $tNumInsert_pos = 6;

  my $port = 17779;
  my %server = ( 'mm3' =>  'blat9.cse.ucsc.edu',
                 'hg13' => 'blat3.cse.ucsc.edu',
                 'hg15' => 'blat2.cse.ucsc.edu',
                 'hg16' => 'blat6.cse.ucsc.edu',
                 'rn2' =>  'blat10.cse.ucsc.edu',
                 'rn3' =>  'blat11.cse.ucsc.edu',
             );
   my %nib_fa = ('mm3' => '/cluster/data/mm3',
                 'hg13' => '/cluster/data/hg13',
                 'hg15' => '/cluster/data/hg15',
                 'hg16' => '/cluster/data/hg16',
                 'rn2' =>  '/cluster/data/rn2',
                 'rn3' =>  '/cluster/data/rn3',
                 );

  unless ( exists $server{$build} ) {
  	print STDERR "\nCould not find blat server for build $build\n\n";
  	return ERROR; 
  }
	    
  my $pslFile = "/tmp/psltempfile.tmp";   
  my $clusterData = '/cluster/data';
         
  my $command = "/cluster/bin/i386/gfClient $server{$build} $port $clusterData/$build/nib $infile $pslFile -minIdentity=$min_score -nohead -dots=1 2>1 1>/dev/null";
  print STDERR "$command\n";
  system($command);
  
  open (PSLFILE, "<$pslFile") or die ("Cannot open $pslFile \n");
  my $last_qname = '';
  my $last_score = 0;
  while (my $line = <PSLFILE>) {
     my @line = split " ", $line;
     my $qname = $line[$qname_pos];
     my $chrom = $line[$chrom_pos];
     my $strand = $line[$strand_pos];
     my $start = $line[$start_pos] - $upstreamExtend ;
     my $end   = $line[$end_pos] + $downstreamExtend ;
     next unless $end;
     next unless ($end =~ /^\d+$/);   #sanity checks
     next unless ($start =~ /^\d+$/);
     unless ($qname =~ /[a-z]/i) { #name must include a letter
      warn( "Illegal query name $qname found in line $line");
      next;
     }
     next if ( ($end - $start) < $min_length);
	 my $bedLine = bedBuild($qname,	$chrom,	$strand, $start, $end);	
	 print $outFh "$bedLine\n";
	 push 	@bedLines, "$bedLine\n";
     $last_qname = $qname;
  }
  close $outFh;
  return \@bedLines;
}

######################
sub blatSequenceToBed {
# retrieve the cordinates of a single sequence in bed line format
 	 my ($seqName, $seq, %option) = @_;
	 my $faFile = '/tmp/eraseme.fa';
	 my $outFh = getOutFh($faFile);
	 print $outFh ">$seqName\n";
	 print $outFh "$seq\n";
	 close $outFh;
	 my $bedLines = blatToBed($faFile, '/dev/null', %option);
	 return $bedLines->[0];
}

1;
