/* rundata.c
 *
 */

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "score_and_test.h"

#include "target_rundata.h"
#include "pseudoU_test.h"
#include "pseudoU_test_funcs.h"


static char *run_type_flagAsString[RUNTYPENUM] = {
  "ILLEGAL", 
  "SIMPLE",
  "PRE1",
  "PRE2"
};

static int lookupRunType(char *string1, char *runTable[], int tableSize);
/* Look up number of run_type_flag from its ascii-string name. */

RUNDATA *newRunData( FILE  *descfp, float totalScoreCutoff) {
  /* Create a new RUNDATA structure */
  int      linenumber = 0;     /*  line number in descriptor file for debug */
  float descriptorScoreCutoff;	/* score cutoff read from descriptor file */
  char     buffer[MAXLN];       /* storage for the current line */
  char     string1[TOKENLEN];
  int min_ACA_H, max_ACA_H;
  RUNDATA *rundataptr;

  rundataptr = DEBUGMALLOC(1, sizeof(RUNDATA));
  getline(buffer, descfp, &linenumber, TRUE) ; /* read the overall descriptor */
  sscanf(buffer, "%s %d %d %d %d %d %d %d %f", string1, &(rundataptr->numberOfPP1Tests), \
	 &(rundataptr->numberOfPP2Tests) , &(rundataptr->numberOfTests),  \
	 &(rundataptr->numberOfTargets) , &(rundataptr->MinIntervals[stem1gap]), &(rundataptr->MaxIntervals[stem1gap] ), \
	 &(rundataptr->mode) , &descriptorScoreCutoff);

  assert( rundataptr->mode > 0) ;
  assert( rundataptr->mode <= MAX_MODE_NUMBER) ;
  if (rundataptr->mode == SINGLE_STEM ) { rundataptr->startingFeature = XSTEM;}
  if (rundataptr->mode == ACA_PLUS_H ) { rundataptr->startingFeature = H;}
  if (rundataptr->mode == ACA_1_STEM ) { rundataptr->startingFeature = XSTEM;}

  /* use total score cutoff value from descriptor file unlesso verriden on command line */
  if (totalScoreCutoff == USEDESCRIPTORVALUE) { 
    rundataptr->totalScoreCutoff = descriptorScoreCutoff;
  } else {
    rundataptr->totalScoreCutoff = totalScoreCutoff ;
  }
  rundataptr->run_type_flag = lookupRunType(string1, run_type_flagAsString, RUNTYPENUM);
  rundataptr->startSearchPos = XSTEMOFFSET; /* hardcode for now */
  rundataptr->targetLeftMin = TARGETLEFTMIN ;  /* hardcode for now */
  rundataptr->targetLeftMax = TARGETLEFTMAX ;  /* hardcode for now */
  rundataptr->targetRightMin = TARGETRIGHTMIN ;  /* hardcode for now */
  rundataptr->targetRightMax = TARGETRIGHTMAX ;  /* hardcode for now */
  rundataptr->MinIntervals[stem2gap] = rundataptr->MinIntervals[stem1gap]; /* hardcode equal gaplength */ 
  rundataptr->MaxIntervals[stem2gap] = rundataptr->MaxIntervals[stem1gap]; /* limits for now */
  rundataptr->MinIntervals[XSTEM_H] = MIN_XSTEM_H; /* hardcode for now */ 
  rundataptr->MaxIntervals[XSTEM_H] = MAX_XSTEM_H;
  rundataptr->MinIntervals[HACA_ISTEM2R] = MIN_HACA_ISTEMR; /* hardcode for now */ 
  rundataptr->MaxIntervals[HACA_ISTEM2R] = MAX_HACA_ISTEMR;

  min_ACA_H = MIN_XSTEM_H + rundataptr->MinIntervals[stem1gap] + 2* ISTEM_XSTEM;
  max_ACA_H = MAX_XSTEM_H + rundataptr->MaxIntervals[stem1gap] + 2* ISTEM_XSTEM;
  rundataptr->MinIntervals[ACA_H] = min_ACA_H; /* hardcode for now */ 
  rundataptr->MaxIntervals[ACA_H] = max_ACA_H;
  assert(rundataptr->run_type_flag >= 0) ;
  return(rundataptr);
}

void freeRunData(RUNDATA *rundataptr) {
  /* Free up RunDataStruct structure.  */
  DEBUGFREE(rundataptr, sizeof(RUNDATA)) ;
}

int numberOfTests(RUNDATA *rundataptr) {
  /* Get number Of Tests for final pass*/
  return (rundataptr->numberOfTests);
}

int numberOfTargets(RUNDATA *rundataptr) {
  /* Get number Of Targets*/
  return (rundataptr->numberOfTargets);
}

#if 0
int gapmin(RUNDATA *rundataptr) {
  /* Get minimum gap value */
  return (rundataptr->gapmin);
}

int gapmax(RUNDATA *rundataptr) {
  /* Get max gap value */
  return (rundataptr->gapmax);
}

void set_gapmin(RUNDATA *rundataptr, int gapmin) {
  /* Set minimum gap value */
  assert( 0 < gapmin );
  rundataptr->gapmin = gapmin;
}

void set_gapmax(RUNDATA *rundataptr, int gapmax) {
  /* Set max gap value */
  assert( 0 < gapmax );
  rundataptr->gapmax = gapmax;
}
#endif
void set_targetFile(RUNDATA *rundataptr, char *targetfile) {
  /* Set target file name*/
  rundataptr->targetFile = targetfile;
}

void set_queryfile(RUNDATA *rundataptr, char *queryfile) {
  /* Set query file name*/ 
  rundataptr->queryFile = queryfile;
}


/*************Private functions************************/
static int lookupRunType(char *string1, char *runTable[], int tableSize) {
  /* Look up number of run_type_flag from its ascii-string name.
   * Return -1 if string not found  */
  int index;
  for(index = 0; index < tableSize; index++) {
    if(runTable[index] == NULL ) return -1;
    if (strcmp(string1, runTable[index]) == 0) return index;
  }
  return (-1);
}
