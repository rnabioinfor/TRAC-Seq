/* pseudoU_test_funcs.c
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#include "pseudoU_test.h"
#include "pseudoU_test_funcs.h"
#include "squid.h"

#if 0
#include "pseudoU_funcs.h"
#include "pseudoU_config.h"
#endif



/* Function: getline()
 * 
 * Purpose:  Get next non-blank, non-comment line and put it in s,
 *           which is pre-allocated. Ignore everything on a line 
 *           after a comment. (modified from SRE's rnabob)
 *           
 */

#if 0
int
getline(char *s,		/* allocated string memory */
	FILE *fp,		/* open file */
        int  *ret_linenumber,	/* returns current line number */
        int  convert_to_upper)	/* flag for case-conversion */
#endif
int getline(char *s, FILE *fp, int *ret_linenumber, int convert_to_upper)	
{
  char buffer[MAXLN];	        /* tmp storage for a line */
  char *sptr;			/* pointer to position in s */
  int   saw_something;

  while (1)
    {
      if (fgets(buffer,MAXLN,fp) == NULL) return 0;
      *ret_linenumber++;		/* debugging aid for user */
      saw_something = 0;
      for (sptr = buffer; *sptr; sptr++)
	{
	  if (islower(*sptr) && (convert_to_upper == TRUE) ) {
	    *sptr = toupper(*sptr);
	  }
	  if (*sptr == COMMENTSYM)
	    {
	      *sptr = '\0';
	      break;
	    }
	  
	  else if (! isspace(*sptr))
	    saw_something = 1;
	}

      if (saw_something)
	{
	  strcpy(s, buffer);
	  return 1;
	}
    }
  /*NOTREACHED*/
}

/* Allocate memory and duplicate first n characters of string */
char *
Strndup(char *string, size_t length) {
  char *pattern;

  pattern = DEBUGMALLOC(length + 1, sizeof(char));
  strncpy(pattern, string, length);
  *(pattern + length) = '\0'; 
  return (pattern);
}

char *
Complement(char *comp, char *seq) {
/* Just complement the sequence.  Don't reverse.  Based on SRE's 
 * revcomp function */
  long  bases;
  char *fwdp1, *fwdp2;
  int   idx;
  long  pos;
  int   c;

  if (comp == NULL) return NULL;
  if (seq == NULL)  return NULL;
  bases = strlen(seq);

  fwdp2 = comp;
  fwdp1 = seq;
  for (pos = 0; pos < bases; pos++)
    {
      c = *fwdp1;
      c = sre_toupper(c);
      for (idx = 0; c != iupac[idx].sym && idx < IUPACSYMNUM; idx++);
      if (idx == IUPACSYMNUM)
	{
	  Warn("Can't reverse complement an %c, pal. Using N.", c);
	  *fwdp2 = 'N';
	}
      else
	*fwdp2 = iupac[idx].symcomp;
      if (islower((int) *fwdp1)) *fwdp2 = sre_tolower((int) *fwdp2);
      fwdp2++;
      fwdp1++;
    }
  *fwdp2 = '\0';
  return comp;
}
  

char *
Reverse(char *originalString, char *reversedString, size_t length) {
/* Fill previously allocated memory with first n characters of originalString reversed */
  int index;

  for (index = 0; index < length; index++) {
  *(reversedString + index) = *(originalString + length - index - 1);
  }
  *(reversedString + length) = '\0'; 
  return (reversedString);
}

/* Function: SubStr()
 *
 * Purpose:  Create new string which is substring of input string 
 * Arguments:  string        input string
 *             start         index in string to begin extracting
 *             length        number of characters to extract
 *             ret_substring pointer to returned substring
 * Return:  pointer to returned substring 
 */

char * 
SubStr(char *string, int start, size_t length, char *ret_substring)
{

  strncpy(ret_substring, string + start, length);
  *(ret_substring + length) = '\0'; 
  return (ret_substring);
}



/* Function: Index()
 *
 * Purpose:  Find position of first occurrence of character in string 
 * Arguments:  s             input string
 *             ch            character tobe searched for
 * Return:  position of character in string (starting at zero)
 *          Returns -1 if character not found
 */

int 
Index(char *s, int ch) {
  int i ;
  for ( i= 0; s[i] != '\0'; i++) {
    if (s[i] == ch) {
      return (i);
    }
  }
  return (-1);
}



int Paired(char *seq1, char *seq2) {
  /* Are nucelotides W-C or wobble pairs?  To be replaced by function
   * that's more efficient later */
  if( (*seq1 == 'A' &&  *seq2 == 'T')  ||  \
      (*seq1 == 'C' &&  *seq2 == 'G')  ||  \
      (*seq1 == 'G' &&  *seq2 == 'C')  ||  \
      (*seq1 == 'T' &&  *seq2 == 'A')   ) return 1;
 /* wobble pairs */
  if( (*seq1 == 'G' &&  *seq2 == 'T')  ||  (*seq1 == 'T' &&  *seq2 == 'G')   ) return 2;
  return 0;
}



#if DEBUG > 0

/* Function:DebugMalloc()
 *
 * Purpose:  Create a debugging wrapper to malloc. Fills
 *   allocated memory with value likely to crash program if
 *   accessed incorrectly.  
 * Arguments:  size   size of memory block to be allocated
 * Return:  pointer to allocated memory 
 */

void * 
DebugMalloc(size_t size)
{
  void *ptr;
  assert ( (ptr = malloc (size)) != NULL);
#if 0
  ptr =  MallocOrDie (size);
#endif

  /* Fill in allocated memory with 'unlikely value'   */
  memset(ptr, DEBUG_FILL_CHAR, size);
  return (ptr);
}

/* Function:DebugFree()
 *
 * Purpose:  Create a debugging wrapper to free. Fills
 *   memory to be freed with value likely to crash program if
 *   accessed after freeing.  
 * Arguments:  ptr    pointer to memory block to be freed
 *             size   size of memory block to be freed
 * Return: void 
 */

void 
DebugFree(void *ptr, size_t size)
{
  /* Fill in  memory to be freed with 'unlikely value'   */
  memset(ptr, DEBUG_FILL_CHAR, size);
  free(ptr);
}


#endif /* DEBUG */




/* Function: Min()
 *
 * Purpose:   Determine smaller of 2 integers
 * Arguments:  var1, var2        two integers to be compared
 * Return:  value of smaller integer 
 */

int 
Min(int var1, int var2 )
{
  if (var1 > var2 ) {
    return (var2);
  } else {
    return (var1);
  }
}

/* Function: Max()
 *
 * Purpose:   Determine larger of 2 integers
 * Arguments:  var1, var2        two integers to be compared
 * Return:  value of larger integer 
 */

int 
Max(int var1, int var2 )
{
  if (var1 < var2 ) {
    return (var2);
  } else {
    return (var1);
  }
}

#if 0
/* Function: get_seq()
 *
 * Purpose:  Retrieve single seqeunce from a file
 * Arguments:  dbfile     -  pointer to seq filename
 *             ret_seq    -  pointer to seq string
 * Return:   
 */

static int
get_seq( char  *dbfile, char **ret_seq)
{
  SQFILE     *dbfp;		/* ptr to dbfile, opened for sequential read */
  int         fmt;		/* format of dbfile (kEMBL, kPearson, etc.)  */
  SQINFO      sqinfo;		/* optional info about seq                   */
  int   retval;   	        /* ReadSeq return value                       */

  /*********************************************** 
   * Initialize sequence file
   ***********************************************/
  if (! SeqfileFormat(dbfile, &fmt, "BLASTDB"))
    switch (squid_errno) {
    case SQERR_NOFILE: 
      Die("Sequence file %s could not be opened for reading", dbfile); break;
    case SQERR_FORMAT: 
    default:           
      Die("Failed to determine format of sequence file %s", dbfile);
    }

  if ((dbfp = SeqfileOpen(dbfile, fmt, "BLASTDB")) == NULL)
    Die("Failed to open sequence file %s for reading", dbfile);

  retval = ReadSeq(dbfp, fmt, &ret_seq, &sqinfo);

  return(1);			
}

#endif
