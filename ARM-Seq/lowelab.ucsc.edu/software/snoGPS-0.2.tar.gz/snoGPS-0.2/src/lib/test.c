/* test.c
 *
 */

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "score_and_test.h"
#include "target_rundata.h"
#include "pseudoU_test.h"
#include "pseudoU_test_funcs.h"

#include "sqfuncs.h"		/* needed for StrInsert */

extern int DEBUG_LEVEL;

/* Prototypes of private functions and constants*/
static int checkStemWithDither(TEST *testptr, HIT_SCORE *scoreptr, int maxLenLeft, int maxLenRight, \
			       char *leftStartPos, char *rightStartPos, int complement, int feature) ;
static double checkStemWith2Dithers(TEST *testptr, HIT_SCORE *scoreptr, int maxLenLeft, int maxLenRight, \
				 char *leftStartPos, char *rightStartPos, int complement, int feature) ;
#if 0
static void storeStemPatterns(TEST *testptr, HIT_SCORE *scoreptr, char *bestLeftStartPos, char *reverseRightStem, int feature) ;
#endif
static void storeStemPatterns(HIT_SCORE *scoreptr, char *bestLeftStartPos, char *bestRightStartPos, int stemLength, int feature) ;
#if 0
static void outputHitStem2(HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
#endif
static int runHACA2_Test(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
static int check_IStem(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) ;
static int check_XStem(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) ;
static int check_double_stem(TEST *testptr, HIT_SCORE *scoreptr,  RUNDATA *rundataptr); 
static int runMatchTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq);
static int multiMatchTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq) ;
static int runExactTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq);
static int extendScoreCompl(TEST *testptr, HIT_SCORE *scoreptr,int hit1index, int hit2index) ;
static char *getTypeName(TEST *testptr) ;
static int lookupType(char *string, char *typeTable[], int tableSize);
static int seqncmp_unencoded(char *seq1, char *seq2, int len, int allow) ;
static int paired_seqncmp_unencoded(char *s1, char *s2, int len, int allow);
static void initParentFeatureTable(void) ;
static void initParentFeatureTable2(void) ;
static char *getParentfposition(TEST *testptr, int hit1index, int hit2index, int whichParent);
static char *retrievefposition(TEST *testptr, int hit1index, int hit2index) ;
static TEST *getParent1(TEST *testptr) ;
static TEST *getParent2(TEST *testptr) ;
static int dummyScoreCompl(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) ;
static void  scoreHACA2(HIT_SCORE *scoreptr, char *HACA2_position, int currentlySearching) ;
static int xstem2Search(TEST *testptr, HIT_SCORE *scoreptr, char *HACA2_position, RUNDATA *rundataptr, int currentlySearching, char *xstemSearch); 
static int istem2Search(TEST *testptr, HIT_SCORE *scoreptr, char *HACA2_position, RUNDATA *rundataptr, int currentlySearching);
static int score2StemIntervals( HIT_SCORE *scoreptr, RUNDATA *rundataptr, int currentlySearching) ;
static int score2StemTotals( HIT_SCORE *scoreptr, RUNDATA *rundataptr) ; 
static void setXstemSearchLimits( HIT_SCORE *scoreptr, RUNDATA *rundataptr, char *HACA2_position, char **startXstemSearch, char **stopXstemSearch, int currentlySearching );
static int check_ACA_stem_with_H (TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
static int scoreH_XstemInterval( HIT_SCORE *scoreptr, RUNDATA *rundataptr, int currentlySearching) ; 
static void  copyPointers(HIT_SCORE *currentscoreptr, HIT_SCORE *scoreptr ) ;
static void  copyPatterns( HIT_SCORE *scoreptr) ;
static void  initCurrentScorePtr(HIT_SCORE *currentscoreptr, HIT_SCORE *scoreptr ) ; 
 
 
int scoreIntervals(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
int scoreHACAPattern(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
int scoreTargets(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
int scoreTargetMatrix(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
int scoreTargetIntervals(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;

int scorePOST_ACA(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr, int haca_or_aca) ;

static int inittedParentFeatureTable = FALSE;
static int inittedParentFeatureTable2 = FALSE;
static int parentFeatureTable[FEATURENUM] = {0};
static int parentFeatureTable2[FEATURENUM] = {0};

static char *featureAsString[FEATURENUM] = {
  "UNUSED", 
  "RCOMPLMIN",	       	/*  1  */
  "LCOMPLMIN", 		/*  2  */
  "ISTEM", 		/*  3  */
  "XSTEM", 		/*  4  */
  "ISTEMSCORE",        	/*  5  */
  "XSTEMSCORE",		/*  6  */
  "RCOMPL", 		/*  7  */
  "LCOMPL", 		/*  8  */
  "HACA",		/*  9  */
  "H",		        /*  10  */
  "ACA",		/*  11  */
  "ISTEM2",		/*  12  */
  "XSTEM2",		/*  13  */
  "POST_ACA",		/*  14  */
  "UNUSED1",		/*  15  */
  "UNUSED2",		/*  16  */
  "UNUSED3",		/*  17  */
  "UNUSED4",		/*  18  */
} ;

static char *typeAsString[TESTTYPENUM] = {
  "UNUSED", 
  "MATCH",
  "LEFT_MATCH_TARGET",
  "RIGHT_MATCH_TARGET",
  "SCORE_INTERVALS",
  "SCORE_HACA_PATTERN",
  "SCORE_LEFT_COMPL",
  "SCORE_RIGHT_COMPL",
  "EXACT_MATCH",
  "CHECK_ISTEM",
  "CHECK_XSTEM",
  "CHECK_DOUBLE_STEM",
  "OUTPUT_STEM1_TARGET",
  "SCORE_STEM1_TARGET",
  "MATCH_HACA2",
  "DUMMY_LEFT_COMPL",   /* used when target is "NNNN" */
  "DUMMY_RIGHT_COMPL",  /* used when target is "NNNN" */
  "SCORE_TARGETS",
  "SCORE_POST_ACA",
  "CHECK_ONESTEM_PLUS",
  "FIND_MULTI_MATCHES",
  "SCORE_TARGET_MATRIX",
  "SCORE_TARGET_INTERVALS",
#if 0
"LEFT_TARGET_GU_OK",
"RIGHT_TARGET_GU_OK",
"SCORE_LEFT_COMPL_GU_OK",
"SCORE_RIGHT_COMPL_GU_OK"
#endif
  };


/* Public Arrays */  
 
 
/* Public functions */


TEST *newTestFromDescriptor(FILE  *descfp, int testIndex ) {
  /* Create a new TEST structure from Descriptor. */
  int      linenumber = 0;     /*  line number in descriptor file for debug */
  char     buffer[MAXLN];       /* storage for the current line */
  char typeName[TOKENLEN];           /* Type of test */
  int type;           /* Type of test */
  int pflag;           /* Non-zero => preprocessor pass => store hits */
  int offset;            /* offset from search start position to look for feature */
  int offset2;            /* offset for second half of stem from pp2 hit position */
  char featureName[TOKENLEN];          /* feature being currently tested  (0 < && < FEATURENUM) */
  int feature;          /* feature being currently tested  (0 < && < FEATURENUM) */
  char pattern[TOKENLEN];                /* pattern to search for */
  int mismat;                   /* allowed mismatches */
  int dither;                   /* allowed "dither" */
  /* To prevent needing to modify descriptor format, the following integer
   * is the second-stem dither in stem tests and a test-dependent flag for other tests */
  int dither2_tflag;                   /* allowed "dither" for 2nd half of stem */
  int scoreMatrix;           /* index of score matrix (not used yet) */
  double minScore; /* minimum passing score for test */
  TEST *testptr;
  int status;

  status = getline(buffer, descfp, &linenumber, TRUE) ; /* read the next TEST descriptor */
  assert(status != 0);		/* there better be something on the line */
  sscanf(buffer, "%s %d %s %s %d %d %d %d %d %d %lf",  \
	 typeName, &offset, featureName, pattern, &mismat, \
	 &dither, &scoreMatrix,  &pflag, &offset2, &dither2_tflag, &minScore);

  assert( TOKENLEN >= strlen(typeName));
  assert( TOKENLEN >= strlen(featureName));
  assert( TOKENLEN >= strlen( pattern));
  feature = lookupType(featureName, featureAsString, FEATURENUM);
  type = lookupType(typeName, typeAsString, TESTTYPENUM);
  assert( feature >= 0);
  assert( type >= 0);
  assert( (offset < 200) && (offset > -200));
  assert( (mismat < 10) && (mismat >= 0));
  assert( (dither < 10) && (dither >= 0));
  assert( (dither2_tflag < 100) && (dither2_tflag >= 0));
  assert( (offset2 < 100) && (offset2 >= -100));
  assert( (pflag < 4) && (dither >= 0));
  assert( (scoreMatrix < 4) && (scoreMatrix >= 0));
  assert( (minScore < 100) && (scoreMatrix > -100));
  testptr = newTest(type, offset, feature, pattern, mismat, dither, \
		    scoreMatrix, pflag, offset2, dither2_tflag, minScore, testIndex );
  return(testptr);
}


TEST *newTest(int type, int offset, int feature, char *pattern, \
	      int mismat, int dither, int scoreMatrix, int pflag, \
	      int offset2, int dither2_tflag, double minScore, int testIndex ) {
  /* Create a new TEST structure. */
  TEST *testptr;
  /* Not an efficient place for this call but otherwise compiler is whining*/
  initParentFeatureTable();	
  initParentFeatureTable2();	
  testptr = DEBUGMALLOC(1, sizeof(TEST));
  /* Allocate memory for patterns & found patterns */
  testptr->pattern = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  testptr->fpattern = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  testptr->fpattern2 = DEBUGMALLOC(PATTERNMAX, sizeof(char) );

  assert( type <= CURRENTTYPEMAX  && type > 0);
  testptr->type = type;
  testptr->offset = offset;
  testptr->offset2 = offset2;
  assert( feature <= CURRENTFEATUREMAX && feature >= 0);
  testptr->feature = feature;
  testptr->mismat = mismat;
  testptr->dither = dither;
  if ( (type == SCORE_LEFT_COMPL) || (type == SCORE_RIGHT_COMPL) || \
       (type == LEFT_MATCH_TARGET) || (type == RIGHT_MATCH_TARGET)
       ) {
    testptr->tflag = dither2_tflag;
  } else {
    testptr->dither2 = dither2_tflag;
  }
  testptr->score = minScore;
  if ( (type == SCORE_LEFT_COMPL) || (type == SCORE_RIGHT_COMPL) ) {
    testptr->scoreMatrix = complScoresPtr;
  } else {
    testptr->scoreMatrix = IstemScoresPtr;
  }
  assert(strlen(pattern) < PATTERNMAX);
  strcpy(testptr->pattern, pattern);
  /* store pattern length so we don't have to keep recomputing it */
  testptr->length = strlen(testptr->pattern); 
  /* initialize results to impossible values */ 
  testptr->fdither = 0;
  testptr->fmismat = BAD_VALUE;
  testptr->fpairs = BAD_VALUE;
  testptr->fscore = BAD_VALUE;
  testptr->fposition = NULL;
  testptr->fposition2 = NULL;
  testptr->pflag = pflag;
  testptr->pptestnum = testIndex; 

  return (testptr);
}

void freeTest(TEST *testptr) {
  /* Free up Test structure.  */
  if (testptr == NULL) return;
  DEBUGFREE(testptr, sizeof(TEST)) ;
}

void setPattern(TEST *testptr, char *pattern) {
  /* Set required pattern. Pattern length must be < PATTERNMAX */
  assert(testptr != NULL);
  assert(strlen(pattern) < PATTERNMAX);
  strcpy(testptr->pattern, pattern);
  /*  testptr->pattern = strdup(pattern); */
}


void loadTargetPattern(TEST *testptr, TARGET *targetptr) {
  /* Load pattern from target object if test type = LEFT_MATCH_TARGET or RIGHT_MATCH_TARGET */

  assert(testptr != NULL);
  if (testptr->tflag ==  GU_OK ) {
    if (testptr->type ==  LEFT_MATCH_TARGET ) setPattern(testptr, leftMinSeq(targetptr) ) ;
    if (testptr->type == RIGHT_MATCH_TARGET ) setPattern(testptr, rightMinSeq(targetptr) ) ;
    if (testptr->type ==  SCORE_LEFT_COMPL ) setPattern(testptr, leftMaxSeq(targetptr) ) ;
    if (testptr->type ==  SCORE_RIGHT_COMPL ) setPattern(testptr, rightMaxSeq(targetptr) ) ;
  } else {
    if (testptr->type ==  LEFT_MATCH_TARGET ) setPattern(testptr, leftComplMinSeq(targetptr) ) ;
    if (testptr->type == RIGHT_MATCH_TARGET ) setPattern(testptr, rightComplMinSeq(targetptr) ) ;
    if (testptr->type ==  SCORE_LEFT_COMPL ) setPattern(testptr, leftComplMaxSeq(targetptr) ) ;
    if (testptr->type ==  SCORE_RIGHT_COMPL ) setPattern(testptr, rightComplMaxSeq(targetptr) ) ;
  }
#if 0
  if (testptr->type ==  LEFT_TARGET_GU_OK ) \
					      setPattern(testptr, leftMinSeq(targetptr) ) ;
  if (testptr->type == RIGHT_TARGET_GU_OK ) \
					      setPattern(testptr, rightMinSeq(targetptr) ) ;

  if (testptr->type ==  SCORE_LEFT_COMPL_GU_OK ) \
					     setPattern(testptr, leftMaxSeq(targetptr) ) ;

  if (testptr->type ==  SCORE_RIGHT_COMPL_GU_OK ) \
					      setPattern(testptr, rightMaxSeq(targetptr) ) ;
#endif
  /* Next lines are 'hack' for case where there is no target */
  if (testptr->type ==  DUMMY_LEFT_COMPL ) \
					     setPattern(testptr, leftComplMaxSeq(targetptr) ) ;

  if (testptr->type ==  DUMMY_RIGHT_COMPL ) \
					      setPattern(testptr, rightComplMaxSeq(targetptr) ) ;
  testptr->length = strlen(testptr->pattern);
}

int getType(TEST *testptr) {
  /* Get test type */
  assert(testptr != NULL);
  return (testptr->type);
}

int allowedMismatch(TEST *testptr) {
  /* Get number of mismatches */
  assert(testptr != NULL);
  return (testptr->mismat);
}

char *getFeatureName(TEST *testptr) {
  /* Get  pointer to string decsription of feature being tested */
  assert(testptr != NULL);
  return ( featureAsString[testptr->feature] );
}

char *getFoundPattern(TEST *testptr) {
  /* Get dynamically allocated copy of found pattern. */
  assert(testptr != NULL);
  return (testptr->fpattern);
}

char *getFoundPattern2(TEST *testptr) {
  /* Get dynamically allocated copy of found pattern 2. */
  assert(testptr != NULL);
  return (testptr->fpattern2);
}

void setOffset(TEST *testptr, int offset) {
  /* Set offset position. */
  assert(testptr != NULL);
  testptr->offset = offset;
}

int getOffset(TEST *testptr) {
  /* Get offset value */
  assert(testptr != NULL);
  return (testptr->offset);
}


int getFoundMismatch(TEST *testptr) {
  /* Get actual number of mismatches */
  assert(testptr != NULL);
  return (testptr->fmismat);
}

int getFoundLength(TEST *testptr) {
  /* Get length of found pattern */
  assert(testptr != NULL);
  return (testptr->flength);
}

int getFoundPosition(TEST *testptr, char *seq) {
  /* Get numeric position of found pattern in input sequence seq */
  int position;
  assert(testptr != NULL);
  position = testptr->fposition - seq;
  return ( position );
}

double getScore(TEST *testptr) {
  /* Get score of found pattern */
  fprintf( stderr, "getScore not implemented yet \n");
  assert(0);
}

int getDither(TEST *testptr) {
  /* Get "dither" value of match */
  assert(testptr != NULL);
  return (testptr->fdither);
}

void writeTestRequirements(TEST *testptr) {
  /* Output test parameters. */
  assert(testptr != NULL);
  fprintf( stdout, "Type: %s\t",  getTypeName(testptr));
  fprintf( stdout, "Feature: %s\t", getFeatureName(testptr));
  fprintf( stdout, "Input: %s\t", testptr->pattern);
  if(testptr->offset !=0)  fprintf( stdout, "Offset: %d\t", testptr->offset);
  if(testptr->offset2 !=0)  fprintf( stdout, "Stem Offset 2: %d\t", testptr->offset2);
#if 0
  if (testptr->type == CHECK_STEM )  {
    fprintf( stdout, "Pairs - Mismatches Minimum: %d\t", allowedMismatch(testptr));
  } else {
    fprintf( stdout, "Allowed mismatches: %d\t", allowedMismatch(testptr));
  }
#endif
  fprintf( stdout, "Allowed mismatches: %d\t", allowedMismatch(testptr));
  if(testptr->dither !=0)  fprintf( stdout, "Allowed dither: %d", testptr->dither);
  fprintf( stdout, "\n");
}

void writeTestResults(TEST *testptr, char *seq) {
  /* Output test results. */
  int fmismatch, fpairs;
  double fscore;
  char *fposition2;
  assert(testptr != NULL);
  fprintf( stderr, "Feature: %s\t", getFeatureName(testptr));
  fprintf( stderr, "Pattern: %s\t", getFoundPattern(testptr));
  fflush(stdout);		/* debug aid 4/11/02 */
#if 0
  if (testptr->type == CHECK_STEM )  {
    fprintf( stderr, "Stem pattern 2: %s\t", getFoundPattern2(testptr));
  }
#endif
  fmismatch = getFoundMismatch(testptr);
  fscore = testptr->fscore;
  if (fmismatch != BAD_VALUE)  fprintf( stderr, "Mismatches: %d\t", fmismatch );
  fpairs = testptr->fpairs;
  if (fpairs != BAD_VALUE)  fprintf( stderr, "Pairs: %d\t", fpairs );
  if (fscore != BAD_VALUE)  fprintf( stderr, "Score: %.2f\t", fscore );
  if(testptr->dither !=0)  fprintf( stderr, "Found dither: %d\t", testptr->fdither);
  if(testptr->dither2 !=0)  fprintf( stderr, "Found dither2: %d\t", testptr->fdither2);
  fprintf( stderr, "Position: %d\t", getFoundPosition(testptr, seq));
  if((fposition2 = testptr->fposition2) != NULL)  fprintf( stderr, "Stem Position2: %d\t", (fposition2 -seq) );
  fprintf( stderr, "\n");
}

int runTest(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr, char *seq, int hit1index, int hit2index) {
  /* Execute test at sequence starting at position
   * pointed to by *seq, return TEST_PASSED or TEST_FAILED
   * Store found values depending on type of test 
   * Increment seq by 1 for test fail, or by length
   * of matched pattern for match */
  int status;
  char *search_position;
  
  assert(testptr != NULL);
  search_position = seq + testptr->offset;
  switch(testptr->type) {
  case EXACT_MATCH:
    status = runExactTest(testptr, scoreptr, search_position);
    if (status == TEST_PASSED) testptr->fposition = search_position + testptr->fdither;
    break;
#if 0
  case CHECK_STEM:
    fprintf(stderr, "CHECK_STEM no longer an acceptable test type...dying\n");
    assert(0);
#endif
  case CHECK_ISTEM:
    status = check_IStem(testptr,  scoreptr, hit1index, hit2index);
    /* testptr->fposition computed in check_IStem */
    break;
  case CHECK_XSTEM:
    status = check_XStem(testptr,  scoreptr, hit1index, hit2index);
    break;
  case CHECK_DOUBLE_STEM:
    status = check_double_stem(testptr,  scoreptr, rundataptr);
    break;
#if 0
  case SCORE_LEFT_COMPL_GU_OK:
  case SCORE_RIGHT_COMPL_GU_OK:
    GU_OK = TRUE;
    status = extendScoreCompl(testptr,  scoreptr, hit1index, hit2index, GU_OK);
    /* testptr->fposition computed in extendScoreCompl */
    break;
  case LEFT_TARGET_GU_OK:
  case RIGHT_TARGET_GU_OK:
    GU_OK = TRUE;
    status = runMatchTest(testptr, scoreptr, search_position, GU_OK);
    if (status == TEST_PASSED) testptr->fposition = search_position + testptr->fdither;
    break;
#endif
  case SCORE_LEFT_COMPL:
  case SCORE_RIGHT_COMPL:
    status = extendScoreCompl(testptr,  scoreptr, hit1index, hit2index);
    /* testptr->fposition computed in extendScoreCompl */
    break;
  case DUMMY_LEFT_COMPL:
  case DUMMY_RIGHT_COMPL:
    status = dummyScoreCompl(testptr,  scoreptr, hit1index, hit2index);
    /* placeholder function used so when dummy target of "NNNN" is used */
    break;
  case LEFT_MATCH_TARGET:
  case RIGHT_MATCH_TARGET:
  case MATCH:
    status = runMatchTest(testptr, scoreptr, search_position);
    if (status == TEST_PASSED) testptr->fposition = search_position + testptr->fdither;
    break;
   case FIND_MULTI_MATCHES:
    status = multiMatchTest(testptr, scoreptr, search_position);
    if (status == TEST_PASSED) testptr->fposition = search_position + testptr->fdither;
    break;
  case MATCH_HACA2:
    status = runHACA2_Test(testptr, scoreptr, rundataptr);
    if (status == TEST_PASSED) testptr->fposition = search_position + testptr->fdither;
    break;
  case SCORE_INTERVALS:
    status = scoreIntervals(testptr, scoreptr, rundataptr);
    break;
  case SCORE_HACA_PATTERN:
    status = scoreHACAPattern(testptr, scoreptr, rundataptr);
    break;
  case SCORE_TARGETS:		/* "deprecated, will be removed */
    status = scoreTargets(testptr, scoreptr, rundataptr);
    break;
  case SCORE_TARGET_MATRIX:
    status = scoreTargetMatrix(testptr, scoreptr, rundataptr);
    break;
  case SCORE_TARGET_INTERVALS:
    status = scoreTargetIntervals(testptr, scoreptr, rundataptr);
    break;
  case SCORE_POST_ACA:
    status = scorePOST_ACA(testptr, scoreptr, rundataptr, HACA); /* so far used directly only 1-stem scanner */
    break;
  case  SCORE_STEM1_TARGET:
    status = scoreStem1Total(testptr, scoreptr, rundataptr);
    break;
  case CHECK_ONESTEM_PLUS:
    status = check_ACA_stem_with_H(testptr,  scoreptr, rundataptr);
    break;
  case  OUTPUT_STEM1_TARGET:
    /* first check that score is high enough */
    if (  scoreptr->totalScoreStem1 >= rundataptr->totalScoreCutoff) {
      status = outputHit(scoreptr, rundataptr) ;
      printf("####\n");		/*  output end of record marker (this is kludgey)  */
    } else {
      status = TEST_FAILED;
    }
    break;
  default:
    fprintf( stderr, "Unknown test type %d", testptr->type);
    assert(0);
  }
  return (status);
}

TEST *getTest(int feature) {
  /* Get the test pointer for the test corresponding to the feature */
  TEST *testptr;
  assert ((feature > 0) || (feature <= CURRENTFEATUREMAX));
  testptr = testPtrTable[feature];
  assert(testptr != NULL);
  return testptr;
}


/************* private functions ****************/


static int runExactTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq) {
  /* Execute match test at sequence starting at position
   * pointed to by *seq and using pattern stored in testptr
   * return TEST_PASSED or TEST_FAILED
   * Store found values depending on type of test */
  int status;
  int dither;

  for (dither = 0; dither <= testptr->dither; dither++) {
    /* do simple string comparison with no mismatches for now */
    status = strncmp(seq+dither, testptr->pattern, testptr->length) ;
    if (status == 0) {
      strcpy(testptr->fpattern, testptr->pattern);
      testptr->flength  = strlen(testptr->fpattern);
      testptr->fdither  = dither;
      if (testptr->pflag == 0) { /* if final pass store test results in scoreptr*/
	scoreptr->Patterns[testptr->feature] = testptr->fpattern; 
	scoreptr->Lengths[testptr->feature] = testptr->flength ;
	scoreptr->Dithers[testptr->feature] = testptr->fdither ;
      }
      return (TEST_PASSED);
    } 
  }
  return ( TEST_FAILED );
}

static int runMatchTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq) {
  /* Execute match test at sequence starting at position
   * pointed to by *seq and using pattern stored in testptr
   * return TEST_PASSED or TEST_FAILED
   * Store found values depending on type of test */
  int dither;
  int fmismat;
  int allowed;
  int best_mismat;
  int fdither;
  allowed = testptr->mismat;
  best_mismat = allowed + 1;  /* Fail if we don't find something */
  if (testptr->tflag == GU_OK) { 
    for (dither = 0; dither <= testptr->dither; dither++) {
      fmismat = paired_seqncmp_unencoded(seq+dither, testptr->pattern, testptr->length, allowed);
      if (fmismat < best_mismat) {
	fdither = dither;
	best_mismat = fmismat;
      }
    }
  } else {			/* GU matches not OK */
    for (dither = 0; dither <= testptr->dither; dither++) {
      fmismat = seqncmp_unencoded(seq+dither, testptr->pattern, testptr->length, allowed);
      if (fmismat < best_mismat) {
	fdither = dither;
	best_mismat = fmismat;
      }
    }
  }
  if (best_mismat > allowed) {  return ( TEST_FAILED ); }  
  strncpy(testptr->fpattern, seq+fdither, testptr->length );
  *(testptr->fpattern + testptr->length) = '\0';
  testptr->flength  = strlen(testptr->fpattern);
  testptr->fdither  = fdither;
  testptr->fmismat  = best_mismat;  
  if (testptr->pflag == 0) { /* if final pass store test results in scoreptr */
    scoreptr->Patterns[testptr->feature] = testptr->fpattern; 
    scoreptr->Lengths[testptr->feature] = testptr->flength;
    scoreptr->Dithers[testptr->feature] = testptr->fdither;
  }  
  return (TEST_PASSED); 
}


static int multiMatchTest(TEST *testptr, HIT_SCORE *scoreptr, char *seq) {
  /* Execute match test at sequence starting at position
   * pointed to by *seq and using pattern stored in testptr
   * return TEST_PASSED or TEST_FAILED
   * Store found values depending on type of test */
  int dither;
  int fmismat;
  int allowed;
  int fdither;
  int matchNumber = 0;
  
  allowed = testptr->mismat; 
  for (dither = 0; dither <= testptr->dither; dither++) {
    fmismat = seqncmp_unencoded(seq+dither, testptr->pattern, testptr->length, allowed);
    if (fmismat <= allowed) {
      fdither = dither;
      scoreptr->HACAs_per_RCompl[matchNumber] = seq+dither;
      matchNumber++;
    }
  }
  assert(matchNumber < MAX_HACAS);  /* Could remove this later for efficiency  */
  scoreptr->HACAs_per_RCompl_totalhitcounter = matchNumber;
  if (matchNumber == 0) {  return ( TEST_FAILED ); }  
  testptr->fdither  = fdither;
  return (TEST_PASSED); 
}




static int extendScoreCompl(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) {
  char  *targetStart, *targetEnd, *query, *originalFoundPosition;
  int type, pairs, mismatch, minLen, maxLen, flength, complement, pairsMinusMismatch ;
  double fscore;
  TEST *parentptr; /* pointer to test with data on feature to be scored*/

  type = testptr->type;
  complement = 0;
  parentptr = getParent1(testptr);
  originalFoundPosition =  getParentfposition(testptr,hit1index, hit2index, 1);
  /* This is a little inefficient. minLen = parentptr->length; is more efficient but more complicated */
  minLen = 0;  
  maxLen = testptr->length;
 
  if (type == SCORE_RIGHT_COMPL) {
    query = originalFoundPosition;
    targetStart = testptr->pattern;
    pairsMinusMismatch = extendHitForward( targetStart, query, minLen, maxLen, &pairs, &mismatch, complement, testptr->tflag) ;
    if (pairsMinusMismatch < testptr->mismat) return ( TEST_FAILED );
    flength = pairs + mismatch;
    fscore = scoreDuplex(testptr->scoreMatrix, targetStart, query, flength, testptr->tflag );
#if 0
    fscore = scoreDuplex(testptr->scoreMatrix, targetStart, query, flength, complement );
#endif
  } else { /* type == SCORE_LEFT_COMPL */
    query = originalFoundPosition + parentptr->flength - 1;
    targetEnd = testptr->pattern + testptr->length - 1;
    pairsMinusMismatch = 
       extendHitBackward( targetEnd, query, minLen, maxLen, &pairs, &mismatch, complement, testptr->tflag) ;
    if (pairsMinusMismatch < testptr->mismat) return ( TEST_FAILED );
    flength = pairs + mismatch;
    fscore = scoreDuplex(testptr->scoreMatrix, targetEnd - flength +1,  query - flength + 1, flength, testptr->tflag );
#if 0
    fscore = scoreDuplex(testptr->scoreMatrix, targetEnd - flength +1,  query - flength + 1, flength, complement );
#endif 
 }
#if 0
  if (fscore < testptr->score) {
#endif
    /* Do not screen with Target-Matrix scores when allowing GU matches since 
     * we have so little GU training data - at least for now (1/9/03) */
  if ( (fscore < testptr->score) && (testptr->tflag == 0) ) {
    return (TEST_FAILED);
  } else {
    testptr->fscore = fscore;
    testptr->fpairs = pairs;      
    testptr->fmismat = mismatch;
    testptr->flength = testptr->fpairs + testptr->fmismat;
    if (type == SCORE_RIGHT_COMPL) {
      testptr->fposition = originalFoundPosition ;
      /*      testptr->fpattern = Strndup(query, flength); */
      strncpy(testptr->fpattern, query, flength); 
      *(testptr->fpattern + flength) = '\0'; 
    } else {
      testptr->fposition = originalFoundPosition + parentptr->flength - testptr->flength ;
      strncpy(testptr->fpattern, query - flength + 1, flength); 
      *(testptr->fpattern + flength) = '\0'; 
    }
    if (testptr->pflag == 0) { /* if final pass store test results in scoreptr */
      scoreptr->Scores[testptr->feature] = testptr->fscore;
      scoreptr->Pairs[testptr->feature] = testptr->fpairs;
      scoreptr->MisMatches[testptr->feature] = testptr->fmismat;
      scoreptr->Lengths[testptr->feature] = testptr->flength;
      scoreptr->Positions[testptr->feature] = testptr->fposition;
      scoreptr->Patterns[testptr->feature] = testptr->fpattern;
    }  
    return (TEST_PASSED);
  }
}

 
static int seqncmp_unencoded(char *s1, char *s2, int len, int allow) {
  /* Like SRE's seqncmp, but without sequence encoding.
   * Skips test if 'pattern' (seq2) = 'N'.
   Returns number of mismatches, but quits
   * when maximum number allowed is exceeded. */
  int mmat = 0;

  while ((*s2 != '\0' )  && (len-- != 0))
    {
      if ( (*s1 != *s2)  &&  (*s2 != 'N')  && (++mmat > allow))
	return(mmat);
      s1++;
      s2++;
    }
  while ((len-- != 0) && (*s1++ != '\0') && (mmat <= allow))
    mmat++;
  return (mmat);
}
      


static int paired_seqncmp_unencoded(char *s1, char *s2, int len, int allow) {
  /* Like seqncmp_unencoded, but allows GU matches
   * Skips test if 'pattern' (seq2) = 'N'.
   * Returns number of mismatches, but quits
   * when maximum number allowed is exceeded. */
  int mmat = 0;

  while ((*s2 != '\0' )  && (len-- != 0))
    {
      if ( !Paired(s1, s2)  &&  (*s2 != 'N')  && (++mmat > allow))
#if 0
      if ( (*s1 != *s2)  &&  (*s2 != 'N')  && (++mmat > allow))
#endif
	return(mmat);
      s1++;
      s2++;
    }
  while ((len-- != 0) && (*s1++ != '\0') && (mmat <= allow))
    mmat++;
  return (mmat);
}
      

  

static char *getTypeName(TEST *testptr) {
  /* Get  pointer to string decsription of test type */
  return ( typeAsString[testptr->type] );
}

static int lookupType(char *string, char *typeTable[], int tableSize) {
  /* Look up number of type_flag from its ascii-string name.
   * Return -1 if string not found  */
  int index;
  for(index = 0; index < tableSize; index++) {
    if(typeTable[index] == NULL ) return -1;
    if (strcmp(string, typeTable[index]) == 0) return index;
  }
  return (-1);
}

static TEST *getParent1(TEST *testptr) {
  /* Look up pointer to previous test storing required data for present test  */
  int currentFeature;
  int parentFeature;
  TEST *parentPtr;
  currentFeature = testptr->feature;
  parentFeature = parentFeatureTable[currentFeature];
  parentPtr = testPtrTable[parentFeature];
  assert(parentPtr != NULL);
  return (parentPtr);
}

static TEST *getParent2(TEST *testptr) {
  /* Look up pointer to previous test storing required data for 
   * second half of stem for present test  */
  int currentFeature;
  int parentFeature;
  TEST *parentPtr;
  currentFeature = testptr->feature;
  parentFeature = parentFeatureTable2[currentFeature];
  parentPtr = testPtrTable[parentFeature];
  assert(parentPtr != NULL);
  return (parentPtr);
}

static char *getParentfposition(TEST *testptr, int hit1index, int hit2index, int whichParent) {
  /* Get found start position of parent of present test  */
  TEST *parentPtr;
  char *fposition;

  assert( (whichParent ==1) || (whichParent == 2) );
  if (whichParent ==1 ) {
    parentPtr = getParent1(testptr);
  } else {
    parentPtr = getParent2(testptr);
  }
  fposition = retrievefposition(parentPtr, hit1index, hit2index);
  return (fposition);
}

static char *retrievefposition(TEST *testptr, int hit1index, int hit2index) {
  /* Get found start position of present test.
   * If test is from Preprocessor Pass, get found position from preprocessor hit (pphit)
   * structure array  */
  char *fposition;

  assert(testptr != NULL);
  switch (testptr->pflag) {
  case PASS1:
    switch (testptr->pptestnum) {
    case TEST_0:
      fposition = pp1hits[hit1index]->fpositionA; break;
    case TEST_1:
      fposition = pp1hits[hit1index]->fpositionB; break;
    default:
      assert (0); /* should never happen */
    }
    break;
  case PASS2:
    switch (testptr->pptestnum) {
    case TEST_0:
      fposition = pp2hits[hit2index]->fpositionA; break;
    case TEST_1:
      fposition = pp2hits[hit2index]->fpositionB; break;
    default:
      assert (0); /* should never happen */
    }
    break;
  case FINALPASS:
    fposition = testptr->fposition;
    break;
  default:
    assert (0); /* should never happen */
  }
  return (fposition);
}

static void initParentFeatureTable(void) {
  if ( !inittedParentFeatureTable) {
    parentFeatureTable[RCompl] = RComplMin;
    parentFeatureTable[LCompl] = LComplMin;
    parentFeatureTable[ISTEM] =  LComplMin;
    parentFeatureTable[XSTEM] =  LCompl;
    /*    parentFeatureTable[XSTEM] =  LComplMin; */
    inittedParentFeatureTable = TRUE;
  }
}

static void initParentFeatureTable2(void) {
  if ( !inittedParentFeatureTable2) {
    parentFeatureTable2[ISTEM] =  RComplMin;
    parentFeatureTable2[XSTEM] =  RCompl;
    /*    parentFeatureTable2[XSTEM] =  HACA; */
    inittedParentFeatureTable2 = TRUE;
  }
}

static int check_IStem(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) {

  int maxLenLeft, maxLenRight, complement, feature;
  char *LfoundPos, *RfoundPos, *leftStartPos, *rightStartPos ;
  TEST *parent1ptr;
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */
  double bestScore = -100;

  parent1ptr = getParent1(testptr);
  feature = testptr->feature;
  complement = +1;
  /* Get start positions of L/RCompl hits */
  LfoundPos =  getParentfposition(testptr,hit1index, hit2index, 1);
  RfoundPos =  getParentfposition(testptr,hit1index, hit2index, 2);

  leftStartPos =  LfoundPos +  parent1ptr->flength + testptr->offset ;
  rightStartPos =  RfoundPos -1 - testptr->offset2; 
  maxLenLeft = testptr->length;  /* Assumes gapmin > (2 * testptr->length) */
  maxLenRight = testptr->length;  /* Assumes gapmin > (2 * testptr->length) */

  assert(maxLenLeft > 0 && maxLenRight > 0 );
  bestScore = checkStemWithDither(testptr, scoreptr, maxLenLeft, maxLenRight, leftStartPos, rightStartPos, complement, testptr->feature) ;
  
  /* for stemChecks, testptr->mismat contains minimum pairs mismatch excess */
  if ( bestScore < testptr->mismat)  {
    return ( TEST_FAILED );
  } else {
    Reverse(testptr->fposition2 , reverseRightStem, testptr->flength); /* reverse right stem to enable scoring */
    testptr->fscore = scoreDuplex(testptr->scoreMatrix, testptr->fposition, reverseRightStem, testptr->flength, complement );
  }
  if (testptr->fscore < testptr->score) {
    return ( TEST_FAILED );
  } else {			/* TEST PASSED, store found data */

    storeStemPatterns(scoreptr, testptr->fposition, testptr->fposition2, testptr->flength, ISTEM) ;
    scoreptr->Scores[testptr->feature] = testptr->fscore;	/* store score in scoreptr */
    /* Store HACA position which is needed to set up XSTEM test. 
       Note scoreptr is a **global** variable currently */
    scoreptr->Positions[HACA] = retrievefposition( getTest(HACA) , hit1index, hit2index);
    return (TEST_PASSED);
  }
}

static int check_XStem(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) {

  int maxLenLeft, maxLenRight, complement, feature, RcomplPlusXstemLength;
  char *LfoundPos, *RfoundPos, *leftStartPos, *rightStartPos ;
  TEST *parent1ptr, *parent2ptr ;
#if 0
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */
#endif
  double bestScore = -100;

  parent1ptr = getParent1(testptr);
  parent2ptr = getParent2(testptr);
  feature = testptr->feature;
  complement = +1;
  /* Get start positions of L/RCompl hits */
  LfoundPos =  getParentfposition(testptr,hit1index, hit2index, 1);
  RfoundPos =  getParentfposition(testptr,hit1index, hit2index, 2);

  assert(scoreptr->Positions[HACA] != NULL);
  rightStartPos =  scoreptr->Positions[HACA] -1 - testptr->offset2;    
  RcomplPlusXstemLength = rightStartPos - RfoundPos + 1;
  leftStartPos =  LfoundPos + parent1ptr->flength - RcomplPlusXstemLength + testptr->offset ;
  /* Next two lines insure that Xstem doesn't overlap LCOMPL or RCOMPL regions */
  maxLenLeft =  (LfoundPos - leftStartPos )  ;  
  maxLenRight = RcomplPlusXstemLength - parent2ptr->flength ;  
  assert(maxLenLeft > 0 && maxLenRight > 0 );
  bestScore = checkStemWith2Dithers(testptr, scoreptr, maxLenLeft, maxLenRight, leftStartPos, rightStartPos, complement, testptr->feature) ;
  if ( bestScore < testptr->score)  {return ( TEST_FAILED );}   
  return (TEST_PASSED);
}

static int checkStemWithDither(TEST *testptr, HIT_SCORE *scoreptr, int maxLenLeft, int maxLenRight, \
			       char *leftStartPos, char *rightStartPos, int complement, int feature) {
  int pairs, mismatch;
  int pairsMinusMismatch, maxLenWithDither;
  int dither; 
  char *bestRightStartPos ;
  char *bestLeftStartPos ;
  double bestScore = -100;
  testptr->fpairs = 0;
  testptr->fmismat = 0;
  for (dither = 0; dither <= testptr->dither; dither++) {
    /* Note: We need to check that maxLen doesn't overlap COMPL region even after adding dither*/

    maxLenWithDither = MIN(maxLenLeft - dither, testptr->length);
    maxLenWithDither = MIN(maxLenWithDither, maxLenRight);
    pairsMinusMismatch = extendHitForwardBack(leftStartPos + dither, rightStartPos, 0, maxLenWithDither, &pairs, \
					      &mismatch, complement, TRUE);
    if (pairsMinusMismatch > bestScore) {
      bestScore = pairsMinusMismatch;
      testptr->fpairs = pairs;                /* bestPairs, so far*/
      testptr->fmismat = mismatch;            /* bestMismatch, so far */
      testptr->fdither = dither;
      bestLeftStartPos = leftStartPos + dither;  /* bestLeftStartPos, so far */
      bestRightStartPos = rightStartPos;
    }
    if (dither != 0) {
      maxLenWithDither = MIN(maxLenRight - dither, testptr->length);
      maxLenWithDither = MIN(maxLenWithDither, maxLenLeft);
      pairsMinusMismatch = extendHitForwardBack(leftStartPos, rightStartPos - dither, 0, maxLenWithDither, &pairs, \
						&mismatch, complement, TRUE);
      if (pairsMinusMismatch > bestScore) {
	bestScore = pairsMinusMismatch;
	testptr->fpairs = pairs;
	testptr->fmismat = mismatch;
	testptr->fdither = -dither;
	bestLeftStartPos = leftStartPos;
	bestRightStartPos = rightStartPos - dither;
      }
    }
  }
  /* If score passes minimum, check that initial bases are paired, and, if not, remove them */
  if (bestScore >= testptr->mismat ) {  
    while (Paired(bestLeftStartPos, bestRightStartPos) == 0 ) {
      bestLeftStartPos++;
      bestRightStartPos--;
      testptr->fmismat--;
      bestScore++;
    }
  } 
  if (bestScore >= testptr->mismat && testptr->pflag == 0) {  /* if final pass store test results */
    testptr->flength = testptr->fpairs + testptr->fmismat;  /* Best found length */
    testptr->fposition = bestLeftStartPos;       
    testptr->fposition2 = bestRightStartPos - testptr->flength + 1;   /* fposition starts at 3' end */       
    testptr->fscore = bestScore;
    scoreptr->Scores[feature] = testptr->fscore;
    scoreptr->Pairs[feature] = testptr->fpairs;
    scoreptr->Dithers[feature] = testptr->fdither;
    scoreptr->Positions[feature] = testptr->fposition;
    scoreptr->Lengths[feature] = testptr->flength; 
    scoreptr->PositionsRight[feature] = testptr->fposition2;
#if 0
    scoreptr->Scores[testptr->feature] = testptr->fscore;      
#endif
  }     
  return (bestScore);
}  
 

static double checkStemWith2Dithers(TEST *testptr, HIT_SCORE *scoreptr, int maxLenLeft, int maxLenRight, \
				 char *leftStartPos, char *rightStartPos, int complement, int feature) {
  int pairs, mismatch;
  int pairsMinusMismatch;
  int currentMaxLen;
  int currentLeadingMismatches;
  int dither, dither2; 
  char *currentRightStartPos ;
  char *currentLeftStartPos ;
  char *bestRightStartPos ;
  char *bestLeftStartPos ;
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */
  double currentScore;
  double bestScore = -100;
 
  testptr->fpairs = 0;
  testptr->fmismat = 0;
  /* Using two loops is inefficient, but I won't worry about it now */
  for (dither = 0; dither <= testptr->dither; dither++) {
    for (dither2 = 0; dither2 <= testptr->dither2; dither2++) {
      /* Note: We need to check that maxLen doesn't overlap COMPL region even after adding dither*/
      currentRightStartPos = rightStartPos -dither2;
      currentLeftStartPos = leftStartPos + dither;
      currentLeadingMismatches = 0;
      currentMaxLen = MIN(maxLenLeft - dither, testptr->length);
      currentMaxLen = MIN(currentMaxLen, maxLenRight - dither2);
      /* skip leading mismatches */
      while (Paired(currentLeftStartPos, currentRightStartPos) == 0 && currentMaxLen > 0) {
	currentLeftStartPos++;
	currentRightStartPos--;
	currentMaxLen--;
	currentLeadingMismatches++;
      }
      pairsMinusMismatch = extendHitForwardBack(currentLeftStartPos, currentRightStartPos, 0, currentMaxLen, &pairs, \
						&mismatch, complement, TRUE);
      if (strlen(currentLeftStartPos) < 1) { /* Too near end of sequence */
#if 0
	fprintf (stderr, " stem too short - probably too near start of sequence.  Skipping..\n");
#endif
	continue;
      }
#if 0
      Reverse(bestRightStartPos , reverseRightStem, testptr->flength); /* reverse right stem to enable scoring */
      testptr->fscore = scoreDuplex(testptr->scoreMatrix, testptr->fposition, reverseRightStem, testptr->flength, complement );
#endif
      Reverse(currentRightStartPos -(pairs + mismatch) + 1, reverseRightStem, pairs + mismatch); /* reverse right stem to enable scoring */
      currentScore = scoreDuplex(testptr->scoreMatrix, currentLeftStartPos, reverseRightStem, pairs + mismatch, complement );
      if (currentScore > bestScore) {
	bestScore = currentScore;
	testptr->fpairs = pairs;
	testptr->fmismat = mismatch;
	testptr->fdither = dither + currentLeadingMismatches;
	testptr->fdither2 = dither2 + currentLeadingMismatches;
	bestLeftStartPos = currentLeftStartPos;
	bestRightStartPos = currentRightStartPos;
      }
    }
  }
  if (bestScore >= testptr->score && \
      testptr->pflag == 0) {  /* if final pass store test results */
    testptr->flength = testptr->fpairs + testptr->fmismat;  /* Best found length */
    testptr->fposition = bestLeftStartPos;       
    testptr->fposition2 = bestRightStartPos - testptr->flength + 1;   /* fposition starts at 3' end */       
    scoreptr->Scores[feature] = testptr->fscore = bestScore;
    scoreptr->Pairs[feature] = testptr->fpairs;
    scoreptr->Dithers[feature] = testptr->fdither;
    scoreptr->Positions[feature] = testptr->fposition;
    scoreptr->Lengths[feature] = testptr->flength; 
    scoreptr->PositionsRight[feature] = testptr->fposition2;
    storeStemPatterns(scoreptr, testptr->fposition, testptr->fposition2, testptr->flength, feature) ;    
  }     
  return (bestScore);
}  
 



int scoreStem1Total(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate total score for hit and output if score exceeds cutoff */
 
  if (scoreptr->totalScoreStem1 < testptr->score) {
    return (TEST_FAILED);
  } else {
#if 0
    storeScores(scoreptr, rundataptr) ; /* This is all that's left of this routine - it should be moved */
#endif
    return (TEST_PASSED); 
  }
}

static int runHACA2_Test(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  char *startSearchPosition;     
  char *stopSearchPosition;	 
  char *searchPosition;	 
  int status;
  int hitIndex = 0;

  if (scoreptr->H_or_ACA != 'H' ) { /* Not a 'definite' H so search upstream */

    startSearchPosition = scoreptr->Positions[XSTEM] - rundataptr->MaxIntervals[XSTEM_H] ;
    stopSearchPosition =  scoreptr->Positions[XSTEM] - rundataptr->MinIntervals[XSTEM_H];
    startSearchPosition =  MAX(startSearchPosition, rundataptr->querySeq + rundataptr->MinIntervals[stem2gap] + 2 * ISTEM_XSTEM );
    stopSearchPosition =   MAX(stopSearchPosition,  rundataptr->querySeq + rundataptr->MinIntervals[stem2gap] + 2 * ISTEM_XSTEM ); 
    assert(stopSearchPosition >=   startSearchPosition);
    for ( searchPosition = startSearchPosition; searchPosition <= stopSearchPosition; searchPosition++) {
      status = runMatchTest(testptr, scoreptr, searchPosition);
      if (status == TEST_PASSED ) { 
	assert (hitIndex < ALLOWED_HACA2_HITS);
	addHit(scoreptr->HACA2hits[hitIndex], testptr, NULL, searchPosition);
	hitIndex++;
      }
    }
  }

  if (scoreptr->H_or_ACA != 'C' ) { /* Not a 'definite' ACA so search downstream */

    startSearchPosition = scoreptr->Positions[HACA] + rundataptr->MinIntervals[ACA_H];
    stopSearchPosition =  scoreptr->Positions[HACA] + rundataptr->MaxIntervals[ACA_H];
    stopSearchPosition =  MIN( rundataptr->querySeq + rundataptr->segment_length - HACALENGTH, stopSearchPosition);
    startSearchPosition = MIN( rundataptr->querySeq + rundataptr->segment_length - HACALENGTH, startSearchPosition);
    assert(stopSearchPosition >=   startSearchPosition);
    for ( searchPosition = startSearchPosition; searchPosition <= stopSearchPosition; searchPosition++) {
      status = runMatchTest(testptr, scoreptr, searchPosition);
       if (status == TEST_PASSED ) { 
	if (hitIndex >=  ALLOWED_HACA2_HITS) {
	  fprintf( stderr, "Too many ANA's in candidate number %d Skipping some hits \n", rundataptr->candidate_number);
	  return (TEST_FAILED);
#if 0
	  assert(0);		/* Panic! */
#endif
	}
	addHit(scoreptr->HACA2hits[hitIndex], testptr, NULL, searchPosition);
	hitIndex++;
      }
    }
  }  
  if ( hitIndex == 0 ) { /* No hits found anywhere */
    return ( TEST_FAILED );
  } else {
    scoreptr->HACA2_totalhitcounter  = hitIndex ; /* Record number of HACA2 candidates found */
    return ( TEST_PASSED );
  }
} 


static int dummyScoreCompl(TEST *testptr, HIT_SCORE *scoreptr, int hit1index, int hit2index) {
  char *query, *originalFoundPosition;
  int type, flength ;
  TEST *parentptr; /* pointer to test with data on feature to be scored*/

  type = testptr->type;
  parentptr = getParent1(testptr);
  originalFoundPosition =  getParentfposition(testptr,hit1index, hit2index, 1);
  testptr->fscore = 0;
  testptr->fpairs = 0;      
  testptr->fmismat = 0;
  flength = parentptr->flength;
  testptr->flength = parentptr->flength;
  if (type == DUMMY_RIGHT_COMPL) {
    query = originalFoundPosition ;
    testptr->fposition = originalFoundPosition ;
    strncpy(testptr->fpattern, query, flength); 
    *(testptr->fpattern + flength) = '\0'; 
  } else {
    query = originalFoundPosition  + parentptr->flength - 1 ;
    testptr->fposition = originalFoundPosition + parentptr->flength - testptr->flength ;
    strncpy(testptr->fpattern, query - flength + 1, flength); 
    *(testptr->fpattern + flength) = '\0'; 
  }
  scoreptr->Scores[testptr->feature] = 0;
  scoreptr->Pairs[testptr->feature] = 0;
  scoreptr->Lengths[testptr->feature] = testptr->flength;
  scoreptr->Positions[testptr->feature] = testptr->fposition;
  scoreptr->Patterns[testptr->feature] = testptr->fpattern;
  return (TEST_PASSED);
}

int scoreIntervals(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate scores for all intervals not involving a "target" */
  int ISTEMStart, status;

  ISTEMStart = scoreptr->Dithers[ISTEM];
  
  /* get length distribution scores */
  scoreptr->IntervalScores[stem1gap] = scoreLength(gapScores,SCORETABLESIZE, scoreptr->Intervals[stem1gap]);
  scoreptr->IntervalScores[ISTEM1Length] = scoreLength(iStemLengthScores, SCORETABLESIZE , scoreptr->Lengths[ISTEM]);
  scoreptr->IntervalScores[ISTEM1Start] = scoreLength(IStemStartScores, SCORETABLESIZE, ISTEMStart);
   
  scoreptr->totalScoreStem1 +=  scoreptr->Scores[ISTEM] ;
  scoreptr->totalScoreStem1 +=  scoreptr->Scores[XSTEM] + scoreptr->IntervalScores[stem1gap];
  scoreptr->totalScoreStem1 +=  scoreptr->IntervalScores[ISTEM1Length] + scoreptr->IntervalScores[ISTEM1Start];

/* xstem length scores not implemented yet */ 
#if 0
  scoreptr->IntervalScores[XSTEM1Length] = scoreLength(xStemLengthScores, SCORETABLESIZE , scoreptr->Lengths[XSTEM]);
  scoreptr->totalScoreStem1 +=  scoreptr->IntervalScores[XSTEM1Length] 
#endif   
  
  status = TEST_PASSED; /* No Interval score cutoff implemented yet */
  return status;
}

int scoreTargetMatrix(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate scores relating to "targets" */
  int status;
  scoreptr->totalScoreStem1 += scoreptr->Scores[RCompl] + scoreptr->Scores[LCompl] ;
  status = TEST_PASSED; /* No score cutoff implemented yet */
  return status;
}

int scoreTargetIntervals(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate scores relating to "targets" */
  int ComplLength, status;
  ComplLength = scoreptr->Lengths[RCompl] + scoreptr->Lengths[LCompl];
  scoreptr->Intervals[HACA_RCompl] = scoreptr->Positions[HACA] - scoreptr->Positions[RCompl];
  /* get length distribution scores */
  scoreptr->IntervalScores[Compl1Length] = scoreLength(complLengthScores, SCORETABLESIZE , ComplLength);
  scoreptr->IntervalScores[HACA_RCompl] = scoreLength(rComplHACAIntervalScores, SCORETABLESIZE, scoreptr->Intervals[HACA_RCompl] );
  
  scoreptr->totalScoreStem1 += scoreptr->IntervalScores[Compl1Length];
  scoreptr->totalScoreStem1 += scoreptr->IntervalScores[HACA_RCompl];
  status = TEST_PASSED; /* No Interval score cutoff implemented yet */
  return status;
}
 

/* The following routine scoreTargets is being replaced by the combined routines scoreTargetMatrix 
 * and scoreTargetIntervals, so that the tests can be included or replaced separately.  It is being
 * left in for now so that the old descriptor files which use it still work */
  
int scoreTargets(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate scores relating to "targets" */
  int ComplLength, status;

  ComplLength = scoreptr->Lengths[RCompl] + scoreptr->Lengths[LCompl];
  scoreptr->Intervals[HACA_RCompl] = scoreptr->Positions[HACA] - scoreptr->Positions[RCompl];

  /* get length distribution scores */
  scoreptr->IntervalScores[Compl1Length] = scoreLength(complLengthScores, SCORETABLESIZE , ComplLength);
  scoreptr->IntervalScores[HACA_RCompl] = scoreLength(rComplHACAIntervalScores, SCORETABLESIZE, scoreptr->Intervals[HACA_RCompl] );
  
  scoreptr->totalScoreStem1 += scoreptr->Scores[RCompl] + scoreptr->Scores[LCompl] ;
  scoreptr->totalScoreStem1 += scoreptr->IntervalScores[Compl1Length];
  scoreptr->totalScoreStem1 += scoreptr->IntervalScores[HACA_RCompl];

 
  status = TEST_PASSED; /* No Interval score cutoff implemented yet */
  return status;
}
 
int scoreHACAPattern(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Calculate score of stem1 HACA pattern and determine whether pattern could be H or ACA */
  /* If scoreptr->Scores[POST_ACA] != 0 we are looking only for ACA stems */
  /* As currently set up, this needs to be either the *last* stem1 test */
  int status;

  strncpy(scoreptr->Patterns[HACA], scoreptr->Positions[HACA], HACALENGTH);  
  *(scoreptr->Patterns[HACA] + HACALENGTH) = '\0'; 
  scoreHACAmotif(scoreptr, 'B'); 

  if (scoreptr->Scores[POST_ACA] != 0) { /* force ACA motif scoring  */
    if ( scoreptr->ACA1Score + scoreptr->totalScoreStem1 < testptr->score) return (TEST_FAILED);
    scoreptr->H_or_ACA = 'C';
    scoreptr->Scores[HACA] = scoreptr->ACA1Score; /* Needed for display of single stem */
  } else {
    if (scoreptr->ACA1Score > scoreptr->H1Score) {
      if ( scoreptr->ACA1Score + scoreptr->totalScoreStem1 < testptr->score) {
	return (TEST_FAILED);
      }
      if ( scoreptr->H1Score + scoreptr->totalScoreStem1 > testptr->score) { /* Both H and ACA possible, ACA better */
	scoreptr->H_or_ACA = 'c';
      } else {			/* only ACA possible */
	scoreptr->H_or_ACA = 'C';
      }
      scoreptr->Scores[HACA] = scoreptr->ACA1Score; /* Needed for display of single stem */
    } else {			/* H score higher */
      if ( scoreptr->H1Score + scoreptr->totalScoreStem1 < testptr->score) {
	return (TEST_FAILED);
      }
      if ( scoreptr->ACA1Score + scoreptr->totalScoreStem1 > testptr->score) { /* Both H and ACA possible, H better */
	scoreptr->H_or_ACA = 'h';
      } else {			/* only H possible */
	scoreptr->H_or_ACA = 'H';
      }
      scoreptr->Scores[HACA] = scoreptr->H1Score; /* Needed for display of single stem */
    }
  }
  scoreptr->totalScoreStem1 +=  scoreptr->Scores[HACA];
  status = TEST_PASSED; /* No HACA Pattern cutoff implemented yet */
  return status;
}
      
static int xstem2Search(TEST *testptr, HIT_SCORE *scoreptr, char *HACA2_position, RUNDATA *rundataptr, \
			int currentlySearching, char *xstemSearchPosition) {
  int maxLen, Xstem2PairScore;
  char *rightStartPos;
  int complement = 1;
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */

  maxLen = testptr->length;  

  rightStartPos =  HACA2_position - 1;     
  Xstem2PairScore = checkStemWithDither(testptr, scoreptr, maxLen, maxLen, xstemSearchPosition, rightStartPos, complement, XSTEM2) ;
  /* for stemChecks, testptr->mismat contains minimum pairs mismatch excess */
  if ( Xstem2PairScore < testptr->mismat)  {
    return (TEST_FAILED);
  }   /* No point in continuing if no Xstem found */
  Reverse(testptr->fposition2 , reverseRightStem, testptr->flength); /* reverse right stem to enable scoring */
  scoreptr->Scores[XSTEM2] = scoreDuplex(testptr->scoreMatrix, testptr->fposition, reverseRightStem, testptr->flength, complement );
  if (scoreptr->Scores[XSTEM2] < testptr->score) {
    return (TEST_FAILED);
  }   /* No point in continuing if no Xstem found */
#if 0
  storeStemPatterns(testptr, scoreptr, testptr->fposition, reverseRightStem, XSTEM2 ) ;
#endif
  scoreptr->Positions[XSTEM2] = testptr->fposition; 
  scoreptr->PositionsRight[XSTEM2] = testptr->fposition2; 
  scoreptr->Lengths[XSTEM2] = testptr->flength; 
  return (TEST_PASSED);
}  

static int istem2Search(TEST *testptr, HIT_SCORE *scoreptr, char *HACA2_position, RUNDATA *rundataptr, int currentlySearching) {
  char *rightStartPos, *leftStartPos;
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */
  int complement = 1;
  int maxLen, Istem2PairScore;
  
  maxLen = testptr->length;  
  leftStartPos =   scoreptr->Positions[XSTEM2] + ISTEM_XSTEM;     
  rightStartPos =  scoreptr->PositionsRight[XSTEM2] + scoreptr->Lengths[XSTEM2]  - ISTEM_XSTEM;  
  if ((rightStartPos - leftStartPos) < rundataptr->MinIntervals[stem2gap]){
    return (TEST_FAILED);   /* Not enough room for a stem loop, so skip to next */
  } 
  Istem2PairScore = checkStemWithDither(testptr, scoreptr, maxLen, maxLen, leftStartPos, rightStartPos, complement, ISTEM2) ;
  if ( Istem2PairScore < testptr->mismat)  {
    return (TEST_FAILED);   /* No point in continuing if no Istem found */
  }   
  Reverse(testptr->fposition2 , reverseRightStem, testptr->flength); /* reverse right stem to enable scoring */
  scoreptr->Scores[ISTEM2] = scoreDuplex(testptr->scoreMatrix, testptr->fposition, reverseRightStem, testptr->flength, complement );
  if (scoreptr->Scores[ISTEM2] < testptr->score) {
    return (TEST_FAILED);   /* No point in continuing if no Istem found */
  }   
#if 0
  storeStemPatterns(scoreptr, testptr->fposition, reverseRightStem, ISTEM2 ) ; 
#endif
  scoreptr->Positions[ISTEM2] = testptr->fposition; 
  scoreptr->PositionsRight[ISTEM2] = testptr->fposition2; 
  scoreptr->Lengths[ISTEM2] = testptr->flength; 
  return (TEST_PASSED);
}  

int scorePOST_ACA(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr, int haca_or_aca) {
  /* Calculate score of POST_ACA pattern */
  int status;
  scoreptr->Positions[POST_ACA] = scoreptr->Positions[haca_or_aca] + HACALENGTH;
/* Added flag to enable skipping test 6/6/03 */
  if (testptr->tflag == NO_POST_ACA ) {
    scoreptr->Scores[POST_ACA] = 0;
    return TEST_PASSED;
  }
  /* Check that we're not at end of segment and if OK score 'tail' downstream of ACA */
  if ( (scoreptr->Positions[POST_ACA] + POST_ACALENGTH - 1) < (rundataptr->querySeq + rundataptr->segment_length)) {
    scoreptr->Scores[POST_ACA] = scoreBaseFrequency(POST_ACA_freqScores, scoreptr->Positions[POST_ACA], POST_ACALENGTH,'T') ;
  } else {
    scoreptr->Scores[POST_ACA] = 0;
  }
  if ( haca_or_aca == HACA) { /* If stem1-only scanner, add score to total */
    scoreptr->totalScoreStem1 +=  scoreptr->Scores[POST_ACA];
  }
  status = TEST_PASSED; /* No POST_ACA Pattern cutoff implemented yet */
  return status;
}

static int score2StemIntervals( HIT_SCORE *scoreptr, RUNDATA *rundataptr, int currentlySearching) { 
  if ( scoreptr->Positions[XSTEM2] > scoreptr->Positions[XSTEM] ) { /* Stem 2 is ACA stem */
    scoreptr->Intervals[XSTEM_H] = scoreptr->Positions[XSTEM2] - scoreptr->Positions[H];
    scoreptr->Intervals[HACA_ISTEM2R] = (scoreptr->Positions[ACA] - scoreptr->PositionsRight[ISTEM2]) - scoreptr->Lengths[ISTEM2] ;
  } else {                       /* Stem 2 is H stem */
    scoreptr->Intervals[XSTEM_H] = scoreptr->Positions[XSTEM] - scoreptr->Positions[H];
    scoreptr->Intervals[HACA_ISTEM2R] = (scoreptr->Positions[H] - scoreptr->PositionsRight[ISTEM2]) - scoreptr->Lengths[ISTEM2] ;
  }  
  scoreptr->Intervals[stem2gap] = (scoreptr->PositionsRight[ISTEM2] - scoreptr->Positions[ISTEM2]) + scoreptr->Lengths[ISTEM2];
  if ( scoreptr->Intervals[stem2gap] <  rundataptr->MinIntervals[stem2gap] || \
       scoreptr->Intervals[stem2gap] >  rundataptr->MaxIntervals[stem2gap]  ) { /* paranoia? */
    if (DEBUG > 1) {
      fprintf( stderr, "Interval out of range, skipping...\n");
      fprintf( stderr, "Stem2gap -inc istem: %d  \n", \
	       scoreptr->Intervals[stem2gap]  );
    }
    return (TEST_FAILED); 
  }
  if ( scoreptr->Intervals[XSTEM_H] <  rundataptr->MinIntervals[XSTEM_H] || \
       scoreptr->Intervals[XSTEM_H] >  rundataptr->MaxIntervals[XSTEM_H] ) { /* paranoia? */
    if (DEBUG > 1) {
      fprintf( stderr, "XStem-H Interval out of range, skipping...\n");
      fprintf( stderr, " xstem-H interval: %d \n", \
	       scoreptr->Intervals[XSTEM_H] );
    }
    return (TEST_FAILED); 
  }
  if ( scoreptr->Intervals[HACA_ISTEM2R] <  rundataptr->MinIntervals[HACA_ISTEM2R] || \
       scoreptr->Intervals[HACA_ISTEM2R] >  rundataptr->MaxIntervals[HACA_ISTEM2R]  ) { /* paranoia? */
    if (DEBUG > 1) {
      fprintf( stderr, "HACA-ISTEM Interval out of range, skipping...\n");
      fprintf( stderr, " HACA-ISTEMR int: %d \n", \
	       scoreptr->Intervals[HACA_ISTEM2R] );
    }
    return (TEST_FAILED); 
  }
  scoreptr->IntervalScores[XSTEM_H] = scoreLength(H_XSTEM_intervalScores, SCORETABLESIZE, scoreptr->Intervals[XSTEM_H] );
  scoreptr->IntervalScores[stem2gap] = scoreLength(gapScores,SCORETABLESIZE, scoreptr->Intervals[stem2gap]);    
  scoreptr->IntervalScores[HACA_ISTEM2R] = scoreLength(HACA_ISTEM2R_intervalScores, SCORETABLESIZE, scoreptr->Intervals[HACA_ISTEM2R] );
  return (TEST_PASSED);
}

static int score2StemTotals( HIT_SCORE *scoreptr, RUNDATA *rundataptr) { 
  scoreptr->totalScore = scoreptr->totalScoreStem1 - scoreptr->Scores[HACA] + scoreptr->Scores[ACA] +  scoreptr->Scores[H];
  scoreptr->totalScore  += scoreptr->IntervalScores[XSTEM_H] + scoreptr->Scores[ISTEM2] + scoreptr->Scores[XSTEM2];
  scoreptr->totalScore  += scoreptr->IntervalScores[stem2gap] + scoreptr->IntervalScores[HACA_ISTEM2R] ;
  scoreptr->totalScore  += scoreptr->Scores[POST_ACA] ;
  if (  scoreptr->totalScore >= rundataptr->totalScoreCutoff) {
#if 0
    storeScores(scoreptr, rundataptr) ; /* Need to compute relative positions again */
#endif
    return (TEST_PASSED);
  } else {
    return (TEST_FAILED); 
  }    
}

static void setXstemSearchLimits( HIT_SCORE *scoreptr, RUNDATA *rundataptr, char *HACA2_position, char **startXstemSearchPtr, char **endXstemSearchPtr, int currentlySearching) {
  *startXstemSearchPtr = HACA2_position - (rundataptr->MaxIntervals[stem2gap] + 2 * ISTEM_XSTEM);
  *endXstemSearchPtr   = HACA2_position - (rundataptr->MinIntervals[stem2gap] + 2 * ISTEM_XSTEM);
  /* MAX calls needed to make sure we're not looking before beginning of sequence */
  if ( currentlySearching == DOWNSTREAM ) {  
    *startXstemSearchPtr = MAX(scoreptr->Positions[HACA] + rundataptr->MinIntervals[XSTEM_H] , *startXstemSearchPtr);
    *endXstemSearchPtr =   MIN(scoreptr->Positions[HACA] + rundataptr->MaxIntervals[XSTEM_H] , *endXstemSearchPtr);
  } else {                                              /* We're currently searching upstream */
    *startXstemSearchPtr = MAX( rundataptr->querySeq, *startXstemSearchPtr);
    *endXstemSearchPtr =   MAX( rundataptr->querySeq, *endXstemSearchPtr);
  }
  assert (*endXstemSearchPtr >= *startXstemSearchPtr);  
}

static int check_ACA_stem_with_H (TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  int hitIndex = 0;   /* index of hit from preprocessor Pass */
  int currentlySearching = UPSTREAM; 
  int status;
  char *HACA2_position;
  HIT_SCORE *currentscoreptr; /* pointer to struct for best scoring H motif associated with current 1st stem */
  double bestHscore = -9999;  /* best score so far for associated H motif */
  
  currentscoreptr = DEBUGMALLOC(1, sizeof(HIT_SCORE)); 
  initCurrentScorePtr (currentscoreptr, scoreptr);
  for ( hitIndex = 0; scoreptr->HACA2_totalhitcounter  > hitIndex ; hitIndex++) {
    HACA2_position = getHitEndPosition(scoreptr->HACA2hits[hitIndex]);

    /* Score H_XSTEM interval and H motif */
    scoreHACA2(currentscoreptr, HACA2_position, currentlySearching );
    status = scoreH_XstemInterval(currentscoreptr, rundataptr, currentlySearching); 
    if (status == TEST_FAILED) {
      continue;
    }
    status = score2StemTotals(currentscoreptr, rundataptr); 
    if (currentscoreptr->totalScore > bestHscore ) {
      bestHscore = currentscoreptr->totalScore;
      copyPointers(currentscoreptr, scoreptr);
    }
  }  	/* End for-each-HACA2 LOOP */			
  if ( bestHscore > testptr->score  &&
       (bestHscore + scoreptr->totalScoreStem1) > rundataptr->totalScoreCutoff ) { 
    scoreptr->totalScore = bestHscore + scoreptr->totalScoreStem1;
    copyPatterns(scoreptr);
    outputHit(scoreptr, rundataptr);
    printf("####\n\n");		/* output end-of-record marker */
  }
  DEBUGFREE(currentscoreptr, sizeof(HIT_SCORE)) ;
  return (TEST_PASSED);
}

static int check_double_stem(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  int hitIndex = 0;   /* index of hit from preprocessor Pass */
  int currentlySearching, status;
  char *HACA2_position;
  int maxLen;
  char *startXstemSearch, *endXstemSearch, *xstemSearch;
  HIT_SCORE *currentscoreptr; /* pointer to struct for best scoring H motif associated with current 1st stem */
  double best2StemScore = -9999;  /* best score so far for associated H motif */

  currentscoreptr = DEBUGMALLOC(1, sizeof(HIT_SCORE)); 
  initCurrentScorePtr (currentscoreptr, scoreptr);
  maxLen = testptr->length;  
  for ( hitIndex = 0; scoreptr->HACA2_totalhitcounter  > hitIndex ; hitIndex++) {
    HACA2_position = getHitEndPosition(scoreptr->HACA2hits[hitIndex]);

    /* First score H_XSTEM interval, H motif and ACA motif */
    if (abs( HACA2_position - scoreptr->Positions[HACA]) < rundataptr->MinIntervals[ACA_H] ) {
      continue;			/* this shouldn't be necessary...I think I'm doing something wrong */
    } 
    if ( HACA2_position > scoreptr->Positions[HACA] ) { /* We're currently searching downstream */
      currentlySearching = DOWNSTREAM;
    } else {
      currentlySearching = UPSTREAM;
    }
    scoreHACA2(currentscoreptr, HACA2_position, currentlySearching );
    scorePOST_ACA(testptr, currentscoreptr, rundataptr, ACA);    
    setXstemSearchLimits( currentscoreptr, rundataptr, HACA2_position, &startXstemSearch, &endXstemSearch, currentlySearching );
    for ( xstemSearch = startXstemSearch; xstemSearch <= endXstemSearch; xstemSearch++) { 
      status = xstem2Search(testptr, currentscoreptr, HACA2_position, rundataptr,  currentlySearching, xstemSearch ); 
      if (status == TEST_FAILED) {
	continue;
      }
      status = istem2Search(testptr, currentscoreptr, HACA2_position, rundataptr, currentlySearching); 
      if (status == TEST_FAILED) {
	continue;
      }
      status = score2StemIntervals(currentscoreptr, rundataptr, currentlySearching); 
      if (status == TEST_FAILED) {
	continue;
      } 
      status = score2StemTotals(currentscoreptr, rundataptr); 
#if 0
      if (status == TEST_FAILED) {
	continue;
      }
#endif
      if (currentscoreptr->totalScore > best2StemScore ) {
	best2StemScore = currentscoreptr->totalScore;
	copyPointers(currentscoreptr, scoreptr);
      }
    } /* end of xstem2 search loop */
  }  	/* End for-each-HACA2 LOOP */			
  if ( best2StemScore > testptr->score  &&
       ( best2StemScore + scoreptr->totalScoreStem1) > rundataptr->totalScoreCutoff ) { 
    scoreptr->totalScore = best2StemScore + scoreptr->totalScoreStem1;
    copyPatterns(scoreptr);

    if (scoreptr->Positions[XSTEM] < scoreptr->Positions[XSTEM2] ) { 
				/* Stem found first is H stem */
      scoreptr->H_or_ACA = 'H';
    } else {
      scoreptr->H_or_ACA = 'C';
    } 
    outputHit(scoreptr, rundataptr);
    outputHitStem2(scoreptr, rundataptr);
    printf("####\n\n");		/* output end-of-record marker */
    DEBUGFREE(currentscoreptr, sizeof(HIT_SCORE)) ;
    return (TEST_PASSED);
  } else {    
    DEBUGFREE(currentscoreptr, sizeof(HIT_SCORE)) ;
    return (TEST_FAILED);
  }
}

static int scoreH_XstemInterval(HIT_SCORE *currentscoreptr, RUNDATA *rundataptr, int currentlySearching) { 
  if ( currentlySearching == DOWNSTREAM ) { /* Stem 2 is ACA stem => H known, ACA-xstem being searched for  */
    currentscoreptr->Intervals[XSTEM_H] = currentscoreptr->Positions[XSTEM2] - currentscoreptr->Positions[H];
  } else {                       /* Stem 2 is H stem => ACA-xstem known, H being searched for */
    currentscoreptr->Intervals[XSTEM_H] = currentscoreptr->Positions[XSTEM] - currentscoreptr->Positions[H];
  }  
  if ( currentscoreptr->Intervals[XSTEM_H] <  rundataptr->MinIntervals[XSTEM_H] || \
       currentscoreptr->Intervals[XSTEM_H] >  rundataptr->MaxIntervals[XSTEM_H] ) { /* paranoia? */
    if (DEBUG > 1) {
      fprintf( stderr, "XStem-H Interval out of range, skipping...\n");
      fprintf( stderr, " xstem-H interval: %d \n", \
	       currentscoreptr->Intervals[XSTEM_H] );
    }
    return (TEST_FAILED); 
  }
  currentscoreptr->IntervalScores[XSTEM_H] = scoreLength(H_XSTEM_intervalScores, SCORETABLESIZE, currentscoreptr->Intervals[XSTEM_H] );
  return (TEST_PASSED);
}

static void  copyPointers(HIT_SCORE *currentscoreptr, HIT_SCORE *scoreptr ) {
  scoreptr->Positions[ACA] = currentscoreptr->Positions[ACA];
  scoreptr->Positions[H] = currentscoreptr->Positions[H];
  scoreptr->Positions[XSTEM2] = currentscoreptr->Positions[XSTEM2];
  scoreptr->Positions[ISTEM2] = currentscoreptr->Positions[ISTEM2];
  scoreptr->PositionsRight[XSTEM2] = currentscoreptr->PositionsRight[XSTEM2];
  scoreptr->PositionsRight[ISTEM2] = currentscoreptr->PositionsRight[ISTEM2];
  scoreptr->Lengths[XSTEM2] = currentscoreptr->Lengths[XSTEM2];
  scoreptr->Lengths[ISTEM2] = currentscoreptr->Lengths[ISTEM2];
  scoreptr->Scores[ACA] = currentscoreptr->Scores[ACA];
  scoreptr->Scores[H] = currentscoreptr->Scores[H];
  scoreptr->Scores[XSTEM2] = currentscoreptr->Scores[XSTEM2];
  scoreptr->Scores[ISTEM2] = currentscoreptr->Scores[ISTEM2];
  scoreptr->Intervals[XSTEM_H] = currentscoreptr->Intervals[XSTEM_H];
  scoreptr->Intervals[stem2gap] = currentscoreptr->Intervals[stem2gap];
  scoreptr->Intervals[HACA_ISTEM2R] = currentscoreptr->Intervals[HACA_ISTEM2R];
  scoreptr->IntervalScores[XSTEM_H] = currentscoreptr->IntervalScores[XSTEM_H]; 
  scoreptr->IntervalScores[stem2gap] = currentscoreptr->IntervalScores[stem2gap];    
  scoreptr->IntervalScores[HACA_ISTEM2R] =  currentscoreptr->IntervalScores[HACA_ISTEM2R];

  if ( currentscoreptr->Positions[POST_ACA] != 0 ) {  
    scoreptr->Positions[POST_ACA] = currentscoreptr->Positions[POST_ACA];
    scoreptr->Scores[POST_ACA] = currentscoreptr->Scores[POST_ACA];
  }

}
 
static void  copyPatterns( HIT_SCORE *scoreptr) {
  strncpy(scoreptr->Patterns[ACA], scoreptr->Positions[ACA], HACALENGTH);  
  *(scoreptr->Patterns[ACA] + HACALENGTH) = '\0'; 
  strncpy(scoreptr->Patterns[H], scoreptr->Positions[H], HACALENGTH);  
  *(scoreptr->Patterns[H] + HACALENGTH) = '\0'; 
  storeStemPatterns(scoreptr, scoreptr->Positions[XSTEM2], scoreptr->PositionsRight[XSTEM2], scoreptr->Lengths[XSTEM2], XSTEM2) ;
  storeStemPatterns(scoreptr, scoreptr->Positions[ISTEM2], scoreptr->PositionsRight[ISTEM2], scoreptr->Lengths[ISTEM2], ISTEM2) ;
  if ( scoreptr->Positions[POST_ACA] != 0 ) {  
    strncpy(scoreptr->Patterns[POST_ACA], scoreptr->Positions[POST_ACA] , POST_ACALENGTH);  
    *(scoreptr->Patterns[POST_ACA] + POST_ACALENGTH) = '\0';
  } else {
    *(scoreptr->Patterns[POST_ACA]) = '\0'; 
  }
}

static void  scoreHACA2(HIT_SCORE *scoreptr, char *HACA2_position, int currentlySearching) {
  if ( currentlySearching == DOWNSTREAM ) {
    scoreptr->Positions[ACA] = HACA2_position;	
    scoreHACAmotif(scoreptr, 'C'); 
    scoreptr->Positions[H] = scoreptr->Positions[HACA];
    scoreptr->Scores[H] = scoreptr->H1Score;
    scoreptr->Scores[HACA] = scoreptr->H1Score; /* Need value to subtract - so as not to double count */
  } else {                                              /* We're currently searching upstream */
    scoreptr->Positions[H] = HACA2_position;	
    scoreHACAmotif(scoreptr, 'H'); 
    scoreptr->Positions[ACA] = scoreptr->Positions[HACA];
    scoreptr->Scores[ACA] = scoreptr->ACA1Score;
    scoreptr->Scores[HACA] = scoreptr->ACA1Score; /* Need value to subtract - so as not to double count */ 
  }
}

static void  initCurrentScorePtr(HIT_SCORE *currentscoreptr, HIT_SCORE *scoreptr ) {
  memset(currentscoreptr, 0, sizeof(HIT_SCORE));  /* initialization needed */
  currentscoreptr->Positions[HACA] = scoreptr->Positions[HACA];
  currentscoreptr->Positions[XSTEM] = scoreptr->Positions[XSTEM];
  currentscoreptr->H1Score = scoreptr->H1Score;
  currentscoreptr->ACA1Score = scoreptr->ACA1Score;
}

static void storeStemPatterns(HIT_SCORE *scoreptr, char *bestLeftStartPos, char *bestRightStartPos, int stemLength, int feature) {
  char reverseRightStem[PATTERNMAX];  /* temporary storage for reversed right stem */
 
  Reverse(bestRightStartPos , reverseRightStem, stemLength); /* reverse right stem */
  scoreptr->Patterns[feature] =  strncpy(scoreptr->Patterns[feature], bestLeftStartPos, stemLength ); 
  *(scoreptr->Patterns[feature] + stemLength) = '\0';
  scoreptr->PatternsRight[feature] = strncpy(scoreptr->PatternsRight[feature], reverseRightStem, stemLength ); 
  *(scoreptr->PatternsRight[feature] + stemLength) = '\0';
  return; 
}
#if 0
static void outputHitStem2(HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Output score and other data for hit */
  int start, end, length; 
  int  genomeStartPosition, genomeEndPosition; 

  start = scoreptr->Positions[XSTEM2] - rundataptr->querySeq;
  if ( scoreptr->Positions[XSTEM2] > scoreptr->Positions[XSTEM] ) { /* Stem 2 is ACA stem */
    end =   scoreptr->Positions[ACA] + HACALENGTH -1  - rundataptr->querySeq;
  } else {                       /* Stem 2 is H stem */
    end =   scoreptr->Positions[H] + HACALENGTH - 1 - rundataptr->querySeq;  
  }  
  length = end - start + 1;
 

  /* convert to RNA for output */
  ToRNA(scoreptr->Patterns[ISTEM2]);
  ToRNA(scoreptr->Patterns[XSTEM2]);
  ToRNA(scoreptr->PatternsRight[ISTEM2]);
  ToRNA(scoreptr->PatternsRight[XSTEM2]);
  ToRNA(scoreptr->Patterns[ACA]);
  ToRNA(scoreptr->Patterns[H]);
  
    /* Computation of actual position of hit on genome is different for W and C strands */
  if (rundataptr->strand == 'W' ) {
    genomeStartPosition = rundataptr->segmentOffset + start;
    genomeEndPosition =  rundataptr->segmentOffset + end;
  } else {
    genomeStartPosition = rundataptr->segmentOffset - end ;
    genomeEndPosition =  rundataptr->segmentOffset - start;
  }

  printf("#    H: %s\t (%d) Sc: %.2f\t Stem1-Score: %.2f\t Stem2 Gap Len: %d\t Sc: %.2f\n", \
	 scoreptr->Patterns[H], convertToGenomicPos(scoreptr->Positions[H], rundataptr) , \
	 scoreptr->Scores[H],  scoreptr->totalScoreStem1, scoreptr->Intervals[stem2gap], scoreptr->IntervalScores[stem2gap] );
  printf("#  ACA: %s\t (%d) Sc: %.2f\t HACA2-ISTEM2Rend Int: %d\t Sc: %.2f\n", \
	 scoreptr->Patterns[ACA], convertToGenomicPos(scoreptr->Positions[ACA], rundataptr) , scoreptr->Scores[ACA], \
	 scoreptr->Intervals[HACA_ISTEM2R], scoreptr->IntervalScores[HACA_ISTEM2R]);

  printf("#  \n# IntStem2 Sc: %.2f (%d,%d)\t ExtStem2 Sc: %.2f (%d,%d)\n", \
	 scoreptr->Scores[ISTEM2], convertToGenomicPos(scoreptr->Positions[ISTEM2], rundataptr) , \
	 convertToGenomicPos(scoreptr->PositionsRight[ISTEM2], rundataptr) , \
	 scoreptr->Scores[XSTEM2], convertToGenomicPos(scoreptr->Positions[XSTEM2], rundataptr) , \
	 convertToGenomicPos(scoreptr->PositionsRight[XSTEM2], rundataptr) );

  printf("# IntStem2: 5'%s--+\\ \t ExtStem2: 5'%s\n", \
	 scoreptr->Patterns[ISTEM2], scoreptr->Patterns[XSTEM2]);
  printf("#             %s--+/  \t ExtStem2: 3'%s \n", \
	 scoreptr->PatternsRight[ISTEM2], scoreptr->PatternsRight[XSTEM2]);


  printf("#stem2 seq\n");  outputSeq(scoreptr->Positions[XSTEM2], length);
  /*  printf("#\n%s\n", querytemp); */
  drawStructureStem2(scoreptr) ;
}
#endif
