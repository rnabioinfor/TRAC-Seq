/* target.c
 *
 */

#include <stdio.h>
#include <string.h>
#include <assert.h>
#if 0
#include "target.h"
#include "rundata.h"
#include "test.h"
#endif
#include "target_rundata.h"
#include "squid.h"
#include "sqfuncs.h"    /* needed for revcomp.c & sqio.c */
#include "score_and_test.h"
#include "pseudoU_test.h"
#include "pseudoU_test_funcs.h"

/* Prototypes of private functions and constants*/
static char *createLeftMinSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement);
static char *createRightMinSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement);
static char *createLeftMaxSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement);
static char *createRightMaxSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement);
static char *createLeftSeq(TARGET *targetptr, RUNDATA *rundataptr, int minOrMax, int complement);
static char *createRightSeq(TARGET *targetptr, RUNDATA *rundataptr, int minOrMax, int complement);

#if 0
static char *targetAsString[TARGETNUM] = {
  "TEST_TARGET", 
  "SSU_106" };
#endif

/* Public functions */


TARGET *newTarget(FILE  *descfp, RUNDATA *rundataptr) {
  /* Create a new TARGET structure.  */
  int      linenumber;     /*  line number in descriptor file for debug */
  char     buffer[MAXLN];       /* storage for the current line */
  char string1[MAXTARGETLEN];           /* temp buffer 1 */
  char string2[MAXLN];                /* temp buffer 2 */
  char pseudoU_char;  
  int position;
  int status;			/* did getline find anything? */
  TARGET *targetptr;
  targetptr = DEBUGMALLOC(1, sizeof(TARGET));

  status = getline(buffer, descfp, &linenumber, FALSE) ; /* read the next TARGET descriptor */
  assert( status != 0); 
  sscanf(buffer, "%s %s %d",  string1, string2, &position);
  targetptr->targetPosition = position;
  targetptr->targetName = strdup(string1);
  targetptr->snoAssign = strdup(string2);
  getline(buffer, descfp, &linenumber, TRUE) ; /* read the next TARGET sequence */
  sscanf(buffer, "%s",  string1);
  ToDNA(string1);
  pseudoU_char =  *(string1 + position); 
  assert( pseudoU_char  == 'Y' ) ; /* pseudoU location */
  targetptr->targetSeq = strdup(string1);
  targetptr->leftTargetLength = position;
  targetptr->rightTargetLength = strlen(targetptr->targetSeq) - (position+1);
  targetptr->leftComplMinSeq = createLeftMinSeq(targetptr, rundataptr, TRUE);
  targetptr->rightComplMinSeq = createRightMinSeq(targetptr, rundataptr, TRUE);
  targetptr->leftComplMaxSeq = createLeftMaxSeq(targetptr, rundataptr, TRUE);
  targetptr->rightComplMaxSeq = createRightMaxSeq(targetptr, rundataptr, TRUE);
  targetptr->leftMinSeq = createLeftMinSeq(targetptr, rundataptr, FALSE);
  targetptr->rightMinSeq = createRightMinSeq(targetptr, rundataptr, FALSE);
  targetptr->leftMaxSeq = createLeftMaxSeq(targetptr, rundataptr, FALSE);
  targetptr->rightMaxSeq = createRightMaxSeq(targetptr, rundataptr, FALSE);

  return(targetptr);
}

void freeTarget(TARGET *targetptr) {
/* Free up TARGET structure.  */
  if (targetptr == NULL) return;
  DEBUGFREE(targetptr->targetName, \
  (strlen(targetptr->targetName) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->snoAssign, \
  (strlen(targetptr->snoAssign) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->targetSeq, \
  (strlen(targetptr->targetSeq) +1) * sizeof (char)) ;

   DEBUGFREE(targetptr->leftComplMinSeq, \
  (strlen(targetptr->leftComplMinSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->rightComplMinSeq, \
  (strlen(targetptr->rightComplMinSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->leftComplMaxSeq, \
  (strlen(targetptr->leftComplMaxSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->rightComplMaxSeq, \
  (strlen(targetptr->rightComplMaxSeq) +1) * sizeof (char)) ;

  DEBUGFREE(targetptr->leftMinSeq, \
  (strlen(targetptr->leftMinSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->rightMinSeq, \
  (strlen(targetptr->rightMinSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->leftMaxSeq, \
  (strlen(targetptr->leftMaxSeq) +1) * sizeof (char)) ;
  DEBUGFREE(targetptr->rightMaxSeq, \
  (strlen(targetptr->rightMaxSeq) +1) * sizeof (char)) ;
/* Free entire 'target' last */
  DEBUGFREE(targetptr, sizeof(TARGET)) ;
}

char *targetName(TARGET *targetptr)  {
/* Get pointer to string decsription of target (eg SSU_106) */
  return ( targetptr->targetName );
}

char *leftComplMinSeq(TARGET *targetptr) {
/* Get pointer to minimum left complement pattern */
  return (targetptr->leftComplMinSeq);
}

char *rightComplMinSeq(TARGET *targetptr) {
  /* Get pointer to minimum right complement pattern */
  return (targetptr->rightComplMinSeq);
}

char *leftComplMaxSeq(TARGET *targetptr) {
/* Get pointer to maximim left complement pattern */
  return (targetptr->leftComplMaxSeq);
}

char *rightComplMaxSeq(TARGET *targetptr) {
/* Get pointer to maximim right complement pattern */
  return (targetptr->rightComplMaxSeq);
}

char *leftMinSeq(TARGET *targetptr) {
/* Get pointer to minimum left complement pattern */
  return (targetptr->leftMinSeq);
}

char *rightMinSeq(TARGET *targetptr) {
  /* Get pointer to minimum right complement pattern */
  return (targetptr->rightMinSeq);
}

char *leftMaxSeq(TARGET *targetptr) {
/* Get pointer to maximim left complement pattern */
  return (targetptr->leftMaxSeq);
}

char *rightMaxSeq(TARGET *targetptr) {
/* Get pointer to maximim right complement pattern */
  return (targetptr->rightMaxSeq);
}



/************* private functions ****************/

static char *createLeftMinSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement) {

/* get target left side sequence  and reverse complement */
 char *pattern;
 int min = MINflag;
 pattern = createLeftSeq(targetptr, rundataptr, min, complement);
 return pattern;
}

static char *createLeftMaxSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement) {

/* get target left side sequence  and reverse complement */
 char *pattern;
 int max = MAXflag;
 pattern = createLeftSeq(targetptr, rundataptr, max, complement);
 return pattern;
}

static char *createLeftSeq(TARGET *targetptr, RUNDATA *rundataptr, int minOrMax, int complement) {
  /* get target left side sequence  and reverse complement */
  char *pattern;
  char temp[PATTERNMAX];
  int patternlength;
  int start;
  assert((minOrMax == MINflag) || (minOrMax == MAXflag ) );

  /* Note: the left-compl matches the **RIGHT** target seq!! */
  if (minOrMax == MINflag) {
    assert(rundataptr->targetRightMin <= targetptr->rightTargetLength);
    patternlength = rundataptr->targetRightMin;
  }
  if (minOrMax == MAXflag) {
 /* Need to subtract 1 from max target length because of offset in start variable
  * below.  (This should be done better) */
    patternlength = MIN(rundataptr->targetRightMax, (targetptr->rightTargetLength - 1) ) ;
#if 0
    patternlength = MIN(rundataptr->targetRightMax, targetptr->rightTargetLength) ;
#endif
  }

  start = targetptr->targetPosition +2 ;  /* hardcoded for now */
  pattern = DEBUGMALLOC((patternlength + 1) , sizeof(char));
  SubStr(targetptr->targetSeq, start, patternlength, temp); /* answer is in temp */
  assert(strlen(temp) == patternlength); /* sanity check */
  if ( complement == TRUE) { 
    pattern = revcomp(pattern, temp);
  } else {  /* reverse only (note different order of arguments! */
    pattern = Reverse(temp, pattern, patternlength);
  }
  return pattern;
}

static char *createRightMinSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement){
/* get target right side sequence  and reverse complement */
 char *pattern;
 int min = MINflag;
 pattern = createRightSeq(targetptr, rundataptr, min, complement);
  return pattern;
} 
static char *createRightSeq(TARGET *targetptr, RUNDATA *rundataptr, int minOrMax, int complement){
  /* get target right side sequence  and reverse complement */
  char *pattern;
  int patternlength;
  char temp[PATTERNMAX];
  int start;
  assert((minOrMax == MINflag) || (minOrMax == MAXflag) );

/* Note: the right-compl matches the **LEFT** target seq!! */
  if (minOrMax == MINflag) {
    assert(rundataptr->targetLeftMin <= targetptr->leftTargetLength);
    patternlength = rundataptr->targetLeftMin;
  }
  if (minOrMax == MAXflag) {
    patternlength = MIN(rundataptr->targetLeftMax, targetptr->leftTargetLength) ;
  }

  start = targetptr->targetPosition -  patternlength;  /* hardcoded for now */
  pattern = DEBUGMALLOC((patternlength + 1) , sizeof(char));
  SubStr(targetptr->targetSeq, start, patternlength, temp); /* answer is in temp */
  assert(strlen(temp) == patternlength); /* sanity check */
  pattern = revcomp(pattern, temp);
  if ( complement == TRUE) { 
    pattern = revcomp(pattern, temp);
  } else {  /* reverse only (note different order of arguments! */
    pattern = Reverse(temp, pattern, patternlength);
  }
  return pattern;
}

static char *createRightMaxSeq(TARGET *targetptr, RUNDATA *rundataptr, int complement) {

/* get target left side sequence  and reverse complement */
 char *pattern;
 int max = MAXflag;
 pattern = createRightSeq(targetptr, rundataptr, max, complement);
 return pattern;
}
