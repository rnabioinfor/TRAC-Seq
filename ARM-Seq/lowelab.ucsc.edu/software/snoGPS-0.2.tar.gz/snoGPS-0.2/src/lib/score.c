/* score.c
 *
 */

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "score_and_test.h"
#include "pseudoU_test_funcs.h"
#include "pseudoU_test.h"
#include "squid.h"

/* global variable used */
extern int DEBUG_LEVEL;

/* Prototypes of private functions and constants*/

static int extendHit( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		      int *mismatch, int complement, int direction1, int direction2, int GU_flag) ;
static void drawStructure(HIT_SCORE *scoreptr) ;
static void loadLengthScores(FILE *fp, SCORE_LENGTH *lengthDistPtr);
static void loadPairScores(FILE *fp, double (*pairScoresPtr)[4]);
static void loadSingleBaseScores(FILE *fp, double positionScores[]);
static void outputCandidateFasta(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
static void outputSeq(char *seqStartPtr, int length) ;
static void drawStructureStem2(HIT_SCORE *scoreptr) ;

static double ACAPosition2Scores[4] = {};
static double ACAPosition4Scores[4] = {};
static double ACAPosition5Scores[4] = {};
static double ACAPosition6Scores[4] = {};
static double HPosition2Scores[4] = {};
static double HPosition4Scores[4] = {};
static double HPosition5Scores[4] = {};
static double HPosition6Scores[4] = {}; 
  
/* Public functions and constants */

SCORE_LENGTH  gapScores[SCORETABLESIZE] = {};
SCORE_LENGTH  complLengthScores[SCORETABLESIZE] = {};
SCORE_LENGTH  iStemLengthScores[SCORETABLESIZE] = {};
SCORE_LENGTH  IStemStartScores[SCORETABLESIZE] = {};
SCORE_LENGTH  xStemLengthScores[SCORETABLESIZE] = {};
SCORE_LENGTH  XStemStartScores[SCORETABLESIZE] = {};
SCORE_LENGTH  rComplHACAIntervalScores[SCORETABLESIZE] = {};
SCORE_LENGTH  H_XSTEM_intervalScores[SCORETABLESIZE] = {};
SCORE_LENGTH  HACA_ISTEM2R_intervalScores[SCORETABLESIZE] = {};
SCORE_LENGTH  POST_ACA_freqScores[SCORETABLESIZE] = {}; /* Not lengths but same data format */

double complScores[4][4] = {};
double (*complScoresPtr)[4] = complScores;
double IstemScores[4][4] = {};
double (*IstemScoresPtr)[4] = IstemScores;
double XstemScores[4][4] = {};
double (*XstemScoresPtr)[4] = XstemScores;


char *nucAlpha = "ACGT";
char *nucAlphaCompl = "TGCA";

void storeRelativePositions(HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  int feature;
  
  rundataptr->candidate_number++; /* increment found candidates */

 if  (rundataptr->mode == TWO_STEM) { 
     assert (scoreptr->H_or_ACA == 'H' || scoreptr->H_or_ACA == 'C');
     if (scoreptr->H_or_ACA == 'H' ) {
       rundataptr->startingFeature = XSTEM;
     } else {
       rundataptr->startingFeature = XSTEM2;  
     }
 }    
  /* also store relative positions of sequence features */

  /* Computation of  is different for W and C strands */
  /* also retrieve sequence start and end positions */
  scoreptr->startpos = scoreptr->Positions[XSTEM];
  scoreptr->endpos =  scoreptr->Positions[HACA]  + HACALENGTH - 1; 
  for ( feature = 1; feature <= CURRENTFEATUREMAX; feature++) {
    scoreptr->RelativePositions[feature] = scoreptr->Positions[feature] - rundataptr->querySeq;
    scoreptr->RelativePositionsRight[feature] = scoreptr->PositionsRight[feature] - rundataptr->querySeq;
    scoreptr->LocalPositions[feature] = scoreptr->Positions[feature] - scoreptr->Positions[rundataptr->startingFeature] + 1;
    scoreptr->LocalPositionsRight[feature] = \
                        scoreptr->PositionsRight[feature] - scoreptr->Positions[rundataptr->startingFeature] + 1;
  }  
}

static void outputSeq(char *seqStartPtr, int length) { 
  char querytemp[MAXLN];
  assert(length < MAXLN);
  strncpy(querytemp, seqStartPtr , length);
  *(querytemp+length) = '\0';	/* make querytemp into a proper C string */
  ToRNA(querytemp);		/* to prettify output */
  printf("%s\n", querytemp);
}

static void outputCandidateFasta(HIT_SCORE *scoreptr, RUNDATA *rundataptr) { 
  char seqtemp[MAXLN];
  int length;
  length = scoreptr->length;
  if (scoreptr->length > MAXLN) {
    fprintf( stderr, " Warning: sequence for candidate number %dtoo long for buffer. Truncating... \n", rundataptr-> candidate_number);
    length = MAXLN -1;
  }
  strncpy(seqtemp, scoreptr->Positions[rundataptr->startingFeature], length);
  *(seqtemp + scoreptr->length) = '\0';	/* make seqtemp into a proper C string */
  fprintf(rundataptr->fastaOutFilePtr, ">%s.%d\t %.2f\t (%d-%d)\t Cmpl: %s \t %s\tPairs: %d/%d/%d/%d/%c \t %d bp (%c)\n",  \
	  rundataptr->sqinfo.name, rundataptr->candidate_number, scoreptr->totalScore, \
	  scoreptr->genomeStartPosition, scoreptr->genomeEndPosition, \
	  rundataptr->currentTarget->targetName, rundataptr->currentTarget->snoAssign, \
	  scoreptr->Pairs[RCompl], scoreptr->Pairs[LCompl], scoreptr->Pairs[ISTEM], \
	  scoreptr->Pairs[XSTEM], scoreptr->H_or_ACA, scoreptr->length, rundataptr->strand);
  fprintf(rundataptr->fastaOutFilePtr, "%s\n", seqtemp);  
  printf("%s\n", seqtemp);	/* added 12/11/02 to create fasta file within result file */
}


int outputHit(HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Output score and other data for hit */
  int start, end, targetLength, maxLength, displayLength, totalPairs, totalMisMatches;
  int stem1start, stem1end,  stem1length;
  char *startpos, *endpos;
  char *stem1startpos, *stem1endpos;
  /*  char querytemp[MAXLN]; */
  char maxTarget[PATTERNMAX];  /* temporary storage for full pattern of target seq */
  char hitTargetL[PATTERNMAX];  /* temporary storage for matched pattern of target seq */
  char hitTargetR[PATTERNMAX];  /* temporary storage for matched pattern of target seq */
  char *Left_RComplptr;  
  char *Right_RComplptr;  
      
  storeRelativePositions(scoreptr, rundataptr) ; 
  stem1startpos = scoreptr->Positions[XSTEM];
  stem1endpos = scoreptr->Positions[HACA] + HACALENGTH -1;
  stem1start = stem1startpos - rundataptr->querySeq;
  stem1end = stem1endpos - rundataptr->querySeq;
  stem1length = stem1end - stem1start + 1; 
  totalPairs = scoreptr->Pairs[RCompl] + scoreptr->Pairs[LCompl];
  totalMisMatches = scoreptr->MisMatches[RCompl] + scoreptr->MisMatches[LCompl];

  /* if only scoring single stem, single-stem-score is total score */
  if (scoreptr->totalScore == 0) {/* Single stem only */
    scoreptr->totalScore = scoreptr->totalScoreStem1;
    startpos = stem1startpos;
    endpos = stem1endpos;
  } else {    /* Double stem or single stem plus leading 'H' */
    endpos = scoreptr->Positions[ACA] + HACALENGTH -1;     
    if ( scoreptr->Positions[XSTEM2] == 0) { /* single stem plus 'H' only mode */
      startpos = stem1startpos ;
    } else {
      startpos = MIN(scoreptr->Positions[XSTEM], scoreptr->Positions[XSTEM2]);
    }
  }
    start = startpos - rundataptr->querySeq;
    end =  endpos - rundataptr->querySeq;
    scoreptr->length = end - start + 1; 

  /* Computation of actual position of hit on genome is different for W and C strands */
  if (rundataptr->strand == 'W' ) {
    scoreptr->genomeStartPosition = rundataptr->segmentOffset + start;
    scoreptr->genomeEndPosition =  rundataptr->segmentOffset + end;
  } else {
    scoreptr->genomeStartPosition = rundataptr->segmentOffset - end ;
    scoreptr->genomeEndPosition =  rundataptr->segmentOffset - start;
  }
  targetLength = scoreptr->Lengths[RCompl];
  Right_RComplptr = rundataptr->currentTarget->rightComplMaxSeq;
  Complement( maxTarget , Right_RComplptr);  /* uncomplement revcomped target */
  SubStr(maxTarget, 0, targetLength, hitTargetR);

  targetLength = scoreptr->Lengths[LCompl];
  Left_RComplptr = rundataptr->currentTarget->leftComplMaxSeq;
  maxLength = strlen(Left_RComplptr);
  Complement( maxTarget , Left_RComplptr);  /* uncomplement revcomped target */
  SubStr(maxTarget, maxLength - targetLength, targetLength, hitTargetL);

  /* convert to RNA for output */
  ToRNA(hitTargetR);
  ToRNA(hitTargetL);
  ToRNA(scoreptr->Patterns[LCompl]);
  ToRNA(scoreptr->Patterns[RCompl]);
  ToRNA(scoreptr->Patterns[ISTEM]);
  ToRNA(scoreptr->Patterns[XSTEM]);
  ToRNA(scoreptr->PatternsRight[ISTEM]);
  ToRNA(scoreptr->PatternsRight[XSTEM]);
  ToRNA(scoreptr->Patterns[HACA]);
  if ( scoreptr->IntervalScores[XSTEM_H] !=0 ) {
    ToRNA(scoreptr->Patterns[H]);
  }



  printf(">%s.%d\t %.2f\t (%d-%d)\t Cmpl: %s \t %s\tPairs: %d/%d/%d/%d/%c \t %d bp (%c)\n",  \
	 rundataptr->sqinfo.name, rundataptr->candidate_number, scoreptr->totalScore, \
	 scoreptr->genomeStartPosition, scoreptr->genomeEndPosition, \
	 rundataptr->currentTarget->targetName, rundataptr->currentTarget->snoAssign, \
	 totalPairs, totalMisMatches, scoreptr->Pairs[ISTEM], \
	 scoreptr->Pairs[XSTEM], scoreptr->H_or_ACA, scoreptr->length, rundataptr->strand);

  outputCandidateFasta(scoreptr, rundataptr); /* Added 12/11/02 to create 'fasta like' file embedded in result */

  printf("#  Gap Len: %d\t Sc: %.2f\t Compl Len Sc: %.2f \t IntStem Len Sc: %.2f \t IntStem St Sc: %.2f \n", \
	 scoreptr->Intervals[stem1gap], scoreptr->IntervalScores[stem1gap], scoreptr->IntervalScores[Compl1Length], \
	 scoreptr->IntervalScores[ISTEM1Length], scoreptr->IntervalScores[ISTEM1Start]);

  printf("#  IntStem Dither: %d\t Sc: 0.00 ExtStem Dither: %d\t Sc: %.2f\t HACA-RCstart Int: %d\t Sc: %.2f \n", \
	 scoreptr->Dithers[ISTEM], scoreptr->Dithers[XSTEM], scoreptr->IntervalScores[XSTEMOffset], \
	 scoreptr->Intervals[HACA_RCompl], scoreptr->IntervalScores[HACA_RCompl]) ;
  assert (scoreptr->H_or_ACA == 'C' || scoreptr->H_or_ACA == 'H' || \
  scoreptr->H_or_ACA == 'c' || scoreptr->H_or_ACA == 'h'); /* debug check */
    printf("# HACA: %s\t (%d) Sc: %.2f\n", \
	   scoreptr->Patterns[HACA], scoreptr->LocalPositions[HACA] , scoreptr->Scores[HACA]);
  if ( scoreptr->IntervalScores[XSTEM_H] !=0 ) {
    printf("#    H: %s\t (%d) Sc: %.2f\t", \
	   scoreptr->Patterns[H], scoreptr->LocalPositions[H], scoreptr->Scores[H]);
    printf(" XSTEM2-H Int: %d\t Sc: %.2f\n", \
	   scoreptr->Intervals[XSTEM_H], scoreptr->IntervalScores[XSTEM_H]);
  }
  printf("#   HACA-ISTEMRend Int: %d  \t", \
	(scoreptr->Positions[HACA] - scoreptr->PositionsRight[ISTEM]) - scoreptr->Lengths[ISTEM] );

  if ( scoreptr->Scores[POST_ACA] !=0 ) {
     strncpy(scoreptr->Patterns[POST_ACA], scoreptr->Positions[POST_ACA] , POST_ACALENGTH);  
    *(scoreptr->Patterns[POST_ACA] + POST_ACALENGTH) = '\0'; 
    printf(" POST_ACA: %s\t Sc: %.2f\n",  scoreptr->Patterns[POST_ACA], scoreptr->Scores[POST_ACA] );
  } else {
    printf ("\n");
  }
	
  printf("#  \n#  LC Sc: %.2f (%d)\t RC Sc: %.2f (%d)\t IntStem Sc: %.2f (%d,%d)\t ExtStem Sc: %.2f (%d,%d)\n", \
	 scoreptr->Scores[LCompl], scoreptr->LocalPositions[LCompl], \
	 scoreptr->Scores[RCompl], scoreptr->LocalPositions[RCompl], \
	 scoreptr->Scores[ISTEM], scoreptr->LocalPositions[ISTEM], \
	 scoreptr->LocalPositionsRight[ISTEM] , \
	 scoreptr->Scores[XSTEM], scoreptr->LocalPositions[XSTEM] , \
	 scoreptr->LocalPositionsRight[XSTEM]);

  printf("#  LCompl: %s-3'\t RCompl: %s-3'\t IntStem: 5'%s--+\\ \t ExtStem: 5'%s \n", \
	 scoreptr->Patterns[LCompl], scoreptr->Patterns[RCompl], scoreptr->Patterns[ISTEM], scoreptr->Patterns[XSTEM]);
  printf("#    rRNA: %s-5'\t       : %s-5'\t            %s--+/ \t ExtStem: 3'%s \n", \
	 hitTargetL, hitTargetR, scoreptr->PatternsRight[ISTEM], scoreptr->PatternsRight[XSTEM]);

  if (DEBUG_LEVEL >= 1) {
    displayLength = MIN(stem1start, MAXDISPLAYLENGTH);
    printf("#upstream seq \n");  outputSeq(stem1startpos - displayLength , displayLength );
    displayLength = MIN(strlen(scoreptr->endpos), MAXDISPLAYLENGTH);
    printf("#downstream seq \n");  outputSeq(stem1endpos + 1 , displayLength);
  }
  printf("#stem1 seq\n");  outputSeq(stem1startpos, stem1length);
  /*  printf("#\n%s\n", querytemp); */
  drawStructure(scoreptr) ;
  return (TEST_PASSED); 
}

void scoreHACAmotif(HIT_SCORE *scoreptr, char mode) {
  double ACAScore, HScore;
  int position, feature;
  
  switch ( mode) {
  case 'C':
    feature = ACA; break;
  case 'H':  
    feature = H; break;
  case 'B':  
    feature = HACA; break;
  default:
    assert (0);  
  }
  /* Get profile scores for positions'2', '4' , '5' and '6'  of ACA and H patterns */
  position = 2;
  ACAScore = scoreSingleBase(ACAPosition2Scores, scoreptr->Positions[feature], position);
  HScore = scoreSingleBase(HPosition2Scores, scoreptr->Positions[feature], position);
  position = 4;
  ACAScore += scoreSingleBase(ACAPosition4Scores, scoreptr->Positions[feature], position);
  HScore += scoreSingleBase(HPosition4Scores, scoreptr->Positions[feature], position);
  position = 5;
  ACAScore += scoreSingleBase(ACAPosition5Scores, scoreptr->Positions[feature], position);
  HScore += scoreSingleBase(HPosition5Scores, scoreptr->Positions[feature], position);
  position = 6;
  ACAScore += scoreSingleBase(ACAPosition6Scores, scoreptr->Positions[feature], position);
  HScore += scoreSingleBase(HPosition6Scores, scoreptr->Positions[feature], position);

  if ( mode == 'C' ) {
    scoreptr->Scores[ACA] =  ACAScore;
    return;
  }
  if ( mode == 'H' ) {
    scoreptr->Scores[H] =  HScore;
    return;
  }
  /* 'B' mode, store both H and ACA scores */      
    scoreptr->ACA1Score =  ACAScore;
    scoreptr->H1Score =  HScore;
}


static void drawStructureStem2(HIT_SCORE *scoreptr) {
  /* Display structure.  Current implementation does not include 
   * displaying H-ACA motif explicitly */
  int currentPosition;
  int i, skipLength ;
  
  for (i = 0; i < scoreptr->Lengths[XSTEM2]; i++) putchar( 'X' ); 
  currentPosition = scoreptr->RelativePositions[XSTEM2] + scoreptr->Lengths[XSTEM2];
  skipLength = scoreptr->RelativePositions[ISTEM2] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[ISTEM2]; i++) putchar( 'I' ); 
  currentPosition = scoreptr->RelativePositions[ISTEM2] + scoreptr->Lengths[ISTEM2];
  skipLength = scoreptr->RelativePositionsRight[ISTEM2] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[ISTEM2]; i++) putchar( 'I' ); 
  currentPosition = scoreptr->RelativePositionsRight[ISTEM2] + scoreptr->Lengths[ISTEM2];
  skipLength = scoreptr->RelativePositionsRight[XSTEM2] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[XSTEM2]; i++) putchar( 'X' ); 
  currentPosition = scoreptr->RelativePositionsRight[XSTEM2] + scoreptr->Lengths[XSTEM2];


  if ( scoreptr->Positions[XSTEM2] > scoreptr->Positions[XSTEM] ) { /* Stem 2 is ACA stem */
    skipLength = scoreptr->RelativePositions[ACA] - currentPosition;
    for (i = 0; i < skipLength; i++) putchar( ' ' );
    for (i = 0; i < HACALENGTH; i++) putchar( 'C' ); 
  } else { /* Stem 2 is H stem */
    skipLength = scoreptr->RelativePositions[H] - currentPosition;
    for (i = 0; i < skipLength; i++) putchar( ' ' );
    for (i = 0; i < HACALENGTH; i++) putchar( 'H' ); 
  }
  printf("\n\n");
}



void loadScoreTables(char *scoretablefile) {
  FILE *fp;

  /* Load Score Table values from file */
  if ((fp = fopen(scoretablefile, "r")) == NULL) {
    fprintf( stderr, "Failed to open score-table file %s for reading\n", scoretablefile);
    assert(0) ;
  }
  /* Load Length Scores for "Gap-length" */
  loadLengthScores(fp, gapScores);
  /* Load Length Scores for "Compl-region-length" */
  loadLengthScores(fp, complLengthScores);
  /* Load Length Scores for "IntStem-length") */
  loadLengthScores(fp, iStemLengthScores);
  /* Load Length Scores for "IntStem-Start-Position" */
  loadLengthScores(fp, IStemStartScores);
  /* Load Pair-frequency Scores for "Compl-region" */
  loadPairScores(fp, complScoresPtr);
  /* Load Pair-frequency Scores for "IntStem" */
  loadPairScores(fp, IstemScoresPtr);
  /* Load Length Scores for "ExtStem-length") */
  loadLengthScores(fp, xStemLengthScores);
  /* Load Length Scores for "ExtStem-Start-Position" */
  loadLengthScores(fp, XStemStartScores);
  /* Load Pair-frequency Scores for "ExtStem" */
  loadPairScores(fp, XstemScoresPtr);
  /* Load Single-Base-frequency Scores for "H Position 2" */
  loadSingleBaseScores(fp, HPosition2Scores);
  /* Load Single-Base-frequency Scores for "H Position 4" */
  loadSingleBaseScores(fp, HPosition4Scores);
  /* Load Single-Base-frequency Scores for "H Position 5" */
  loadSingleBaseScores(fp, HPosition5Scores);
  /* Load Single-Base-frequency Scores for "H Position 6" */
  loadSingleBaseScores(fp, HPosition6Scores);
  /* Load Single-Base-frequency Scores for "ACA Position 2" */
  loadSingleBaseScores(fp, ACAPosition2Scores);
  /* Load Single-Base-frequency Scores for "ACA Position 4" */
  loadSingleBaseScores(fp, ACAPosition4Scores);
  /* Load Single-Base-frequency Scores for "ACA Position 5" */
  loadSingleBaseScores(fp, ACAPosition5Scores);
  /* Load Single-Base-frequency Scores for "ACA Position 6" */
  loadSingleBaseScores(fp, ACAPosition6Scores);
  /* Load Length Scores for "RComp-HACA_Interval" */
  loadLengthScores(fp,rComplHACAIntervalScores );
  /* Load Length Scores for "HACA_ISTEM2R_interval" */
  loadLengthScores(fp, HACA_ISTEM2R_intervalScores );
  /* Load Length Scores for "H_XSTEM_Interval" */
  loadLengthScores(fp, H_XSTEM_intervalScores );
  /* Load U-frequency Scores for "POST_ACA_U_frequencies" */
  loadLengthScores(fp, POST_ACA_freqScores );

  fclose(fp);
}

int extendHitForward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		      int *mismatch, int complement, int GU_flag) {
  /* Extend hit from min length to max length.  Both extensions are in "plus" (5'->3')
 * direction.  *pairs and *mismatch return number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches. */
  int direction1 = +1;
  int direction2 = +1;
  int score;
  score = extendHit( seq1, seq2, minLen, maxLen, pairs, mismatch, complement, \
		     direction1, direction2, GU_flag);
  return score;
}
 
 
int extendHitBackward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		       int *mismatch, int complement, int GU_flag) {
  /* Extend hit from min length to max length.  Both extensions are in "minus" (3'->5')
 * direction.  */
  int direction1 = -1;
  int direction2 = -1;
  int score;
  score = extendHit( seq1, seq2, minLen, maxLen, pairs, mismatch, complement, \
		     direction1, direction2, GU_flag);
  return score;
}
 
int extendHitForwardBack( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
			  int *mismatch, int complement, int GU_flag) {
  int direction1 = +1;
  int direction2 = -1;
  int score;
  score = extendHit( seq1, seq2, minLen, maxLen, pairs, mismatch, complement, \
		     direction1, direction2, GU_flag);
  return score;
}
 
 
double scoreDuplex(double scoreMatrix[][4], char *seq1, char *seq2, int length, int already_complemented) {
#if 0
double scoreDuplex(double scoreMatrix[][4], char *seq1, char *seq2, int length, int complement) {
#endif
  /* Calculate score from score matrix. 
   * if already_complemented == FALSE, complement seq1 before scoring */

  double score = 0.0;
  int i;
  int index1;
  int index2;

  for ( i = 0; i < length; i++) {
    if (already_complemented == FALSE) {
#if 0
    if (complement == 0) {
#endif
      index1 = Index(nucAlphaCompl, *(seq1+i) );
    } else {
      index1 = Index(nucAlpha, *(seq1+i) );
    }
    index2 = Index(nucAlpha, *(seq2+i) );

    if (! ( index1 >= 0 && index2 >= 0 ) ) { /* debugging code */
      fprintf(stderr, " Char 1 = %c, char 2 = %c \n", *(seq1+i), *(seq2+i) );
      fprintf(stderr, " Rejecting sequence because of unknown base" );
      score += -10000; /* reject sequence with bad base  */
    } else {
      score += scoreMatrix[index1][index2];
    }
  }
  return score;
}

double scoreLength(SCORE_LENGTH lenDistr[], int matrixLength, int value) {
  /* Calculate score from length distribution structure.  */
  int i;

  for ( i = 0; i < matrixLength; i++) {
    if ( value <= lenDistr[i].value ) {
      return (lenDistr[i].score);  
    }
  }
  /* Should never reach here, except when using old scoretables in debugging mode  */
  fprintf(stderr, "Reached end of Score Length Matrix. Should never happen!\n");
  fprintf(stderr,"First entry of matrix is %d, its score is %f , current-value = %d \n", \
	  lenDistr[0].value,  lenDistr[i].score, value );
  if (DEBUG_LEVEL > 0) {
    return (lenDistr[matrixLength-1].score);
  }
  assert (0);  /* if not in debug this error is fatal */
}

double scoreSingleBase(double profileScores[], char *pattern, int position) {
  /* Calculate score from profile of single-base frequencies.  */
  char ch;
  int A=0; int C=1; int G=2; int T=3; /* define locally to be safe */
  
  position-- ; /* Arrays start at position zero. String patterns at position 1 */
  ch = pattern[position]; 
  switch (ch) {
  case 'A':
    return profileScores[A]; /* Don't need break, since we're returning anyway...*/
  case 'C':
    return profileScores[C]; 
  case 'G':
    return profileScores[G]; 
  case 'T':
    return profileScores[T];
  default:
#if 0
 /* Currently commented out (12/31/02) Should check what's happening later  */
    fprintf(stderr, "Unknown character %c found in Single base Profile Scoring. \n", ch );
    fprintf(stderr, "Rejecting sequence. \n");
#endif
    return -9999999;		/* return large negative number to reject candidate */
    ;
  }     
}


double scoreBaseFrequency(SCORE_LENGTH frequencyScores[], char *pattern, int patternLength, char ch) {
  /* Look up log odds score for finding the number occurrences of 'char'
   * in the 'pattern'  */

  int count=0; 
  int i;
  double result;
  
  for (i = 0; i < patternLength ; i++) {
    assert ( pattern[i] != 0 ); /* paranoia */
#if 0
  for (i = 0; pattern[i] != 0; i++) {
    assert (i < patternLength); /* paranoia */
#endif
    if (pattern[i] == ch) {
      count++;
    }
  }
  result = scoreLength( frequencyScores , SCORETABLESIZE, count);
  return (result);
}



/* Private functions*/

static void loadLengthScores(FILE *fp, SCORE_LENGTH *lengthDistPtr) {
  int      linenumber = 0;     /*  line number in descriptor file for debug */
  char     buffer[MAXLN];       /* storage for the current line */
  int row, status;
  int arraySize;
  char     name[MAXLN]; /* Name of ScoreTable; not currently used */


  SCORE_LENGTH *currentPtr;   /* ScoreLength Struct currently being loaded */

  status = getline(buffer, fp, &linenumber, TRUE) ; /* read the length of the table */
  assert ( status != 0);
  sscanf(buffer, "%s %d", name, &arraySize);
  for ( row = 0; row < arraySize; row++) {
    currentPtr = lengthDistPtr + row;
    getline(buffer, fp, &linenumber, TRUE) ; /* read each individual array line */
    sscanf(buffer, "%d %lf", &(currentPtr->value), &(currentPtr->score));
  }
}

static void loadPairScores(FILE *fp, double (*pairScoresPtr)[4]) {
  int      linenumber = 0;     /*  line number in descriptor file for debug */
  char     buffer[MAXLN];       /* storage for the current line */
  int row, index, status;
  double column[4];  

  for ( row = 0; row < 4;  row++) {
    status = getline(buffer, fp, &linenumber, TRUE) ; /* read the overall descriptor */
    assert ( status != 0);
    sscanf(buffer, "%lf %lf %lf %lf", \
	   &column[0], &column[1], &column[2], &column[3]);
    for (index = 0; index < 4; index++) {
      pairScoresPtr[row][index] = column[index];
    }
  }
}

static void loadSingleBaseScores(FILE *fp, double baseScores[]) {
  int      linenumber = 0;     /*  line number in descriptor file for debug */
  char     buffer[MAXLN];       /* storage for the current line */
  int status;

  status = getline(buffer, fp, &linenumber, TRUE) ; /* read the overall descriptor */
  assert ( status != 0);
  sscanf(buffer, "%lf %lf %lf %lf", \
	 &baseScores[0], &baseScores[1], &baseScores[2], &baseScores[3]);
}

/* Extend hit between two sequences.  Extending starts at "minLen" from sequence start
 * positions. match and mismatch number are returned via pointers. "Score" (pairs - mismatches)
 * returned directly.  if "direction1" = +1, extension is in 5'->3' (positive) direction for
 * sequence1.  Similarly for direction2. 
 * If "complement" = 0, seq1 is compared directly to seq2. 
 * If "complement" = 1, seq1 is compared to complement of seq2.  */
static int extendHit( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		      int *mismatch, int complement, int direction1, int direction2, int GU_flag) {
  int index;
  int index1;
  int index2;
  int current_score;
  int current_pairs = 0 ;  
  int current_mismatch = 0 ;
  int best_score = -100; 
  int best_pairs = 0 ;  
  int best_mismatch = 0 ;
  int result;
  
  assert( (direction1 == 1) || (direction1 == -1) );
  assert( (direction2 == 1) || (direction2 == -1) );
  assert( (complement == 1) || (complement == 0) );

  for (index = minLen; index < maxLen; index++) {
    index1 = index * direction1;
    index2 = index * direction2;
#if 0
    if (complement == 1) {
#endif
    if ((complement == 1) || GU_flag == GU_OK) {
      result = Paired(seq1+ index1, seq2 + index2) ; /*  use for stem extension */
    } else {
      result =  (*(seq1+ index1) == *( seq2 + index2) ); /* for target matching if GU's not OK*/
    }    
    /* so far wobble pairs are considered as good as WC pairs */
    if ((result == 1 ) || 	/* WC pair */  \
	(result == 2) ) {	/* wobble pair */
      current_pairs++ ;
    } else {
      current_mismatch++ ;
    }
    current_score = current_pairs - current_mismatch;
    if (current_score > best_score) {
      best_score = current_score;
      best_pairs = current_pairs;
      best_mismatch = current_mismatch ;
    }
  } /*  end for loop */
  *pairs = best_pairs;
  *mismatch = best_mismatch;
  return best_score;
}
      

static void drawStructure(HIT_SCORE *scoreptr) {
  /* Display structure.  Current implementation does not include 
   * displaying H-ACA motif explicitly */
  int currentPosition;
  int i, skipLength ;
  
  for (i = 0; i < scoreptr->Lengths[XSTEM]; i++) putchar( 'X' ); 
  currentPosition = scoreptr->RelativePositions[XSTEM] + scoreptr->Lengths[XSTEM];
  skipLength = scoreptr->RelativePositions[LCompl] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[LCompl]; i++) putchar( 'L' ); 
  currentPosition = scoreptr->RelativePositions[LCompl] + scoreptr->Lengths[LCompl];
  skipLength = scoreptr->RelativePositions[ISTEM] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[ISTEM]; i++) putchar( 'I' ); 
  currentPosition = scoreptr->RelativePositions[ISTEM] + scoreptr->Lengths[ISTEM];
  skipLength = scoreptr->RelativePositionsRight[ISTEM] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[ISTEM]; i++) putchar( 'I' ); 
  currentPosition = scoreptr->RelativePositionsRight[ISTEM] + scoreptr->Lengths[ISTEM];
  skipLength = scoreptr->RelativePositions[RCompl] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[RCompl]; i++) putchar( 'R' ); 
  currentPosition = scoreptr->RelativePositions[RCompl] + scoreptr->Lengths[RCompl];
  skipLength = scoreptr->RelativePositionsRight[XSTEM] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < scoreptr->Lengths[XSTEM]; i++) putchar( 'X' ); 
  currentPosition = scoreptr->RelativePositionsRight[XSTEM] + scoreptr->Lengths[XSTEM];
  skipLength = scoreptr->RelativePositions[HACA] - currentPosition;
  for (i = 0; i < skipLength; i++) putchar( ' ' );

  for (i = 0; i < HACALENGTH; i += 2) {
    putchar( 'H' ); 
    putchar( 'C' ); 
  }

  printf("\n\n");
}

void outputHitStem2(HIT_SCORE *scoreptr, RUNDATA *rundataptr) {
  /* Output score and other data for hit */

  int start, end, stem2length; 

#if 0
  int  genomeStartPosition, genomeEndPosition; 
#endif
  start = scoreptr->Positions[XSTEM2] - rundataptr->querySeq;
  if ( scoreptr->Positions[XSTEM2] > scoreptr->Positions[XSTEM] ) { /* Stem 2 is ACA stem */
    end =   scoreptr->Positions[ACA] + HACALENGTH -1  - rundataptr->querySeq;
  } else {                       /* Stem 2 is H stem */
    end =   scoreptr->Positions[H] + HACALENGTH - 1 - rundataptr->querySeq;  
  }  
  stem2length = end - start + 1;

 

  /* convert to RNA for output */
  ToRNA(scoreptr->Patterns[ISTEM2]);
  ToRNA(scoreptr->Patterns[XSTEM2]);
  ToRNA(scoreptr->PatternsRight[ISTEM2]);
  ToRNA(scoreptr->PatternsRight[XSTEM2]);
  ToRNA(scoreptr->Patterns[ACA]);
  ToRNA(scoreptr->Patterns[H]);

  printf("#    H: %s\t (%d) Sc: %.2f\t Stem1-Score: %.2f\t Stem2 Gap Len: %d\t Sc: %.2f\n", \
	 scoreptr->Patterns[H], scoreptr->LocalPositions[H] , \
	 scoreptr->Scores[H],  scoreptr->totalScoreStem1, scoreptr->Intervals[stem2gap], scoreptr->IntervalScores[stem2gap] );
  printf("#  ACA: %s\t (%d) Sc: %.2f\t HACA2-ISTEM2Rend Int: %d\t Sc: %.2f\n", \
	 scoreptr->Patterns[ACA], scoreptr->LocalPositions[ACA] , scoreptr->Scores[ACA], \
	 scoreptr->Intervals[HACA_ISTEM2R], scoreptr->IntervalScores[HACA_ISTEM2R]);

  printf("#  \n# IntStem2 Sc: %.2f (%d,%d)\t ExtStem2 Sc: %.2f (%d,%d)\n", \
	 scoreptr->Scores[ISTEM2], scoreptr->LocalPositions[ISTEM2] , \
	 scoreptr->LocalPositionsRight[ISTEM2], \
	 scoreptr->Scores[XSTEM2],scoreptr->LocalPositions[XSTEM2], \
	 scoreptr->LocalPositionsRight[XSTEM2]);

  printf("# IntStem2: 5'%s--+\\ \t ExtStem2: 5'%s\n", \
	 scoreptr->Patterns[ISTEM2], scoreptr->Patterns[XSTEM2]);
  printf("#             %s--+/  \t ExtStem2: 3'%s \n", \
	 scoreptr->PatternsRight[ISTEM2], scoreptr->PatternsRight[XSTEM2]);


  printf("#stem2 seq\n");  outputSeq(scoreptr->Positions[XSTEM2], stem2length);
  /*  printf("#\n%s\n", querytemp); */
  drawStructureStem2(scoreptr) ;
}



