/* pphit.c
 *
 */


#include <stdio.h>
#include <string.h>
#include <assert.h>
#if 0
#include "pphit.h"
#endif
#include "score_and_test.h"
#include "pseudoU_test.h"
#include "pseudoU_test_funcs.h"


void addHit(PASS_HIT *passHit, TEST *testAptr, char *fpositionB, char *seqptr) {
#if 0
void addHit(PASS_HIT *passHit, TEST *testAptr, TEST *testBptr, char *seqptr) {
#endif
  /* load info for PASS_HIT struct to end of hitlist.  Caller is responsible for
   * identifying the correct passHit struct to be filled */
  assert (testAptr->pflag != 0 || testAptr->type == MATCH_HACA2);
  passHit->fpositionA = testAptr->fposition;
  passHit->fpositionB = fpositionB;
#if 0
  if (testBptr !=0) passHit->fpositionB = testBptr->fposition;
#endif
  passHit->fendpos = seqptr;
}



char *getHitStartPosition(PASS_HIT *passHit) {
/* retrieve start position of specified pass_hit struct
 * Hit is returned as pointer to position in sequence at *start* of hit-patttern */
  return ( passHit->fpositionA );
}


char *getHitEndPosition(PASS_HIT *passHit ) {
  /* retrieve hit number "hitindex" from test of preprocessor pass 
   * Hit is returned as pointer to position in sequence at *end* of hit-patttern */  /* assert (totalHitNumber >= hitindex ); */
  return ( passHit->fendpos );
}


void writePassResults(PASS_HIT *passHit,  \
		      TEST *testAptr, TEST *testBptr, char *seq) {
  /* Output preprocessor pass results. */
  char fpattern[PATTERNMAX];
  char *patternptr = fpattern;
  int position;
  int mismatch;

  fprintf( stderr, "Feature: %s\t", getFeatureName(testAptr));
  position = 0;
  patternptr = SubStr(passHit->fpositionA, position, testAptr->length, patternptr );
  fprintf( stderr, "Pattern: %s\t", fpattern );
  position = passHit->fpositionA - seq;
  fprintf( stderr, "Position: %d\t", position  );
  mismatch = passHit->fmismatA;
    if (mismatch >= 0 && mismatch < 10)  { /* temporary kludge to print only if believable number */
      fprintf( stderr, "Mismatches: %d\t", mismatch );
    }
   if (testBptr != NULL) {
  fprintf( stderr, "\n");
    fprintf( stderr, "Feature: %s\t", getFeatureName(testBptr));
    patternptr = SubStr(passHit->fpositionB, 0, testBptr->length, patternptr );
    fprintf( stderr, "Pattern: %s\t", fpattern );
    position = (passHit->fpositionB) - seq;
    fprintf( stderr, "Position: %d\t", position  );
    mismatch = passHit->fmismatB;
    if (mismatch >= 0 && mismatch < 10)  { /* temporary kludge to print only if believable number */
      fprintf( stderr, "Mismatches: %d\t", mismatch );
    }
  }
  fprintf( stderr, "\n");
}
  
