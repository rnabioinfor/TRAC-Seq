/* score.h
 *
 */

#ifndef SCOREH_INCLUDED
#define SCOREH_INCLUDED

#ifndef TESTH_INCLUDED
#include "test.h"
#endif

#define SCORETABLESIZE 20	/* maximum # of entries in a length-score table */
#define HACALENGTH 6		/* default length of HACA motif */
#if 0
#define MAXDISPLAYLENGTH  200	/* length of up/stream sequence of hit to display */
#endif
#define MAXDISPLAYLENGTH  300	/* length of up/stream sequence of hit to display */

struct scoreLengthStruct {
  int value;           /* Cutoff length value for this score */
  double score;        /* score for this length value */
} ;
  
typedef struct scoreLengthStruct SCORE_LENGTH;

struct scoreStruct {
  char *startpos;   /* pointer to start of found hit in sequence */
  char *endpos;   /* pointer to end of found hit in sequence */
  char *hacapos;   /* pointer to start of HACA motif in sequence */
  int RComplPairs; 
  int LComplPairs; 
  int RComplflength; /* needed to output correct length of target */
  int LComplflength; 
  int ISTEMLength;
  int XSTEMLength;
  int HACA_RComplInterval;	/* Distance between motifs (typ. = 14) */
  int RComplPosition; 
  int LComplPosition; 
  int ISTEMLPosition;
  int XSTEMLPosition;
  int ISTEMRPosition;
  int XSTEMRPosition;
  int HACAPosition;
  int ISTEMPairs; 
  int XSTEMPairs; 
  int ISTEMDither; 
  int XSTEMDither; 
  double LCScore;
  double RCScore;
  double HScore;		 
  double ACAScore;		 
  char *LCfoundPattern;
  char *RCfoundPattern;
  char *IStemLPattern;
  char *IStemRPattern;
  char *XStemLPattern;
  char *XStemRPattern;
  char *HACAPattern;		/* temporary pattern storage until we've classified it as H or ACA */
  char *ACAPattern;
  char *HPattern;
/*  H_or_ACA = 'H' => stem1 found first; = 'C' => stem2 found first*/
  char H_or_ACA;		
  double ISTEMScore; 
  double XSTEMScore; 
  double XSTEMOffsetScore; 
  double gapscore; 
  double HACA_RComplIntervalScore;     
  double ComplLengthScore;
  double ISTEMLengthScore; 
  double ISTEMStartScore; 
  double totalScore;
} ;

typedef struct scoreStruct HIT_SCORE;

extern SCORE_LENGTH  gapScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  complLengthScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  iStemLengthScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  IStemStartScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  xStemLengthScores[SCORETABLESIZE];
extern SCORE_LENGTH  XStemStartScores[SCORETABLESIZE];

/* Global variables used */
extern HIT_SCORE *scoreptr; /* pointer to struct for storing scores for all tests of current hit */

extern double complScores[4][4];
extern double IstemScores[4][4];
extern double XstemScores[4][4];
extern double (*complScoresPtr)[4];
extern double (*IstemScoresPtr)[4];
extern double (*XstemScoresPtr)[4];

void loadScoreTables(char *scoretablefile);
/* Load Score Table values from file */

double scoreDuplex(double scoreMatrix[][4], char *seq1, char *seq2, int length, int complement) ;
/* Calculate score from score matrix.  
  * if complement = 0, complement seq1 before scoring */

double scoreLength(SCORE_LENGTH Scores[],  int matrixLength, int length);
/* Calculate score from length distribution structure.  */

double scoreSingleBase(double profileScores[], char *pattern, int position) ;
/* Calculate score from profile of single-base frequencies.  */

int extendHitForward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		      int *mismatch, int complement);
/* Extend hit from min length to max length.  Both extensions are in "plus" (5'->3')
 * direction.  *pairs and *mismatch return number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches  Returns "score"*/
 
int extendHitBackward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		       int *mismatch, int complement);
/* Extend hit from min length to max length.  Both extensions are in "minus" (3'->5')
 * direction.  *pairs and *mismatch contain number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches Returns "score" */
 
int extendHitForwardBack( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
			  int *mismatch, int complement);
/* Extend hit from min length to max length.  Seq1 is extended in plus direction
 * Seq2 is extended in "minus" (3'->5')  direction.  *pairs and *mismatch return 
 * number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches  Returns "score"*/
 
int scoreTotal(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
/* Calculate total score for hit and output if score exceeds cutoff */

int displayHit(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
/* Output score and other data for hit */

#endif /*SCOREH_INCLUDED*/

  
