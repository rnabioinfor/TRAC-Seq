/* test.h
 *
 */

#ifndef TESTH_INCLUDED
#define TESTH_INCLUDED

#if 0
#ifndef RUNDATAH_INCLUDED
#include "rundata.h"
#endif
#ifndef TARGETH_INCLUDED
#include "target.h"
#endif
#endif

#ifndef TARGET_RUNDATAH_INCLUDED
#include "target_rundata.h"
#endif

#define BAD_VALUE -1
#define PATTERNMAX 20  /* maximum PATTERN length */

/* Define features */
#define  FEATURENUM   12        /* maximum number of FEATURES */
#define  CURRENTFEATUREMAX 9   /* Current max index for features */
#define  RComplMin 1  /* FEATURE = 0 is illegal */
#define  LComplMin 2
#define  ISTEM 3
#define  XSTEM 4
#define  istemScore 5
#define  xstemScore 6
#define  RComplScore 7
#define  LComplScore 8
#define  HACA   9

/* Define codes for TEST types */
#define  TESTTYPENUM  12        /* maximum number of types of tests */
#define  CURRENTTYPEMAX 8   /* Current max index for test types */
#define  MATCH   1  /* mismatches allowed */
#define  LEFT_MATCH_TARGET   2
#define  RIGHT_MATCH_TARGET   3
#define  CHECK_STEM 4
#define  SCORE_STEM 5
#define  SCORE_LEFT_COMPL 6
#define  SCORE_RIGHT_COMPL 7
#define  EXACT_MATCH   8

#define TEST_0 0
#define TEST_1 1

/* pflag labels for different passes */
#define  PASS1   1
#define  PASS2   2
#define  FINALPASS 0


struct testStruct {
  int type;           /* Type of test */
/* Non-zero => preprocessor pass => store hits */
  int pflag;           /* 0 => final pass; 1 => pp pass 1; 2 => pp pass 2 */
  int pptestnum;           /* Which preprocessor test (0 or 1) of pass pflag  */
  int offset;            /* offset from search start position to look for feature */
  int offset2;            /* offset to second half of stem */
  int feature;          /* feature being currently tested  (0 < && < FEATURENUM) */
  char *pattern;                /* pattern to search for */
  char *fpattern;                /* found matching pattern */
  char *fpattern2;                /* second found matching pattern - for stems */
  char *fposition;      /* pointer to start position of found matching pattern */
  char *fposition2;      /* pointer to start position of found stem matching pattern */
  int length;                   /* length of input pattern */
  int flength;                   /* length of found matching pattern */
  /* allowed mismatches. For stems minimum value of #pairs - #mismatches */
  int mismat;                    
  int fmismat;                   /* found mismatches */
  int fpairs;                   /* found pairs (for stem matching) */
  int wobble;                   /* found allowed GU wobble matches  (not used yet) */
  int fwobble;                   /* found mismatches (not used yet) */
  int dither;                   /* allowed "dither" for start of search  */
  int dither2;                   /* allowed "dither" for second half of stem */
  int fdither;                   /* found dither */
  int fdither2;                   /* found dither for second half of stem*/
  double (*scoreMatrix)[4];           /* pointer to score matrix */
  double score;           /* minimum passing score */
  double fscore;           /* found score */
} ;

typedef struct testStruct TEST;

/* Lookup table of test pointers of tests from _all_ passes by feature type */
extern TEST *testPtrTable[FEATURENUM];


TEST *newTest(int type, int offset, int feature, char *pattern, \
int mismat, int dither, int scoreMatrixChoice, int pflag, int offset2, \
int dither2, double minScore, int testIndex );
/* Create a new TEST structure. */

TEST *newTestFromDescriptor(FILE  *descfp, int testIndex );
/* Create a new TEST structure from Descriptor. */

void freeTest(TEST *testptr);
/* Free up Test structure.  */

void setPattern(TEST *testptr, char *pattern);
/* Set required pattern. Pattern length must be < PATTERNMAX */

void loadTargetPattern(TEST *testptr, TARGET *targetptr);
/* Load pattern from target object if test type = LEFT_MATCH_TARGET or RIGHT_MATCH_TARGET */

int getType(TEST *testptr);
/* Get test type */

int allowedMismatch(TEST *testptr);
/* Get number of mismatches.  */

char *getFeatureName(TEST *testptr) ;
/* Get  pointer to string decsription of feature being tested */

char *getFoundPattern(TEST *testptr);
/* Get dynamically allocated copy of found pattern. */

char *getFoundPattern2(TEST *testptr);
/* Get dynamically allocated copy of found pattern 2. */

void setOffset(TEST *testptr, int offset);
/* Set offset position. */

int getOffset(TEST *testptr);
/* Get offset value */

int getFoundMismatch(TEST *testptr);
/* Get actual number of mismatches */

int getFoundLength(TEST *testptr);
/* Get length of found pattern */

int getFoundPosition(TEST *testptr, char *seq);
/* Get position of found pattern in input sequence seq */

double getScore(TEST *testptr);
/* Get score of found pattern */

int getDither(TEST *testptr);
/* Get "dither" value of match */

void writeTestRequirements(TEST *testptr);
/* Output test parameters. */

void writeTestResults(TEST *testptr, char *seq);
/* Output test results. */

int runTest(TEST *testptr, char *seq, int hit1index, int hit2index);
/* Execute test at sequence starting at position
 * pointed to by *seq, return TEST_PASSED or TEST_FAILED
 * Store found values depending on type of test  
 * Hit indices needed to find results of pp pass for extension & scoring tests */

TEST *getTest(int feature);
/* Get the test pointer for the test corresponding to the feature 
 * The feature *must* be tested in the *final* pass as currently implemented */ 

#if 0
int runTest2(TEST *testptr, char *seq, char *seq2, int hit1index, int hit2index);
/* Variant of runTest needed when test requires 
 * positions of hits from both preprocessor passes
 * Store found values depending on type of test  */
#endif

#endif /*TESTH_INCLUDED*/

  
