/* target.h
 *
 */

#ifndef TARGETH_INCLUDED
#define TARGETH_INCLUDED

  #ifndef RUNDATAH_INCLUDED
  #include "rundata.h"
  #endif

/* Define codes for target "keys" */
#define  TEST_TARGET   0
#define  SSU_106   1
#define  TARGETNUM 50		/* allow room for expansion */
#define  MAXTARGETLEN 50	 /* max length of target sequence */
#define MINCOMPLEN -1
#define MAXCOMPLEN 1

struct TargetStruct {
  int targetPosition;           /* offset in target sequence of pseudoU */
  char *targetName  ;   /* (eg SSU_106 ) */
  char *targetSeq  ;   /* actual target sequence */
  char *snoAssign  ;   /* snoRNA assignment annotation (eg snR34 -E ) */
  char *leftComplMinSeq;           /* minimum left complement pattern */
  char *rightComplMinSeq;          /* minimum right complement pattern */
  char *leftComplMaxSeq;           /* maximum left complement pattern */
  char *rightComplMaxSeq;          /* maximum right complement pattern */
} ;

typedef struct TargetStruct TARGET;

TARGET *newTarget(FILE  *descfp, PARAMS *rundataptr);
/* Create a new TARGET structure.  */

void freeTarget(TARGET *targetptr);
/* Free up TARGET structure.  */

char *targetName(TARGET *targetptr) ;
/* Get pointer to string decsription of target (eg SSU_106) */

char *leftComplMaxSeq(TARGET *targetptr);
/* Get pointer to maximim left complement pattern */

char *rightComplMaxSeq(TARGET *targetptr);
/* Get pointer to maximim right complement pattern */

char *leftComplMinSeq(TARGET *targetptr);
/* Get pointer to minimum left complement pattern */

char *rightComplMinSeq(TARGET *targetptr);
/* Get pointer to minimum right complement pattern */


#endif /*TARGETH_INCLUDED*/

 
