/* score_and_test.h
 *
 */

#ifndef SCORE_AND_TESTH_INCLUDED
#define SCORE_AND_TESTH_INCLUDED

#ifndef TEST_CONFIGH_INCLUDED
#include "pseudoU_test.h"
#endif

#ifndef TARGET_RUNDATAH_INCLUDED
#include "target_rundata.h"
#endif

/* Added MisMatches to scoreptr struct */

struct pass1HitStruct {
  char *fpositionA;  /* pointer to start of testA found matching pattern */
  char *fpositionB;  /* pointer to start of testB found matching pattern */
  char *fendpos;  /* pointer to end  of found matching pattern for entire Pass */
  int   fmismatA;                   /* found mismatch for test A */
  int   fmismatB;                   /* found mismatch for test B */
} ;

typedef struct pass1HitStruct PASS_HIT;

extern PASS_HIT *pp1hits[ALLOWEDHITS];
extern PASS_HIT *pp2hits[ALLOWEDHITS];


struct testStruct {
  int type;           /* Type of test */
/* Non-zero => preprocessor pass => store hits */
  int pflag;           /* 0 => final pass; 1 => pp pass 1; 2 => pp pass 2 */
  /* tflag: Test-specific options.  .
   *  In target matching, if set to 1 allows GU matches; if zero GU matches not allowed 
   *  If set in check_double_stem, skips POST_ACA scoring */
  int tflag;         
  int pptestnum;           /* Which preprocessor test (0 or 1) of pass pflag  */
  int offset;            /* offset from search start position to look for feature */
  int offset2;            /* offset to second half of stem */
  int feature;          /* feature being currently tested  (0 < && < FEATURENUM) */
  char *pattern;                /* pattern to search for */
  char *fpattern;                /* found matching pattern */
  char *fpattern2;                /* second found matching pattern - for stems */
  char *fposition;      /* pointer to start position of found matching pattern */
  char *fposition2;      /* pointer to start position of found stem matching pattern */
  int length;                   /* length of input pattern */
  int flength;                   /* length of found matching pattern */
  /* allowed mismatches. For stems minimum value of #pairs - #mismatches */
  int mismat;                    
  int fmismat;                   /* found mismatches */
  int fpairs;                   /* found pairs (for stem matching) */
  int wobble;                   /* found allowed GU wobble matches  (not used yet) */
  int fwobble;                   /* found mismatches (not used yet) */
  int dither;                   /* allowed "dither" for start of search  */
  int dither2;                   /* allowed "dither" for second half of stem */
  int fdither;                   /* found dither */
  int fdither2;                   /* found dither for second half of stem*/
  double (*scoreMatrix)[4];           /* pointer to score matrix */
  double score;           /* minimum passing score */
  double fscore;           /* found score */
} ;

typedef struct testStruct TEST;

struct scoreLengthStruct {
  int value;           /* Cutoff length value for this score */
  double score;        /* score for this length value */
} ;
  
typedef struct scoreLengthStruct SCORE_LENGTH;

struct scoreStruct {
  char *startpos;   /* pointer to start of found hit in sequence */
  char *endpos;   /* pointer to end of found hit in sequence */
  int Lengths[FEATURENUM];
  int Pairs[FEATURENUM];
  int MisMatches[FEATURENUM];
  int Dithers[FEATURENUM];
  char *Positions[FEATURENUM];  /* Positions as pointers in memory */
  char *PositionsRight[FEATURENUM];
  int RelativePositions[FEATURENUM]; /* Position from sequence start */
  int RelativePositionsRight[FEATURENUM];
  int LocalPositions[FEATURENUM]; /* Position from hit start */
  int LocalPositionsRight[FEATURENUM];
  char *Patterns[FEATURENUM];
  char *PatternsRight[FEATURENUM];
/*  H_or_ACA = 'H' => stem1 found first; = 'C' => stem2 found first*/
  char H_or_ACA;		
  double Scores[FEATURENUM];
  double IntervalScores[INTERVAL_FEATURENUM];
  int Intervals[INTERVAL_FEATURENUM];
  double totalScore;
  double totalScoreStem1;
  double H1Score;
  double ACA1Score;
  PASS_HIT *HACA2hits[ALLOWED_HACA2_HITS];
  char *HACAs_per_RCompl[MAX_HACAS];
  int HACA2_totalhitcounter;
  int HACAs_per_RCompl_totalhitcounter;
  int genomeStartPosition;
  int genomeEndPosition; 
  int length;			/* length of entire candidate hit */
} ;

typedef struct scoreStruct HIT_SCORE;

extern SCORE_LENGTH  gapScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  complLengthScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  iStemLengthScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  IStemStartScores[SCORETABLESIZE] ;
extern SCORE_LENGTH  xStemLengthScores[SCORETABLESIZE];
extern SCORE_LENGTH  XStemStartScores[SCORETABLESIZE];
extern SCORE_LENGTH  H_XSTEM_intervalScores[SCORETABLESIZE];
extern SCORE_LENGTH  rComplHACAIntervalScores[SCORETABLESIZE];
extern SCORE_LENGTH  HACA_ISTEM2R_intervalScores[SCORETABLESIZE];
extern SCORE_LENGTH  POST_ACA_freqScores[SCORETABLESIZE];

/* Global variables used */
extern HIT_SCORE *scoreptr; /* pointer to struct for storing scores for all tests of current hit */

extern double complScores[4][4];
extern double IstemScores[4][4];
extern double XstemScores[4][4];
extern double (*complScoresPtr)[4];
extern double (*IstemScoresPtr)[4];
extern double (*XstemScoresPtr)[4];

#if 0
void drawStructureStem2(HIT_SCORE *scoreptr) ;
int convertToGenomicPos(char *featureStart, RUNDATA *rundataptr);
void outputSeq(char *seqStartPtr, int length) ;
#endif
int outputHit(HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
void outputHitStem2(HIT_SCORE *scoreptr, RUNDATA *rundataptr);

int scoreStem1Total(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
void scoreHACAmotif(HIT_SCORE *scoreptr, char mode);
void storeRelativePositions(HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
#if 0
void storeScores(HIT_SCORE *scoreptr, RUNDATA *rundataptr) ;
#endif

void loadScoreTables(char *scoretablefile);
/* Load Score Table values from file */


double scoreDuplex(double scoreMatrix[][4], char *seq1, char *seq2, int length, int already_complemented) ;
#if 0
double scoreDuplex(double scoreMatrix[][4], char *seq1, char *seq2, int length, int complement) ;
#endif
/* Calculate score from score matrix.  
  * if complement = 0, complement seq1 before scoring */

double scoreLength(SCORE_LENGTH Scores[],  int matrixLength, int length);
/* Calculate score from length distribution structure.  */

double scoreSingleBase(double profileScores[], char *pattern, int position) ;
/* Calculate score from profile of single-base frequencies.  */

double scoreBaseFrequency(SCORE_LENGTH frequencyScores[], char *pattern, int patternLength, char ch) ;

int extendHitForward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		      int *mismatch, int complement, int GU_flag);
/* Extend hit from min length to max length.  Both extensions are in "plus" (5'->3')
 * direction.  *pairs and *mismatch return number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches  Returns "score"*/
 
int extendHitBackward( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
		       int *mismatch, int complement, int GU_flag);
/* Extend hit from min length to max length.  Both extensions are in "minus" (3'->5')
 * direction.  *pairs and *mismatch contain number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches Returns "score" */
 
int extendHitForwardBack( char *seq1, char *seq2, int minLen, int maxLen, int *pairs, \
			  int *mismatch, int complement, int GU_flag);
/* Extend hit from min length to max length.  Seq1 is extended in plus direction
 * Seq2 is extended in "minus" (3'->5')  direction.  *pairs and *mismatch return 
 * number of pairs & mismatches of extension
 * with best "score" - ie max pairs - mismatches. Complement =1 => look for WC pairs
 * rather than matches  Returns "score"*/
 
int scoreTotal(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
/* Calculate total score for hit and output if score exceeds cutoff */

int scoreTotal(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
/* Calculate total score for hit and output if score exceeds cutoff */

int displayHit(HIT_SCORE *scoreptr, RUNDATA *rundataptr);
/* Output score and other data for hit */

/* Lookup table of test pointers of tests from _all_ passes by feature type */
extern TEST *testPtrTable[FEATURENUM];


TEST *newTest(int type, int offset, int feature, char *pattern, \
int mismat, int dither, int scoreMatrixChoice, int pflag, int offset2, \
int dither2, double minScore, int testIndex );
/* Create a new TEST structure. */

TEST *newTestFromDescriptor(FILE  *descfp, int testIndex );
/* Create a new TEST structure from Descriptor. */

void freeTest(TEST *testptr);
/* Free up Test structure.  */

void setPattern(TEST *testptr, char *pattern);
/* Set required pattern. Pattern length must be < PATTERNMAX */

void loadTargetPattern(TEST *testptr, TARGET *targetptr);
/* Load pattern from target object if test tflag = GU_OK */

int getType(TEST *testptr);
/* Get test type */

int allowedMismatch(TEST *testptr);
/* Get number of mismatches.  */

char *getFeatureName(TEST *testptr) ;
/* Get  pointer to string decsription of feature being tested */

char *getFoundPattern(TEST *testptr);
/* Get dynamically allocated copy of found pattern. */

char *getFoundPattern2(TEST *testptr);
/* Get dynamically allocated copy of found pattern 2. */

void setOffset(TEST *testptr, int offset);
/* Set offset position. */

int getOffset(TEST *testptr);
/* Get offset value */

int getFoundMismatch(TEST *testptr);
/* Get actual number of mismatches */

int getFoundLength(TEST *testptr);
/* Get length of found pattern */

int getFoundPosition(TEST *testptr, char *seq);
/* Get position of found pattern in input sequence seq */

double getScore(TEST *testptr);
/* Get score of found pattern */

int getDither(TEST *testptr);
/* Get "dither" value of match */

void writeTestRequirements(TEST *testptr);
/* Output test parameters. */

void writeTestResults(TEST *testptr, char *seq);
/* Output test results. */

int runTest(TEST *testptr, HIT_SCORE *scoreptr, RUNDATA *rundataptr, char *seq, int hit1index, int hit2index);
/* Execute test at sequence starting at position
 * pointed to by *seq, return TEST_PASSED or TEST_FAILED
 * Store found values depending on type of test  
 * Hit indices needed to find results of pp pass for extension & scoring tests */

TEST *getTest(int feature);
/* Get the test pointer for the test corresponding to the feature 
 * The feature *must* be tested in the *final* pass as currently implemented */ 

void addHit(PASS_HIT *passHit, TEST *testAptr, char *fpositionB, char *seqptr);
#if 0
void addHit(PASS_HIT *passHit, TEST *testAptr, TEST *testBptr, char *seqptr);
#endif
/* load info for PASS_HIT struct to end of hitlist.  Caller is responsible for
 * identifying the correct passHit struct to be filled */

char *getHitStartPosition(PASS_HIT *passHit);
/* retrieve start position of specified pass_hit struct
 * Hit is returned as pointer to position in sequence at *start* of hit-patttern */

char *getHitEndPosition(PASS_HIT *passHit);
/* retrieve end position of specified pass_hit struct
 * Hit is returned as pointer to position in sequence at *end* of hit-patttern */

void writePassResults(PASS_HIT *passHit,  \
		      TEST *testAptr, TEST *testBptr, char *seq) ;

#endif /* SCORE_AND_TESTH_INCLUDED */

  
