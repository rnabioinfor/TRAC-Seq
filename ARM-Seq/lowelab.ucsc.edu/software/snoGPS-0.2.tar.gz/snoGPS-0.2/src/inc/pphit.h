/* pphit.h
 *
 */

#ifndef PPHITH_INCLUDED
#define PPHITH_INCLUDED

  #ifndef TESTH_INCLUDED
    #include "test.h"
  #endif


#define ALLOWEDHITS 20000  /* Maximum number of hits - preprocess pass  */
#if 0
#define ALLOWEDHITS 200  /* Maximum number of hits - preprocess pass  */
#endif

 struct pass1HitStruct {
  char *fpositionA;  /* pointer to start of testA found matching pattern */
  char *fpositionB;  /* pointer to start of testB found matching pattern */
  char *fendpos;  /* pointer to end  of found matching pattern for entire Pass */
  int   fmismatA;                   /* found mismatch for test A */
  int   fmismatB;                   /* found mismatch for test B */
} ;

typedef struct pass1HitStruct PASS_HIT;

extern PASS_HIT *pp1hits[ALLOWEDHITS];
extern PASS_HIT *pp2hits[ALLOWEDHITS];


void addHit(PASS_HIT *passHit, TEST *testAptr, TEST *testBptr, char *seqptr);
/* load info for PASS_HIT struct to end of hitlist.  Caller is responsible for
 * identifying the correct passHit struct to be filled */

char *getHitStartPosition(PASS_HIT *passHit);
/* retrieve start position of specified pass_hit struct
 * Hit is returned as pointer to position in sequence at *start* of hit-patttern */

char *getHitEndPosition(PASS_HIT *passHit);
/* retrieve end position of specified pass_hit struct
 * Hit is returned as pointer to position in sequence at *end* of hit-patttern */

void writePassResults(PASS_HIT *passHit,  \
TEST *testAptr, TEST *testBptr, char *seq) ;

#endif /*PPHITH_INCLUDED*/

  
