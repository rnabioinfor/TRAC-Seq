
/* pseudoU_funcs.h header file for functions used by pseudoU_search program
 *
 */
 

/****** NOTE This file is modified from SRE's file of the same name*****/

#ifndef PSFUNCS_INCLUDED
#define PSFUNCS_INCLUDED


/* 
 * from pseudoU_funcs.c
 */

#if 0
#define MAX( a, b)   ( (a) > (b) ? (a) : (b) )
#define MIN( a, b)   ( (a) < (b) ? (a) : (b) )
#endif

extern int getline(char *s, FILE *fp, int *linenumber, int convert_to_upper);		
extern int Index(char *string, int ch) ;
extern int Paired(char *seq1, char *seq2);


extern char *SubStr(char *string, int start, size_t length, char *ret_substring);
/* Allocate memory and duplicate first n characters of string */
extern char *Strndup(char *string, size_t length);
extern char *Reverse(char *originalString, char *reversedString, size_t length);
/* Fill previously allocated memory with first n characters of originalString reversed */
char *Complement(char *comp, char *seq) ;
/* Just complement the sequence.  Don't reverse. */

extern int Min(int var1, int var2 );
extern int Max(int var1, int var2 );

#if DEBUG > 0
extern void *DebugMalloc(size_t size);
extern void  DebugFree(void *pointer, size_t size);
#endif /* DEBUG */

#endif /* PSFUNCS_INCLUDED */
