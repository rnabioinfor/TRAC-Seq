/* rundata.h
 *
 */

#ifndef RUNDATAH_INCLUDED
#define RUNDATAH_INCLUDED

/* Define codes for run_type_flag types */
#define  SIMPLE   1
#define  PRE1   2
#define  PRE2   3
#define  RUNTYPENUM 5		/* allow room for expansion */


 struct RunDataStruct {
  int run_type_flag;           /* Type of rundata */
  int numberOfTests;           /* Number of tests in *final* pass */
  int numberOfPP1Tests;           /* Number of tests in preprocessor 1 pass */
  int numberOfPP2Tests;           /* Number of tests in preprocessor 2 pass */
  int numberOfTargets;           /* */
  int gapmin;
  int gapmax;
  char *targetFile ;  
  char *queryFile ;  
  int targetLeftMin;
  int targetLeftMax; 
  int targetRightMin;  
  int targetRightMax;  
} ;

typedef struct RunDataStruct PARAMS;

PARAMS *newRunData(FILE  *descfp);
/* Create a new PARAMS structure.  */

void freeRunData(PARAMS *rundataptr);
/* Free up Test structure.  */

int gapmin(PARAMS *rundataptr);
/* Get minimum gap value */

int gapmax(PARAMS *rundataptr);
/* Get max gap value */

void set_gapmin(PARAMS *rundataptr, int gapmin);
/* Set minimum gap value */

void set_gapmax(PARAMS *rundataptr, int gapmax);
/* Set minimum gap value */

int numberOfTests(PARAMS *rundataptr);
/* Get number Of Tests for final pass*/

int numberOfTargets(PARAMS *rundataptr);
/* Get number Of Targets*/

void set_targetFile(PARAMS *rundataptr, char *targetfile);
/* Set target file name*/

void set_queryfile(PARAMS *rundataptr, char *queryfile);
/* Set target file name*/

#endif /*RUNDATAH_INCLUDED*/

 
