/* target_rundata.h
 *
 */

#ifndef TARGET_RUNDATAH_INCLUDED
#define TARGET_RUNDATAH_INCLUDED

#ifndef TEST_CONFIGH_INCLUDED
#include "pseudoU_test.h"
#endif

/* Define codes for target "keys" */
#define  TEST_TARGET   0
#define  SSU_106   1
#if 0
#define  TARGETNUM 50		/* no longer used */
#endif
#define  MAXTARGETLEN 50	 /* max length of target sequence */
#define MINflag -1
#define MAXflag 1


/* Define codes for run_type_flag types */
#define  SIMPLE   1
#define  PRE1   2
#define  PRE2   3
#define  RUNTYPENUM 5		/* allow room for expansion */

#ifndef SQUIDH_INCLUDED
#include "squid.h"
#endif

struct TargetStruct {
  int targetPosition;           /* offset in target sequence of pseudoU */
  int leftTargetLength;         /* length of target sequence left of pseudoU  */
  int rightTargetLength;         /* length of target sequence right of pseudoU  */
  char *targetName  ;   /* (eg SSU_106 ) */
  char *targetSeq  ;   /* actual target sequence */
  char *snoAssign  ;   /* snoRNA assignment annotation (eg snR34 -E ) */
  char *leftComplMinSeq;           /* minimum left complement pattern */
  char *rightComplMinSeq;          /* minimum right complement pattern */
  char *leftComplMaxSeq;           /* maximum left complement pattern */
  char *rightComplMaxSeq;          /* maximum right complement pattern */
  char *leftMinSeq;           /* minimum left uncomplemented pattern */
  char *rightMinSeq;          /* minimum right uncomplemented pattern */
  char *leftMaxSeq;           /* maximum left uncomplemented pattern */
  char *rightMaxSeq;          /* maximum right uncomplemented pattern */
} ;

typedef struct TargetStruct TARGET;

struct RunDataStruct {
  int run_type_flag;           /* Type of rundata */
  int mode;			/* 1 or 2 stems etc  */
  int startingFeature;		/* 5' most feature - used for display */
  int numberOfTests;           /* Number of tests in *final* pass */
  int numberOfPP1Tests;           /* Number of tests in preprocessor 1 pass */
  int numberOfPP2Tests;           /* Number of tests in preprocessor 2 pass */
  int numberOfTargets;           /* */
  double totalScoreCutoff;   
  int MinIntervals[INTERVAL_FEATURENUM];
  int MaxIntervals[INTERVAL_FEATURENUM];
  char strand; /* Stand currently being tested 'W' or 'C' */
  int segmentOffset; /* Start of current sequence segment (multiple of maxSegLen) */
  int candidate_number;
  char *targetFile ;  
  char *queryFile ;  
  int segment_length;
  char *querySeq ;  /* pointer to current query sequence segment */
  char *entireSeq ;  /* pointer to start of entire current query sequence */
  /* start search offset if later test (eg XSTEM) might backtrack before
   * start of sequence */
  int startSearchPos;
  int targetLeftMin;
  int targetLeftMax; 
  int targetRightMin;  
  int targetRightMax; 
  TARGET *currentTarget;
  SQINFO sqinfo;
  FILE *fastaOutFilePtr;
} ;

typedef struct RunDataStruct RUNDATA;

RUNDATA *newRunData(FILE  *descfp, float totalScoreCutoff);
/* Create a new RUNDATA structure.  */

void freeRunData(RUNDATA *rundataptr);
/* Free up Test structure.  */


#if 0
int gapmin(RUNDATA *rundataptr);
/* Get minimum gap value */

int gapmax(RUNDATA *rundataptr);
/* Get max gap value */

void set_gapmin(RUNDATA *rundataptr, int gapminValue);
/* Set minimum gap value */

void set_gapmax(RUNDATA *rundataptr, int gapmaxValue);
/* Set minimum gap value */
#endif

int numberOfTests(RUNDATA *rundataptr);
/* Get number Of Tests for final pass*/

int numberOfTargets(RUNDATA *rundataptr);
/* Get number Of Targets*/

void set_targetFile(RUNDATA *rundataptr, char *targetfile);
/* Set target file name*/

void set_queryfile(RUNDATA *rundataptr, char *queryfile);
/* Set target file name*/

TARGET *newTarget(FILE  *descfp, RUNDATA *rundataptr);
/* Create a new TARGET structure.  */

void freeTarget(TARGET *targetptr);
/* Free up TARGET structure.  */

char *targetName(TARGET *targetptr) ;
/* Get pointer to string decsription of target (eg SSU_106) */

char *leftComplMaxSeq(TARGET *targetptr);
/* Get pointer to maximim left complement pattern */

char *rightComplMaxSeq(TARGET *targetptr);
/* Get pointer to maximim right complement pattern */

char *leftComplMinSeq(TARGET *targetptr);
/* Get pointer to minimum left complement pattern */

char *rightComplMinSeq(TARGET *targetptr);
/* Get pointer to minimum right complement pattern */

char *leftMaxSeq(TARGET *targetptr);
/* Get pointer to maximim left (un)complement(ed) pattern */

char *rightMaxSeq(TARGET *targetptr);
/* Get pointer to maximim right (un)complement(ed) pattern */

char *leftMinSeq(TARGET *targetptr);
/* Get pointer to minimum left (un)complement(ed) pattern */

char *rightMinSeq(TARGET *targetptr);
/* Get pointer to minimum right (un)complement(ed) pattern */


#endif /*TARGET_RUNDATAH_INCLUDED*/

 
