/* pseudoU_test.h
 *
 * Configurable compile-time parameters and structure
 * definitions in pseudoU_search.
 */

#ifndef TEST_CONFIGH_INCLUDED
#define TEST_CONFIGH_INCLUDED

#define  DEBUG   1       /* defining DEBUG  >0  triggers debugging */

#define MAXLN    1024		/* changed 10/21/02 to accomodate even longer seqs */
#if 0
#define MAXLN    512		/* changed 7/12/02 to accomodate long upstream seqs */
#define MAXLN    256
#endif

#if 0
#define TOKENLEN   10		/* too short! 9/17/03, maximum length of a string token in descriptor file */
#endif
#define TOKENLEN   30		/* maximum length of a string token in descriptor file */

#define SEPS     " \t\n"
#define COMMENTSYM '#'
#define TEST_PASSED 1
#define TEST_FAILED 0
#define TRUE 1
#define FALSE 0
#define USEDESCRIPTORVALUE -999
#define UPSTREAM 0
#define DOWNSTREAM 1	
#define GU_OK 1
#define NO_POST_ACA 1

#define MAXTESTNUM 20
#define MAXPPTESTNUM 5

#define MAXTARGETNUM 100000 /* 6/24/04 increased for use when scanning known snos for unknown targets */
#if 0
#define MAXTARGETNUM 5000
#define MAXTARGETNUM 3000
#define MAXTARGETNUM 50
#endif

#if 0
#define XSTEMOFFSET 9 /* decreased 6/10/03; human snos have short H-stem distance  */
#endif

#define XSTEMOFFSET 7 /* decreased 2/19/04; otherwise snos with short initial xstem are not found unless extended  */
#define TARGETLEFTMAX 10
#define TARGETRIGHTMAX 10
#if 0
#define TARGETLEFTMIN 3 /* decreased 2/26/04; U4 snRNA has pseudouU at position 3  */
#endif
#define TARGETLEFTMIN 4 /* returned to = 4  8/10/04 to fix problem */
#define TARGETRIGHTMIN 4
/* distance from sequence end to stop checking rcompl hits - empirical*/
#define MAXRIGHTHITLENGTH 19	/* HACA motif = 6; RCOMPLMINLEN = 4; OFFSET = 9 */

#define BAD_VALUE -1
#define PATTERNMAX 20  /* maximum PATTERN length */

#define ISTEM_XSTEM 15

#if 0
#define MAX_XSTEM_H 10 
#endif
#define MIN_XSTEM_H 8   	/* decreased 6/10/03; human snos have short H-stem distance  */
#define MAX_XSTEM_H 140		/* increased 9/27/02  */
#if 0
#define MAX_XSTEM_H 49
#endif
#define MIN_HACA_ISTEMR 13
#define MAX_HACA_ISTEMR 20
#if 0
#define MIN_STEMS_PLUS_GAP 60
#define MAX_STEMS_PLUS_GAP 160
#define MIN_ACA_H   MIN_STEMS_PLUS_GAP +  MIN_H_XSTEM 
#define MAX_ACA_H   MAX_STEMS_PLUS_GAP +  MAX_H_XSTEM
#endif
#define ALLOWED_HACA2_HITS 80

#if 0
/* Test for no-target searching - Maximum number of hits - preprocess pass  */
#define ALLOWEDHITS 200000  
#define ALLOWEDHITS 30000  /* Increased 10/21/02 because of crashing - not sure why necessary  */
#define MAX_SEG_LEN 20000
#define SEG_OVERLAP 200 
#endif
#if 0
#define ALLOWEDHITS 20000  /* Maximum number of hits - preprocess pass  */
#define MAX_SEG_LEN 200000
#endif
#define ALLOWEDHITS 100000  /* Increased again 6/02/03 because of crashing - not sure why necessary  */
#define MAX_SEG_LEN 200000
#define SEG_OVERLAP 200 

#define SCORETABLESIZE 20	/* maximum # of entries in a length-score table */
#define HACALENGTH 6		/* default length of HACA motif */
#define POST_ACALENGTH 12	/* default length of POST_ACA motif */
#define MAXDISPLAYLENGTH  300	/* length of up/stream sequence of hit to display */
#define MAX_HACAS 8	        /* max number of ANA motifs to be searched for after a given rcomplement motif */

/* Define modes  */
#define MAX_MODE_NUMBER 4	/* Used for input error checking */
#define SINGLE_STEM 1
#define TWO_STEM 2
#define ACA_1_STEM 3
#define ACA_PLUS_H 4

/* Define features */
#define  FEATURENUM   20       /* maximum number of FEATURES */
#define  CURRENTFEATUREMAX 18   /* Current max index for features */
#define  unused  0
#define  RComplMin 1  
#define  LComplMin 2
#define  ISTEM 3
#define  XSTEM 4
#define  istemScore 5 ok9i
#define  xstemScore 6
#define  RCompl 7
#define  LCompl 8
#define  HACA   9
#define  H   10
#define  ACA   11
#define  ISTEM2 12
#define  XSTEM2 13
#define  POST_ACA 14
#define  unused1  15		/* for debugging purposes */
#define  unused2  16            /* for debugging purposes */ 
#define  unused3  17
#define  unused4  18

/* Define interval features */
#define  INTERVAL_FEATURENUM   16       /* maximum number of INTERVAL FEATURES */
#define  stem1gap 1  /* gap includes ISTEMs, ie LCompl to RCompl distance */
#define  stem2gap 2  /* gap includes ISTEMs, ie LCompl to RCompl distance */ 
#define  Compl1Length 3
#define  ISTEM1Length 4
#define  ISTEM1Start 5
#define  XSTEM_H 6
#define  HACA_RCompl 7
#define  HACA_ISTEM2R 8
#define  XSTEMOffset 9
#define  ACA_H 10
#define  XSTEM1Length 11
#define  XSTEM1Start 12
#define  ISTEM2Length 13
#define  XSTEM2Length 14

/* Define codes for TEST types */
#define  TESTTYPENUM  26        /* maximum number of types of tests */
#define  CURRENTTYPEMAX 22   /* Current max index for test types */
#define  MATCH   1  /* mismatches allowed */
#define  LEFT_MATCH_TARGET   2
#define  RIGHT_MATCH_TARGET   3
#define  SCORE_INTERVALS 4
#define  SCORE_HACA_PATTERN 5
#define  SCORE_LEFT_COMPL 6
#define  SCORE_RIGHT_COMPL 7
#define  EXACT_MATCH   8
#define  CHECK_ISTEM 9
#define  CHECK_XSTEM 10
#define  CHECK_DOUBLE_STEM 11
#define  OUTPUT_STEM1_TARGET 12
#define  SCORE_STEM1_TARGET 13
#define  MATCH_HACA2 14
#define  DUMMY_LEFT_COMPL 15
#define  DUMMY_RIGHT_COMPL 16
#define  SCORE_TARGETS 17	/* Deprecated. Use tests SCORE_TARGET_MATRIX plus SCORE_TARGET_INTERVALS instead  */
#define  SCORE_POST_ACA 18
#define  CHECK_ONESTEM_PLUS 19
#define  FIND_MULTI_MATCHES 20
#define  SCORE_TARGET_MATRIX 21
#define  SCORE_TARGET_INTERVALS 22
#if 0
#define  LEFT_TARGET_GU_OK   21
#define  RIGHT_TARGET_GU_OK   22
#define  SCORE_LEFT_COMPL_GU_OK 23
#define  SCORE_RIGHT_COMPL_GU_OK 24
#endif 

#define TEST_0 0
#define TEST_1 1

/* pflag labels for different passes */
#define  PASS1   1
#define  PASS2   2
#define  FINALPASS 0


#define PRINTLINENUM \
  fprintf(stderr, "FILE: %s ; LINE %d \n ",__FILE__ , __LINE__)
#define PRINTVAL (FORMAT, VALUE) \
        printf(  #VALUE  " = " FORMAT "\n", VALUE )

#if DEBUG > 0
#define DEBUG_FILL_CHAR   0xFE
#define DEBUGPRINT(FORMAT, VALUE) \
        printf(  #VALUE  " = " FORMAT "\n", VALUE ); \
        fflush( stdout )
#define DEBUGMALLOC(NUMBER, SIZE)  DebugMalloc(NUMBER * SIZE)
#define DEBUGFREE(PTR, SIZE)  DebugFree(PTR, SIZE)

#else
#define DEBUGPRINT(FORMAT, VALUE)
#define DEBUGMALLOC(NUMBER, SIZE)  MallocOrDie(NUMBER * SIZE)
#define DEBUGFREE(PTR, SIZE)  free(PTR)

#endif /* DEBUG */


#endif /*TEST_CONFIGH_INCLUDED*/
