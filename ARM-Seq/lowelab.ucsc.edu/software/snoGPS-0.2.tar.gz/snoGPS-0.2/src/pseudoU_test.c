/* pseudoU_test.c
 *
 * test program for pseudoU routines
 *
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <time.h>
#include "squid.h"
#include "sqfuncs.h"

#include "target_rundata.h"
#include "pseudoU_test.h"
#include "score_and_test.h"
#include "pseudoU_test_funcs.h"

static void parseCommandline(int argc, char **argv, char **descfileptr, char **dbfileptr) ; 
static void runAllTestsSimple(TEST *testptr[], char *queryseq, char *seqlimit) ;
static int runPreprocessTest(TEST *testptr[], HIT_SCORE *scoreptr, PASS_HIT *pphits[], \
			     char *queryseq, char *seqlimit, int startSearchPos);
static void runAllTestsFromHitList(TEST *testptr[], char *queryseq, PASS_HIT *pp1hits[],\
				   TEST *test1ptr[], char *seqlimit, int  hit1Total) ;

static void runAllTestsFrom2HitLists(TEST *testptr[], char *queryseq, \
				     TEST *test1ptr[], TEST *test2ptr[], PASS_HIT *pp1hits[], PASS_HIT *pp2hits[],  \
				     char *seqlimit, RUNDATA *rundataptr, HIT_SCORE *scoreptr, int  hit1Total, int hit2Total ) ;

/* global variables and arrays */
int DEBUG_LEVEL = 1;		/* =1 => output up/downstream sequence =2 or 3 are very verbose */
TEST *testPtrTable[FEATURENUM] = {NULL};
PASS_HIT *pp1hits[ALLOWEDHITS];
PASS_HIT *pp2hits[ALLOWEDHITS];
RUNDATA *rundataptr;
HIT_SCORE *scoreptr; /* pointer to struct for storing scores for all tests of current hit */
int         watson_only = FALSE;          /* Flag: when set only test + strand          */
int         crick_only = FALSE;          /* Flag: when set only test - strand          */
int         quiet = FALSE;          /* "Quiet" Flag: when set, run data not sent to output     */
int         command_line_target_number = -1 ;          /* Override descriptor file number_of_targets at command line     */
float totalScoreCutoff = USEDESCRIPTORVALUE; /* set in descriptor file; can be overridden on command line */
char *targetfile = "targets/knownsno_sites.targ" ; /* default target-filename */
char *scoretablefile = "scoretables/26snos_with_HACA.5_20" ; /* default "score-table" filename */
char *fastaOutfile = "results/pseudoU_fa/hits.fa" ; /* default fasta output filename */

int
main(int argc, char **argv)
{
  SQFILE     *dbfp;             /* ptr to dbfile, opened for sequential read */
  int         fmt;              /* format of dbfile (kEMBL, kPearson, etc.)  */
  char       *queryseq;         /* current sequence-segment being searched           */
  int         seg_no ;          /* index of segment within query sequence    */
  int         seg_offset ;      /* start position of curr. segment in sequence */
                                /* maximum segment length (default = 100000) */
  int         maxSegLen = MAX_SEG_LEN ;
  int         seg_len ;         /* length of current segment                 */
  int         strand ;          /* strand index (0 => + , 1 => - )           */
  char       *entireSeq;           /* pointer to entire sequence to be searched   */
  char       *tempSeq;          /* temporary sequence pointer                */

  time_t start_time, end_time;
  double diff_time;

  int type1;
  int type2;
  int i = 0; 
  int j= 0;
  char *seqlimit   ;  /* largest position in query sequence that could still have a hit */
  char *seqlimit2   ;  /* largest position in query that could have relevant pass 2 hit */
  TEST *testptr[MAXTESTNUM] = {NULL};  
  TEST *test1ptr[MAXPPTESTNUM]  = {NULL};   /* Test struct for Preprocessor Pass 1 */
  TEST *test2ptr[MAXPPTESTNUM]  = {NULL};   /* Test struct for Preprocessor Pass 2 */

  FILE       *descfp;           /* ptr to descfile, opened for read          */
  FILE       *targetfp;           /* ptr to targetfile, opened for read          */

  char *descfile; /* hardcode name for now */
  char *dbfile =  "Sc-ACAs.fa" ; /* hardcode query-filename for now */

  TARGET *targetptr[MAXTARGETNUM] = {NULL};
  
  int hit1Total =0 ;
  int hit2Total = 0;
  
  for (i = 0; i < ALLOWEDHITS; i++)  pp1hits[i]  = DEBUGMALLOC(1, sizeof(PASS_HIT)); 
  for (i = 0; i < ALLOWEDHITS; i++)  pp2hits[i]  = DEBUGMALLOC(1, sizeof(PASS_HIT));

  /***********************************************
   * Parse command line and descriptor file
   * Then build list of tests to perform
   ***********************************************/

  parseCommandline(argc, argv, &descfile, &dbfile);

  if (quiet == FALSE) {
    start_time = time(NULL);
    fprintf( stdout, "## Starting time: %s \n", asctime(localtime(&start_time)) ); 
    fprintf( stdout, "## Descriptor File: %s \n", descfile);
    fprintf( stdout, "## Target File: %s \n", targetfile);
    fprintf( stdout, "## Score-Tables File: %s \n", scoretablefile );
    fprintf( stdout, "## Search File: %s \n", dbfile );
  }
  if ((descfp = fopen(descfile, "r")) == NULL) {
    fprintf( stderr, "Failed to open descriptor file %s for reading\n", descfile);
    assert(0) ;
  }
  rundataptr = newRunData(descfp, totalScoreCutoff);
  /*  Set number of targets if over-ridden on command line */
  if ( command_line_target_number > -1 ) {
    rundataptr->numberOfTargets = command_line_target_number ; 
  }
  assert( rundataptr->numberOfTargets < MAXTARGETNUM);
  if ((rundataptr->fastaOutFilePtr = fopen(fastaOutfile, "w")) == NULL) {
    fprintf( stderr, "Failed to open outputfile %s for writing\n", fastaOutfile );
    assert(0) ;
  }

  scoreptr = DEBUGMALLOC(1, sizeof(HIT_SCORE)); 
  memset(scoreptr, 0, sizeof(HIT_SCORE));  /* initialization needed */
  scoreptr->Patterns[HACA] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[ACA] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[H] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[POST_ACA] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[XSTEM] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->PatternsRight[XSTEM] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[ISTEM] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->PatternsRight[ISTEM] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[XSTEM2] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->PatternsRight[XSTEM2] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->Patterns[ISTEM2] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  scoreptr->PatternsRight[ISTEM2] = DEBUGMALLOC(PATTERNMAX, sizeof(char) );
  for (i = 0; i < ALLOWED_HACA2_HITS; i++)  scoreptr->HACA2hits[i]  = DEBUGMALLOC(1, sizeof(PASS_HIT)); 
  loadScoreTables(scoretablefile);

  
  if ( rundataptr->run_type_flag != SIMPLE ) 
    {for (i = 0; i < rundataptr->numberOfPP1Tests; i++) {
      test1ptr[i] = newTestFromDescriptor(descfp, i);
      testPtrTable[test1ptr[i]->feature] = test1ptr[i];
    }
    }
  if ( rundataptr->run_type_flag == PRE2 )   {
    for (i = 0; i < rundataptr->numberOfPP2Tests; i++) {
      test2ptr[i] = newTestFromDescriptor(descfp, i);
      testPtrTable[test2ptr[i]->feature] = test2ptr[i];
    }
  }
  for (i = 0; i < rundataptr->numberOfTests; i++) {
    testptr[i] = newTestFromDescriptor(descfp, i);
    testPtrTable[testptr[i]->feature] = testptr[i];
  }

  if ((targetfp = fopen(targetfile, "r")) == NULL) {
    fprintf( stderr, "Failed to open target file %s for reading\n", targetfile);
    assert(0) ;
  }
  for (i = 0; i < rundataptr->numberOfTargets; i++) {
    targetptr[i] = newTarget(targetfp, rundataptr);
  }

  if (quiet == FALSE) {
    if ( rundataptr->run_type_flag != SIMPLE ) {
      for (i = 0; test1ptr[i] != NULL; i++) {
	fprintf( stdout,  "## Preprocess-1 Test: %d\t", i);
	writeTestRequirements(test1ptr[i]);
      }
    } 

    if ( rundataptr->run_type_flag == PRE2 ) {
      for (i = 0; test2ptr[i] != NULL; i++) {
	fprintf( stdout,  "## Preprocess-2 Test: %d\t", i);
	writeTestRequirements(test2ptr[i]);
      } 
      fprintf( stdout,  "## Overall cutoff Score: %.2lf\t", rundataptr->totalScoreCutoff);
      fprintf( stdout,  "Min gap: %d\t Max gap: %d\n", rundataptr->MinIntervals[stem1gap], rundataptr->MaxIntervals[stem1gap]);

    }
    for (i = 0; testptr[i] != NULL; i++) {
      fprintf( stdout,  "## Test: %d\t", i);
      writeTestRequirements(testptr[i]);
    } 
      fprintf( stdout,  "#### \n");
  }

  fprintf( stderr, "Opening query sequence file....\n");

  /***********************************************
   * Open query file
   ***********************************************/
  if (! SeqfileFormat(dbfile, &fmt, "BLASTDB"))
    switch (squid_errno) {
    case SQERR_NOFILE:
      PRINTLINENUM;
      Die("Sequence file %s could not be opened for reading", dbfile); break;
    case SQERR_FORMAT:
    default:
      Die("Failed to determine format of sequence file %s\n", dbfile);
    }
  if ((dbfp = SeqfileOpen(dbfile, fmt, "BLASTDB")) == NULL)
    Die("Failed to open sequence file %s for reading", dbfile);

  /***********************************************
   * Read a sequence from query file 
   ***********************************************/
  while (  ReadSeq(dbfp, fmt, &entireSeq, &rundataptr->sqinfo) ) {
    s2upper(entireSeq);
    ToDNA(entireSeq);		/* Can be omitted for speed when we know we're looking at DNA */
    rundataptr->entireSeq = entireSeq;  /* save seq pointer in rundata struct */
    rundataptr->candidate_number = 0;

    /***********************************************
     *  Extract next segment
     ***********************************************/

    for (seg_no=0; (seg_no * maxSegLen) < rundataptr->sqinfo.len; seg_no++) {
      fprintf( stderr,  "Searching seq: %s\tSegment: %d\t", rundataptr->sqinfo.name, seg_no );
      seg_offset = seg_no * maxSegLen ;

      seg_len = MIN(maxSegLen + SEG_OVERLAP, rundataptr->sqinfo.len - seg_offset);
      queryseq = (char *) DEBUGMALLOC((seg_len + 1) , sizeof(char));

      for (strand=0; strand <= 1; strand++) {
	
	if ( (watson_only == 1) && (strand == 1)) {continue;};
	if ( (crick_only == 1)  && (strand == 0))  {continue;};

	if (strand == 0) {
	  rundataptr->strand = 'W';
	  rundataptr->segmentOffset = seg_offset  ;	/* used for display of genomic hit position */
	  queryseq = SubStr(entireSeq, seg_offset, seg_len, queryseq);
	}
	else {
	  rundataptr->strand = 'C';
	  rundataptr->segmentOffset = seg_offset + seg_len  ;/* used for display of genomic hit position */
	  tempSeq = (char *) DEBUGMALLOC((seg_len + 1) , sizeof(char));
	  tempSeq = SubStr(entireSeq, seg_offset, seg_len, tempSeq);
	  queryseq = revcomp(queryseq, tempSeq);
	  DEBUGFREE(tempSeq, (seg_len + 1) * sizeof(char));
	}
	rundataptr->querySeq = queryseq;  /* save seq segment pointer in rundata struct */
	rundataptr->segment_length = strlen(queryseq);  /* save seq segment pointer in rundata struct */

	seqlimit = queryseq + strlen(queryseq) - MAXRIGHTHITLENGTH ;
	if ( rundataptr->run_type_flag == PRE2 ) { 
	  seqlimit2 = seqlimit;	/* rightmost position of right complement feature */
	  seqlimit -= rundataptr->MinIntervals[stem1gap];    /* rightmost position of left complement feature */  
	}

	fprintf( stderr, "Searching on strand: %c ...\n",\
		 rundataptr->strand );

	j = 0; 
	do {   /* target loop */
	  /*	for (j = 0; targetptr[j] != NULL; j++) {   */
  
	  rundataptr->currentTarget = targetptr[j]; 
  
	  /* load the target pattern in all relevant tests */
	  if ( (j/25) == 0) {  /* Only update progress only for first 25 targets */
	    fprintf( stderr, "Searching for target[%d] of %d: %s %s ...\n",\
		     j+1, rundataptr->numberOfTargets, targetName(targetptr[j]) , targetptr[j]->snoAssign);
	  }
	  for (i = 0; testptr[i] != NULL; i++) {
	    loadTargetPattern(testptr[i], targetptr[j]);
	  }
	  if( rundataptr->run_type_flag != SIMPLE) {
	    for (i = 0; test1ptr[i] != NULL; i++) {loadTargetPattern(test1ptr[i], targetptr[j]);}
	  }
	  if( rundataptr->run_type_flag == PRE2) {
	    for (i = 0; test2ptr[i] != NULL; i++) {loadTargetPattern(test2ptr[i], targetptr[j]);}
	  }
 
	  switch (rundataptr->run_type_flag) {
	  case SIMPLE:
	    runAllTestsSimple(testptr, queryseq, seqlimit) ;
	    break;
	  case PRE1:
	    /* Only need to run preprocessor pass once if pp test is target independent  */
	    type1 = getType(test1ptr[0]);
	    if (type1 == LEFT_MATCH_TARGET || type1 == RIGHT_MATCH_TARGET || j == 0) { 
	      hit1Total = runPreprocessTest(test1ptr, scoreptr, pp1hits, queryseq, seqlimit, rundataptr->startSearchPos);
	    }
	    runAllTestsFromHitList(testptr, queryseq, pp1hits, test1ptr, seqlimit, hit1Total) ;
	    break;
	  case PRE2:
	    /* Only need to run preprocessor pass once if pp test is target independent  */
	    type1 = getType(test1ptr[0]);
	    if (type1 == LEFT_MATCH_TARGET || type1 == RIGHT_MATCH_TARGET || j == 0) { 
	      hit1Total = runPreprocessTest(test1ptr, scoreptr, pp1hits, queryseq, seqlimit, rundataptr->startSearchPos);
     
#if DEBUG > 0
	      if (DEBUG_LEVEL > 2) {
		fprintf( stderr, "Pass one hit-total: %d\n leftComp hits at: ", hit1Total );
		for (i = 0; i < hit1Total; i++) fprintf( stderr, " %d ", pp1hits[i]->fendpos - queryseq );
		fprintf( stderr, "\n");
	      }
#endif
	    }
	    type2 = getType(test2ptr[0]);
	    if (type2 == LEFT_MATCH_TARGET || type2 == RIGHT_MATCH_TARGET || j == 0) { 
	      hit2Total = runPreprocessTest(test2ptr, scoreptr, pp2hits, queryseq, seqlimit2, rundataptr->startSearchPos);
#if DEBUG > 0
	      if (DEBUG_LEVEL > 2) {
		fprintf( stderr, "Pass two hit-total: %d\n rightComp hits at: ", hit2Total );
		for (i = 0; i < hit2Total; i++) fprintf( stderr, " %d ", pp2hits[i]->fpositionA - queryseq );
		fprintf( stderr, "\n");
	      }
#endif
	    }
	    runAllTestsFrom2HitLists(testptr, queryseq, test1ptr, test2ptr, \
				     pp1hits, pp2hits, seqlimit, rundataptr, scoreptr, hit1Total, hit2Total) ;
	    break;
	  default:
	    assert (0);
	  }   /* end switch */
	  j++ ;  /* increment target pointer */
	}  while (targetptr[j] != NULL); /* end target loop */
      }  /* end strand loop */
      DEBUGFREE(queryseq, (seg_len + 1) *  sizeof(char));
    }  /* end sequence segment loop */
    FreeSequence(entireSeq, &rundataptr->sqinfo);
  } /*  end read queries loop */
  
  fprintf( stderr,  "Finishing search... \n" );
  
  /* Free up Test structures.  */
  for (i = 0; test1ptr[i] != NULL; i++) freeTest(test1ptr[i]);
  for (i = 0; test2ptr[i] != NULL; i++)freeTest(test2ptr[i]);
  for (i = 0; testptr[i] != NULL; i++) freeTest(testptr[i]);
  for (i = 0; targetptr[i] != NULL; i++) freeTarget(targetptr[i]);
  freeRunData(rundataptr);
  DEBUGFREE(scoreptr->Patterns[HACA], PATTERNMAX * sizeof(char)) ;
  DEBUGFREE(scoreptr, sizeof(HIT_SCORE)) ;

  SeqfileClose(dbfp);		/* should  close descriptor, fasta out & target files too */

  if (quiet == FALSE) {
    end_time = time(NULL);
    diff_time = difftime(end_time, start_time);
    fprintf( stdout, "## Elapsed time (minutes): %f \n", diff_time / 60.); 
  }
  return (0);
}

/************** End of main ***************************/

/* Run all tests for "single pass" (ie no preprocessing) run */
static 
void runAllTestsSimple(TEST *testptr[], char *queryseq, char *seqlimit) {
  char *seqptr;    /* pointer to current place in query sequence */
  char *savpos;	/* save position of start of current search */
  int status;
  int i;

  seqptr = queryseq;
  while (seqptr < seqlimit) {
    savpos = seqptr;
    for (i = 0; testptr[i] != NULL; i++) {
      status = runTest(testptr[i], scoreptr, rundataptr, seqptr, 0, 0);
      assert (status == TEST_PASSED || status == TEST_FAILED);
      if (status == TEST_FAILED ) { break;}
      seqptr += getFoundLength(testptr[i]) + getOffset(testptr[i]) + getDither(testptr[i]);
    }
    if (testptr[i] == NULL) { /* Made it to end of list => Passed all tests */
      for (i = 0; testptr[i] != NULL; i++) { 
	writeTestResults(testptr[i], queryseq);
      }
      fprintf( stderr, "\n");
    } 
    seqptr = savpos + 1; /* Backup to start of last search */
  }
}

/* Run tests for preprocessing pass*/

static 
int runPreprocessTest(TEST *test1ptr[], HIT_SCORE *scoreptr, PASS_HIT *pphits[], \
		      char *queryseq, char *seqlimit,int startSearchPos ) {

  char *seqptr;    /* pointer to current place in query sequence */
  char *savpos;	/* save position of start of current search */
  int status;
  int i;
  int hitIndex = 0;

  seqptr = queryseq + startSearchPos ;
  while (seqptr < seqlimit) {
    savpos = seqptr;
    for (i = 0; test1ptr[i] != NULL; i++) {
      status = runTest(test1ptr[i], scoreptr, rundataptr, seqptr, 0, 0);
      assert (status == TEST_PASSED || status == TEST_FAILED);
      if (status == TEST_FAILED ) { break;}
      seqptr += getFoundLength(test1ptr[i]) + getOffset(test1ptr[i]) + getDither(test1ptr[i]); 
    }
    if (test1ptr[i] == NULL) { /* Made it to end of list => Passed all tests */

      if (scoreptr->HACAs_per_RCompl_totalhitcounter == 0) {
         assert (hitIndex < ALLOWEDHITS);
	 if ( test1ptr[1] != 0) {
         addHit(pphits[hitIndex], test1ptr[0], test1ptr[1]->fposition, seqptr);
	 } else {
         addHit(pphits[hitIndex], test1ptr[0], NULL, seqptr);
	 }
         hitIndex++;
      } else {
        for (i=0; i< scoreptr->HACAs_per_RCompl_totalhitcounter; i++) {
         assert (hitIndex < ALLOWEDHITS);
         addHit(pphits[hitIndex], test1ptr[0], scoreptr->HACAs_per_RCompl[i], scoreptr->HACAs_per_RCompl[i] + HACALENGTH);
         hitIndex++;
        }
        scoreptr->HACAs_per_RCompl_totalhitcounter = 0;
      }   
    }
    seqptr = savpos + 1; /* Backup to start of last search */
  }
  return hitIndex;  /* return total number of hits found */
}  

/* Run all tests for final run after single preprocessing pass*/
static 
void runAllTestsFromHitList(TEST *testptr[], char *queryseq, PASS_HIT *pp1hits[],\
			    TEST *test1ptr[], char *seqlimit, int  hit1Total) {

  char *seqptr;    /* pointer to current place in query sequence */
  char *savpos;    /* save pointer to (end) of current pp hit position */
  int status;
  int i ;    /* test list index */
  int hitindex = 0;   /* index of hit from preprocessor Pass */

  while (hit1Total > hitindex) {
    seqptr = getHitEndPosition(pp1hits[hitindex]);
    savpos = seqptr;
    if (seqptr > seqlimit) return; /* too near end of sequence; don't need to check */
    for (i = 0; testptr[i] != NULL; i++) {
      status = runTest(testptr[i], scoreptr, rundataptr, seqptr, 0, 0);
      assert (status == TEST_PASSED || status == TEST_FAILED);
      if (status == TEST_FAILED ) { break;}
      seqptr += getFoundLength(testptr[i]) + getOffset(testptr[i]) + getDither(testptr[i]);
    }
    if (testptr[i] == NULL) { /* Made it to end of list => Passed all tests */
      writePassResults(pp1hits[hitindex], test1ptr[0], test1ptr[1], queryseq) ;
      for (i = 0; test1ptr[i] != NULL; i++) writeTestResults(test1ptr[i], queryseq);
      for (i = 0; testptr[i] != NULL; i++) writeTestResults(testptr[i], queryseq);
    }   
    hitindex++ ;  /*  search at next possible position*/
  }  /* end hitlist loop */
}  /* end subroutine */


/* Run all tests for final run after 2 preprocessing passes*/
static 
void runAllTestsFrom2HitLists(TEST *testptr[], char *queryseq, \
			      TEST *test1ptr[], TEST *test2ptr[], PASS_HIT *pp1hits[], PASS_HIT *pp2hits[],  \
			      char *seqlimit, RUNDATA *rundataptr, HIT_SCORE *scoreptr, int  hit1Total, int hit2Total ) {

  char *seqptr;    /* pointer to current place in query sequence */
  char *seq2ptr;    /* pointer to place in query sequence where preprocessor pass 2 found hit */
  char *savpos;    /* save pointer to (end) of current pp hit position */
  char *seq2limit   ;  /* largest position in query sequence that could still be position of hit from pp pass 2 */
  int status;
  int i ;    /* test list index */
  int hit1index = 0;   /* index of hit from preprocessor Pass 1*/
  int hit2index = 0;   /* index of hit from preprocessor Pass 2*/
#if DEBUG > 0
  int    hit1position;	/* only used in debug */
  int    hit2position;    /* only used in debug */
#endif
  seq2limit = seqlimit + rundataptr->MinIntervals[stem1gap];   /* furtherest possible position of post-gap pattern */ 
  for (hit1index = 0; hit1Total > hit1index; hit1index++ ) {
    seqptr = getHitEndPosition(pp1hits[hit1index]);
    savpos = seqptr;
    if (seqptr > seqlimit) return; /* too near end of sequence; don't need to check */
    for (hit2index = 0; hit2Total > hit2index; hit2index++ ) {
      scoreptr->H_or_ACA = '\0';	/* reset flag 10/22/02 */
      scoreptr->totalScore = 0;
      scoreptr->totalScoreStem1 = 0;
      for (i = 0; i < FEATURENUM; i++) {
	scoreptr->Scores[i] = 0 ;
	scoreptr->IntervalScores[i] = 0 ;
      }	/* reset scores 10/22/02 */
      seq2ptr = getHitStartPosition(pp2hits[hit2index]);
      scoreptr->Intervals[stem1gap] = (seq2ptr - savpos); 
      if (scoreptr->Intervals[stem1gap] < rundataptr->MinIntervals[stem1gap] ) continue;
      if (scoreptr->Intervals[stem1gap] > rundataptr->MaxIntervals[stem1gap] ) break;
      if (seq2ptr > seq2limit) {
#if DEBUG > 0
	if (DEBUG_LEVEL > 2 ) fprintf( stderr, "DEBUG: PASS 2 hit too near end of sequence \n");
#endif
	break;
      } /* too near end of sequence; don't need to check */
      scoreptr->totalScore = 0;	/* initialize total scores for next candidate */
      scoreptr->totalScoreStem1 = 0;	/* initialize total scores for next candidate */
      scoreptr->Scores[H] = 0;	/* initialize score as flag for next candidate (kludgey) */
      for (i = 0; testptr[i] != NULL; i++) {
	status = runTest(testptr[i], scoreptr, rundataptr, seqptr, hit1index, hit2index);
	assert (status == TEST_PASSED || status == TEST_FAILED);
	if (status == TEST_FAILED ) { 
#if DEBUG > 0
	  if (DEBUG_LEVEL > 2 ) { 
	    hit1position = savpos - rundataptr->querySeq;
	    hit2position = seq2ptr - rundataptr->querySeq;
	    fprintf( stderr, "DEBUG: For Left hit at %d and Right hit at %d, test for feature %s failed \n", \
		     hit1position, hit2position, getFeatureName(testptr[i]) );
	  }
#endif
	  break;
	}
	seqptr += getFoundLength(testptr[i]) + getOffset(testptr[i]) + getDither(testptr[i]);
      }
      if (testptr[i] == NULL) { /* Made it to end of list => Passed all tests */
#if DEBUG > 0
	if (DEBUG_LEVEL > 4 ) { 
	  writePassResults(pp1hits[hit1index], test1ptr[0], test1ptr[1], queryseq) ;
	  writePassResults(pp2hits[hit2index], test2ptr[0], test2ptr[1], queryseq) ;
	  for (i = 0; testptr[i] != NULL; i++) writeTestResults(testptr[i], queryseq);
	  fprintf( stderr, "\n");
	}
#endif
      }   
    }  /* end hit2list loop */
  }  /* end hit1list loop */
}  /* end subroutine */

/* Function: parseCommandline()
 *
 * Purpose: Modify global parameters as indicated by command line options
 *
 * Args:  argc, argv
 *
 * Return:  none
 */

static void
parseCommandline(int argc, char **argv, char **descfileptr, char **dbfileptr) {
  char *optname;                /* ptr to option name */
  char *optarg;
  int   optind;

  static struct opt_s OPTIONS[] = {
    { "-W", TRUE, ARG_NONE },
    { "-C", TRUE, ARG_NONE },
    { "-q", TRUE, ARG_NONE },
    { "-h", TRUE, ARG_NONE },
    { "-D", TRUE, ARG_INT },
    { "-t", TRUE, ARG_INT },
    { "-S", TRUE, ARG_FLOAT },
    { "-T", TRUE, ARG_STRING },
    { "-F", TRUE, ARG_STRING },
    { "-L", TRUE, ARG_STRING },
  };
#define NOPTIONS (sizeof(OPTIONS) / sizeof(struct opt_s))

  static char usage[] = "\
Usage: pseudoU_test [-options]  <sequence-file> <descriptor file> \n\
\n\
  Available options: \n\
     -h:    print short help and usage info\n\
     -D:    set DEBUG LEVEL (=0, 1 or 2) \n\
     -S:    set overall score cutoff (float) \n\
     -T:    set target-file-name  \n\
     -F:    set fasta hit-outfile [def: results/pseudoU_fa/hits.fa] \n\
     -t:    set number of targets to read from target file (int)  \n\
     -L:    load custom score-tables (score-tables file-name)  \n\
     -W:    test 'Watson' strand only \n\
     -C:    test 'Crick' strand only \n\
     -q:    'quiet' mode: header data *not* sent to output \n\
";

  while (Getopt(argc, argv, OPTIONS, NOPTIONS, usage,
		&optind, &optname, &optarg))
    {
      if      (strcmp(optname, "-W") == 0) {
	watson_only = TRUE;
      } 
      else if      (strcmp(optname, "-C") == 0) {
	crick_only = TRUE ;
      } 
      else if      (strcmp(optname, "-q") == 0) {
	quiet = TRUE ;
      } 
      else if (strcmp(optname, "-D") == 0) {
	DEBUG_LEVEL = atoi(optarg);
      }
      else if (strcmp(optname, "-t") == 0) {
	command_line_target_number  = atoi(optarg);
      }
      else if (strcmp(optname, "-S") == 0) {
	totalScoreCutoff = atof(optarg);
      }
      else if (strcmp(optname, "-T") == 0) {
	targetfile  = optarg;
      }
      else if (strcmp(optname, "-L") == 0) {
	scoretablefile  = optarg;
      }
      else if (strcmp(optname, "-F") == 0) {
	fastaOutfile  = optarg;
      }
      else if (strcmp(optname, "-h") == 0) {
	puts(usage);
	exit(EXIT_SUCCESS);
      }
      else {
	Die("Unknown option: %s\n%s", optname, usage);
      }
    }
  if (argc - optind != 2) {
    PRINTLINENUM;
    Die("Incorrect number of arguments\n%s", usage);
  }
  *dbfileptr   = argv[optind++];
  *descfileptr   = argv[optind++];
  if ((watson_only == 1) && (crick_only == 1)) {
    Die("Can't request watson strand only and crick strand only!\n%s", usage);
  }
    
}

  
  
  

