#!/bin/sh
perl -w scripts/sortHits.pl -e AJ609480 results/expected/H_sapiens.demo.sorted stdout | \
perl -w scripts/makeGuideMaps.pl -s -l 6 -t targs/H_sapiens/all_Us.targ stdin results/guideDemo.txt
cat results/guideDemo.txt
