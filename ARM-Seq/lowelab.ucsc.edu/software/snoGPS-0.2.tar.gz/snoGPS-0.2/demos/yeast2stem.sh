#!/bin/sh
snoGPS -D 0 -S 15 -W -t 44 -L scoretables/haca2stemv7.tables -T targs/S_cerevisiae/allsites.targ -F /dev/null data/S_cerevisiae/snoseqs.fa desc/haca2stemv4a.desc >results/yeast2stem.demo
perl -w scripts/sortHits.pl -T 1 -f -p 8 results/yeast2stem.demo results/yeast2stem.demo.sorted
grep '>' results/yeast2stem.demo.sorted 