#!/bin/sh
perl -w scripts/runMafHomologs.pl -t targs/H_sapiens -d desc/MamGUs2.v3.desc -l scoretables/human.v3.scoretables data/H_sapiens/ACA30.maf H_sapiens_LSU.U4633
perl -w scripts/runMafHomologs.pl  -t targs/H_sapiens -d desc/MamGUs2.v3.desc -l scoretables/human.v3.scoretables data/H_sapiens/ACA52.maf H_sapiens_LSU.U1723
perl -w scripts/runMafHomologs.pl  -t targs/H_sapiens -d desc/MamGUs2.v3.desc -l scoretables/human.v3.scoretables data/H_sapiens/ACA14.maf H_sapiens_SSU.U966
mv data/H_sapiens/*.aln data/H_sapiens/*.homolHits results/
cat results/ACA30.aln  results/ACA52.aln results/ACA14.aln > results/demo.tmp.aln
perl  scripts/scoreAlns.pl -m hg -v results/demo.tmp.aln stdout | perl  scripts/sortAlns.pl -m hg stdin results/hmr.demo.aln
cat results/hmr.demo.aln
rm results/demo.tmp.aln