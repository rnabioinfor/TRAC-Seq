#!/bin/sh
perl -w scripts/getRnaTargets.pl -n data/H_sapiens/Hu-18S.fa results/makeTargetsDemo.targ
head -20 results/makeTargetsDemo.targ

