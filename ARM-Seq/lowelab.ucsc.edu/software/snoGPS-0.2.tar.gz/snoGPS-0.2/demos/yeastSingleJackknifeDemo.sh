#!/bin/sh
perl -w scripts/pseudoU_train_and_test.pl -G targs -k S_cerevisiae/snR003 -a newtrain.yeast.v2.data -d haca2stemv4a.jack -o Scerev -s haca2stemv7.tables -i train_and_test.yeast.v4.sites results/snR003-jack.demo
# clean up
rm eraseme*
mv scoretables/scoretable.temp results/noSnr003.scoretable.demo
