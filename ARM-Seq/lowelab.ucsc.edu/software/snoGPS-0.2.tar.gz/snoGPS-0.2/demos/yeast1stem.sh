#!/bin/sh
snoGPS -D 0 -S 12 -W -t 44 -L scoretables/haca2stemv7.tables -T targs/S_cerevisiae/allsites.targ -F /dev/null data/S_cerevisiae/snoseqs.fa desc/hacaNv4a.desc >results/yeast1stem.demo
perl -w scripts/sortHits.pl -T 1 -f -p 8 results/yeast1stem.demo results/yeast1stem.demo.sorted
grep '>' results/yeast1stem.demo.sorted 