#!/bin/sh
snoGPS -D 0 -S 25 -W -t 136 -L scoretables/human.v3.scoretables  -F /dev/null -T targs/H_sapiens/snAndRrna.targ data/H_sapiens/mammalianSnos.hg.fa desc/MamGUs2.v3.desc >results/H_sapiens.demo
perl -w scripts/sortHits.pl -T 1 -f -p 9 results/H_sapiens.demo results/H_sapiens.demo.sorted
grep '>' results/H_sapiens.demo.sorted 
