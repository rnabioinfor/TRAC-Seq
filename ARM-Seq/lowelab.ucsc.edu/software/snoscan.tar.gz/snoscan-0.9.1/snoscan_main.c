/* snoscan  - methylation guide snoRNA search program
 *
 * by Todd MJ Lowe    v. 0.1       12/08/96
 *                    v. 0.9 beta  02/19/99
 *                    v. 0.9.1     04/26/17 - updates squid library (SRE)
 *
 * copyright 1999 by T. Lowe
 *
 * Uses Sean Eddy's function library for biological sequence analysis
 * (Squid v1.5.11)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "squid.h"
#include "snoscan.h"

char snoscan_version[] = "0.9.1";
char snoscan_date[]    = "26 Apr 2017";

#define OPTIONS "ho:VX:c:l:C:D:m:M:d:p:Os"
char usage[] = "\n\
Usage: snoscan [-options] <rRNA sequence file> <query sequence file>\n\
Find snoRNA genes containing rRNA complementarity\n\
and C & D boxes\n\n\
Available options:\n\
-h             : help - print version and usage info\n\
-m <meth file> : specify methylation sites\n\
-o <outfile>   : save candidates in <outfile>\n\
-s             : save snoRNA sequences with hit info\n\
-l <length>    : set minimim length for snoRNA-rRNA pairing (def=9bp)\n\
-C <Score>     : set C Box score cutoff to <Score>\n\
-D <Score>     : set D prime Box score cutoff to <Score>\n\
-X <Score>     : set final score cutoff to <Score>\n\
-c <score>     : set min score for complementary region match\n\
-d <dist>      : set max distance between C & D boxes\n\
-p <dist>      : set min distance between rRNA match & \n\
                 D box when D prime box is present (def=10bp)\n\
-O             : use original C-D distance scoring\n\
-M <integer>   : set max distance to known meth site (Def=0)\n\
-V             : verbose output\n";

char *dbseqs[MAX_DBSEQS],       /* array of pointers to all "database"
				   sequences */
  *idbseqs[MAX_DBSEQS];      /* array of pointers to all
				integer-encoded db seqs */
 
SQINFO dbseqinfo[MAX_DBSEQS];

int OutputSeqs;         /* print snoRNA sequence along with hit info */


int
main (int argc, char **argv)
{
  char  *seqfile;               /* file containing query seqs */
  char  *dbfile;                /* contains rRNA seq(s) to search for
				   homology */
  char  *outfile;               /* destination file for snoRNAs   */
  int    seqfmt, dbfmt;	        /* format of seqfile  */

  FILE  *outfp;              /* output file  */

  FILE  *methfp;             /* Methylation site info file */
  char  *methfile;           /* name of methylation info file */
  
  SQFILE   *seqfp, *dbfp;  
  SQINFO   sqinfo;
  
  PARAM_TYPE Params;    /* Search parameters */
  
  STATS_TYPE Stats;     /* Search statistics */

  HIT_TYPE Hit;         /* snoRNA hit info */

  METH_SITE_TYPE meth_list[MAX_METH_SITES];  /* methylation sites */

  int errno, ct;

  int VerbMode; 
  
  int UseMeth;          /* flag: Use methylation data? (y/n) */
  int num_methsites;

  int Search_CD_first = 1;  /* search for C/D box first */

  char 
    *orig_seq, 
    *seq, 
    *newseq,                  /* query sequence  */
    *iseq;                    /* encoded seq */
  
  char *dbseq;                    /* current db seq */

  char *dbseq_name;

  int dbseqct;
  
  int strand;                  /* strandedness of current seq:
				  WATSON, REV_WATSON, CRICK, REV_CRICK  */
  
  int          optchar;
  extern char *optarg;
  extern int   optind;

  /***********************************************
   * Parse command line
   ***********************************************/

  outfile    = NULL;
  methfile   = NULL;
  UseMeth    = FALSE;
  VerbMode   = 0;
  OutputSeqs = FALSE;

  Params.Old_dist_scoring = FALSE;

  Params.MaxGap      = DEF_MAXGAP;;
  Params.MaxMethDist = DEF_MAX_METH_DIST;
  Params.MinMatch    = DEF_MIN_MATCH;
  Params.MaxCDdist   = DEF_MAX_CD_DIST;
  Params.MinD_Dp_Boxdist = MIN_MATCH_DPBOX_DIST;

  Params.CBoxCutoff   = CBOX_CUTOFF;
  Params.DPrimeCutoff = DPRIME_BOX_CUTOFF;
  Params.ComplCutoff  = DEF_MIN_COMPL_SCORE; 
  Params.FinalCutoff  = FINAL_SCORE_CUTOFF; 

  while ((optchar = getopt(argc, argv, OPTIONS)) != -1)
    switch (optchar) {

    case 'o': outfile    = optarg; break;
    case 'm': methfile   = optarg; UseMeth = TRUE;  break;
    case 'h': 
      printf("snoscan %s, %s\n%s\n", snoscan_version, snoscan_date, usage);
      exit(EXIT_SUCCESS);
    case 'X': Params.FinalCutoff   = atof(optarg); break;
    case 'c': Params.ComplCutoff   = atof(optarg)*BIT_NAT_CONV; break;
    case 'C': Params.CBoxCutoff    = atof(optarg); break;
    case 'D': Params.DPrimeCutoff  = atof(optarg); break;
    case 'M': Params.MaxMethDist   = atoi(optarg); break;
    case 'l': Params.MinMatch      = atoi(optarg); break;
    case 'd': Params.MaxCDdist     = atoi(optarg); break;
    case 'p': Params.MinD_Dp_Boxdist  = atoi(optarg); break;
    case 'O': Params.Old_dist_scoring = TRUE;         break;
    case 'V': VerbMode         = TRUE;  break;
    case 's': OutputSeqs         = TRUE;  break;
    default:
      Die("%s\n", usage);
    }

  if (Params.MinMatch < 1) {
    Die("Length of minimum database match must be above 0.\n%s\n", usage);
  }

  if (argc -optind != 2)
    Die("Wrong number of arguments specified on command line\n%s\n", usage);

  dbfile = argv[optind];
  seqfile = argv[optind+1];

  if (outfile == NULL)
    outfp = stdout;
  else if ((outfp = fopen(outfile, "w")) == NULL)
    Die("Failed to open snoRNA output file %s", outfile);

  if (UseMeth) 
    if ((methfp = fopen(methfile, "r")) == NULL) {
      Die("Failed to open methylation info file %s", methfile);
    }
  

  /***********************************************
   * Determine seq format & open for reading     *
   ***********************************************/

  if (! SeqfileFormat(dbfile, &dbfmt, NULL))
    Die("Can't determine format of file %s\n", dbfile);
  if ((dbfp = SeqfileOpen(dbfile, dbfmt, NULL)) == NULL)
    Die("Failed to open sequence file %s for reading", dbfile);

  if (! SeqfileFormat(seqfile, &seqfmt, NULL))
    Die("Can't determine format of file %s\n", seqfile);
  if ((seqfp = SeqfileOpen(seqfile, seqfmt, NULL)) == NULL)
    Die("Failed to open sequence file %s for reading", seqfile);


  /* Read all DB seqs into memory */
  dbseqct = 0;
  Stats.tot_dblen = 0;

  while (ReadSeq(dbfp, dbfmt, &(dbseqs[dbseqct]), &(dbseqinfo[dbseqct]))) {
    ToRNA(dbseqs[dbseqct]);
    s2upper(dbseqs[dbseqct]);
    Stats.tot_dblen += dbseqinfo[dbseqct].len;

    if ((iseq = calloc (dbseqinfo[dbseqct].len+2, sizeof(char))) == NULL)
      Die("Memory failure, couldn't allocate integer-encoded sequence\n"); 
    IntEncodeSeq(iseq,dbseqs[dbseqct],dbseqinfo[dbseqct].len);
    idbseqs[dbseqct] = iseq;

    dbseqct++;
  }
  Stats.numdbseqs = dbseqct;
  
  /* Read in methylation data */

  if (UseMeth) {
    if (! ReadMethData(methfp, meth_list, &num_methsites,
		       dbseqinfo, Stats.numdbseqs))
      Die("Can't determine format of meth file %s\n", methfile);
  }
  else 
    num_methsites = 0;


  /* Output run parameters */
  
  PrintRunParams(&Params,outfp);
  
  Stats.basect=0;
  while (ReadSeq(seqfp, seqfmt, &seq, &sqinfo)) {

    Stats.Cbox_ct=0;
    if (VerbMode) 
      fprintf (outfp,"# Seq: %s\n",sqinfo.name);
    
    ToRNA(seq);
    s2upper(seq);
    Hit.qname = sqinfo.name;
    Hit.qlen = sqinfo.len;

    if ((iseq = calloc (sqinfo.len+2, sizeof(char))) == NULL)
      Die("Memory failure, couldn't allocate integer-encoded sequence\n"); 
    

    /* Search reverse (3'->5') orientations of both strands  */
    /*  -1=REV_WATSON=top strand 3'->5'   */
    /*  -2=REV_CRICK=bottom strand 3'->5') */

    for (strand=REV_WATSON; strand >= REV_CRICK; strand--) {
      
      Hit.strand = strand;
      
      if ((newseq = calloc (sqinfo.len+2, sizeof(char))) == NULL)
	Die("Memory failure, couldn't allocate reverse sequence (strand=%d)\n",
	    strand); 
	
      switch (strand) {
      case REV_WATSON: 
	ReverseSeq(newseq,seq);  /* 5'->3' conv to 3'->5'  */
	orig_seq = seq;   /* keep original sequence */
	seq = newseq;
	break;
      case REV_CRICK:
	RevComp(newseq, seq);  /* take rev complement (lower strand) */
	                       /* keeps 3'->5' orientation */
	free(seq);       /* free seq from previous strand analysis */
	seq = newseq;
	break;
      default: 
	Die("Unrecognized strand orientation (%d) for %s\n",strand,
	    sqinfo.name);
      }
    
      Hit.qseq = seq;     

      /* encode search sequence (A=0, C=1, G=2, U/T=3, Other=4) */

      IntEncodeSeq(iseq,seq,sqinfo.len);

      if (Search_CD_first) 
	FindSnos_CD_first(&Hit,&sqinfo,&Params,&Stats,
			  meth_list,num_methsites,iseq,outfp);

      /* Not fully implemented yet */
      else
	FindSnos_match_first(&Hit,&sqinfo,&Params,&Stats,
			     meth_list,num_methsites,iseq,outfp);
      
    }   /* search both strands  */
    
    if (VerbMode) 
      fprintf (outfp,"# Possible C-D box Hits: %d, bases: %d\n",
	       Stats.Cbox_ct,Stats.basect);

    free(orig_seq);
    free(iseq);
    FreeSequence(seq, &sqinfo);
  }
  
  
  for (ct=0; dbseqct < Stats.numdbseqs; ct++) {
    FreeSequence(&(dbseq[ct]),&(dbseqinfo[ct]));
  }
  
  SeqfileClose(dbfp);
  SeqfileClose(seqfp);
  fclose(outfp);
  return 0;
}


