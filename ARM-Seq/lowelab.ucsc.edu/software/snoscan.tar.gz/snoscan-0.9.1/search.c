
/* snoscan  - methylation guide snoRNA search program
 *
 * by Todd MJ Lowe    v. 0.1       12/08/96
 *                    v. 0.9 beta  02/19/99
 *                    v. 0.9.1     04/26/17 - updates squid library (SRE)
 *
 * copyright 1999 by T. Lowe
 *
 * Uses Sean Eddy's function library for biological sequence analysis
 * (Squid v1.5.11)
 *
 *  search.c  - contains snoRNA search functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "squid.h"
#include "snoscan.h"
#include "matrices.h"

char tmp_snoseq[MAX_SNO_LEN];


/* Read the table of known methylation sites specified in the file
   given by the "-m" parameter */

int
ReadMethData (FILE *methfp,
	      METH_SITE_TYPE meth_sites[],
	      int *num_methsites,
	      SQINFO *dbseqinfo,
	      int numdbseqs)
    
{
  char line[MAX_LINE+1];
  char meth_seqname[40];
  
  int ct=0, dbct;

  while ((fgets(line, MAX_LINE, methfp)) != NULL) {
    if (line[0] == '>') {
      sscanf(line, ">%s",meth_seqname);
      dbct=0; 
      while ((dbct < numdbseqs) &&
	     (strcmp(meth_seqname,dbseqinfo[dbct].name)))
	dbct++;
      if (dbct == numdbseqs) {
	Die("Can't find matching dbseq for methylation site seq name %s\n", 
	    meth_seqname);
      }
    }

    if ((sscanf(line, "%1s %d %s\n", &(meth_sites[ct].mod_nuc),
                &(meth_sites[ct].base_num), 
                meth_sites[ct].status)) == 3) {
      meth_sites[ct].seqname = dbseqinfo[dbct].name;
      ct++;
    }
  }
  
  *num_methsites = ct;
  return 1;
}

/* Finds best scoring C box in the given range */

int
FindCBox (char **seq_pos, 
	  char *seq_end,
	  float *score, 
	  float CBoxCutoff)
{
  char *seq_ptr;
  int j, ct, 
    pos, lastpos, Cbox_ct = 0;
  float best_score = -100;
  
  for (seq_ptr=*seq_pos, ct=0; seq_ptr<seq_end; seq_ptr++, ct++) {
    *score = 0;
    for (j=0; j< CBOX_LEN; j++) {
      *score += Sc2_Cbox_Mat[(int)(seq_ptr[j])][j];
    }

    if (*score > best_score) {
      best_score = *score;
      *seq_pos = seq_ptr;
    }

    /*
      if (*score >= CBoxCutoff) {
      Cbox_ct++;
      pos = seq_ptr - *seq_pos;
      printf("C Box # %d: %f at %d  (%d downstream)\n",
      Cbox_ct,*score,pos,pos-lastpos);
      lastpos = pos;
      }
    */

  }

  if (best_score > CBoxCutoff) {
    *score = best_score;
    return 1;
  }
  
  *score = -100;
  return 0;
  
}

/* Finds very next D box (CUGA/AUGA) in sequence */

int
FindNext_DBox(char **seq_pos, char *seq_end, float *DboxSc)
    
{
  char *ptr;
  char *start_ptr;
  long pos, last_pos = 0;

  start_ptr = *seq_pos;
  
  for (ptr=*seq_pos; ptr < seq_end; ptr++) 
    if ((ptr[0] == 'A') && (ptr[1] == 'G') &&
	(ptr[2] == 'U') && ((ptr[3] == 'C') || (ptr[3] == 'A'))) {
	       
      *seq_pos = ptr;

      /*      printf ("D box at %d\n",ptr-start_ptr); */

      if (ptr[3] == 'C') 
	*DboxSc = D_BOX_CUGA_SCORE;
      else 
	*DboxSc = D_BOX_AUGA_SCORE;
      
      /*      pos = ptr-start_ptr;
      printf ("D box at %d (%d downstream)\n",pos,pos-last_pos);
      last_pos = pos;
      */
      
      return 1;
    }
  
  return 0;
}

/* Not used */

int
FindPrev_DBox(char **seq_pos, char *seq_end)
    
{
  char *ptr;

  for (ptr=*seq_pos; ptr > seq_end; ptr--) 
    if ((ptr[0] == 'A') && (ptr[1] == 'G') &&
	(ptr[2] == 'U') && (ptr[3] == 'C')) {
      
      *seq_pos = ptr;

      return 1;
    }
  
  return 0;
}

/* Search for the best scoring D' box within the given range */

int
FindDPrimeBox(HIT_TYPE *Hit,
	      int search_start,
	      char *iseq, int q_idx,
	      float DPrimeCutoff)
    
{
  int i,j, end_idx;

  int best_i = 0;
  float
    score,
    best_score = -100;
  
  char *ptr;

  ptr = iseq + search_start - 1 + q_idx 
    - MAX_DPBOX_DIST - DBOX_LEN;

  for (i=0; i<= MAX_DPBOX_DIST;  i++) {
    score = 0;
    for (j=0; j< DBOX_LEN; j++) {
      score += Sc2_DpBox_Mat[(int)(ptr[i+j])][j];
    }      
    if (score > best_score) {
      best_score = score;
      best_i = i;
    }
  }

  if (best_score > DPrimeCutoff) {
    Hit->rDpBox_pos = best_i;
    Hit->DpBoxSc = best_score;
    return 1;
  }

  Hit->rDpBox_pos = -1;
  Hit->DpBoxSc = -100;
  return 0;
}


/* Score the rRNA-snoRNA complementary region based on matrix in
   matrices.h */

float 
ScoreCompl(HIT_TYPE *Hit)
{

  char *iseq, *idb;
  float max_score = 0.0;
  int max_compl_len = 0;
  float score = 0.0;
  
  int ct;
  int bound;    /* upper bound checking for complementarity */

  iseq = Hit->iq_comp;
  idb  = &(Hit->idbseq[Hit->db_start-1]);

  bound = MIN(Hit->match_len + 4,MAX_MATCH_LEN);
  
  IntEncodeSeq(iseq,Hit->q_comp,bound);
  
  Hit->FirstCompBpSc = Sc2_Compl_Mat[(int)(idb[0])][(int)(iseq[0])];
  
  for (ct=0; ct < bound; ct++) {
    score += Sc2_Compl_Mat[(int)(idb[ct])][(int)(iseq[ct])];
    
    if (score > max_score) {
      max_score = score;
      max_compl_len = ct+1;
    }
  }
  Hit->match_len = max_compl_len;

  return max_score;
}

/* Return non-zero if a traditional Watson-Crick pair is passed in the
   params */ 

int
WCpair (char bp1, char bp2)
{
  if (((bp1 == 'A') && (bp2 == 'U')) ||
      ((bp1 == 'C') && (bp2 == 'G')) ||
      ((bp1 == 'G') && (bp2 == 'C')) ||
      ((bp1 == 'U') && (bp2 == 'A')))
    return 1;
  else
    return 0;
}

/* Return non-zero if a G-U pair is passed in the params */

int
GUpair (char bp1, char bp2)
{
  if (((bp1 == 'G') && (bp2 == 'U')) ||
      ((bp1 == 'U') && (bp2 == 'G')))
    return 1;
  else
    return 0;
}

/* Return non-zero if an RNA-pair is passed in the params */

int
RNApair (char bp1, char bp2)
{
  if (((bp1 == 'A') && (bp2 == 'U')) ||
      ((bp1 == 'C') && (bp2 == 'G')) ||
      ((bp1 == 'G') && ((bp2 == 'C') || (bp2 == 'U'))) ||
      ((bp1 == 'U') && ((bp2 == 'A') || (bp2 == 'G'))))
    return 1;
  else
    return 0;
}

/* Count types of pairs found in rRNA-snoRNA paired region */

void
CountPairTypes(HIT_TYPE *Hit)
{
  int ct, gu_ct;
  char *db, *qry;

  Hit->WC_pairs = 0;
  Hit->GU_pairs = 0;
  Hit->Mis_pairs = 0;

  db = Hit->db_comp;
  qry = Hit->q_comp;

  for (ct=0; ct < (Hit->match_len); db++, qry++, ct++) {
    if (WCpair(*db,*qry)) {
      Hit->WC_pairs++;
      Hit->ComplMatchStr[ct] = '|';
    }

    else if (GUpair(*db,*qry)) {
      Hit->GU_pairs++;
      Hit->ComplMatchStr[ct] = ':';
    }    
    else {
      Hit->Mis_pairs++;
      Hit->ComplMatchStr[ct] = ' ';
    }    
  }
  Hit->ComplMatchStr[ct] = '\0';
  
}

/*
    Finds next match of min MinMatch bp between sequence being
    searched and db seq (e.g. rRNA)
*/

int
FindMatch (char *qseq, 
	   HIT_TYPE *Hit,
	   PARAM_TYPE *Params,
	   int *offset, int *db_idx, int *q_idx,
	   int qlen                    /* length of query seq to search */
	   )
{
  int i,j, offset_endpt, 
    match, gap,
    start_i, start_j,
    seed_vals=1,
    query_bound;

  int hitct, last_hit = 0;
  
  char *dbseq, *idbseq;
  
  dbseq = Hit->dbseq;
  idbseq= Hit->idbseq;
  
  query_bound = qlen - CBOX_LEN;

  offset_endpt = Hit->dblen + qlen -
    (2*(Params->MinMatch+Params->MaxGap));
  
  for (; *offset < offset_endpt; (*offset)++) {

    match=0;
    gap=0;
    
    if ((seed_vals) && (*db_idx >= 0)) {
      i= *db_idx;
      j= *q_idx;
    }
    else {
      i = MAX(0,*offset - qlen + Params->MinMatch + Params->MaxGap);
      j = MAX(0,qlen - Params->MinMatch - Params->MaxGap - *offset);
    }
    seed_vals=0;

    start_i = i;
    start_j = j;
    
    for (; ((i<Hit->dblen) && (j<query_bound)); i++, j++) { 
      
      switch (dbseq[i]) {
      case 'A': 
	if (qseq[j] == 'U') match++;  
	else gap++;  break;

      case 'C': 
	if (qseq[j] == 'G') match++;  
	else gap++;  break;

      case 'U': 
	if ((qseq[j] == 'A') || (qseq[j] == 'G'))  match++;
	else gap++;  break;
      case 'G': 
	if ((qseq[j] == 'C')  || (qseq[j] == 'U')) match++; 
	else gap++;  break;
	
      case '\0': printf("End of sequence!!! i=%d, j=%d\n",i,j); break;
      }

      if ((gap>1) && (!match)) {
	gap=0;
	start_i++;
	start_j++;
      }

      /*      if ((start_i == 1262) && (start_j == 61)) {
	printf("stop here 2\n\n");
      }
      */
      if ((gap > Params->MaxGap) ||
	  (match >= MAX_MATCH_LEN) ||
	  ((i+1) == Hit->dblen) || ((j+1) == query_bound)) {
	
	if (gap > Params->MaxGap) {
	  gap--;
	  i--;
	  j--;
	}
	  
	if (match >= Params->MinMatch) {
	  
	  Hit->match_len = match+gap;
	  Hit->db_start  = i - Hit->match_len + 2;
	  Hit->db_end    = i+1;

 	  Hit->db_comp = &(dbseq[start_i]);
	  Hit->q_comp  = &(qseq[start_j]);
	  
	  Hit->ComplSc = 20.0;
	  Hit->ComplSc = ScoreCompl(Hit); 

	  CountPairTypes(Hit);

	  if ((Hit->ComplSc >= Params->ComplCutoff) &&
	      ((Hit->GU_pairs+Hit->WC_pairs) >= Params->MinMatch)) {
	    
	    
	     *db_idx = ++start_i;
	     *q_idx  = ++start_j;
	     return 1;
	    
	     /*
	    hitct++;
	    printf("Hit at %d,\t%d downstr (%d bp)\t# %d hit\n",
		   j,j-last_hit,Hit->GU_pairs+Hit->WC_pairs,hitct);
	    last_hit = j;
	    start_i += Hit->match_len-1;
	    start_j += Hit->match_len-1;
	     */
	  }

	}
	match = 0;
	gap = 0;
	
	i = start_i++;
	j = start_j++;

      } /* if (gap > maxgap)  */
    }  /* for i and j */

  }   /* for offset */
  return 0;
}

/* Big MESSY function to save hits by converting coordinate systems,
   and grabbing substrings of features to save from searched seq --
   figure out at your own risk (but it does work!)  */

void
SaveHit(HIT_TYPE *Hit, int match_pos)

{ 
  char tmp_str[CBOX_LEN+TERM_SEQ_LEN];
  int bound3p, match_display_len;


  /* get C Box */

  strncpy(tmp_str, Hit->qseq + Hit->rCbox_pos, CBOX_LEN);
  tmp_str[CBOX_LEN] = '\0';
  ReverseSeq(Hit->Cbox_seq,tmp_str);

  /* get D Box */

  strncpy(tmp_str, Hit->qseq + Hit->rDbox_pos, DBOX_LEN);
  tmp_str[DBOX_LEN] = '\0';
  ReverseSeq(Hit->Dbox_seq,tmp_str);

  
  /* get 5' sequence to C Box to check for terminal stem */

  strncpy(Hit->Termseq_5p, Hit->qseq + Hit->rCbox_pos + CBOX_LEN+1, TERM_SEQ_LEN);
  Hit->Termseq_5p[TERM_SEQ_LEN] = '\0';

  /* get 3' sequence to D box to check for terminal stem */

  bound3p = Hit->rDbox_pos - TERM_SEQ_LEN;
   
  strncpy(tmp_str, Hit->qseq + MAX(0,bound3p), TERM_SEQ_LEN);
  tmp_str[TERM_SEQ_LEN+MIN(bound3p,0)] = '\0';
  Hit->Termseq_3p[TERM_SEQ_LEN] = '\0';

  ReverseSeq(Hit->Termseq_3p,tmp_str);
  

  /* get feature coordinates (lower strand) */

  Hit->match_start = match_pos + DBOX_LEN -2;
  Hit->match_end   = Hit->match_start + Hit->match_len-1; 
  
  Hit->Cbox_st     = Hit->rCbox_pos + CBOX_LEN -1;
  Hit->Cbox_end    = Hit->Cbox_st - CBOX_LEN +1;
  
  Hit->bound_start = MIN(Hit->qlen-1, Hit->Cbox_st + ESTIM_CBOX_TO_END);
  Hit->bound_end   = MAX(0, Hit->rDbox_pos - ESTIM_DBOX_TO_END);

  Hit->match_end_rel = abs(Hit->match_end - Hit->bound_start) + 1; 

  /* translate feature coordintates for hits on upper strand */

  if (Hit->strand == REV_WATSON) {

    Hit->match_start = Hit->qlen - Hit->match_start -1;
    Hit->match_end   = Hit->qlen - Hit->match_end -1;

    Hit->Cbox_st     = Hit->qlen - Hit->Cbox_st -1;
    Hit->Cbox_end    = Hit->qlen - Hit->Cbox_end -1;

    Hit->bound_start = Hit->qlen - Hit->bound_start -1;  
    Hit->bound_end   = Hit->qlen - Hit->bound_end -1;

  }

  Hit->sno_len = abs(Hit->bound_end - Hit->bound_start) + 1;

  /* save copy of entire snoRNA */

  if (Hit->strand == REV_WATSON) 
    strncpy(tmp_snoseq, Hit->qseq + (Hit->qlen - Hit->bound_start) - Hit->sno_len, Hit->sno_len);
  else 
    strncpy(tmp_snoseq, Hit->qseq + Hit->bound_start - Hit->sno_len+1, Hit->sno_len);
  
  
  tmp_snoseq[Hit->sno_len] = '\0';
  ReverseSeq(Hit->snoseq, tmp_snoseq);

  /* set max length of complementarity to display */

  match_display_len = MIN(MAX_MATCH_DISPLAY_LEN,Hit->match_len);
  
  /* save string copies of complementarity & D prime box in query */

  if (Hit->DpBox_present) {
    strncpy(Hit->qhit,
	    Hit->qseq + match_pos + Hit->rDpBox_pos -3,
	    match_display_len + DBOX_LEN + Hit->rDpBox_pos + 3);

    Hit->qhit[match_display_len + DBOX_LEN - Hit->rDpBox_pos + 1] = '\0';

    Hit->meth_pos = Hit->db_start + Hit->rDpBox_pos + 3;

    strncpy(tmp_str, Hit->qhit, DBOX_LEN);
    tmp_str[DBOX_LEN] = '\0';
    ReverseSeq(Hit->DpBox_seq,tmp_str);

  }

  /* save string copies of compl & D box in query */

  else {	      
    strncpy(Hit->qhit,
	    Hit->qseq + match_pos - Hit->DBox_hit_dist,
	    match_display_len+ DBOX_LEN + Hit->DBox_hit_dist+1);
    
    Hit->qhit[match_display_len+ DBOX_LEN + Hit->DBox_hit_dist-2] = '\0';
    
    Hit->meth_pos = Hit->db_start -Hit->DBox_hit_dist+1 + METH_DBOX_OFFSET; 

    Hit->DpBox_seq[0] = '\0';
  }

  /* save string copy of complementarity in rRNA sequence */

  strncpy(Hit->dbhit,
	  Hit->dbseq + Hit->db_start-1,
	  match_display_len);
  Hit->dbhit[match_display_len] = '\0';

  /* save pointers to non-feature sequence */

  Hit->nonfeat1_seqp = Hit->qseq + match_pos + Hit->match_len + 2;
  Hit->nonfeat1_len = MAX(0,Hit->rCbox_pos - (match_pos+Hit->match_len+2));

  if (Hit->DpBox_present) {
    
    Hit->nonfeat2_seqp = Hit->qseq + Hit->rDbox_pos + DBOX_LEN;
    Hit->nonfeat2_len = Hit->DBox_hit_dist - DBOX_LEN - 1
      - (MAX_DPBOX_DIST - Hit->rDpBox_pos);
  }
  
  else {
    Hit->nonfeat2_seqp = 0;
    Hit->nonfeat2_len = 0;
  }
  
}

/* Old Scoring scheme -- not used anymore 
   saved for comparison to old seaches results */

float ScoreCDgap (int CD_len) 
{
  float score = -100.0;
  
  if (CD_len >= 135) 
    score = -4.60;         /* ln(1/100) */
  else if (CD_len >= 100)   
    score = -3.50;         /* ln(1/33) */
  else if (CD_len >= 90)   
    score = -2.80;         /* ln(2/33) */
  else if (CD_len >= 80)   
    score = -1.10;         /* ln(11/33) */
  else if (CD_len >= 70)   
    score = -1.19;         /* ln(10/33) */
  else if (CD_len >= 60)   
    score = -1.55;         /* ln(7/33) */
  else if (CD_len >= 50)   
    score = -3.50;         /* ln(1/33) */
  else if (CD_len < 50)   
    score = -4.60;         /* ln(1/100) */
  
  return score;
}
 
/* Scores gaps between C, compl region, and D box based on observed
 * length distributions in known snoRNAs */

void ScoreFeatureGaps (HIT_TYPE *Hit) 
{
  int ct;

  if (Hit->DpBox_present) {
    
    for (ct=0;
	   ((Hit->nonfeat1_len > CBxComplDp_DistIdx_Mat[ct]) &&
	    (ct < CBOX_COMPLDp_MAT_SIZE)); 
	 ct++);
    Hit->CBxCompldistSc = CBxComplDp_DistSc_Mat[ct];
    

    for (ct=0;
	   ((Hit->nonfeat2_len > ComplDBx_DistIdx_Mat[ct]) &&
	    (ct < CBOX_COMPLDp_MAT_SIZE)); 
	   ct++);
    Hit->ComplDBxdistSc = ComplDBx_DistSc_Mat[ct];
    
  }
  else {
    for  (ct=0;
	  ((Hit->nonfeat1_len > CBxCompl_DistIdx_Mat[ct]) &&
	   (ct < CBOX_COMPL_MAT_SIZE)); 
	  ct++);	   
    Hit->CBxCompldistSc = CBxCompl_DistSc_Mat[ct];
    Hit->ComplDBxdistSc = 0.0;
  }
}

/* Puts a length distribution score on length of observed snoRNA-rRNA
   duplexes */

float ScoreGuideDuplexLen (HIT_TYPE *Hit) 
{
  int bin;

    for (bin=0;
	   ((Hit->match_len > GuideDuplexLenBins_Mat[bin]) &&
	    (bin < GUIDE_DUPLEX_LEN_MAT_SIZE)); 
	 bin++);
    
    return GuideDuplexLenSc_Mat[bin];
}

/* Not currently used -- 
   Scores nucleotide content of gaps between features 
*/

float
ScoreNonFeatureSeq (HIT_TYPE *Hit)
{
  int ct, 
    Act = 0, Cct = 0, Gct = 0, Uct = 0;
  float score = 0.0;
  char *seqp, *bound;
  
  bound = Hit->nonfeat1_seqp + Hit->nonfeat1_len; 
  for (seqp =  Hit->nonfeat1_seqp; seqp < bound; seqp++) {
    switch (*seqp) {
    case 'A': score +=  0.0739; Act++; break;
    case 'C': score += -0.0902; Cct++; break;
    case 'G': score += -0.205;  Gct++; break;
    case 'U': score +=  0.0859; Uct++; break;
    default:
      score += 0.0;
    }
  }

  if (Hit->DpBox_present) {
    bound = Hit->nonfeat2_seqp + Hit->nonfeat2_len; 
    for (seqp =  Hit->nonfeat2_seqp; seqp < bound; seqp++) {
      switch (*seqp) {
      case 'A': score +=  0.0739; Act++; break;
      case 'C': score += -0.0902; Cct++; break;
      case 'G': score += -0.2048; Gct++; break;
      case 'U': score +=  0.0859; Uct++; break;
      default:
	score += 0.0;
      }
    }
  }
  
  Hit->nonfeat_Act = Act;
  Hit->nonfeat_Cct = Cct;
  Hit->nonfeat_Gct = Gct;
  Hit->nonfeat_Uct = Uct;
  
  return score;
}

/* Scores the terminal stem, if present */

float
ScoreTermStem (HIT_TYPE *Hit)
{
  char 
    iseq_5p[TERM_SEQ_LEN+1], 
    iseq_3p[TERM_SEQ_LEN+1];

  int ct, len5p, len3p, 
    max_stem_len = 0;
  int offset, best_offset = 0, matches;
  
  float score, tscore = 0.0, 
    max_score = -100.0;

  
  len5p = strlen(Hit->Termseq_5p);
  len3p = strlen(Hit->Termseq_3p);

  IntEncodeSeq(iseq_5p,Hit->Termseq_5p,len5p);
  IntEncodeSeq(iseq_3p,Hit->Termseq_3p,len3p);
  
  for (offset=-1; offset <= 1; offset++) {
    
    matches = 0;
    score = 0.0;

    for (ct=0; ((ct+offset) < len5p) && (ct < len3p); ct++) {
      if (ct+offset < 0) ct++;
      tscore = TermStem_Mat[(int)(iseq_5p[ct+offset])][(int)(iseq_3p[ct])];
      if (RNApair(Hit->Termseq_5p[ct+offset],Hit->Termseq_3p[ct])) 
	matches++;
      if (matches || ((ct+offset) >2))   /* only start scoring on a match @start of stem */ 
	score += tscore;

      if (score > max_score) {
	max_score = score;
	best_offset = offset;
	max_stem_len = matches;
      }
    }
  }

  /* create "match string" for graphical output of stem matches */

  Hit->TermStemMatchStr[0] = ' ';
  for (ct=0; ((ct+best_offset) < len5p) && (ct < len3p); ct++) {
    if (ct+best_offset < 0) ct++;
    if (WCpair(Hit->Termseq_5p[ct+best_offset],Hit->Termseq_3p[ct]))
      Hit->TermStemMatchStr[ct+best_offset] = '|';
    else if (GUpair(Hit->Termseq_5p[ct+best_offset],Hit->Termseq_3p[ct]))
      Hit->TermStemMatchStr[ct+best_offset] = ':';
    else
      Hit->TermStemMatchStr[ct+best_offset] = ' ';
  }  
  Hit->TermStemMatchStr[ct+best_offset] = '\0';

  Hit->TermStemOffset = best_offset;
  Hit->TermStemBp = max_stem_len;
  
  return (max_score-STEM_PENALTY);

}

/* Scores if complementarity is overlapping D or D' box,
   0 bp away, or 1 bp away 
   Need to split between D or D' box guides since
   two different numbering schemes keep track of
this distance */

float
ScoreComplDboxGap (HIT_TYPE *Hit)
{
  float score;

  if (Hit->DpBox_present) {
    switch (Hit->rDpBox_pos) {
    case 0: score = -0.693; break;  /* 1 bp away   ln(23/46 total) */
    case 1: score = -1.190; break;  /* adjacent    ln(14/46) */
    case 2: score = -1.631; break;  /* 1 bp overlap ln(09/46) */
    default: score = -100;
    }
  }

  /* else compl is next to D box */

  else {
    switch (Hit->DBox_hit_dist) {
    case 3: score = -0.693; break;  /* 1 bp away */
    case 2: score = -1.190; break;  /* adjacent */
    case 1: score = -1.631; break;  /* 1 bp overlap */
    default: score = -100;
    }
  }      
  
  return score;
}

/* Main scoring routine for candidate snoRNAs 
 *  
 * Adds all the scores together (in nats), then converts total score 
 * to bits after sum */

void
ScoreHit (HIT_TYPE *Hit, int tot_dblen, int Old_dist_scoring)

{
  float     
    Dist_score = 0;

  if (Hit->DpBox_present) 
    Hit->DpboxTransitSc = -0.461;  /* ln(29/46) 29 of 46 sites guided by D'
			      boxes */ 
  else
    Hit->DpboxTransitSc = -0.995;   /* ln(17/46) 17 of 46 sites guided by D
			        box */
  
  Hit->GuideBoxGapSc = ScoreComplDboxGap(Hit);
  Hit->GuideDuplexLenSc = ScoreGuideDuplexLen(Hit);

  Hit->CDdistSc   = ScoreCDgap(Hit->CD_dist);
  ScoreFeatureGaps(Hit);

  if (Old_dist_scoring) 
    Dist_score = Hit->CDdistSc;
  else 
    Dist_score = Hit->CBxCompldistSc + Hit->ComplDBxdistSc;

  /* A stem is defined as giving a positive score by the ScoreTermStem function */ 
  /* Some snos have stems of 4 or 5 bp, but are not counted b/c their
     stems are weak and likely to be random  */

  Hit->TermStemSc = ScoreTermStem(Hit); 
  if (Hit->TermStemSc > 0) 
    Hit->TermTransitSc = -0.769;    /* ln(19/41) 19 of 41 Sc snos have stems */
  else
    Hit->TermTransitSc = -0.622;    /* ln(22/41) 22 of 41 Sc snos do not have stems */ 
  
  
  if (Hit->meth_site > -1) 
    Hit->MethSc = -5.10;    /* ln(54 mapped/55  * (1/3*54 start sites)) */ 
  else 
    Hit->MethSc = -12.54;   /* ln(1 unmapped/55 * (1/5100 start sites)) */
  
  Hit->TotSc = NAT_BIT_CONV *
    
    (Hit->ComplSc +
     Hit->GuideBoxGapSc +
     Hit->GuideDuplexLenSc +
     Hit->MethSc +

     Hit->CboxSc + 
     Hit->DBoxSc +
     Hit->DpboxTransitSc +     
     Hit->DpBoxSc +

     MAX(0,Hit->TermStemSc) +
     Hit->TermTransitSc +

     Dist_score);   
}


/* Runs through list of provided methyl sites to see if current hit
   matches any in list */
							    
void
Check_MethSites (HIT_TYPE *Hit,
		 METH_SITE_TYPE *meth_list,
		 int num_methsites,
		 int MaxMethDist)

{
  int ct, 
    best_site = -1,
    best_dist = 100;

  for (ct=0; ct<num_methsites; ct++) {
    if ((Hit->dbname == meth_list[ct].seqname) &&
	(Hit->dbseq[Hit->meth_pos-1] == meth_list[ct].mod_nuc) &&
	((abs(Hit->meth_pos-meth_list[ct].base_num)) <= MaxMethDist)) {
      if ((abs(Hit->meth_pos-meth_list[ct].base_num)) < best_dist) {
	best_site = ct;
	best_dist = abs(Hit->meth_pos-meth_list[ct].base_num);
      }
    }
  }

  Hit->meth_site = best_site;
}

/* Displayed when program starts up to record run params */

void
PrintRunParams (PARAM_TYPE *Params,
		FILE *outfp)
{
  fprintf(outfp,"\nSnoscan (v.%s) search results:\n",snoscan_version);
  fprintf(outfp,"==============================\n");
  fprintf(outfp,"Cutoffs (bits)\n");
  fprintf(outfp,
	  "C Box: %.2f\tD'Box: %.2f\tCompl score: %.1f\tFinal score: %.1f\n",
	  Params->CBoxCutoff*NAT_BIT_CONV,  Params->DPrimeCutoff*NAT_BIT_CONV,
	  Params->ComplCutoff*NAT_BIT_CONV, Params->FinalCutoff);

  fprintf(outfp,"Min Match: %d bp \t\tMax mismatch: %d bp\n",
	  Params->MinMatch, Params->MaxGap );
  fprintf(outfp,"Max C-D Box Dist: %d bp\tMin D box-Match Dist w/D' Box present: %d bp\n",
	  Params->MaxCDdist,Params->MinD_Dp_Boxdist);
  fprintf(outfp,"--------------------------------------------------------------------------------\n\n");
  

}


/* Outputing entire hit record for each snoRNA surpassing cutoff */

void
Output_Hit (HIT_TYPE *Hit, 
	    METH_SITE_TYPE *meth_list,
	    FILE *outfp)
{
  int strpos;

  float nonfeat_len;
  char tmpstr[FASTA_LINE_LEN+2];
  
  char meth_str[MAX_DB_MATCH] = 
    "                                                                           ";
  char padding[4] = "    ";
  char guidebox[6];


  if (Hit->DpBox_present)
    strcpy(guidebox,"DpBox");
  else 
    strcpy(guidebox,"D box");
    

  fprintf(outfp,">> %s  %.2f  (%d-%d)  Cmpl: %s-%cm%d ",
	  Hit->qname, Hit->TotSc, 
	  Hit->bound_start+1,  Hit->bound_end+1,
	  Hit->dbname, 	  
	  Hit->dbseq[Hit->meth_pos-1],Hit->meth_pos);

  if (Hit->meth_site >= 0) 
    fprintf(outfp,"(%s)  ",meth_list[Hit->meth_site].status);
  else 
    fprintf(outfp,"(-)  ");
    
  fprintf(outfp,"%d/%d bp  Gs-%s: %d (%d)  Len: %d  ",
  	  Hit->WC_pairs+Hit->GU_pairs, Hit->Mis_pairs, 
	  guidebox,
	  Hit->match_end+1, Hit->match_end_rel,  
	  Hit->sno_len);
  
  if (Hit->TermStemSc > 0.0)
    fprintf(outfp,"TS");
  
  fprintf(outfp,  "\n\nC Box:  %s   Sc: %.2f    (%d-%d)\t\t  C-D box dist: %d bp\n",
	  Hit->Cbox_seq,
	  Hit->CboxSc*NAT_BIT_CONV, Hit->Cbox_st+1,Hit->Cbox_end+1,
	  Hit->CD_dist);

  fprintf(outfp,  "D Box:  %s      Sc: %.2f    \n",
	  Hit->Dbox_seq,
	  Hit->DBoxSc*NAT_BIT_CONV);   /* Hit->Dbox_st,Hit->Dbox_st */
	  
  if (Hit->DpBox_present) {
    fprintf(outfp,"D'Box:  %s      Sc: %.2f    ",
	    Hit->DpBox_seq,Hit->DpBoxSc*NAT_BIT_CONV);  /* Hit->DpBox_st, Hit->DpBox_st */
    fprintf(outfp,"\t\tD'box Guide Transit Sc: %.2f\n\n",
	    Hit->DpboxTransitSc*NAT_BIT_CONV);
  }
  else {
    fprintf(outfp,"D'Box:  None");
    fprintf(outfp,"\t\t\t\tD box Guide Transit Sc: %.2f\n\n",
	    Hit->DpboxTransitSc*NAT_BIT_CONV);
  }
  
  if (Hit->meth_site >= 0) 
    fprintf(outfp,"Meth site found: %d (%s)  \t",
	    Hit->meth_pos, meth_list[Hit->meth_site].status);
  else
    fprintf(outfp,"No known meth site found  \t");
  
  fprintf(outfp,"Guide Seq Sc: %.2f  (%.2f %.2f %.2f %.2f)\n\n",	    
	  (Hit->ComplSc+ Hit->GuideDuplexLenSc+ Hit->MethSc+ Hit->GuideBoxGapSc)
	  *NAT_BIT_CONV, 
	  Hit->ComplSc*NAT_BIT_CONV, 
	  Hit->GuideDuplexLenSc*NAT_BIT_CONV,
	  Hit->MethSc*NAT_BIT_CONV, 
	  Hit->GuideBoxGapSc*NAT_BIT_CONV);

  /*
  nonfeat_len = (float) (Hit->nonfeat1_len + Hit->nonfeat2_len);
  
  fprintf(outfp,
	  "\nNon-feature freq score: %.2f  \tA: %.1f  U: %.1f  G: %.1f  C: %.1f\n\n",
	  Hit->NonFeatSc*NAT_BIT_CONV,
	  Hit->nonfeat_Act/nonfeat_len*100,
	  Hit->nonfeat_Uct/nonfeat_len*100,
	  Hit->nonfeat_Gct/nonfeat_len*100,
	  Hit->nonfeat_Cct/nonfeat_len*100);
  */  

  meth_str[43-MIN(Hit->match_len,MAX_MATCH_DISPLAY_LEN) + (Hit->meth_pos - Hit->db_start)] = '*';
  fprintf(outfp,"%s\n", meth_str);
 
  fprintf(outfp,"Db seq:  5'- %30s -3'  %8s\t(%d-%d)\n", 
	  Hit->dbhit, 
	  Hit->dbname, Hit->db_start, Hit->db_end);
  
  fprintf(outfp,"             %30s\n",Hit->ComplMatchStr);  

  fprintf(outfp,"Qry seq: 3'- %30s -5'  %8s\t(%d-%d)\n\n\n",
	  Hit->qhit,
	  Hit->qname, Hit->match_start+1, Hit->match_end+1);
  

  /*  fprintf(outfp,"----------------------------------------------------------------------------------------------\n");
   */

  if (Hit->DpBox_present) {
    fprintf(outfp,"C Box-> Guide Seq Gap Sc: %.2f (%d bp)   \t",
	    Hit->CBxCompldistSc*NAT_BIT_CONV, Hit->nonfeat1_len);
    fprintf(outfp,"Guide Seq-> D Box Gap Sc: %.2f (%d bp)\n\n",
	    Hit->ComplDBxdistSc*NAT_BIT_CONV, Hit->nonfeat2_len);
  }
  else 
    fprintf(outfp,"C Box-> Guide Seq Gap Sc: %.2f (%d bp)\n\n",
	    Hit->CBxCompldistSc*NAT_BIT_CONV, Hit->nonfeat1_len);
  
  if (Hit->TermStemSc > 3.0)
    fprintf(outfp,"Strong terminal stem:  \t  ");
  else if (Hit->TermStemSc > 0.0)
    fprintf(outfp,"Terminal stem:         \t  ");
  else if (Hit->TermStemBp > 2) 
    fprintf(outfp,"Possible terminal stem:\t  ");
  else 
    fprintf(outfp,"No terminal stem:      \t  ");

  padding[1-Hit->TermStemOffset] = '\0';

  fprintf(outfp,"+-[C Box] -N-%s%s - 5'  \t\tStem Sc: %.2f (%d bp)\n",padding,
	  Hit->Termseq_5p, 
	  Hit->TermStemSc*NAT_BIT_CONV,Hit->TermStemBp);
  
  
  fprintf(outfp,"\t\t\t  |%s            %s\n",padding,Hit->TermStemMatchStr);
  fprintf(outfp,"\t\t\t  +---[D Box] - %s - 3'  \t\tStem Transit Sc: %.2f\n\n\n",
	  Hit->Termseq_3p,Hit->TermTransitSc*NAT_BIT_CONV);


  if (Hit->DpBox_present) {

    fprintf(outfp,
	    ">Summary      [ C Box ] --         -- [ Cmpl/ Mism ]  X [D'Bx] --       -- [D Bx]  Length\n");
    fprintf(outfp,
	    ">Meth %cm%4d  [%s] --  %2d bp  -- [  %2d / %d    ] %2d [%s] -- %2d bp -- [%s]  %3d bp\n",
	    Hit->dbseq[Hit->meth_pos-1],Hit->meth_pos,
	    Hit->Cbox_seq, Hit->nonfeat1_len,
	    Hit->WC_pairs + Hit->GU_pairs, Hit->Mis_pairs, 1 - Hit->rDpBox_pos,
	    Hit->DpBox_seq, Hit->nonfeat2_len, Hit->Dbox_seq, 
	    Hit->sno_len);
    
    fprintf(outfp,
  	    ">Sc    %.2f  [ %5.2f ] --  %5.2f  -- [ %5.2f bits ]    [%.2f]    %5.2f    [%.2f]\n\n",
	    Hit->TotSc,
	    Hit->CboxSc*NAT_BIT_CONV, Hit->CBxCompldistSc*NAT_BIT_CONV,
	    Hit->ComplSc*NAT_BIT_CONV, Hit->DpBoxSc*NAT_BIT_CONV,
	    Hit->ComplDBxdistSc*NAT_BIT_CONV,Hit->DBoxSc*NAT_BIT_CONV); 
  }
  else {
    fprintf(outfp,
	    ">Summary      [ C Box ]        --          --           [ Cmpl/ Mism ]  X [D Bx]  Length\n");
    fprintf(outfp,
	    ">Meth %cm%4d  [%s]        --  %2d bp  --            [  %2d / %d    ] %2d [%s]  %3d bp\n",
	    Hit->dbseq[Hit->meth_pos-1],Hit->meth_pos,
	    Hit->Cbox_seq, Hit->nonfeat1_len,
	    Hit->WC_pairs + Hit->GU_pairs, Hit->Mis_pairs, Hit->DBox_hit_dist-2,
	    Hit->Dbox_seq, Hit->sno_len);
    
    fprintf(outfp,
     	     ">Sc    %.2f  [ %5.2f ]        --  %5.2f  --            [ %.2f bits ]    [%.2f]\n\n",
	    Hit->TotSc,
	    Hit->CboxSc*NAT_BIT_CONV, Hit->CBxCompldistSc*NAT_BIT_CONV,
	    Hit->ComplSc*NAT_BIT_CONV, Hit->DBoxSc*NAT_BIT_CONV); 
  }
   
  /* write snoRNA hit in FASTA format, preceded with "Seq: " line tag */
 
  if (OutputSeqs) {
    fprintf(outfp,"Seq: >%s  %.2f  (%d-%d)  Cmpl: %s-%cm%d  Len: %d\n",
	    Hit->qname, Hit->TotSc, 
	    Hit->bound_start+1,  Hit->bound_end+1,
	    Hit->dbname, 	  
	    Hit->dbseq[Hit->meth_pos-1],Hit->meth_pos, Hit->sno_len);
    
    for (strpos=0; strpos < Hit->sno_len; strpos+=FASTA_LINE_LEN) {
      strncpy(tmpstr, Hit->snoseq + strpos, FASTA_LINE_LEN);
      tmpstr[FASTA_LINE_LEN] = '\0';
      fprintf(outfp,"Seq: %s\n",tmpstr);
    }
    fprintf(outfp,"\n");
  }
  
  
  fprintf(outfp,"====================================================================================================\n\n");
  fflush(outfp);

  
}

/* Reverse complement sequence */

char *
RevComp(char *comp, char *seq)
{
  long  bases;
  char *bckp, *fwdp;
  int   idx;
  long  pos;
  int   c;

  if (comp == NULL) return NULL;
  if (seq == NULL)  return NULL;
  bases = strlen(seq);

  fwdp = comp;
  bckp = seq + bases -1;
  for (pos = 0; pos < bases; pos++, fwdp++, bckp--)
    switch (*bckp) {
    case 'A':  *fwdp = 'U'; break;
    case 'U':  *fwdp = 'A'; break;
    case 'C':  *fwdp = 'G'; break;
    case 'G':  *fwdp = 'C'; break;
    default: 
      /*    Warn("Can't reverse complement an %c, pal. Using N.",
       *bckp);   */
      *fwdp = 'N';
    }
  
  *fwdp = '\0';
  return comp;
}

/* Reverse seqeuence, don't complement */

char *
ReverseSeq(char *revseq, char *seq)
{
  long  bases;
  char *bckp, *fwdp;
  int   idx;
  long  pos;
  int   c;

  if (revseq == NULL) return NULL;
  if (seq == NULL)  return NULL;
  bases = strlen(seq);

  fwdp = revseq;
  bckp = seq + bases -1;
  for (pos = 0; pos < bases; pos++, fwdp++, bckp--)
    *fwdp = *bckp;
  *fwdp = '\0';
  return revseq;
}

/* Encode the sequence to allow easy scoring with matrices */  

int
IntEncodeSeq (char *intseq, char *seq, int seqlen)
{
  int i;
  
  for (i=0; i<seqlen; i++) {
    switch (seq[i]) {
    case 'A': intseq[i]=0; break;
    case 'C': intseq[i]=1; break;
    case 'G': intseq[i]=2; break;
    case 'U': case 'T': intseq[i]=3; break;
    default:
      intseq[i]= 4;      
    }
  }
  return 0;
}

/* main snoRNA search algorithm is here */

void
FindSnos_CD_first(HIT_TYPE *Hit, 
		  SQINFO *sqinfo,
		  PARAM_TYPE *Params,
		  STATS_TYPE *Stats,
		  METH_SITE_TYPE meth_list[],
		  int num_methsites,
		  char *iseq,
		  FILE *outfp)
		  
		  
{
  char  
    *seq_pos,             /* current position in query seq */
    *seq_end,             /* endpoint for a pattern search */
    *cur_dbseq,           /* dbseq being searched for homology */
    *iseq_pos,            /* start for encoded seq pattern search */
    *iseq_end;            /* endpoint for encoded seq pattern
			     search */
  int
    db_idx, q_idx;        /* seq index positions of homology search */

  int
    match, 
    gap, 
    offset;               /* qseq & dbseq offset in bp */
  
  int
    dbseqct;              /* counter for current db seq */
  
  /* set bounds for Dbox search */
      	
  seq_pos = Hit->qseq;
  seq_end = Hit->qseq + sqinfo->len - DBOX_LEN - 30;

  while (FindNext_DBox(&seq_pos,seq_end,&(Hit->DBoxSc))) {

    Hit->rDbox_pos = seq_pos - Hit->qseq;

	/* set bounds for C box search */

	iseq_pos = iseq + Hit->rDbox_pos + DBOX_LEN + MIN_CD_DIST;
	iseq_end = iseq + MIN(Hit->rDbox_pos + DBOX_LEN + Params->MaxCDdist, 
			      sqinfo->len - CBOX_LEN + 1);
	
	if (FindCBox(&iseq_pos, iseq_end, &(Hit->CboxSc), Params->CBoxCutoff)) 
	  {
	    Hit->rCbox_pos = iseq_pos - iseq;
	    Hit->CD_dist = Hit->rCbox_pos - Hit->rDbox_pos - DBOX_LEN;
	    Stats->basect += Hit->CD_dist;
	    Stats->Cbox_ct++;

	    /* search each db seq for matches to current query seq */
	    
	    for (dbseqct=0; dbseqct < Stats->numdbseqs; dbseqct++) {

	      Hit->dbname = (dbseqinfo[dbseqct]).name;
	      Hit->dblen = (dbseqinfo[dbseqct]).len;
	      Hit->dbseq = dbseqs[dbseqct];

	      Hit->idbseq = idbseqs[dbseqct];

	      seq_pos = Hit->qseq + Hit->rDbox_pos + DBOX_LEN - 1;
	      offset = 0;
	      db_idx = q_idx = -1;

	      while (FindMatch(seq_pos,Hit,Params,
			       &offset,&db_idx,&q_idx,
			       Hit->CD_dist+2)) 
		{
		  Hit->DBox_hit_dist = q_idx;

		  Hit->rDpBox_pos = -1;   /* init Dprime box stats */
		  Hit->DpBoxSc = 0;
		  Hit->DpBox_present = 0;

		  if (Hit->DBox_hit_dist > Params->MinD_Dp_Boxdist) 

		    Hit->DpBox_present = 
		      FindDPrimeBox(Hit,Hit->rDbox_pos+DBOX_LEN,
				    iseq,q_idx,Params->DPrimeCutoff);		  
		  
		  /* check for correct posit of match relative to D box */

		  if ((Hit->DBox_hit_dist <=3) || (Hit->DpBox_present)) {
		    
		    SaveHit(Hit, q_idx+Hit->rDbox_pos);
		    Check_MethSites(Hit,meth_list,num_methsites,
				    Params->MaxMethDist);
		    ScoreHit(Hit,Stats->tot_dblen,
			     Params->Old_dist_scoring);
		    
		    if (Hit->TotSc >= Params->FinalCutoff) {
		      Output_Hit(Hit, meth_list, outfp);  
		    }
		  }
		  
		}
	      
	    }  /* search each DB seq for matches */

	  }   /* if CBox is found */
	       
	seq_pos = Hit->qseq + Hit->rDbox_pos + 1;

      }   /* search for next D box */      
}  

/* not fully implemented so not used */

void
FindSnos_match_first(HIT_TYPE *Hit,
		     SQINFO *sqinfo,
		     PARAM_TYPE *Params,
		     STATS_TYPE *Stats,
		     METH_SITE_TYPE meth_list[],
		     int num_methsites,
		     char *iseq,
		     FILE *outfp)
     
{
  char
    *seq_pos,             /* current position in query seq */
    *seq_end,             /* endpoint for a pattern search */
    *cur_dbseq,           /* dbseq being searched for homology */
    *iseq_pos,            /* start for encoded seq pattern search */
    *iseq_end;            /* endpoint for encoded seq pattern
			     search */
  int
    db_idx, q_idx;        /* seq index positions of homology search */

  int
    match, 
    gap, 
    offset;               /* qseq & dbseq offset in bp */
  
  int
    dbseqct;              /* counter for current db seq */
  
  /* search each db seq for matches to current query seq */
	    
  for (dbseqct=0; dbseqct < Stats->numdbseqs; dbseqct++) {

    Hit->dbname = (dbseqinfo[dbseqct]).name;
    Hit->dblen = (dbseqinfo[dbseqct]).len;
    Hit->dbseq = dbseqs[dbseqct];

    offset = 0;
    db_idx = q_idx = -1;
    
    while (FindMatch(Hit->qseq,Hit,Params,
		     &offset,&db_idx,&q_idx,
		     Hit->qlen - MIN_CD_DIST)) 
      {
	if (FindDPrimeBox(Hit,0,iseq,q_idx,Params->DPrimeCutoff)) {		  
	
	  Hit->DBox_hit_dist = MAX_DPBOX_DIST - Hit->rDpBox_pos+1;

	  /* set bounds for C box search */
	  
	  iseq_pos = iseq + q_idx;
	  iseq_end = iseq + MIN(Params->MaxCDdist, sqinfo->len - CBOX_LEN + 1);

	  if (FindCBox(&iseq_pos, iseq_end, &(Hit->CboxSc), Params->CBoxCutoff)) 
	    {
	      Hit->rCbox_pos = iseq_pos - iseq;
	      Hit->CD_dist = Hit->rCbox_pos - q_idx + Hit->match_len +1;

	      if ((Hit->DpBoxSc > -0.70) && (Hit->CD_dist > 40)) {
		Hit->rDbox_pos = q_idx - Hit->match_len - Hit->DBox_hit_dist +1 ;
		Hit->rDpBox_pos = -1;
		Hit->DpBoxSc = 0;
	      }
	      else {
		Hit->rDpBox_pos = Hit->rDpBox_pos-1;
		seq_pos = Hit->qseq + q_idx - Hit->match_len - DBOX_LEN;
		if (FindPrev_DBox(&seq_pos,Hit->qseq)) {
		  Hit->rDbox_pos = seq_pos - Hit->qseq;
		}
		else 
		  Hit->rDbox_pos = Hit->qlen-DBOX_LEN;
	      }
	      Hit->CD_dist = Hit->rCbox_pos - Hit->rDbox_pos;
	      
	      SaveHit(Hit, q_idx+1);
	      Check_MethSites(Hit,meth_list,num_methsites,
			      Params->MaxMethDist);
	      ScoreHit(Hit,Stats->tot_dblen,Params->Old_dist_scoring);
      
	      if (Hit->TotSc >= Params->FinalCutoff) {
		Output_Hit(Hit, meth_list, outfp);
	      }
	  
	  }   /* if CBox is found */

	}  /* if a D or D prime box is found  */
      }  /* while matches are found */

  }  /* search each DB seq for matches */
}


