/* SQUID - A C function library for biological sequence analysis
 * Copyright (C) 1992-1996 Sean R. Eddy	
 *
 *    This source code is distributed under terms of the
 *    GNU General Public License. See the files COPYING 
 *    and GNULICENSE for further details.
 *
 */

/* sre_string.c
 * 
 * my library of extra string functions. Some for portability
 * across UNIXes
 */

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "squid.h"


#ifdef MEMDEBUG
#include "dbmalloc.h"
#endif


/* Obsolete. Anyone who doesn't have strstr() is
 * not ANSI-compliant and must die.
 */
#ifdef NOSTR
char  *strstr(char *s, char *subs)
{
  int  i;

  for ( ; *s != 0; s++) {
    if (*s == *subs) {
      for (i = 1; subs[i] != 0 && subs[i] == s[i]; i++) ;
      if (subs[i] == 0) return(s);
      }
    }
  return (NULL);
}
#endif /* NOSTR */


char *
Strdup(char *s)
{
  char *new;
  if ((new = (char *) malloc (strlen(s) +1)) == NULL) return NULL;
  strcpy(new, s);
  return new;
}

int
Strinsert(char  *s1,            /* string to insert a char into  */
	  char   c,		/* char to insert                */
	  int    pos)		/* position in s1 to insert c at */
{
  char    oldc;
  char   *s;

  for (s = s1 + pos; c; s++)
    {
				/* swap current char for inserted one */
      oldc = *s;		/* pick up current */
      *s   = c;   		/* put down inserted one    */
      c    = oldc;		/* old becomes next to insert */
    }
  *s = '\0';

  return 1;
}


int
Strdelete(char *s1,             /* string to delete a char from       */
	  int   pos)		/* position of char to delete 0..n-1  */
{
  char *s;                      

  for (s = s1 + pos; *s; s++)
    *s = *(s + 1);

  return 1;
}

void
s2lower(char *s)
{
  for (; *s != '\0'; s++)
    *s = sre_tolower((int) *s);
}

void
s2upper(char *s)
{
  for (; *s != '\0'; s++)
    *s = sre_toupper((int) *s);
}


void *
MallocOrDie(size_t size)
{
  void *ptr;
  if ((ptr = malloc (size)) == NULL)
    Die("malloc failed");
  return ptr;
}

void *
ReallocOrDie(void *p, size_t size)
{
  void *ptr;
  if ((ptr = realloc(p, size)) == NULL)
    Die("realloc failed");
  return ptr;
}




/* Function: StrShuffle()
 * 
 * Purpose:  Returns a shuffled version of s2, in s1.
 *  
 * Args:     s1 - allocated space for shuffled string.
 *           s2 - string to shuffle.
 *           
 * Return:   void
 */
void
StrShuffle(char *s1, char *s2)
{
  int  len;
  int  pos;
  char c;
  
  strcpy(s1, s2);
  for (len = strlen(s1); len > 1; len--)
    {				
      pos       = CHOOSE(len);
      c         = s1[pos];
      s1[pos]   = s1[len-1];
      s1[len-1] = c;
    }
}
  
