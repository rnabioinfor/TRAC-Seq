#! /usr/local/bin/perl

# Usage: pir2gsi.pl [pir1.dat] [pir2.dat] [pir3.dat] [pir4.dat]
#
# Index a directory of PIR .dat files.
# Indexes both by entry name and accession number.
#
# Part of the SQUID sequence analysis library.
# Copyright (C) 1992-1996 Sean R. Eddy

$gsifile  = "pir.gsi";
$flatfile = "pir.tmp";

# Library of Perl functions for creating GSI index files.
#
# GSI definition: 
#    1 + <nfiles> + <nkeys> total records.
#    Each record = 38 bytes.
#
#  one header record     :  <"GSI"    (32)> <nfiles (2)> <nkeys (4)> 
#  <nfiles> file records :  <filename (32)> <fileno (2)> <fmt   (4)> 
#  <nkeys>  key records  :  <key      (32)> <fileno (2)> <offset(4)> 
#
# Part of the SQUID sequence analysis library.
# Copyright (C) 1992-1996 Sean R. Eddy


# The following numbers MUST match their counterparts in squid.h
#
$sqd_fmt_genbank = 2;
$sqd_fmt_embl    = 4;
$sqd_fmt_fasta   = 7;
$sqd_fmt_pir     = 12;
 
# Function: GSI_WriteHeader(GSIFILE, $filenum, $keynum)
# 
# Write the header of an open GSI file.
#
sub GSI_WriteHeader {
    local(*GSIFILE, $filenum, $keynum) = @_;
    local($header); 
    $header = pack("a32 n N", "GSI", $filenum, $keynum);
    print GSIFILE $header;
    1;
}

# Function: GSI_WriteFileRecord(GSIFILE, $filename, $idx, $fmt)
#
# Write a file record to an open GSI file.
#
sub GSI_WriteFileRecord {
    local(*GSIFILE, $filename, $idx, $fmt) = @_;
    local($record);
    $record = pack("a32 n N", $filename, $idx, $fmt);
    print GSIFILE $record;
    1;
}
    
# Function: GSI_WriteKeyRecord(GSIFILE, $key, $filenum, $offset)
#
# Write a key record to an open GSI file.
#
sub GSI_WriteKeyRecord {
    local(*GSIFILE, $key, $filenum, $offset) = @_;
    local($record);
    $record = pack("a32 n N", $key, $filenum, $offset);
    print GSIFILE $record;
    1;
}



 

# For each sequence file, created an intermediate file 
# in flat text, containing <key> <filenum> <offset>
#
$filenum = 0;
$recnum  = 0;
$curr_offset = 0;
while ($file = shift(ARGV))
{
    open(SEQFILE,$file) || die;
    $filenum++;
    print "Processing file $file ($filenum)...\n";

    $outfile = $file.".tmp";
    open(OUTFILE,">$outfile");

    $seqfile[$filenum] = $file;
    $tmpfile[$filenum] = $outfile;
    while (<SEQFILE>)
    {
	if (($key) = /^ENTRY\s+(\S+)/)
	{
	    print OUTFILE "$key $filenum $curr_offset\n";
	    $last_offset   = $curr_offset;
	    $recnum++;
	}
	elsif (/^ACCESSIONS/)
	{			# may be multiple accessions per record
	    @fields = split(' '); shift @fields;
	    while ($acc = shift(@fields)) {
		$acc =~ s/;//;
		print OUTFILE "$acc $filenum $last_offset\n";
	    }
	    $recnum++;
	}
	$curr_offset = tell;
    }
    close(SEQFILE);
    close(OUTFILE);
				# Sort the intermediate file in place,
				# alphabetically on key name.
    print "   Sorting...\n";
    system("sort -o $outfile $outfile");
}

				# Merge sort the intermediate files.
print "Sorting and merging intermediate files...\n";
$filelist = join(' ',@tmpfile);
system("sort -m $filelist > $flatfile");
system("rm $filelist");

				# Compress the final sorted flat file
				# into binary GSI format
open(GSIFILE,">$gsifile");

print("Printing GSI header...\n");
&GSI_WriteHeader(GSIFILE, $filenum, $recnum);

print("Printing file header...\n");
for ($i = 1; $i <= $filenum; $i++)
{
    &GSI_WriteFileRecord(GSIFILE, $seqfile[$i], $i, $sqd_fmt_pir);
}

print("Compressing records to binary...\n");
open(FLATFILE,$flatfile);
while (<FLATFILE>)
{
    ($key, $i, $offset) = split;
    &GSI_WriteKeyRecord(GSIFILE, $key, $i, $offset);
}			
close(FLATFILE);
close(GSIFILE);
unlink $flatfile;
 
print "Index file for $filenum files, $recnum records written to $gsifile\n";
