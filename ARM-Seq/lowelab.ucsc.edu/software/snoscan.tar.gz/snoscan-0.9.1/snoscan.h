
/* snoscan  - methylation guide snoRNA search program
 *
 * by Todd MJ Lowe    v. 0.1       12/08/96
 *                    v. 0.9 beta  02/19/99
 *                    v. 0.9.1     04/26/17 - updates squid library (SRE)
 * 
 * copyright 1999 by T. Lowe
 *
 *  snoscan.h   (data structures and constants)
 *
 */

#include <math.h>

extern char snoscan_version[];
extern char snoscan_date[];

extern int OutputSeqs;

#define MAX_LINE 240          /* Max size of line in meth sites data
 				 file */
#define NAT_BIT_CONV 1.443
#define BIT_NAT_CONV 0.693

#define MAX_METH_SITES 120    /* max no. meth sites read from
				 methylation site data file */
#define DEF_MAX_METH_DIST 0     /* min distance to known meth site to
				 report as a match to it */
#define METH_DBOX_OFFSET 5    /* bp of meth site from end of D or D'
				 box */

#define MAX_SNO_LEN  500      /* Max length of snoRNA */
#define FASTA_LINE_LEN 60     /* Length of each line of sequence
				 output in FASTA format */

#define MAX_DB_MATCH 90     /* Max size of exact snoRNA-rRNA match */  
#define MAX_MATCH_LEN MAX_DB_MATCH-10
#define MAX_MATCH_DISPLAY_LEN 25

#define MAX_DBSEQS 100        /* Max no. entries in rRNA db file */

/* All scores are in Nats (natural logs) units, unless otherwise
   indicated */

#define DBOX_LEN 4
#define CBOX_LEN 7
#define TERM_SEQ_LEN 8
#define MIN_STEM_LEN 4
#define STEM_PENALTY 2.20    /* 3 start sites * 3 offsets = ln(9) 
				subtract from total terminal stem score */


#define DEF_MIN_MATCH 9                       /* Min snoRNA-rRNA match */
#define DEF_MIN_COMPL_SCORE BIT_NAT_CONV*8.0  /* Min snoRNA-rRNA score */
#define DEF_MAXGAP 2


#define CBOX_CUTOFF 3.0           /* 4.3 min score Gm1570   relax 2.0 */
#define DPRIME_BOX_CUTOFF -10.00   /* -0.652 min score for Gm2790 */  
#define FINAL_SCORE_CUTOFF 14.00   /* total bit score cutoff for reporting
				      snoRNA hit */

#define DEF_MAX_CD_DIST 178      /* 90 relax 200 max dist C box upstream of D box */
#define MIN_CD_DIST 35           /* 35 relax  20 min dist C box upstream of D box */ 
#define MIN_MATCH_DPBOX_DIST 10  /* Min distance between compl & D Box
				    if D box not immediately adjacent */

#define MAX_DPBOX_DIST 2      /* 2  max bp D prime box found upstream of
				 snoRNA-rRNA match */

#define ESTIM_CBOX_TO_END 4   /* estimated distance between C box and
				 5' end of snoRNA */
#define ESTIM_DBOX_TO_END 2   /* estimated dist between D box and end
				 of snoRNA */

 
/* strand orientations */

/*  original strand 5'->3' */
#define WATSON 1
/* top (original) strand 3'->5' */
#define REV_WATSON -1
/*  bottom strand 5'->3' */
#define CRICK 2
/*bottom strand 3'->5')  */
#define REV_CRICK -2


struct Hit_info_s {
  int bound_start, bound_end,   /* predicted bounds of snoRNA */

    match_start, match_end,     /* query seq bounds for rRNA match */
    match_end_rel,              /* query seq match end, relative to i=0 at
				   start of snoRNA */
    db_start, db_end,           /* dbseq bounds for query seq match */

    match_len, sno_len,
    GU_pairs, WC_pairs, Mis_pairs,

    strand,

    Cbox_st, Cbox_end, 
    rCbox_pos,

    rDpBox_pos,   /* relative start of D-prime box */
    rDbox_pos,    /* relative start of Dbox */
    
    DpBox_present,   /* boolean -> is D prime box present? */

    Dbox_st, DpBox_st,  /* absolute/true base positions of D box and D
			   prime box */

    CD_dist,         /* distance between C and D boxes */
    DBox_hit_dist;   /* distance between D box and rRNA match */


  int TermStemBp,    /* bp in terminal stem */
    TermStemOffset;  /* offset between 5' and 3' ends for stem pairs */			

  float CboxSc,    /* log odds scores for C and D-prime boxes */
    DBoxSc,
    DpBoxSc,
    ComplSc,
    FirstCompBpSc,   /* Score of first bp in rRNA-snoRNA compl duplex */
    GuideBoxGapSc,   /* Score for -1, 0, or 1 bp gap between guide
			D or D' box and rRNA compl region */
    DpboxTransitSc,
    CDdistSc,      
    CBxCompldistSc,
    ComplDBxdistSc,
    MethSc,
    GuideDuplexLenSc,
    NonFeatSc,
    TermStemSc,
    TermTransitSc,
    TotSc;     /* total score for snoRNA */

  int meth_pos;          /* predicted methylated nucleotide */
  int meth_site;         /* index number of matching meth site */

  char *qseq,  *dbseq;    /* pointers to current seqs */
  char *iqseq, *idbseq;   /* pointers to integer-encoded current seqs */
  char *db_comp;          /* db seq pointer to complementarity with query*/
  char *q_comp;           /* query seq pointer to complementarity with
			     rRNA */

  char *nonfeat1_seqp;     /* pointer to non-feature seq, region 1 */
  int   nonfeat1_len;      /* length of non-feature seq, region 1 */

  char *nonfeat2_seqp;     /* pointer to non-feature seq, region 2 */
  int   nonfeat2_len;      /* length of non-feature seq, region 2 */

  int nonfeat_Act, 
    nonfeat_Cct,
    nonfeat_Gct,
    nonfeat_Uct;

  char *qname, *dbname;   /* names of current seqs */
  int   qlen,   dblen;    /* lengths of current seqs */

  /* string copies of snoRNA and snoRNA features */

  char snoseq[MAX_SNO_LEN],
    dbhit[MAX_DB_MATCH],   /* complementary region in DB seq */ 
    qhit[MAX_DB_MATCH],    /* complementary region in query seq */
    ComplMatchStr[MAX_DB_MATCH], 
    Cbox_seq[CBOX_LEN+1],
    Dbox_seq[DBOX_LEN+1],
    DpBox_seq[DBOX_LEN+1],
    Termseq_5p[TERM_SEQ_LEN+1],
    Termseq_3p[TERM_SEQ_LEN+1],
    TermStemMatchStr[TERM_SEQ_LEN+1];

  char iq_comp[MAX_DB_MATCH];  /* space for integer-encoded hit in query seq */
  
};

typedef struct Hit_info_s HIT_TYPE;

struct Params_s {

  float CBoxCutoff, 
    DPrimeCutoff,
    ComplCutoff,
    FinalCutoff;

  int MaxGap, 
    MinMatch,
    MaxCDdist,
    MinD_Dp_Boxdist,
    MaxMethDist;             /* Max nuc dist to nearest known meth
				site */

  int Old_dist_scoring;     /* use original C-D distance scoring */
};

typedef struct Params_s PARAM_TYPE;

struct Stats_s {

  int Cbox_ct,          /* total number of C-D Box hits */
    basect,             /* total bases searched for rRNA homology */
    numdbseqs,          /* db seqs searched for homology */
    tot_dblen;
};  

typedef struct Stats_s STATS_TYPE;

struct Meth_site_s {
  char *seqname;
  int base_num;
  char mod_nuc;
  char status[20];
};

typedef struct Meth_site_s METH_SITE_TYPE;

extern char *dbseqs[MAX_DBSEQS];       /* array of pointers to all "database"
					  sequences */
extern char *idbseqs[MAX_DBSEQS];      /* array of pointers to all
					  integer-encoded db seqs */
extern SQINFO dbseqinfo[MAX_DBSEQS];

extern int Old_dist_scoring;

extern int
ReadMethData (FILE *methfp,
	      METH_SITE_TYPE meth_sites[],
	      int *num_methsites,
	      SQINFO *dbseqinfo,
	      int numdbseqs);

extern int
FindCBox (char **seq_pos, 
	  char *seq_end,
	  float *score, 
	  float CBoxCutoff);

extern int
FindNext_DBox(char **seq_pos, char *seq_end, float *DboxSc);

extern int
FindPrev_DBox(char **seq_pos, char *seq_end);

extern int
FindDPrimeBox(HIT_TYPE *Hit, 
	      int search_start,
	      char *iseq, int q_idx,
	      float DPrimeCutoff);

extern int
FindMatch (char *qseq, 
	   HIT_TYPE *Hit,
	   PARAM_TYPE *Params,
	   int *offset, int *db_idx, int *q_idx,
	   int qlen);

extern void
SaveHit(HIT_TYPE *Hit, int match_pos);

extern void
ScoreHit (HIT_TYPE *Hit, int tot_dblen, int Old_dist_scoring);

extern void
ClearHit (HIT_TYPE *Hit);

extern void
Check_MethSites (HIT_TYPE *Hit,
		 METH_SITE_TYPE *meth_list,
		 int num_methsites,
		 int MaxMethDist);

extern void
PrintRunParams (PARAM_TYPE *Params,
		FILE *outfp);


extern void
Output_Hit (HIT_TYPE *Hit, 
	    METH_SITE_TYPE *meth_list,
	    FILE *outfp);

extern char *
RevComp(char *comp, char *seq);

extern char *
ReverseSeq(char *revseq, char *seq);

extern int
IntEncodeSeq (char *intseq, char *seq, int seqlen);


extern void
FindSnos_CD_first(HIT_TYPE *Hit, 
		  SQINFO *sqinfo,
		  PARAM_TYPE *Params,
		  STATS_TYPE *Stats,
		  METH_SITE_TYPE meth_list[],
		  int num_methsites,
		  char *iseq,
		  FILE *outfp);


extern void
FindSnos_match_first(HIT_TYPE *Hit,
		     SQINFO *sqinfo,
		     PARAM_TYPE *Params,
		     STATS_TYPE *Stats,
		     METH_SITE_TYPE meth_list[],
		     int num_methsites,
		     char *iseq,
		     FILE *outfp);
     
